-- ModuleScript: ReplicatedStorage > Shared > TarotConfig     (NEW)
-- THE TAROT. Everything the cards SAY lives here (the server, ServerScriptService > TarotServer, does what they do;
-- StarterPlayerScripts > TarotClient draws them). Change words and numbers here.
--
--   THE DRAW (free, optional, once a round): during the lobby countdown you can draw ONE card. Upright = its
--     small buff for the round, reversed (upside down) = its small debuff instead. Not drawing is fine.
--   GHOST FLIP: once you're knocked out you get ONE face-down card to flip (2 with Death upright, none with Death
--     reversed). It does a random minor thing to the arena. One flip in the whole server every few seconds.
--   YOUR READING: when the round ends, everybody who played is dealt a card for HOW they played (Readings below).
--     22 cards x 2 ways up = 44 to collect, saved forever (the data key TarotDeck). Never a power: a collection.
--   THE FORTUNE TELLER: a lobby NPC (Workspace > Map > NPCS > FortuneTellerNPC) gives a free reading once a day:
--     a card, a fortune, a few candles and Game Tickets. Never bought, never wagered.
-- Card art: put an uploaded image id in a card's Art ("rbxassetid://..." or the number) and it shows on the card.
-- Until then the card is drawn with its numeral and name.

local TarotConfig = {}

TarotConfig.DrawEnabled = true
TarotConfig.FortuneTellerName = "The Fortune Teller"   -- [OPEN] the dev hasn't named her yet (ideas: Madame Vesper, Madame Marrow)
TarotConfig.FortuneCandles = 10                       -- the daily gift...
TarotConfig.FortuneTickets = 5                        -- ...and Game Tickets with it (a second visit the same day: her card again, no gift)
TarotConfig.FlipCooldown = 4                          -- seconds between ghost flips (the whole server)
TarotConfig.FlipsPerGhost = 1

-- Damage sources that count as "from the dark" (The Sun / The Moon). Any of these words in the source's name.
TarotConfig.DarkWords = { "Last Light", "Dark", "Eclipse", "Shadow", "Night", "Moon", "Blackout", "Lights Out", "Werewolf" }

-- The 22 cards, in order. Weight = how often it's drawn (1 = normal). Upright / Reversed = what it does when DRAWN.
-- Color = the card's trim. Art = your uploaded picture ("" = drawn with its numeral).
TarotConfig.Cards = {
	{ Id = "fool", Numeral = "0", Name = "The Fool", Weight = 0.8, Color = Color3.fromRGB(196, 170, 96), Art = "",
		Upright = "The first time you fall off the edge, the void spits you back onto a plate... with half your health.",
		Reversed = "Clumsy: the first time you get hit, you trip and fall flat." },
	{ Id = "magician", Numeral = "I", Name = "The Magician", Weight = 1, Color = Color3.fromRGB(176, 72, 60), Art = "",
		Upright = "The first item you pick up brings a second one with it.",
		Reversed = "The first item you pick up crumbles to dust." },
	{ Id = "priestess", Numeral = "II", Name = "The High Priestess", Weight = 1, Color = Color3.fromRGB(110, 120, 170), Art = "",
		Upright = "Sixth Sense: you see which plate an event is about to go after.",
		Reversed = "A lying card: now and then you get a warning that isn't true." },
	{ Id = "empress", Numeral = "III", Name = "The Empress", Weight = 1, Color = Color3.fromRGB(120, 150, 90), Art = "",
		Upright = "+15 max health.",
		Reversed = "-15 max health." },
	{ Id = "emperor", Numeral = "IV", Name = "The Emperor", Weight = 1, Color = Color3.fromRGB(160, 60, 50), Art = "",
		Upright = "The first hit you take is shrugged off.",
		Reversed = "The first hit you take hurts twice as much." },
	{ Id = "hierophant", Numeral = "V", Name = "The Hierophant", Weight = 1, Color = Color3.fromRGB(150, 130, 100), Art = "",
		Upright = "You heal 50% faster.",
		Reversed = "You heal 50% slower." },
	{ Id = "lovers", Numeral = "VI", Name = "The Lovers", Weight = 1, Color = Color3.fromRGB(180, 90, 110), Art = "",
		Upright = "You slowly heal while somebody is within 12 studs of you.",
		Reversed = "You can't heal while anybody is within 8 studs of you." },
	{ Id = "chariot", Numeral = "VII", Name = "The Chariot", Weight = 1, Color = Color3.fromRGB(100, 120, 140), Art = "",
		Upright = "+15% walk speed.",
		Reversed = "-15% walk speed." },
	{ Id = "strength", Numeral = "VIII", Name = "Strength", Weight = 1, Color = Color3.fromRGB(190, 120, 60), Art = "",
		Upright = "Shoves and knockback move you half as far.",
		Reversed = "Shoves and knockback move you 50% further." },
	{ Id = "hermit", Numeral = "IX", Name = "The Hermit", Weight = 1, Color = Color3.fromRGB(120, 110, 100), Art = "",
		Upright = "You take 25% less damage while nobody is within 20 studs of you.",
		Reversed = "You take 25% more damage while nobody is within 20 studs of you." },
	{ Id = "wheel", Numeral = "X", Name = "Wheel of Fortune", Weight = 1, Color = Color3.fromRGB(170, 140, 70), Art = "",
		Upright = "Your modifier vote counts twice this time.",
		Reversed = "Fate votes for you: your modifier vote is locked onto a random one." },
	{ Id = "justice", Numeral = "XI", Name = "Justice", Weight = 1, Color = Color3.fromRGB(130, 130, 150), Art = "",
		Upright = "Other players' items (traps, sticks, dolls...) hurt you 30% less.",
		Reversed = "Other players' items hurt you 30% more." },
	{ Id = "hanged", Numeral = "XII", Name = "The Hanged Man", Weight = 1, Color = Color3.fromRGB(90, 120, 130), Art = "",
		Upright = "+20% jump height.",
		Reversed = "-20% jump height." },
	{ Id = "death", Numeral = "XIII", Name = "Death", Weight = 1, Color = Color3.fromRGB(90, 90, 96), Art = "",
		Upright = "If you're knocked out, you get two ghost flips.",
		Reversed = "If you're knocked out, you get no ghost flip." },
	{ Id = "temperance", Numeral = "XIV", Name = "Temperance", Weight = 1, Color = Color3.fromRGB(110, 150, 150), Art = "",
		Upright = "Fire, poison and bleeding hurt you 25% less.",
		Reversed = "Fire, poison and bleeding hurt you 25% more." },
	{ Id = "devil", Numeral = "XV", Name = "The Devil", Weight = 1, Color = Color3.fromRGB(150, 40, 40), Art = "",
		Upright = "The Broker shows you a 4th contract, and you can read his fine print much better.",
		Reversed = "Your debts to the Broker come due twice as fast." },
	{ Id = "tower", Numeral = "XVI", Name = "The Tower", Weight = 1, Color = Color3.fromRGB(170, 100, 50), Art = "",
		Upright = "Big hits (25 damage or more) hurt you 20% less.",
		Reversed = "Big hits (25 damage or more) hurt you 20% more." },
	{ Id = "star", Numeral = "XVII", Name = "The Star", Weight = 1, Color = Color3.fromRGB(150, 170, 200), Art = "",
		Upright = "Once, when you drop below 25 health, a star heals you 20.",
		Reversed = "A dark haze narrows your view for the round." },
	{ Id = "moon", Numeral = "XVIII", Name = "The Moon", Weight = 1, Color = Color3.fromRGB(120, 130, 170), Art = "",
		Upright = "Events that pick one player pick you 25% less often.",
		Reversed = "Events that pick one player pick you 25% more often." },
	{ Id = "sun", Numeral = "XIX", Name = "The Sun", Weight = 1, Color = Color3.fromRGB(210, 160, 60), Art = "",
		Upright = "Things from the dark hurt you half as much.",
		Reversed = "Things from the dark hurt you 50% more." },
	{ Id = "judgement", Numeral = "XX", Name = "Judgement", Weight = 0.4, Color = Color3.fromRGB(190, 170, 140), Art = "",
		Upright = "Once, when you'd be knocked out, you get back up with 25 health.",
		Reversed = "You start the round at 75% health." },
	{ Id = "world", Numeral = "XXI", Name = "The World", Weight = 0.25, Color = Color3.fromRGB(170, 150, 90), Art = "",
		Upright = "+5% speed, max health and jump.",
		Reversed = "-5% speed, max health and jump." },
}

-- GHOST FLIPS: what a knocked-out player's card can do (picked at random). Kind tells the server what to run.
TarotConfig.Flips = {
	{ Id = "gale", Name = "The Gale", Text = "A cold gust sweeps across one plate.", Weight = 1 },
	{ Id = "candle", Name = "The Candle", Text = "Every light in the arena gutters for a moment.", Weight = 1 },
	{ Id = "rattle", Name = "The Rattle", Text = "A plate shudders. Probably nothing.", Weight = 1 },
	{ Id = "bell", Name = "The Bell", Text = "A bell tolls somewhere in the dark.", Weight = 1 },
	{ Id = "tombstone", Name = "The Tombstone", Text = "A tombstone falls on a plate. Only a whistle warns them.", Weight = 1 },
	{ Id = "web", Name = "The Web", Text = "A patch of cobweb spreads over a plate.", Weight = 1 },
	{ Id = "crows", Name = "The Crows", Text = "A flock of crows tears across the arena.", Weight = 1 },
	{ Id = "frost", Name = "The Frost", Text = "A chill settles on one plate.", Weight = 1 },
}

-- YOUR READING: checked top to bottom, the first one that fits is your card. (Winners only get the ones marked
-- Winner; everybody else gets the rest.) "Top half" = you finished in the better half of the round's players.
-- Rule = the name of the check in TarotServer. Two rules can give the same card (both are listed in the deck).
TarotConfig.Readings = {
	-- winners
	{ Winner = true, Card = "world", Upright = true, Rule = "BigWin", How = "Won a round that started with 8 or more players." },
	{ Winner = true, Card = "sun", Upright = true, Rule = "Untouched", How = "Won without taking a single hit." },
	{ Winner = true, Card = "strength", Upright = true, Rule = "Barely", How = "Won with less than 20% of your health left." },
	{ Winner = true, Card = "sun", Upright = false, Rule = "Battered", How = "Won, but took 150 damage or more on the way." },
	{ Winner = true, Card = "devil", Upright = true, Rule = "Contract", How = "Won after signing a contract with the Broker." },
	{ Winner = true, Card = "lovers", Upright = true, Rule = "Together", How = "Won together with somebody (the round ran out of time)." },
	{ Winner = true, Card = "chariot", Upright = true, Rule = "Traveller", How = "Won after covering 1500 studs or more." },
	{ Winner = true, Card = "star", Upright = true, Rule = "DrewUpright", How = "Won with the card you drew upright." },
	{ Winner = true, Card = "star", Upright = false, Rule = "DrewReversed", How = "Won with the card you drew reversed." },
	{ Winner = true, Card = "emperor", Upright = true, Rule = "Always", How = "Won a round." },
	-- everybody else
	{ Card = "death", Upright = false, Rule = "FirstOut", How = "Knocked out first (3 or more players)." },
	{ Card = "world", Upright = false, Rule = "SoClose", How = "Knocked out in second place in a round of 8 or more." },
	{ Card = "death", Upright = true, Rule = "Second", How = "Knocked out in second place (3 or more players)." },
	{ Card = "emperor", Upright = false, Rule = "Third", How = "Knocked out in third place (4 or more players)." },
	{ Card = "fool", Upright = false, Rule = "Fell", How = "Fell off the edge into the void." },
	{ Card = "tower", Upright = false, Rule = "BigHitOut", How = "Knocked out by a single hit of 40 damage or more." },
	{ Card = "moon", Upright = false, Rule = "DarkOut", How = "Knocked out by something from the dark." },
	{ Card = "devil", Upright = false, Rule = "Contract", How = "Knocked out with a contract still on you." },
	{ Card = "strength", Upright = false, Rule = "Quick", How = "Knocked out in the first 20 seconds." },
	{ Card = "temperance", Upright = false, Rule = "Sudden", How = "Went from full health to knocked out in under 5 seconds." },
	{ Card = "empress", Upright = false, Rule = "Weakened", How = "Knocked out with your max health cut below normal." },
	{ Card = "magician", Upright = false, Rule = "Hoarder", How = "Knocked out with 2 or more items still in your bag." },
	{ Card = "judgement", Upright = false, Rule = "RevivedLow", How = "Got back up from a knock-out, and still finished in the bottom half." },
	{ Card = "judgement", Upright = true, Rule = "RevivedHigh", How = "Got back up from a knock-out, and finished in the top half." },
	{ Card = "fool", Upright = true, Rule = "Saved", How = "Fell into the void and got pulled back out." },
	{ Card = "tower", Upright = true, Rule = "BigHitLived", How = "Took a single hit of 40 or more, lived, and finished in the top half." },
	{ Card = "temperance", Upright = true, Rule = "Steady", How = "Lasted 3 minutes or more without dropping below half health." },
	{ Card = "empress", Upright = true, Rule = "Healed", How = "Healed 60 health or more in one round." },
	{ Card = "magician", Upright = true, Rule = "Collector", How = "Got 3 or more items in one round." },
	{ Card = "moon", Upright = true, Rule = "DarkLived", How = "Got hurt by something from the dark and still finished in the top half." },
	{ Card = "hanged", Upright = true, Rule = "StillHigh", How = "Stood still for at least half your round and finished in the top half." },
	{ Card = "hanged", Upright = false, Rule = "StillLow", How = "Stood still for at least half your round and finished in the bottom half." },
	{ Card = "hermit", Upright = true, Rule = "AloneHigh", How = "Kept away from everybody most of the round and finished in the top half." },
	{ Card = "hermit", Upright = false, Rule = "AloneLow", How = "Kept away from everybody most of the round and finished in the bottom half." },
	{ Card = "lovers", Upright = true, Rule = "CloseHigh", How = "Stuck close to somebody most of the round and finished in the top half." },
	{ Card = "lovers", Upright = false, Rule = "CloseLow", How = "Stuck close to somebody most of the round and finished in the bottom half." },
	{ Card = "chariot", Upright = false, Rule = "Stuck", How = "Knocked out after moving less than 80 studs." },
	{ Card = "wheel", Upright = true, Rule = "FlipHit", How = "As a ghost, your flip hurt somebody still playing." },
	{ Card = "wheel", Upright = false, Rule = "FlipMiss", How = "As a ghost, you flipped a card that hurt nobody." },
	{ Card = "priestess", Upright = true, Rule = "DrewHigh", How = "Drew a card and finished in the top half." },
	{ Card = "priestess", Upright = false, Rule = "DrewLow", How = "Drew a card and finished in the bottom half." },
	{ Card = "hierophant", Upright = true, Rule = "StreakHigh", How = "Finished in the top half three rounds in a row." },
	{ Card = "hierophant", Upright = false, Rule = "StreakLow", How = "Finished in the bottom half three rounds in a row." },
	{ Card = "justice", Upright = true, Rule = "TopHalf", How = "Finished in the top half." },
	{ Card = "justice", Upright = false, Rule = "Always", How = "Finished in the bottom half." },
}

-- THE FORTUNE TELLER's words: one line per card each way up (kid-safe, a bit grim)
TarotConfig.Fortunes = {
	fool = { "Jump first. Look later. It has worked so far.", "The edge is closer than you think." },
	magician = { "Your pockets will be heavier before the night is out.", "What you hold today, you will not hold for long." },
	priestess = { "Listen to the quiet. It knows what comes next.", "Not every warning is meant for you. Not every warning is true." },
	empress = { "Something will mend that you thought was broken.", "Rest when you can. The plates will not wait for you." },
	emperor = { "Stand your ground. The ground will stand with you.", "The first blow is always the worst one." },
	hierophant = { "Old habits will keep you alive today.", "Do the same thing twice and the plates will notice." },
	lovers = { "Keep someone close. Two shadows are harder to catch.", "The one beside you will slow you down." },
	chariot = { "Keep moving. Whatever is behind you is slower.", "You will run, and the plate will run out." },
	strength = { "You will be pushed. You will not fall.", "Something heavy is coming. Plant your feet." },
	hermit = { "Walk alone tonight. Nobody can trip you.", "Being alone is not the same as being safe." },
	wheel = { "The wheel turns. This time it turns your way.", "Luck is a cat: it goes where it pleases." },
	justice = { "What others leave lying around will not bite you today.", "Mind the traps. Somebody set them for you." },
	hanged = { "Hang on. The view is better from up here.", "Stand still too long and the plates will remember." },
	death = { "Even an ending is a door.", "A bell will toll when you least expect it." },
	temperance = { "Slow fires burn out. So will this one.", "Smoke, poison, thorns. Pick your path carefully." },
	devil = { "A stranger will offer you something. Read every word.", "You already owe more than you know." },
	tower = { "Something will fall today. Make sure it isn't you.", "The tallest things fall the hardest." },
	star = { "A small light will find you in the dark.", "Clouds tonight. You will not see it coming." },
	moon = { "The dark will look the other way.", "Something in the dark has learned your name." },
	sun = { "Morning always comes. Even here.", "The night is long. Bring a candle." },
	judgement = { "You will get up again.", "Count your breaths. Then count them again." },
	world = { "Everything is where it should be. Enjoy it while it lasts.", "The whole world is against you. Only a little." },
}

---------------------------------------------------------------------
-- Lookups (shared by the server and the client)
---------------------------------------------------------------------

local byId: { [string]: any } = {}
local indexOf: { [string]: number } = {}
for index, card in TarotConfig.Cards do
	byId[card.Id] = card
	indexOf[card.Id] = index
end

function TarotConfig.Get(id: any): any
	return byId[tostring(id)]
end

local flipById: { [string]: any } = {}
for _, flip in TarotConfig.Flips do
	flipById[flip.Id] = flip
end
function TarotConfig.GetFlip(id: any): any
	return flipById[tostring(id)]
end

-- THE DECK is saved as a string of "0"s and "1"s: two per card, in card order (upright, then reversed).
local SLOTS = #TarotConfig.Cards * 2
local function slot(id: string, upright: boolean): number?
	local index = indexOf[id]
	return if index then (index - 1) * 2 + (if upright then 1 else 2) else nil
end

local function normalise(deck: any): string
	local text = if type(deck) == "string" then deck else ""
	if #text < SLOTS then
		text ..= string.rep("0", SLOTS - #text)
	end
	return string.sub(text, 1, SLOTS)
end

function TarotConfig.Has(deck: any, id: string, upright: boolean): boolean
	local at = slot(id, upright)
	return at ~= nil and string.sub(normalise(deck), at, at) == "1"
end

-- returns the new deck string (and whether that card was new)
function TarotConfig.Add(deck: any, id: string, upright: boolean): (string, boolean)
	local text = normalise(deck)
	local at = slot(id, upright)
	if not at or string.sub(text, at, at) == "1" then
		return text, false
	end
	return string.sub(text, 1, at - 1) .. "1" .. string.sub(text, at + 1), true
end

function TarotConfig.Count(deck: any): (number, number)
	local _, ones = string.gsub(normalise(deck), "1", "")
	return ones, SLOTS
end

-- how each card is earned in YOUR READING, upright and reversed (for the deck page)
function TarotConfig.HowToEarn(id: string, upright: boolean): { string }
	local list = {}
	for _, reading in TarotConfig.Readings do
		if reading.Card == id and reading.Upright == upright then
			table.insert(list, reading.How)
		end
	end
	return list
end

return TarotConfig
