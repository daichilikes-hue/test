-- ModuleScript: ReplicatedStorage > EventClients > zombies     (REPLACE; it has an "Animations" folder inside it)
-- What a Zombie Shuffle zombie looks like on each client: it claws its way out of a mound of dirt, shambles
-- with its arms out, crouches back before it lunges (or before it jumps a gap), slumps for a moment afterwards,
-- stands swaying at a ledge it will not walk off, and flails as it falls if a lunge or a whack takes it over the
-- edge. A swing knocks it back; a jump on its head squashes it down for a moment, and it bites.
-- Oct 10 2026 (update 11), "make it look less like a kids birthday party": no words popping up ("!", "WHACK!",
-- "SQUISH!", "SPLAT!"), no gold stars, no bright slime, no ping, no red light. Dirt, dust, chips of bone, a dark
-- stain; a dull glow in its eyes while it winds up is the only light. (The faces and clothes: Events > ZombieShuffle.)
-- The server (Events > ZombieShuffle) moves it and decides the hits; this draws it smoothly from the server's
-- messages.
-- A zombie is an R6 character dressed from the Roblox Marketplace (the looks are listed at the top of
-- Events > ZombieShuffle), moved by the animations below. If the characters or the animations are not
-- there, the old zombie built from blocks is shown instead, so the event always works.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))

-- YOUR SOUNDS: put an id in Id. While Id is "" the built-in Roblox sound in Stand plays ("" = silence).
--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	ZombieGrowl = { Id = "", Stand = "rbxasset://sounds/action_get_up.mp3", Speed = 0.55, Volume = 0.7 }, -- it winds up (to lunge, or to jump a gap)
	ZombieBite = { Id = "", Stand = "rbxasset://sounds/swordslash.wav", Speed = 1.6, Volume = 0.5 },      -- it bites somebody
	ZombieSquish = { Id = "", Stand = "rbxasset://sounds/impact_water.mp3", Speed = 0.7, Volume = 0.8 },  -- one is squished
}
--[[DMP:END]]
FX.UseSounds(SOUNDS)

-- THE ZOMBIE ANIMATIONS. The seven KeyframeSequences are in this module's "Animations" folder. For each one:
-- right-click it > Save to Roblox (as the OWNER of the game: you, or the group), then paste the id you get here.
-- 0 = not uploaded yet: in Studio it is played straight from the folder so you can see it; in the real game
-- the block zombies are shown until the ids are in.
local ANIMATIONS = {
	Rise = 0,      -- climbs out of the ground, arms first
	Walk = 0,      -- the shamble, arms out (loops)
	WindUp = 0,    -- crouches back before the lunge
	Lunge = 0,     -- the dive
	Rest = 0,      -- dizzy after the dive
	Fall = 0,      -- flailing as it falls off the edge (loops)
	Bite = 0,      -- a quick grab when it touches someone
}
local USE_RIGS = true     -- false = always the old block zombies
local RIG_SIZE = 1.2      -- how much bigger than a player the R6 zombies are (1 = the same size)
local RISE_LENGTH = 1     -- the Rise animation climbs out in this many seconds (it is sped up / slowed down to the server's RISE_TIME)

local C = FX.Colors
local SKIN = Color3.fromRGB(106, 120, 100)
local TROUSERS = Color3.fromRGB(40, 40, 48)
local DIRT = Color3.fromRGB(74, 58, 46)
local SHIRTS = { Color3.fromRGB(52, 58, 72), Color3.fromRGB(78, 50, 48), Color3.fromRGB(62, 70, 54), Color3.fromRGB(70, 62, 78) }
local EYE = Color3.fromRGB(196, 190, 132)
local GORE = Color3.fromRGB(44, 54, 38)   -- what is left of a squished one (dark, not bright slime)
local BONE = Color3.fromRGB(206, 198, 170)
local SIZE = 1.25         -- (the block zombie)
local ACTIONS = { "Rise", "WindUp", "Lunge", "Rest", "Fall" }   -- one of these at a time, on top of Walk

local function arm(x: number, pitch: number): CFrame
	return CFrame.new(x, 3.9, 0) * CFrame.Angles(pitch, 0, 0) * CFrame.new(0, 0, -1.1)
end
local function leg(x: number, swing: number): CFrame
	return CFrame.new(x, 2, 0) * CFrame.Angles(swing, 0, 0) * CFrame.new(0, -1, 0)
end

-- the R6 character for this zombie, ready to be animated (nil = show the block zombie)
local function makeActor(self: any, props: any): FX.Actor?
	if not USE_RIGS or type(props.Look) ~= "string" then
		return nil
	end
	local rigs = script:FindFirstChild("Rigs") -- (Events > ZombieShuffle builds the characters and puts them here)
	local template = rigs and rigs:FindFirstChild(props.Look)
	if not (template and template:IsA("Model")) then
		return nil
	end
	local ok, clone = pcall(function(): Instance
		return template:Clone()
	end)
	if not ok or typeof(clone) ~= "Instance" or not clone:IsA("Model") then
		return nil
	end
	local model: Model = clone
	pcall(function()
		model:ScaleTo(RIG_SIZE)
	end)
	local actor = FX.Actor(model, ANIMATIONS, script)
	if not actor.Animated then
		model:Destroy() -- (a character that cannot move a limb looks worse than the block zombie)
		return nil
	end
	-- how high its root is above its feet, and how tall it is
	local root = actor.Root
	local low, high = root.Position.Y - root.Size.Y / 2, root.Position.Y + root.Size.Y / 2
	for _, item in model:GetDescendants() do
		if item:IsA("BasePart") and (item.Name == "Left Leg" or item.Name == "Right Leg" or item.Name == "Head") then
			low = math.min(low, item.Position.Y - item.Size.Y / 2)
			high = math.max(high, item.Position.Y + item.Size.Y / 2)
		end
	end
	self.RootHeight = root.Position.Y - low
	self.Tall = high - low + 0.6
	model.Name = "Zombie"
	actor.Place(CFrame.new(self.Origin.Position - Vector3.new(0, 60, 0)))
	model.Parent = self.Inst
	self.Glow = FX.Light(root, EYE, 9, 0)
	return actor
end

-- starts the animation that goes with what the zombie is doing
local function animate(self: any, state: string, fade: number)
	local actor: FX.Actor = self.Actor
	-- (at a ledge it stands and sways: the walk, slowed right down)
	actor.Play("Walk", 0.2, if state == "edge" then 0.3 else 1)
	local wanted: string? = if state == "rise" then "Rise" elseif state == "windup" then "WindUp" elseif state == "lunge" then "Lunge"
		elseif state == "rest" or state == "stagger" then "Rest" elseif state == "fall" then "Fall" else nil
	for _, name in ACTIONS do
		if name ~= wanted then
			actor.Stop(name, fade)
		end
	end
	self.Track = nil
	if wanted then
		local speed = if wanted == "Rise" then RISE_LENGTH / math.max(self.Props.Rise or 1, 0.2) else 1
		self.Track = actor.Play(wanted, fade, speed, 0)
		self.Holds = wanted ~= "Fall" -- (it keeps its last pose until the server says what comes next)
	end
end

return FX.Module({
	Zombie = {
		Init = function(self: any, props: any)
			local rng = Random.new(props.Seed or 1)
			local start: Vector3 = self.Origin.Position
			self.Follow = FX.Follower(start, Vector3.new(0, 0, -1), 14)
			self.State, self.StateAt = "rise", 0
			self.Actor = makeActor(self, props)
			if not self.Actor then
				-- the block zombie
				local shirt = SHIRTS[rng:NextInteger(1, #SHIRTS)]
				local rig = FX.Rig(self.Inst)
				rig:Block("Body", Vector3.new(2, 2.2, 1.1), CFrame.new(0, 3.1, 0), shirt)
				rig:Block("Rip", Vector3.new(0.9, 0.7, 1.14), CFrame.new(0.3, 2.5, 0), SKIN)
				rig:Block("Head", Vector3.new(1.4, 1.4, 1.4), CFrame.new(0, 4.9, 0), SKIN)
				rig:Block("Mouth", Vector3.new(0.7, 0.22, 0.1), CFrame.new(0, 4.5, -0.72), C.Black)
				rig:Add(FX.Ball(self.Inst, 0.34, Vector3.new(), EYE, Enum.Material.SmoothPlastic), CFrame.new(-0.32, 5.05, -0.7), "EyeL")
				rig:Add(FX.Ball(self.Inst, 0.24, Vector3.new(), EYE, Enum.Material.SmoothPlastic), CFrame.new(0.34, 5.1, -0.7), "EyeR")
				rig:Block("ArmL", Vector3.new(0.8, 0.8, 2.2), arm(-1.4, 0), SKIN)
				rig:Block("ArmR", Vector3.new(0.8, 0.8, 2.2), arm(1.4, 0), SKIN)
				rig:Block("LegL", Vector3.new(0.9, 2, 0.9), leg(-0.5, 0), TROUSERS)
				rig:Block("LegR", Vector3.new(0.9, 2, 0.9), leg(0.5, 0), TROUSERS)
				self.Rig = rig
			end
			self.Phase = rng:NextNumber(0, 6)
			-- the mound it climbs out of
			self.Mound = FX.Disc(self.Inst, 2.4, start, DIRT, 0.1, 0.3)
			self.Mound.Material = Enum.Material.Slate
			local rising = self:Time() < (props.Rise or 1)
			if rising then
				FX.Chunks(start, 8, DIRT, { Size = 0.7, Speed = 9, Up = 16, Life = 1.1 })
				FX.Burst(start, "Dust", 8, { Color = DIRT, Scale = 1.2 })
				FX.Sound("Shuffle", start, 0.8 * FX.Near(start, 20, 90), 0.8)
				FX.Sound("Groan", start, 0.8)
			else
				self.State = "walk" -- (someone who joined late: it has been up for a while)
			end
			if self.Actor then
				local actor: FX.Actor = self.Actor
				actor.Play("Walk", 0.2, 1, self.Phase % 1)
				if rising then
					animate(self, "rise", 0)
				end
			end
		end,

		-- (K.Signal) it changed what it is doing: "walk", "edge" (standing at a ledge), "windup", "lunge", "rest",
		-- "stagger" (knocked back), "fall"
		State = function(self: any, state: string, position: Vector3, facing: Vector3)
			local before: string = self.State
			self.State, self.StateAt = state, self:Time()
			self.Follow.Push(position, facing)
			if self.Actor then
				animate(self, state, if state == "lunge" then 0.05 elseif state == "walk" and before == "rest" then 0.25 else 0.12)
			end
			if state == "windup" then
				FX.Sound("ZombieGrowl", position, FX.Near(position, 20, 80))
			elseif state == "lunge" then
				FX.Sound("Lunge", position, 0.8 * FX.Near(position, 20, 90), 0.8)
				FX.Burst(position, "Dust", 6, { Color = DIRT, Scale = 1.1 })
			elseif state == "rest" then
				FX.Burst(position, "Dust", 4, { Color = DIRT, Scale = 0.9 })
			elseif state == "fall" then
				self.FallFrom = position
			elseif state == "stagger" then
				FX.Burst(position + Vector3.new(0, 3, 0), "Dust", 6, { Color = DIRT, Scale = 1.1 })
				FX.Chunks(position + Vector3.new(0, 3, 0), 3, { DIRT, BONE }, { Size = 0.4, Speed = 9, Up = 10, Life = 0.7 })
				FX.Sound("Thud", position, 0.8 * FX.Near(position, 20, 90), 1.2)
			end
		end,

		-- (K.Signal) somebody whacked it (and it is still standing): the knock itself is shown by its "stagger"
		Whacked = function(_self: any, _userId: number)
		end,

		-- (K.Signal) somebody landed on its head and it is not squished yet: it is squashed down for a moment
		Stomped = function(self: any, _userId: number, position: Vector3)
			self.Squash = self:Time()
			FX.Burst(position + Vector3.new(0, 4.5, 0), "Dust", 5, { Color = DIRT, Scale = 1 })
			FX.Sound("Thud", position, 0.7 * FX.Near(position, 20, 90), 1.3)
		end,

		-- (K.Signal) squished: "whack" (finished off) or "stomp" (somebody landed on its head)
		Die = function(self: any, position: Vector3, how: string)
			if self.Dead then
				return
			end
			self.Dead = self:Time()
			self.Follow.Snap(position)
			local middle = position + Vector3.new(0, 2.5, 0)
			FX.Burst(middle, "Dust", 12, { Color = DIRT, Scale = 1.5 })
			FX.Burst(middle, "Drop", 10, { Color = GORE, Scale = 1.1, LightEmission = 0 })
			FX.Chunks(middle, 9, { DIRT, BONE, GORE }, { Size = 0.55, Speed = 13, Up = 15, Life = 1.1 })
			FX.Sound("ZombieSquish", position, FX.Near(position, 20, 90))
			FX.Sound("Thud", position, 0.6 * FX.Near(position, 20, 90), if how == "stomp" then 0.8 else 1)
			if self.Actor then
				local actor: FX.Actor = self.Actor
				actor.Stop(nil, 0.1)
			end
		end,

		-- (K.Signal, a few times a second while it walks or lunges) where it is and which way it faces
		At = function(self: any, position: Vector3, facing: Vector3)
			self.Follow.Push(position, facing)
		end,

		Step = function(self: any, dt: number, t: number)
			local position: Vector3, facing: Vector3 = self.Follow.Step(dt)
			local state: string = self.State
			local since = t - self.StateAt
			local dead: number? = self.Dead
			if dead then
				-- squished: it flattens into the plate and is gone
				local flat = FX.Ease.In(FX.Span(t, dead, dead + 0.25))
				if self.Actor then
					local actor: FX.Actor = self.Actor
					actor.Place(FX.Facing(position + Vector3.new(0, self.RootHeight * (1 - flat * 0.85), 0), facing) * CFrame.Angles(-flat * 1.2, 0, 0))
					if flat >= 1 and not self.Hidden then
						self.Hidden = true
						actor.Model.Parent = nil
					end
				elseif self.Rig then
					local rig: FX.Rig = self.Rig
					rig:Fade(flat)
					rig:Move(FX.Facing(position, facing) * CFrame.Angles(-flat * 1.3, 0, 0), SIZE * (1 - flat * 0.5))
				end
				return
			end

			if self.Actor then
				-- the R6 character: the animations move its body, this only puts it in the right place
				local actor: FX.Actor = self.Actor
				local sink, tumble = 0, 0
				if state == "rise" then
					sink = -self.Tall * (1 - FX.Ease.Smooth(t / (self.Props.Rise or 1)))
				elseif state == "fall" then
					sink = -40 * since * since
					tumble = since * 5
				elseif state == "lunge" then
					-- (a lunge is a low dive through the air: it clears a gap between plates)
					sink = math.sin(FX.Clamp01(since / (self.Props.Lunge or 0.5)) * math.pi) * 1.4
				end
				local squash: number? = self.Squash
				if squash then
					-- somebody landed on its head: down into its shoulders and back up
					sink -= math.sin(FX.Clamp01((t - squash) / 0.35) * math.pi) * 1.2
				end
				if self.Leaving then
					-- the end of the event: back into the ground
					sink -= (self.Tall + 0.5) * FX.Ease.In(FX.Span(t, self.Leaving, self.Leaving + 1))
				end
				actor.Place(FX.Facing(position + Vector3.new(0, self.RootHeight + sink, 0), facing) * CFrame.Angles(tumble, 0, 0))
				-- a move that has reached its last pose keeps it (until the server says what comes next)
				local track: AnimationTrack? = self.Track
				if track and self.Holds and track.IsPlaying and track.Length > 0 and track.TimePosition >= track.Length - 0.06 then
					track:AdjustSpeed(0)
				end
				local glow: PointLight? = self.Glow
				if glow then
					local want = if state == "windup" then 0.8 + math.sin(t * 30) * 0.25 elseif state == "lunge" then 1.1 else 0
					glow.Brightness += (want - glow.Brightness) * math.min(dt * 14, 1)
				end
				return
			end

			-- the block zombie
			local rig: FX.Rig = self.Rig
			local beat = t * 5 + self.Phase
			local lean, roll, sink = 0, math.sin(beat) * 0.08, 0
			local armL, armR, legL, legR = 0.15 + math.sin(beat) * 0.12, 0.15 - math.sin(beat) * 0.12, math.sin(beat) * 0.5, -math.sin(beat) * 0.5
			if state == "rise" then
				local up = FX.Ease.Smooth(t / (self.Props.Rise or 1))
				sink = -4.8 * (1 - up)
				armL, armR, legL, legR = 1.45 - up * 1.3, 1.45 - up * 1.3, 0, 0
			elseif state == "windup" then
				lean = math.rad(20) * FX.Ease.Out(since / 0.3)
				armL, armR, legL, legR = -0.9, -0.9, 0.3, -0.2
				roll = math.sin(t * 40) * 0.03
			elseif state == "lunge" then
				lean = math.rad(-34)
				armL, armR, legL, legR = 0.35, 0.35, -0.7, -0.5
				roll = 0
			elseif state == "rest" or state == "stagger" then
				lean = math.rad(if state == "stagger" then -26 else -16)
				armL, armR, legL, legR = -1.3, -1.3, 0, 0
			elseif state == "fall" then
				sink = -40 * since * since
				lean = since * 5
				armL, armR = 1.4 + math.sin(t * 22) * 0.5, 1.4 - math.sin(t * 22) * 0.5
				rig:Fade(FX.Span(since, 0.7, 1.3))
			end
			if self.Leaving then
				-- the end of the event: back into the ground
				local down = FX.Ease.In(FX.Span(t, self.Leaving, self.Leaving + 1))
				sink -= 5.5 * down
				armL, armR = 1.4, 1.4
			end
			rig:Pose("ArmL", arm(-1.4, armL))
			rig:Pose("ArmR", arm(1.4, armR))
			rig:Pose("LegL", leg(-0.5, legL))
			rig:Pose("LegR", leg(0.5, legR))
			rig:Move(FX.Facing(position + Vector3.new(0, sink * SIZE, 0), facing) * CFrame.Angles(lean, 0, roll), SIZE)
		end,

		-- (K.Strike) it bit this player, or caught them with a lunge. (No ring, no sparks: dust, and a snap.)
		Hit = function(self: any, userId: number)
			local root = FX.Root(userId)
			if root then
				FX.Burst(root.Position - Vector3.new(0, 1.5, 0), "Dust", 4, { Color = DIRT, Scale = 0.8 })
				FX.Sound("ZombieBite", root.Position, FX.Near(root.Position, 16, 70))
			end
			if FX.IsMe(userId) then
				FX.Shake(1.5, 15, 0.02, 0.3)
				FX.Pulse(C.Blood, 0.55, 0.25)
			end
			if self.Actor and (self.State == "walk" or self.State == "rest" or self.State == "edge") then
				local actor: FX.Actor = self.Actor
				actor.Play("Bite", 0.06, 1, 0)
			end
		end,

		Outro = function(self: any, _seconds: number?)
			if not self.Leaving then
				self.Leaving = self:Time()
				local position: Vector3 = self.Follow.Step(0)
				FX.Burst(position, "Dust", 8, { Color = DIRT, Scale = 1.2 })
				if self.Actor then
					-- arms up, the way it came
					local actor: FX.Actor = self.Actor
					self.Track = nil
					actor.Stop(nil, 0.3)
					actor.Seek("Rise", 0, 0.3)
				end
			end
		end,
	},
})
