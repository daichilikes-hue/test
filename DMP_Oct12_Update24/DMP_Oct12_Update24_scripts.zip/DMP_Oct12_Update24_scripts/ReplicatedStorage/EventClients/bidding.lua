-- ModuleScript: ReplicatedStorage > EventClients > bidding
-- Draws The Bidding (server: ServerScriptService > Events > TheBidding).
--   THE ALTAR  the model Altar under the event's server script: a black slate altar on a pillar that grinds up out of
--              the void OFF the plates, a moth-eaten velvet cushion, two candles. The prize is on it: a heap of
--              candles or a pale soul-flame in a lantern (groups of the model, turning slowly), or, for "two round
--              items", a NORMAL chest (the server puts that one there). Above it: the prize's name, the top bid
--              and who holds it, and the clock. A gavel knocks on every bid; "Going once... going twice... SOLD!"
--   THE PANEL  the ScreenGui BidGui under the event's server script, cloned onto the screen of everybody alive in
--              the round: what is sold, the clock, the top bid and who holds it, and YOUR bid with a V and an up
--              arrow next to it, and BID. While you hold the top bid the button is grey: only somebody who was
--              outbid (or has not bid yet) can place a higher one.
-- Oct 11 2026 (update 12): the panel is new (it was a prompt on the altar), and the altar, the prizes and the panel
-- are a model / a ScreenGui now instead of being built here. Restyle them in Studio as you like; the code needs
-- these names:
--   Altar  > Stone > Cushion, FlameL, FlameR, Head, Glow (with a PointLight in it);  PrizeCandles, PrizeRevive
--   BidGui > Panel > Scale (a UIScale), Prize, Clock, ClockBar > Fill, TopBid, Leader, Down, Up, Amount, Unit, Bid, Status
-- On a short screen (a phone) the code shrinks the panel and moves it into the top right corner, out of the way of
-- the jump button: PHONE_BELOW and SMALLEST below.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local FX = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not (FX.Gui and FX.RigFrom) then
	warn("[bidding] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end

-- Your sound ids go in Id. While Id is "", Stand plays (a built-in Roblox sound; "" = silent).
--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	GavelKnock = { Id = "", Stand = "rbxasset://sounds/action_jump_land.mp3", Speed = 1.4, Volume = 1.2 }, -- every bid
	StoneGrind = { Id = "", Stand = "rbxasset://sounds/action_get_up.mp3", Speed = 0.4, Volume = 1 },      -- the altar rises (shared with Sign Here)
	DevilLaugh = { Id = "", Stand = "", Speed = 1, Volume = 1 },                                          -- unsold (shared)
	Sold = { Id = "", Stand = "rbxasset://sounds/electronicpingshort.wav", Speed = 0.5, Volume = 0.8 },    -- SOLD!
	Outbid = { Id = "", Stand = "rbxasset://sounds/action_jump_land.mp3", Speed = 0.7, Volume = 0.9 },     -- somebody bid more than YOU (only you hear it)
}
--[[DMP:END]]
FX.UseSounds(SOUNDS)

local localPlayer = Players.LocalPlayer
local EMBER = Color3.fromRGB(230, 120, 40)
local RISE = 12             -- studs the altar grinds up out of the void (and sinks back at the end)
local PHONE_BELOW = 500     -- a screen less than this many pixels high is a phone: the panel goes to the top right corner
local SMALLEST = 0.72       -- ... and is never drawn smaller than this
local PRIZE_GROUP = { Candles = "PrizeCandles", Revive = "PrizeRevive" } -- (Items: the server's normal chest)
-- the look of a button that cannot be pressed right now (the shop's greys)
local OFF_TOP, OFF_BOTTOM, OFF_EDGE = Color3.fromRGB(62, 46, 48), Color3.fromRGB(34, 25, 27), Color3.fromRGB(100, 72, 75)
local OUTBID = Color3.fromRGB(255, 170, 90)

---------------------------------------------------------------------- the panel
-- a button of the panel, and how it looks when it can be pressed (as the ScreenGui has it)
type Button = { Button: TextButton, Gradient: UIGradient?, Stroke: UIStroke?, On: ColorSequence?, Edge: Color3?, Enabled: boolean, Text: string }
local function button(instance: Instance?): Button?
	if not (instance and instance:IsA("TextButton")) then
		return nil
	end
	local gradient = instance:FindFirstChildOfClass("UIGradient")
	local stroke = instance:FindFirstChildOfClass("UIStroke")
	return { Button = instance, Gradient = gradient, Stroke = stroke, On = gradient and gradient.Color, Edge = stroke and stroke.Color, Enabled = true, Text = instance.Text }
end
local function setButton(b: Button?, enabled: boolean, text: string?)
	if not b or (b.Enabled == enabled and (text == nil or text == b.Text)) then
		return
	end
	b.Enabled = enabled
	local instance = b.Button
	if text then
		b.Text = text
		instance.Text = text
	end
	instance.AutoButtonColor = enabled
	instance.TextTransparency = if enabled then 0 else 0.35
	if b.Gradient and b.On then
		b.Gradient.Color = if enabled then b.On else ColorSequence.new(OFF_TOP, OFF_BOTTOM)
	end
	if b.Stroke and b.Edge then
		b.Stroke.Color = if enabled then b.Edge else OFF_EDGE
	end
end
local function setText(label: Instance?, text: string, color: Color3?)
	if label and (label:IsA("TextLabel") or label:IsA("TextButton")) then
		local words = label :: any
		if words.Text ~= text then
			words.Text = text
		end
		if color and words.TextColor3 ~= color then
			words.TextColor3 = color
		end
	end
end

-- how big the panel is drawn, and where: as the ScreenGui has it on a normal screen; smaller, in the top right
-- corner, on a short one
local function fitPanel(panel: any)
	local size: Vector2 = panel.Gui.AbsoluteSize
	local scale = math.clamp(size.Y / 560, SMALLEST, 1)
	if panel.Scale then
		panel.Scale.Scale = scale
	end
	local frame: GuiObject = panel.Frame
	if size.Y < PHONE_BELOW then
		frame.AnchorPoint = Vector2.new(1, 0)
		frame.Position = UDim2.new(1, -8, 0, math.floor(24 * scale))
	else
		frame.AnchorPoint = panel.Anchor
		frame.Position = panel.Position
	end
end

local function closePanel(self: any)
	local panel = self.Panel
	if panel then
		self.Panel = nil
		panel.Gui:Destroy()
	end
end

-- the auction is over: the V and the up arrow go (and, when nothing was sold, the number between them)
local function shutPanel(panel: any, keepNumber: boolean)
	for _, name in { "Down", "Up" } do
		local b: Button? = panel[name]
		if b then
			b.Button.Visible = false
		end
	end
	if not keepNumber then
		for _, name in { "Amount", "Unit" } do
			local label = panel[name]
			if label and label:IsA("GuiObject") then
				label.Visible = false
			end
		end
	end
end

-- the panel comes onto the screen of whoever is alive in the round
local function openPanel(self: any)
	if localPlayer:GetAttribute("Alive") ~= true then
		return
	end
	local gui = FX.Gui("bidding", "BidGui")
	local frame = gui and gui:FindFirstChild("Panel")
	if not (gui and frame and frame:IsA("GuiObject")) then
		return
	end
	self:Keep(gui)
	local function find(name: string): Instance?
		local found = frame:FindFirstChild(name, true)
		if not found then
			FX.WarnOnce("bidgui" .. name, "'" .. name .. "' is missing in the ScreenGui BidGui (ServerScriptService > Events > TheBidding > BidGui): that part of the bidding panel stays empty")
		end
		return found
	end
	local scale = find("Scale")
	local panel = {
		Gui = gui, Frame = frame, Anchor = frame.AnchorPoint, Position = frame.Position, Scale = if scale and scale:IsA("UIScale") then scale else nil,
		Prize = find("Prize"), Clock = find("Clock"), Fill = find("Fill"), TopBid = find("TopBid"), Leader = find("Leader"),
		Amount = find("Amount"), Unit = find("Unit"), Status = find("Status"),
		Down = button(find("Down")), Up = button(find("Up")), Bid = button(find("Bid")),
	}
	self.Panel = panel
	self.Want = self.Top + self.StepSize
	setText(panel.Prize, self.Name)
	fitPanel(panel)
	self:Keep(gui:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
		if self.Panel == panel then
			fitPanel(panel)
		end
	end))
	-- the V and the up arrow: how much YOU want to bid (always more than the top bid, never more than you can pay)
	local function nudge(by: number)
		if self.Panel == panel and not self.EndAt then
			self.Want += by * self.StepSize
		end
	end
	if panel.Down then
		self:Keep(panel.Down.Button.Activated:Connect(function()
			nudge(-1)
		end))
	end
	if panel.Up then
		self:Keep(panel.Up.Button.Activated:Connect(function()
			nudge(1)
		end))
	end
	if panel.Bid then
		self:Keep(panel.Bid.Button.Activated:Connect(function()
			if self.Panel == panel and self.CanBid and not self.EndAt then
				self.SentAt = self:Time()
				self:Send("Bid", self.Want)
			end
		end))
	end
end

-- everything on the panel that changes, every frame (only what really changed is written)
local function refreshPanel(self: any, t: number)
	local panel = self.Panel
	if not panel then
		return
	end
	if localPlayer:GetAttribute("Alive") ~= true and not self.EndAt then
		closePanel(self) -- (knocked out of the round: the dead do not bid)
		return
	end
	local left = self.Ends - FX.Now()
	local fill = panel.Fill
	if self.EndAt then
		setText(panel.Clock, "")
		if fill and fill:IsA("GuiObject") then
			fill.Visible = false
		end
		return
	end
	setText(panel.Clock, if t >= self.Arrive then tostring(math.max(0, math.ceil(left))) else "")
	if fill and fill:IsA("GuiObject") then
		fill.Size = UDim2.fromScale(math.clamp(left / self.Window, 0, 1), 1)
	end
	-- what you can bid: more than the top bid, and what leaves you FLOOR max health
	local character = localPlayer.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local maxHealth = if humanoid then humanoid.MaxHealth else 100
	local step: number = self.StepSize
	local least = self.Top + step
	local most = math.floor((maxHealth - self.Floor) / step + 1e-6) * step
	local leading = FX.IsMe(self.Leader)
	local waiting = self.SentAt ~= nil and t - self.SentAt < 0.6
	if leading then
		self.Want = self.Top
	else
		self.Want = math.clamp(self.Want, least, math.max(most, least))
	end
	local canPay = most >= least
	self.CanBid = t >= self.Arrive and not leading and canPay and not waiting
	setText(panel.Amount, tostring(self.Want))
	setButton(panel.Down, self.CanBid and self.Want > least)
	setButton(panel.Up, self.CanBid and self.Want < most)
	setButton(panel.Bid, self.CanBid, if leading then "LEADING" elseif waiting then "..." else "BID")
	local outbid = self.OutbidAt ~= nil and t - self.OutbidAt < 3
	if leading then
		setText(panel.Status, "You hold the top bid.", self.StatusColor)
	elseif not canPay then
		setText(panel.Status, "Too rich: you'd be left under " .. self.Floor .. " max HP.", self.StatusColor)
	elseif outbid then
		setText(panel.Status, "OUTBID! Bid more, or let it go.", OUTBID)
	elseif self.Top > 0 then
		setText(panel.Status, "Bid more than " .. self.Top .. ", or let it go.", self.StatusColor)
	else
		setText(panel.Status, "Pick how much, then BID.", self.StatusColor)
	end
end

return FX.Module({
	Altar = {
		Init = function(self, props)
			self.Arrive = tonumber(props.Arrive) or 2
			self.Kind = tostring(props.Prize or "Items")
			self.Ends = tonumber(props.Ends) or (self.T0 + 17)
			self.Window = tonumber(props.Window) or 15
			self.StepSize = tonumber(props.Step) or 10
			self.Floor = tonumber(props.Floor) or 20
			self.Name = tostring(props.PrizeName or "A prize")
			self.Top = 0
			self.Leader = 0
			self.Said = ""
			self.KnockAt = -10
			-- THE MODEL: the pillar and the altar, and the prize that is sold this time (the others are taken away)
			local inst: Instance = self.Inst
			local stone = inst:FindFirstChild("Stone")
			if not stone then
				FX.WarnOnce("biddingmodel", "the model 'Altar' is missing under ServerScriptService > Events > TheBidding (install the update again): the altar is invisible")
			end
			local rig = if stone then FX.RigFrom(stone, self.Origin) else FX.Rig(inst)
			self.Rig = rig
			self.Flames = {}
			for _, name in { "FlameL", "FlameR" } do
				local flame = rig:Get(name)
				if flame then
					self.Flames[name] = flame.Size
				end
			end
			for kind, groupName in PRIZE_GROUP do
				local group = inst:FindFirstChild(groupName)
				if group and kind == self.Kind then
					local root = group:FindFirstChild("Root")
					local at: CFrame = if root and root:IsA("BasePart") then root.CFrame else self.Origin * CFrame.new(0, 9.5, 0)
					self.Prize = FX.RigFrom(group, at)
					self.PrizeAt = self.Origin:ToObjectSpace(at)
					self.Wicks = {}
					self.Prize:Each(function(part: BasePart, name: string)
						if string.sub(name, 1, 4) == "Wick" or name == "Soul" then
							self.Wicks[name] = part.Size
						end
					end)
				elseif group then
					group:Destroy()
				end
			end
			-- the words over it (for whoever is watching from outside the round: the players have the panel)
			local head = rig:Get("Head")
			if head then
				self.Title = FX.Label(head, self.Name, Color3.fromRGB(205, 175, 110), 3.2, 30, 3)
				self.BidLabel = FX.Label(head, "No bids yet. " .. self.StepSize .. " max HP to start.", Color3.fromRGB(200, 190, 170), 0.4, 34, 2.2)
				self.Clock = FX.Label(head, "", Color3.fromRGB(205, 175, 110), -2.2, 8, 2.2)
			end
			local glow = rig:Get("Glow")
			self.Light = glow and glow:FindFirstChildOfClass("PointLight")
			rig:Move(self.Origin * CFrame.new(0, -RISE, 0))
			if self.Prize then
				self.Prize:Move(self.Origin * self.PrizeAt * CFrame.new(0, -RISE, 0), 0.05)
			end
			FX.Sound("StoneGrind", self.Origin.Position)
			openPanel(self)
			local status = self.Panel and self.Panel.Status
			self.StatusColor = if status and status:IsA("TextLabel") then status.TextColor3 else nil
		end,

		Step = function(self, _dt, t)
			local up = FX.Ease.Out(FX.Clamp01(t / self.Arrive))
			local gone = if self.EndAt then FX.Clamp01((t - self.EndAt - 1.2) / 1.6) else 0
			local frame = self.Origin * CFrame.new(0, -RISE * (1 - up) - RISE * FX.Ease.In(gone), 0)
			-- the candle flames flicker
			for name, size in self.Flames do
				self.Rig:Resize(name, size * (1 + FX.Noise(if name == "FlameL" then 3 else 8, t * 9) * 0.16))
			end
			self.Rig:Move(frame)
			local prize = self.Prize
			if prize then
				for name, size in self.Wicks do
					prize:Resize(name, size * (1 + FX.Noise(#name * 7 + string.byte(name, #name), t * 8) * 0.16))
				end
				local prizeFrame = frame * self.PrizeAt * CFrame.new(0, math.sin(t * 1.6) * 0.25, 0) * CFrame.Angles(0, t * 0.6, 0)
				if self.SoldTo then
					-- it flies to whoever bought it
					local root = FX.Root(self.SoldTo)
					local k = FX.Ease.In(FX.Clamp01((t - self.EndAt) / 0.8))
					if root then
						prizeFrame = prizeFrame:Lerp(CFrame.new(root.Position), k)
					end
					prize:Move(prizeFrame, math.max(1 - k, 0.05))
				else
					prize:Move(prizeFrame, math.max(up * (1 - gone), 0.05))
				end
			end
			refreshPanel(self, t)
			if self.EndAt then
				return
			end
			local left = self.Ends - FX.Now()
			local line = ""
			if self.Top > 0 and left <= 1.6 then
				line = "Going twice..."
			elseif self.Top > 0 and left <= 3.2 then
				line = "Going once..."
			end
			if self.Clock then
				self.Clock.Text = if t >= self.Arrive then tostring(math.max(0, math.ceil(left))) else ""
			end
			if line ~= self.Said then
				self.Said = line
				if self.Title then
					self.Title.Text = if line ~= "" then line else self.Name
				end
				if self.Panel then
					setText(self.Panel.Prize, if line ~= "" then line else self.Name)
				end
				if line ~= "" then
					FX.Sound("GavelKnock", self.Origin.Position + Vector3.new(0, 9, 0), 0.7, 0.8)
				end
			end
			if self.Light then
				self.Light.Brightness = 0.8 + FX.Clamp01(1 - (t - self.KnockAt) / 0.4) * 2
			end
		end,

		-- (K.Call) somebody placed a bid: it is the top bid now, and the clock runs until `ends`
		Bid = function(self, userId, bid, ends)
			local was = self.Leader
			self.Top = tonumber(bid) or self.Top
			self.Leader = tonumber(userId) or 0
			self.Ends = tonumber(ends) or self.Ends
			self.KnockAt = self:Time()
			self.SentAt = nil
			self.Said = ""
			local player = FX.Player(self.Leader)
			local who = if player then player.DisplayName else "Someone"
			if self.Title then
				self.Title.Text = self.Name
				self.BidLabel.Text = "Top bid: " .. self.Top .. " max HP  (" .. who .. ")"
			end
			local panel = self.Panel
			if panel then
				setText(panel.Prize, self.Name)
				setText(panel.TopBid, "Top bid: " .. self.Top .. " max HP")
				setText(panel.Leader, if FX.IsMe(self.Leader) then "You" else who)
				-- your own number moves on to the least that beats it (unless you had already set it higher)
				self.Want = math.max(self.Want or 0, self.Top + self.StepSize)
			end
			FX.Sound("GavelKnock", self.Origin.Position + Vector3.new(0, 9, 0))
			if FX.IsMe(was) and not FX.IsMe(self.Leader) then
				self.OutbidAt = self:Time()
				FX.Sound("Outbid", nil, 1)
			end
			local root = FX.Root(self.Leader)
			if root then
				FX.Burst(root.Position + Vector3.new(0, 2, 0), "Ember", 6, { Color = EMBER })
			end
		end,

		-- (K.Call) the clock ran out: that player pays `price` max HP and takes the prize
		Sold = function(self, userId, price)
			self.EndAt = self:Time()
			self.SoldTo = tonumber(userId) or 0
			local player = FX.Player(self.SoldTo)
			local who = if player then player.DisplayName else "Someone"
			if self.Title then
				self.Title.Text = "SOLD!"
				self.BidLabel.Text = who .. " paid " .. tostring(price) .. " max HP"
				self.Clock.Text = ""
			end
			local panel = self.Panel
			if panel then
				local mine = FX.IsMe(self.SoldTo)
				setText(panel.Prize, "SOLD!")
				setText(panel.TopBid, self.Name)
				setText(panel.Leader, if mine then "to you" else "to " .. who)
				setText(panel.Amount, tostring(price))
				setText(panel.Status, if mine then "It is yours. It cost you " .. tostring(price) .. " max HP." else "You paid nothing.", self.StatusColor)
				shutPanel(panel, true)
				setButton(panel.Bid, false, "SOLD")
				self:After(3.4, function()
					closePanel(self)
				end)
			end
			FX.Sound("GavelKnock", self.Origin.Position + Vector3.new(0, 9, 0), 1.3, 0.7)
			FX.Sound("Sold", self.Origin.Position + Vector3.new(0, 9, 0))
			FX.Glint(self.Origin.Position + Vector3.new(0, 10, 0), Color3.fromRGB(220, 170, 80), 24, 3, 0.6)
		end,

		-- (K.Call) nobody bid (or the top bidder is gone)
		Unsold = function(self)
			self.EndAt = self:Time()
			if self.Title then
				self.Title.Text = "The Devil keeps it."
				self.BidLabel.Text = ""
				self.Clock.Text = ""
			end
			local panel = self.Panel
			if panel then
				setText(panel.Prize, "No sale")
				setText(panel.TopBid, "The Devil keeps it.")
				setText(panel.Leader, "")
				setText(panel.Status, "Nobody pays anything.", self.StatusColor)
				shutPanel(panel, false)
				setButton(panel.Bid, false, "CLOSED")
				self:After(3.4, function()
					closePanel(self)
				end)
			end
			FX.Sound("DevilLaugh", self.Origin.Position + Vector3.new(0, 9, 0))
			FX.Burst(self.Origin.Position + Vector3.new(0, 10, 0), "Smoke", 14, { Color = Color3.fromRGB(40, 34, 38) })
		end,
	},
})
