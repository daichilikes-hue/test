-- ModuleScript: ReplicatedStorage > EventClients > nails     (REPLACE)
-- What Bed of Nails looks like on each client: four iron grates on every plate. Each round three of them heat
-- up RED (all of them the same red, whatever kind of spike is under it), then the spikes shoot out of them. The
-- fourth stays dark with a soft blue glow: that one is safe.
-- Oct 10 2026 (update 9): no words over your head and no status cloud made here any more: bleeding / poison / fire
-- show on the character through StatusEffectsClient (the same for every event).
-- The server (Events > BedOfNails) decides who gets hurt; the safe square comes from the same maths here.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))

local C = FX.Colors
local IRON = Color3.fromRGB(52, 48, 56)
local STEEL = Color3.fromRGB(200, 202, 212)
local SAFE = Color3.fromRGB(120, 190, 255)
local RED = Color3.fromRGB(206, 9, 9) -- the glow of every grate that is about to spike, and of its spikes
local POP_SHAKE = 1.2  -- the jolt when the spikes on YOUR plate pop (was 2.2)
local lastShing = 0
local SPIKES = { Vector3.new(0, 0, 0), Vector3.new(-1, 0, -1), Vector3.new(1, 0, -1), Vector3.new(-1, 0, 1), Vector3.new(1, 0, 1) }

-- The safe square (1..4) of round `cycle` on a plate, and the kind of spike (1..3) on each square.
-- KEEP IN SYNC with layout() in ServerScriptService > Events > BedOfNails.
local function layout(seed: number, cycle: number): (number, { number })
	local rng = Random.new(seed * 1000 + cycle)
	local safe = rng:NextInteger(1, 4)
	local kinds = {}
	for tile = 1, 4 do
		kinds[tile] = rng:NextInteger(1, 3)
	end
	return safe, kinds
end

return FX.Module({
	Bed = {
		Init = function(self: any, props: any)
			local top: Vector3 = self.Origin.Position
			local qx, qz = (props.SX or 20) / 4, (props.SZ or 20) / 4
			self.Tall = props.Spike or 3
			self.Tiles = {}
			for i = 0, 1 do
				for j = 0, 1 do
					local middle = top + Vector3.new((i * 2 - 1) * qx, 0, (j * 2 - 1) * qz)
					local grate = FX.Block(self.Inst, Vector3.new(qx * 2 - 0.8, 0.16, qz * 2 - 0.8), CFrame.new(middle + Vector3.new(0, 0.09, 0)), IRON, Enum.Material.DiamondPlate)
					grate.Name = "Grate"
					local spikes = {}
					for _, spot in SPIKES do
						local at = middle + Vector3.new(spot.X * qx * 0.45, 0, spot.Z * qz * 0.45)
						local spike = FX.Egg(self.Inst, Vector3.new(0.95, 0.1, 0.95), CFrame.new(at), STEEL, Enum.Material.Metal, 1)
						spike.Name = "Spike"
						table.insert(spikes, spike)
					end
					-- (tile number = the server's: 1 = -X -Z, 2 = -X +Z, 3 = +X -Z, 4 = +X +Z)
					table.insert(self.Tiles, { Index = i * 2 + j + 1, Grate = grate, Spikes = spikes, Middle = middle, Height = -1, Look = "", Was = "down" })
				end
			end
			self.Cycle = -1
			self.Safe, self.Kinds = 0, { 1, 1, 1, 1 }
			self.Leaving = nil
		end,

		Step = function(self: any, _dt: number, t: number)
			local p = self.Props
			local tall: number = self.Tall
			local since = t - (p.Lead or 1.2)
			local phase: number, warn: number = p.Phase or 2.8, p.Warn or 1.3
			local cycle = math.floor(since / phase)
			local u = since - cycle * phase
			if since >= 0 and cycle ~= self.Cycle then
				self.Cycle = cycle
				self.Safe, self.Kinds = layout(p.Seed or 1, cycle)
			end
			local out = 1
			if self.Leaving then
				out = 1 - FX.Ease.Smooth(FX.Span(t, self.Leaving, self.Leaving + 0.6))
			end
			local poppedHere = false
			for _, tile in self.Tiles do
				-- how far out the spikes are (0..tall) and what the grate looks like
				local height, state, look = 0, "down", "cold"
				local color: Color3 = RED
				local glow = 0
				if since >= 0 then
					if tile.Index == self.Safe then
						state, look = "safe", "safe"
					elseif u < warn then
						local w = u / warn
						state, look = "warn", "warn"
						height = 0.22 * w + math.abs(math.sin(t * 40)) * 0.06 * w
						glow = 0.3 + 0.7 * w * (0.7 + 0.3 * math.sin(t * (10 + 20 * w)))
					else
						state, look = "up", "up"
						height = tall * FX.Ease.Back((u - warn) / 0.14) * (1 - FX.Ease.Smooth(FX.Span(u, phase - 0.22, phase)))
						glow = 1
					end
				end
				height *= out
				glow *= out
				if out < 0.5 then
					look = "cold" -- (the end: everything cools down)
				end
				local was = tile.Was
				tile.Was = state
				if state == "up" and was ~= "up" and not self.Leaving then
					-- SHING: they just popped, in their own colour
					if FX.Near(tile.Middle, 18, 70) > 0.25 then
						FX.Sparks(tile.Middle + Vector3.new(0, 0.5, 0), STEEL, 8)
						FX.Burst(tile.Middle + Vector3.new(0, 1, 0), "Spark", 6, { Color = color, Scale = 1.1 })
					end
					if os.clock() - lastShing > 0.3 then -- (one sound for the whole arena, not one per grate)
						lastShing = os.clock()
						FX.Sound("Shing", nil, 0.3, 1.3)
					end
					poppedHere = true
				end
				if math.abs(height - tile.Height) > 0.01 then
					tile.Height = height
					local hidden = height < 0.04
					for _, spike in tile.Spikes do
						spike.Size = Vector3.new(0.95, math.max(height * 2, 0.06), 0.95)
						spike.Transparency = if hidden then 1 else 0
					end
				end
				-- the grate: dark iron, heating up red, or the soft blue of the safe square
				local key = look .. (if look == "warn" then tostring(math.floor(glow * 20)) else "")
				if key ~= tile.Look then
					tile.Look = key
					local grate: BasePart = tile.Grate
					if look == "cold" then
						grate.Color, grate.Material = IRON, Enum.Material.DiamondPlate
					elseif look == "safe" then
						grate.Color, grate.Material = IRON:Lerp(SAFE, 0.35), Enum.Material.DiamondPlate
					else
						grate.Material = Enum.Material.Neon
						grate.Color = IRON:Lerp(color, math.clamp(glow, 0, 1))
					end
					for _, spike in tile.Spikes do
						spike.Color = if look == "up" then STEEL:Lerp(color, 0.55) else STEEL
					end
				end
			end
			-- a little jolt when the spikes on YOUR plate pop
			if poppedHere then
				local root = FX.MyRoot()
				local offset = root and (root.Position - self.Origin.Position)
				if offset and math.abs(offset.X) <= (p.SX or 20) / 2 and math.abs(offset.Z) <= (p.SZ or 20) / 2 and math.abs(offset.Y) < 9 then
					FX.Shake(POP_SHAKE, 18, 0.02, 0.25)
				end
			end
		end,

		-- (K.Strike) a stab: sparks in the spike's colour, a small shake if it is you
		Hit = function(_self: any, userId: number)
			local root = FX.Root(userId)
			if not root then
				return
			end
			FX.Burst(root.Position - Vector3.new(0, 2, 0), "Spark", 8, { Color = STEEL })
			FX.Sound("Thud", root.Position, 0.5, 1.5)
			if FX.IsMe(userId) then
				FX.Shake(1.2, 14, 0.03, 0.25)
				FX.Pulse(C.Blood, 0.65, 0.2)
			end
		end,

		-- the last moment: everything sinks back and cools down
		Outro = function(self: any, _seconds: number?)
			self.Leaving = self:Time()
		end,
	},
})
