-- ModuleScript: ReplicatedStorage > EventClients > spirittrain     (NEW)
-- What the Spirit Train looks like on each client. A pair of ghostly rails builds itself across the arena
-- and crossing lights flash at both ends with a bell (no red strip on the track any more: the rails are the
-- warning). Then it comes:
-- a see-through steam engine with a skull on its nose, a glaring lamp and a driver who has been dead for a
-- hundred years, pulling three carriages of ghosts staring out of lit windows. Smoke, sparks off the wheels,
-- streaks of light behind it, and the ground shakes while it goes by.
-- The server (Events > SpiritTrain) picks the track and decides who is hit.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))

local C = FX.Colors
local BODY = Color3.fromRGB(170, 214, 255)
local DARK = Color3.fromRGB(46, 62, 92)
local WINDOW = Color3.fromRGB(255, 226, 130)
local LAMP = Color3.fromRGB(255, 244, 200)
local RAIL = Color3.fromRGB(150, 205, 255)
local UP = Vector3.new(0, 1, 0)
local SEE = 0.38              -- how see-through its body is
local LYING = CFrame.Angles(math.pi / 2, 0, 0)   -- turns a standing cylinder so it lies along the track
local ACROSS = CFrame.Angles(0, 0, math.pi / 2)  -- turns a standing cylinder so it lies across the track (wheels)
local ENGINE = 17             -- studs: the engine, then a 1 stud gap
local CARRIAGE = 14           -- studs: each carriage, then a 1 stud gap
local SLEEPERS = 4.5          -- studs between sleepers
local PASS_SHAKE = 1          -- camera shake while it goes by, right next to you (was 3.2)
local HIT_SHAKE = 1.5         -- camera shake when it hits YOU (it used to punch, kick and flash the screen)

-- Everything is built round the middle of the vehicle, standing on the rails, with -Z as the way it goes.
local function buildEngine(parent: Instance): FX.Rig
	local rig = FX.Rig(parent)
	rig:Block("Frame", Vector3.new(5, 1, 16), CFrame.new(0, 1.9, 0), DARK, nil, 0.2)
	rig:Cyl("Boiler", 4.6, 9.4, CFrame.new(0, 4.7, -2.4) * LYING, BODY, Enum.Material.Glass, SEE)
	rig:Cyl("Smokebox", 5, 1, CFrame.new(0, 4.7, -7.5) * LYING, DARK, nil, 0.2)
	rig:Cyl("BandA", 4.8, 0.3, CFrame.new(0, 4.7, -4.4) * LYING, RAIL, Enum.Material.Neon, 0.2)
	rig:Cyl("BandB", 4.8, 0.3, CFrame.new(0, 4.7, -0.6) * LYING, RAIL, Enum.Material.Neon, 0.2)
	rig:Cyl("Chimney", 1.5, 2.8, CFrame.new(0, 8.2, -5.6), DARK, nil, 0.2)
	rig:Cyl("Funnel", 2.3, 0.8, CFrame.new(0, 9.8, -5.6), DARK, nil, 0.2)
	rig:Ball("Dome", 2.2, Vector3.new(0, 7, -1.6), RAIL, Enum.Material.Neon, 0.3)
	rig:Block("Cab", Vector3.new(5.6, 5.6, 5), CFrame.new(0, 5.2, 5), BODY, Enum.Material.Glass, SEE)
	rig:Block("CabRoof", Vector3.new(6.4, 0.5, 6), CFrame.new(0, 8.25, 5), DARK, nil, 0.2)
	rig:Wedge("Cowcatcher", Vector3.new(5.4, 2.4, 3), CFrame.new(0, 1.6, -9.4), RAIL, Enum.Material.Neon, 0.25)
	for _, side in { -1, 1 } do
		rig:Block("CabWindow", Vector3.new(0.16, 1.9, 2.6), CFrame.new(side * 2.85, 6.1, 5), WINDOW, Enum.Material.Neon, 0.1)
		for i = 1, 3 do
			local z = -5.5 + (i - 1) * 4.2
			rig:Cyl("Wheel", 3, 0.6, CFrame.new(side * 2.7, 1.5, z) * ACROSS, DARK, nil, 0.15)
			rig:Block((if side < 0 then "SpokeL" else "SpokeR") .. i, Vector3.new(0.7, 2.7, 0.3), CFrame.new(side * 2.9, 1.5, z), RAIL, Enum.Material.Neon, 0.2)
		end
		rig:Block(if side < 0 then "RodL" else "RodR", Vector3.new(0.3, 0.3, 9), CFrame.new(side * 3.2, 1.5, -1.3), RAIL, Enum.Material.Neon, 0.2)
	end
	-- the face on its nose, the lamp, and the driver
	FX.AddSkull(rig, "Skull", CFrame.new(0, 4.5, -8.3), 2.8, C.Bone, RAIL)
	rig:Add(FX.Ball(parent, 1.7, Vector3.new(), LAMP, Enum.Material.Neon), CFrame.new(0, 7.3, -7.6), "Lamp")
	FX.AddGhost(rig, "Driver", CFrame.new(0, 6, 4.4), 2.4, C.White, 0.25)
	return rig
end

local function buildCarriage(parent: Instance, index: number): FX.Rig
	local rig = FX.Rig(parent)
	rig:Block("Frame", Vector3.new(5, 0.8, 13), CFrame.new(0, 1.9, 0), DARK, nil, 0.2)
	rig:Block("Body", Vector3.new(5.4, 5, 13), CFrame.new(0, 4.8, 0), BODY, Enum.Material.Glass, SEE)
	rig:Block("Roof", Vector3.new(6, 0.5, 13.6), CFrame.new(0, 7.55, 0), DARK, nil, 0.2)
	rig:Block("Stripe", Vector3.new(5.5, 0.3, 13.05), CFrame.new(0, 3.3, 0), RAIL, Enum.Material.Neon, 0.25)
	rig:Block("Coupling", Vector3.new(0.6, 0.5, 2), CFrame.new(0, 1.9, -7.2), DARK, nil, 0.2)
	for _, side in { -1, 1 } do
		for i = 1, 4 do
			local z = -4.5 + (i - 1) * 3
			rig:Block("Window", Vector3.new(0.14, 1.9, 2), CFrame.new(side * 2.74, 5.3, z), WINDOW, Enum.Material.Neon, 0.1)
			-- a passenger staring out of every other window
			if (i + index + (if side < 0 then 0 else 1)) % 2 == 0 then
				rig:Egg("Passenger", Vector3.new(1.2, 1.5, 1.2), CFrame.new(side * 2, 5.2, z), C.White, Enum.Material.Neon, 0.15)
				for _, eye in { -0.25, 0.25 } do
					rig:Egg("Eye", Vector3.new(0.14, 0.34, 0.24), CFrame.new(side * 2.56, 5.35, z + eye), C.Black)
				end
			end
		end
		for _, z in { -4.2, 4.2 } do
			rig:Cyl("Wheel", 2.2, 0.5, CFrame.new(side * 2.7, 1.1, z) * ACROSS, DARK, nil, 0.15)
		end
	end
	if index == 3 then
		-- a red lantern swinging on the back of the last one
		rig:Add(FX.Ball(parent, 0.9, Vector3.new(), C.Warn, Enum.Material.Neon), CFrame.new(0, 4.4, 6.9), "Tail")
	end
	return rig
end

return FX.Module({
	Train = {
		Init = function(self: any, props: any)
			local origin: CFrame = self.Origin -- where it starts, far outside the arena; -Z is the way it goes
			local width: number, runUp: number, span: number = props.Width or 9, props.RunUp or 70, props.Span or 74
			local scale: number = props.Scale or 1 -- (the server can make the whole train bigger)
			self.Scale = scale
			local from, to = runUp - 8, runUp + span + 8 -- the piece of track that is drawn (studs along the line)
			self.From, self.To = from, to
			local function at(along: number, sideways: number?, height: number?): Vector3
				return (origin * CFrame.new(sideways or 0, height or 0, -along)).Position
			end
			self.At = at
			-- rails and sleepers (they build themselves from the end the train comes from): they ARE the warning
			self.Rails = {}
			for _, side in { -1, 1 } do
				-- (under the wheels, whatever size the train is)
				local rail = FX.Block(self.Inst, Vector3.new(0.3 * scale, 0.35, 1), CFrame.new(at(from, side * 2.8 * scale, 0.3)), RAIL, Enum.Material.Neon, 0.15)
				rail.Name = "Rail"
				table.insert(self.Rails, { Part = rail, Side = side * 2.8 * scale })
			end
			self.Sleepers = {}
			for along = from + 1, to - 1, SLEEPERS do
				local sleeper = FX.Block(self.Inst, Vector3.new(width - 2, 0.2, 0.9), CFrame.lookAt(at(along, 0, 0.14), at(along + 1, 0, 0.14)), DARK, nil, 1)
				sleeper.Name = "Sleeper"
				table.insert(self.Sleepers, { Part = sleeper, Along = along, Shown = false })
			end
			-- crossing lights at both ends of the arena, either side of the track
			self.Lamps = {}
			for _, along in { runUp + 1.5, runUp + span - 1.5 } do
				for _, side in { -1, 1 } do
					local foot = origin * CFrame.new(side * (width / 2 + 1.3), 0, -along)
					local post = FX.Rig(self.Inst)
					post:Cyl("Post", 0.34, 6.4, CFrame.new(0, 3.2, 0), C.Silver, Enum.Material.Metal)
					post:Block("Cross", Vector3.new(3.4, 0.5, 0.16), CFrame.new(0, 6.3, 0) * CFrame.Angles(0, 0, math.rad(40)), C.White)
					post:Block("Cross", Vector3.new(3.4, 0.5, 0.16), CFrame.new(0, 6.3, 0) * CFrame.Angles(0, 0, math.rad(-40)), C.White)
					post:Block("Bar", Vector3.new(2.4, 0.3, 0.3), CFrame.new(0, 4.5, 0), C.Black)
					for index, x in { -0.95, 0.95 } do
						local lamp = post:Add(FX.Ball(self.Inst, 0.95, Vector3.new(), C.Warn, Enum.Material.Neon), CFrame.new(x, 4.5, 0), "Lamp")
						local light = FX.Light(lamp, C.Warn, 14, 0)
						table.insert(self.Lamps, { Part = lamp, Light = light, Odd = index == 1 })
					end
					post:Move(foot * CFrame.Angles(0, math.pi / 2, 0))
				end
			end
			self.Mid = at((from + to) / 2, 0, 3)

			-- the train itself (it waits out of sight until the lights have flashed long enough)
			local engine = buildEngine(self.Inst)
			engine:Fade(1)
			self.Cars = { { Rig = engine, Back = ENGINE / 2 * scale } }
			for index = 1, 3 do
				local carriage = buildCarriage(self.Inst, index)
				carriage:Fade(1)
				table.insert(self.Cars, { Rig = carriage, Back = (ENGINE + 1 + (index - 1) * (CARRIAGE + 1) + CARRIAGE / 2) * scale })
			end
			local lamp = engine:Get("Lamp")
			if lamp then
				self.Headlight = FX.Light(lamp, LAMP, 60, 0)
				FX.Trail(lamp, LAMP, 2.6, 0.3)
			end
			local funnel = engine:Get("Funnel")
			if funnel then
				self.Smoke = FX.Emitter(funnel, "Glow", { Color = BODY, Rate = 46, Scale = 2.6, Lifetime = NumberRange.new(0.8, 1.5), Speed = NumberRange.new(4, 9), EmissionDirection = Enum.NormalId.Right })
			end
			local frame = engine:Get("Frame")
			if frame then
				self.Sparks = FX.Emitter(frame, "Spark", { Color = RAIL, Rate = 60, Scale = 0.8, EmissionDirection = Enum.NormalId.Bottom })
			end
			for index = 2, #self.Cars do
				-- a streak of light behind every carriage
				local body = self.Cars[index].Rig:Get("Body")
				if body then
					FX.Trail(body, RAIL, 5, 0.28, { Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.55), NumberSequenceKeypoint.new(1, 1) }) })
				end
			end
			self.NextBell, self.NextShake, self.NextChug = 0, 0, 0
			self.Running = false
			self.BuiltTo = 0
		end,

		Step = function(self: any, _dt: number, t: number)
			local p = self.Props
			local warn: number, speed: number, travel: number = p.Warn or 2.4, p.Speed or 105, p.Travel or 236
			local origin: CFrame = self.Origin
			local from: number, to: number = self.From, self.To
			local at: (number, number?, number?) -> Vector3 = self.At
			local front = (t - warn) * speed          -- how far its nose has come
			local done = front > travel
			local fade = if done then FX.Span(front, travel, travel + speed * 0.5) else 0

			-- the rails run out across the arena in the first second
			local built = from + (to - from) * FX.Ease.Out(t / 0.9)
			if built ~= self.BuiltTo or fade ~= (self.Faded or 0) then
				self.BuiltTo = built
				self.Faded = fade
				for _, rail in self.Rails do
					local part: BasePart = rail.Part
					local a, b = at(from, rail.Side, 0.3), at(math.max(built, from + 0.1), rail.Side, 0.3)
					part.Size = Vector3.new(part.Size.X, 0.35, (b - a).Magnitude)
					part.CFrame = CFrame.lookAt((a + b) / 2, b)
					part.Transparency = 0.15 + 0.85 * fade
				end
				for _, sleeper in self.Sleepers do
					if sleeper.Along <= built then
						sleeper.Part.Transparency = 0.45 + 0.55 * fade
					end
				end
			end

			-- crossing lights: left, right, left, right... with a bell, until it has gone by
			local flashing = not done
			local beat = math.floor(t * 4) % 2 == 0
			if flashing ~= self.Flashing or beat ~= self.Beat then
				self.Flashing, self.Beat = flashing, beat
				for _, lamp in self.Lamps do
					local on = flashing and (lamp.Odd == beat)
					lamp.Part.Color = if on then C.Warn else Color3.fromRGB(70, 20, 24)
					lamp.Part.Material = if on then Enum.Material.Neon else Enum.Material.SmoothPlastic
					lamp.Light.Brightness = if on then 3 else 0
				end
			end
			if flashing and t >= self.NextBell and front < 0 then
				self.NextBell = t + 0.5
				local near = FX.Near(self.Mid, 30, 150)
				if near > 0 and not FX.Sound("Bell", self.Mid, 0.8 * near) then
					FX.Sound("Ding", self.Mid, 0.55 * near, 0.62)
				end
			end

			if front < -speed * 0.6 then
				return
			end
			-- here it comes
			if not self.Running then
				self.Running = true
				if self.Smoke then
					self.Smoke.Enabled = not FX.Off("DisableParticles")
				end
				if self.Sparks then
					self.Sparks.Enabled = not FX.Off("DisableParticles")
				end
				if front < speed and not FX.Sound("Whistle", self.Mid, 1.2) then
					FX.Sound("Whoosh", self.Mid, 1.2, 0.45)
				end
			end
			local appear = FX.Span(front, -speed * 0.6, -speed * 0.2) * (1 - fade)
			local scale: number = self.Scale
			local turn = front / (1.5 * scale) -- (the wheels: one turn every 9.4 studs at size 1)
			for index, car in self.Cars do
				local rig: FX.Rig = car.Rig
				local along = front - car.Back
				rig:Fade(1 - appear)
				if index == 1 then
					for i = 1, 3 do
						local z = -5.5 + (i - 1) * 4.2
						rig:Pose("SpokeL" .. i, CFrame.new(-2.9, 1.5, z) * CFrame.Angles(turn, 0, 0))
						rig:Pose("SpokeR" .. i, CFrame.new(2.9, 1.5, z) * CFrame.Angles(turn, 0, 0))
					end
					local crank = Vector3.new(0, math.cos(turn) * 0.9, math.sin(turn) * 0.9)
					rig:Pose("RodL", CFrame.new(Vector3.new(-3.2, 1.5, -1.3) + crank))
					rig:Pose("RodR", CFrame.new(Vector3.new(3.2, 1.5, -1.3) - crank))
				elseif index == #self.Cars then
					rig:Pose("Tail", CFrame.new(math.sin(t * 7) * 0.5, 4.4 - math.abs(math.sin(t * 7)) * 0.15, 6.9))
				end
				rig:Move(origin * CFrame.new(0, math.sin(t * 15 + index * 1.7) * 0.07, -along) * CFrame.Angles(0, 0, math.sin(t * 9 + index) * 0.018), scale)
			end
			if self.Headlight then
				self.Headlight.Brightness = 4 * appear
			end
			if done and not self.Stopped then
				self.Stopped = true
				FX.SetEmitters(self.Inst, false)
			end

			-- you feel it go by: the nearer the track, the harder the shake
			local camera = workspace.CurrentCamera
			if camera and not done and front > 0 then
				local seen = origin:PointToObjectSpace(camera.CFrame.Position)
				local nearest = math.clamp(-seen.Z, front - (p.Length or 62), front) -- the closest bit of train to the camera
				local distance = (camera.CFrame.Position - at(nearest, 0, 4)).Magnitude
				local near = FX.Clamp01(1 - (distance - 14) / 70)
				if near > 0 and t >= self.NextShake then
					self.NextShake = t + 0.12
					FX.Shake(PASS_SHAKE * near, 18, 0.03, 0.22)
				end
				if near > 0.15 and t >= self.NextChug then
					self.NextChug = t + 0.15
					FX.Sound("Slam", at(nearest, 0, 3), 0.42 * near, 1.5)
				end
			end
		end,

		-- (K.Strike) that player was on the track. (No screen flash and no punch any more: just a small shake.)
		Hit = function(_self: any, userId: number)
			local root = FX.Root(userId)
			if root then
				FX.Burst(root.Position, "Glow", 16, { Color = BODY, Scale = 2.6 })
				FX.Burst(root.Position, "Spark", 14, { Color = C.Ghost })
				FX.Chunks(root.Position, 8, { RAIL, C.White }, { Size = 0.5, Speed = 20, Up = 22, Life = 1, Neon = true })
				FX.Popup(root.Position + UP * 5, "CHOO CHOO!", C.Ghost, 2.6)
				FX.Sound("Thud", root.Position, 0.7, 1.3)
			end
			if FX.IsMe(userId) then
				FX.Shake(HIT_SHAKE, 12, 0.03, 0.35)
				FX.Pulse(C.Blood, 0.65, 0.25)
			end
		end,
	},
})
