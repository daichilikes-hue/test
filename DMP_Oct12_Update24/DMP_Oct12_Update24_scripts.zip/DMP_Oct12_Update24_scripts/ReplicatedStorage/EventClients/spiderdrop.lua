-- ModuleScript: ReplicatedStorage > EventClients > spiderdrop     (REPLACE)
-- What Spider Drop looks like on each client.
-- Oct 10 2026 (update 9): NO dangling spiders. Spiders run across the arena from one border to the other and each
-- leaves a taut line of silk at shin height behind it: a tripwire. A wire that touches you sticks (grey wisps on
-- you). Three, and you are wrapped in a cocoon, and a huge spider sets off toward you from the edge of the arena: if
-- nobody tears you out before it gets there, it drags you off.
-- The wire is the model Thread under ServerScriptService > Events > SpiderDrop (a Beam named Silk between the
-- attachments A and B: Transparency 0 -> 0, Brightness 100, LightEmission 1, 0.05 wide). Restyle the Beam there.
-- The cocoon is the model Cocoon next to it.
-- Spiders: the jar's "Spider" (ReplicatedStorage > EventAssets > spiderdrop > Spider, copied there by the server
-- from ServerStorage > Items > Spider Jar) if it is a single part, otherwise a small built one.
-- The server (Events > SpiderDrop) decides every touch; the wires are laid by the same maths on both.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not (FX.RigFrom and FX.Clone) then
	warn("[spiderdrop] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end
local ReplicatedStorage = game:GetService("ReplicatedStorage")

-- YOUR SOUNDS ("" = a built-in Roblox sound instead, or silence)
--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	Skitter = { Id = "", Volume = 0.7, Speed = 1 },   -- spiders running
	SpiderHiss = { Id = "", Volume = 0.9, Speed = 1 }, -- the huge one
	Silk = { Id = "", Volume = 0.7, Speed = 1 },      -- a wire sticking to you
}
--[[DMP:END]]
for name, entry in SOUNDS do
	if not FX.Sounds[name] then
		FX.Sounds[name] = entry
		if entry.Id ~= "" then
			FX.Sound(name, nil, 0)
		end
	end
end
local function sound(name: string, fallback: string?, at: (Vector3 | Instance)?, volume: number?, speed: number?, fallbackSpeed: number?)
	if FX.Sound(name, at, volume, speed) == nil and fallback then
		FX.Sound(fallback, at, volume, fallbackSpeed or speed)
	end
end

local SILK = Color3.fromRGB(232, 230, 222)
local BODY = Color3.fromRGB(30, 26, 24)
local MARK = Color3.fromRGB(150, 84, 40)
local UP = Vector3.new(0, 1, 0)
local SPIDER_SIZE = 1.9       -- how big the spiders are (studs)
local BIG_SPIDER = 7          -- how big the one that comes for a cocoon is
local SPIDER_TURN = 0         -- degrees to turn YOUR spider mesh if it runs backwards or sideways (180, 90 or -90)

type Wire = {
	A: Vector3, B: Vector3, Dir: Vector3, Start: number, Speed: number, Length: number,
	A0: Attachment, A1: Attachment, Beam: Beam, Width: number, Spider: FX.Rig, Shown: boolean, Flash: number, Gone: boolean,
}

-- How far along wire `w` (studs from its A end) the silk reaches at time `t`.
-- KEEP IN SYNC with reached() in ServerScriptService > Events > SpiderDrop
local function reached(w: Wire, t: number): number
	return math.clamp((t - w.Start) * w.Speed, 0, w.Length)
end

local function spiderTemplate(): BasePart?
	local assets = ReplicatedStorage:FindFirstChild("EventAssets")
	local folder = assets and assets:FindFirstChild("spiderdrop")
	local spider = folder and folder:FindFirstChild("Spider")
	return if spider and spider:IsA("BasePart") then spider else nil
end

-- a spider standing on its feet, front = -Z: the jar's, sized to `size`, or a small built one (a rig either way)
local function buildSpider(parent: Instance, size: number): FX.Rig
	local rig = FX.Rig(parent)
	local template = spiderTemplate()
	if template then
		local part = template:Clone()
		local biggest = math.max(part.Size.X, part.Size.Y, part.Size.Z)
		part.Size = part.Size * (size / math.max(biggest, 0.05))
		part.Anchored = true
		part.CanCollide = false
		part.CanQuery = false
		part.CanTouch = false
		part.CastShadow = false
		part.Parent = parent
		rig:Add(part, CFrame.new(0, part.Size.Y / 2, 0) * CFrame.Angles(0, math.rad(SPIDER_TURN), 0), "Body")
		return rig
	end
	local s = size / 1.9
	rig:Ball("Body", 1.3 * s, Vector3.new(0, 0.75, 0.35) * s, BODY, Enum.Material.SmoothPlastic)
	rig:Ball("Head", 0.8 * s, Vector3.new(0, 0.6, -0.55) * s, BODY, Enum.Material.SmoothPlastic)
	rig:Block("Mark", Vector3.new(0.3, 0.12, 0.5) * s, CFrame.new(0, 1.38 * s, 0.4 * s), MARK, Enum.Material.SmoothPlastic)
	for _, turn in { 0.55, -0.55 } do
		rig:Block("Legs", Vector3.new(3.4, 0.12, 0.18) * s, CFrame.new(0, 0.35 * s, -0.1 * s) * CFrame.Angles(0, turn, 0), BODY, Enum.Material.SmoothPlastic)
	end
	return rig
end

-- one tripwire: a copy of the model Thread (or, if that is missing, the same thing made here)
local function newThread(parent: Instance): (Attachment, Attachment, Beam)
	local model = FX.Clone("spiderdrop", "Thread", parent)
	local a = model and model:FindFirstChild("A", true)
	local b = model and model:FindFirstChild("B", true)
	local beam = model and model:FindFirstChild("Silk", true)
	if a and b and beam and a:IsA("Attachment") and b:IsA("Attachment") and beam:IsA("Beam") then
		return a, b, beam
	end
	local anchor = FX.Block(parent, Vector3.new(0.2, 0.2, 0.2), CFrame.new(), SILK, nil, 1)
	anchor.Name = "ThreadAnchor"
	local a0, a1 = FX.Attach(anchor), FX.Attach(anchor)
	local made = FX.Beam(anchor, a0, a1, SILK, 0.05, { Brightness = 100, LightEmission = 1, LightInfluence = 0, FaceCamera = true, Segments = 1, Transparency = NumberSequence.new(0, 0) })
	return a0, a1, made
end

return FX.Module({
	Web = {
		Init = function(self: any, props: any)
			local flat: { number } = props.Wires or {}
			local y: number = self.Origin.Position.Y -- (the height of every wire)
			self.Wires = {}
			for i = 1, #flat - 5, 6 do
				local a, b = Vector3.new(flat[i], y, flat[i + 1]), Vector3.new(flat[i + 2], y, flat[i + 3])
				local a0, a1, beam = newThread(self.Inst)
				beam.Enabled = false
				local spider = buildSpider(self.Inst, SPIDER_SIZE)
				spider:Fade(1)
				local wire: Wire = {
					A = a, B = b, Dir = FX.Dir(b - a), Start = flat[i + 4], Speed = flat[i + 5], Length = (b - a).Magnitude,
					A0 = a0, A1 = a1, Beam = beam, Width = beam.Width0, Spider = spider, Shown = false, Flash = -10, Gone = false,
				}
				table.insert(self.Wires, wire)
			end
			self.Cocoons = {}
			self.NextSkitter = 0.6
			self.Floor = y - (props.Height or 1.4) -- the plate tops
		end,

		-- (K.Signal) wire `index` stuck to that player: they have touched `count` now
		Touch = function(self: any, userId: number, index: number, count: number)
			local wire: Wire? = self.Wires[index]
			if wire then
				wire.Flash = self:Time()
			end
			local root = FX.Root(userId)
			if root then
				FX.Burst(root.Position - UP * 1.5, "Glow", 6, { Color = SILK, Scale = 0.9 })
				sound("Silk", "Shuffle", root.Position, 0.5 * FX.Near(root.Position, 20, 90), 1, 1.6)
				if not FX.Off("DisableParticles") then
					local wisps = FX.Emitter(root, "Glow", { Color = SILK, Rate = 4, Scale = 0.5, Lifetime = NumberRange.new(0.6, 1.2) })
					wisps.Enabled = true
					game:GetService("Debris"):AddItem(wisps, 8)
				end
			end
			if FX.IsMe(userId) then
				FX.Pulse(Color3.fromRGB(60, 58, 54), 0.6, 0.3)
				if count == 2 then
					FX.Banner("SILK", "Two wires on you. One more and you're wrapped.", SILK, 2.2)
				end
			end
		end,

		-- (K.Signal) that player has been wrapped up; in `seconds` the huge spider reaches them
		Cocoon = function(self: any, userId: number, position: Vector3, seconds: number)
			local model = FX.Clone("spiderdrop", "Cocoon", self.Inst)
			local rig = FX.RigFrom(model, if model then model:GetPivot() else nil)
			rig:Move(CFrame.new(position))
			-- the huge spider sets off from the nearest edge of the arena, straight at the cocoon
			local middle: Vector3 = self.Origin.Position
			local halfX: number, halfZ: number = self.Props.HalfX or 98, self.Props.HalfZ or 98
			local toX = halfX - math.abs(position.X - middle.X)
			local toZ = halfZ - math.abs(position.Z - middle.Z)
			local from: Vector3
			if toX <= toZ then
				from = Vector3.new(middle.X + (if position.X >= middle.X then halfX else -halfX), self.Floor, position.Z)
			else
				from = Vector3.new(position.X, self.Floor, middle.Z + (if position.Z >= middle.Z then halfZ else -halfZ))
			end
			local big = buildSpider(self.Inst, BIG_SPIDER)
			big:Fade(1)
			self.Cocoons[userId] = { Rig = rig, Since = self:Time(), Seconds = seconds, Eaten = nil, Position = position, Big = big, From = from, BigAt = from, Hissed = false }
			FX.Burst(position, "Glow", 14, { Color = SILK, Scale = 1.6 })
			sound("Silk", "Shuffle", position, 0.8, 1, 1.2)
			if FX.IsMe(userId) then
				FX.Banner("WRAPPED", "You can't move. Somebody has to tear you out before the spider gets here...", SILK, seconds)
				self:Vignette(0.35, seconds, Color3.fromRGB(10, 8, 8))
			end
		end,

		-- (K.Signal) somebody tore that player out: the huge spider turns back
		Freed = function(self: any, userId: number)
			local cocoon = self.Cocoons[userId]
			if not cocoon then
				return
			end
			self.Cocoons[userId] = nil
			local rig: FX.Rig = cocoon.Rig
			FX.Chunks(cocoon.Position, 14, { SILK, Color3.fromRGB(160, 158, 150) }, { Size = 0.6, Speed = 14, Up = 14, Life = 1.2, Flat = true })
			rig:Destroy()
			self.Retreats = self.Retreats or {}
			table.insert(self.Retreats, { Big = cocoon.Big, From = cocoon.BigAt, To = cocoon.From, Since = self:Time() })
			if FX.IsMe(userId) then
				self:VignetteOff(0.4)
			end
		end,

		-- (K.Signal) nobody came: the huge spider is on the cocoon and drags it off
		Eaten = function(self: any, userId: number)
			local cocoon = self.Cocoons[userId]
			if not cocoon or cocoon.Eaten then
				return
			end
			cocoon.Eaten = self:Time()
			sound("SpiderHiss", "Lunge", cocoon.Position, 1, 1, 0.4)
			if FX.IsMe(userId) then
				self:Vignette(0, 0.9, Color3.fromRGB(0, 0, 0))
			end
		end,

		Step = function(self: any, _dt: number, t: number)
			local climbTime: number = self.Props.Climb or 2
			local leaving: number? = self.Leaving
			local running: Vector3? = nil
			for index, wire: Wire in self.Wires do
				if t < wire.Start or wire.Gone then
					continue
				end
				if not wire.Shown then
					wire.Shown = true
					wire.Beam.Enabled = true
					wire.Spider:Fade(0)
				end
				-- how far the silk reaches: growing behind the spider; at the end it is taken back the same way
				local far = reached(wire, t)
				local back = false
				if leaving then
					far *= 1 - FX.Ease.Smooth(FX.Span(t, leaving, leaving + climbTime * 0.9))
					back = true
				end
				local head = wire.A + wire.Dir * far
				wire.A0.WorldPosition = wire.A
				wire.A1.WorldPosition = head
				local moving = (far < wire.Length - 0.05 and not back) or (back and far > 0.05)
				if moving then
					running = head
				end
				-- the spider: at the end of its silk, scuttling while it runs; sitting at the far border once it is there
				local bob = if moving then math.abs(math.sin(t * 24 + index)) * 0.1 else math.max(math.sin(t * 2.1 + index * 1.3) - 0.9, 0) * 1.2
				local facing = if back then -wire.Dir else wire.Dir
				wire.Spider:Move(CFrame.lookAt(head + UP * bob, head + UP * bob + facing))
				-- a wire that has just stuck to somebody twangs
				local flash = 1 - math.clamp((t - wire.Flash) / 0.5, 0, 1)
				local width = wire.Width * (1 + 3 * flash)
				if math.abs(wire.Beam.Width0 - width) > 0.002 then
					wire.Beam.Width0, wire.Beam.Width1 = width, width
				end
				if back and far <= 0.05 then
					wire.Gone = true
					wire.Beam.Enabled = false
					wire.Spider:Fade(1)
				end
			end
			if running and t >= self.NextSkitter then
				self.NextSkitter = t + 0.8
				sound("Skitter", "Shuffle", running, 0.4 * FX.Near(running, 30, 120), 1, 1.4)
			end

			-- cocoons, and the huge spider walking in for each of them
			local floor: number = self.Floor
			for userId, cocoon in self.Cocoons do
				local eaten: number? = cocoon.Eaten
				local big: FX.Rig = cocoon.Big
				local from: Vector3 = cocoon.From
				-- (the cocoon follows its player until the spider takes it; after that the player may already be gone)
				local root = if eaten then nil else FX.Root(userId)
				local at: Vector3 = if root then root.Position else cocoon.Position
				local ground = Vector3.new(at.X, floor, at.Z)
				local toward = FX.Dir(ground - from)
				if not eaten then
					-- on its way: it reaches the cocoon as the time runs out
					local walk = FX.Ease.Smooth(FX.Span(t, cocoon.Since + 0.4, cocoon.Since + cocoon.Seconds))
					local reach = math.max((ground - from).Magnitude - BIG_SPIDER * 0.55, 0)
					local spot = from + toward * (reach * walk)
					big:Fade(1 - FX.Clamp01((t - cocoon.Since - 0.4) / 0.3))
					big:Move(CFrame.lookAt(spot + UP * math.abs(math.sin(t * 14)) * 0.25, spot + toward))
					cocoon.BigAt = spot
					if walk > 0.05 and not cocoon.Hissed then
						cocoon.Hissed = true
						sound("Skitter", "Shuffle", spot, 0.8 * FX.Near(spot, 40, 160), 0.7, 0.9)
					end
				else
					-- it has it: a short pounce, then it backs off toward the edge, dragging the cocoon along
					cocoon.Base = cocoon.Base or ground
					local base: Vector3 = cocoon.Base
					local dragTime: number = (self.Props.Eaten or 1.2) + 1.6
					local drag = FX.Ease.In(FX.Span(t, eaten + 0.3, eaten + dragTime))
					local total = (base - from).Magnitude
					local spot = base - toward * (BIG_SPIDER * 0.55 * (1 - FX.Span(t, eaten, eaten + 0.25)) + total * drag)
					big:Fade(0)
					big:Move(CFrame.lookAt(spot + UP * math.abs(math.sin(t * 16)) * 0.3, spot + toward))
					at = spot + toward * (BIG_SPIDER * 0.5) + UP * (at.Y - floor)
					if drag >= 1 then
						big:Destroy()
						cocoon.Rig:Destroy()
						self.Cocoons[userId] = nil
						continue
					end
				end
				cocoon.Position = at
				cocoon.Rig:Move(CFrame.new(at) * CFrame.Angles(0, t * 0.3, 0))
			end
			-- huge spiders whose cocoon was torn open: back to the edge and gone
			local retreats = self.Retreats
			if retreats then
				for index = #retreats, 1, -1 do
					local retreat = retreats[index]
					local big: FX.Rig = retreat.Big
					local go = FX.Ease.Smooth(FX.Span(t, retreat.Since + 0.2, retreat.Since + 1.4))
					local spot: Vector3 = retreat.From:Lerp(retreat.To, go)
					big:Move(CFrame.lookAt(spot + UP * math.abs(math.sin(t * 14)) * 0.25, spot + FX.Dir(retreat.To - retreat.From)))
					if go >= 1 then
						big:Destroy()
						table.remove(retreats, index)
					end
				end
			end
		end,

		Outro = function(self: any, _seconds: number?)
			if not self.Leaving then
				self.Leaving = self:Time()
				sound("Skitter", "Shuffle", self.Origin.Position, 0.5, 1, 1.2)
			end
		end,
	},
})
