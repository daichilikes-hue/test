-- ModuleScript: ReplicatedStorage > EventClients > lilies     (NEW: Oct 12 Update 23, Grave Lilies)
-- What Grave Lilies looks like on each client. The server (Events > GraveLilies) makes the prompts and gives the
-- heal / buff / item; this draws each lily (the model Lily under ServerScriptService > Events > GraveLilies): it
-- pushes up out of the plate, then its petals open with a soft glow; picked = the petals scatter in the air with a
-- sparkle on whoever picked it; never picked = it droops and fades at the end. It rides on its plate.
-- Restyle the model there; keep Head (with the PointLight Glow and the emitter Pollen) and Petal1..6 (Yaw / Open).
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not (FX.OnPlate and FX.UseSounds) then
	warn("[lilies] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end

-- Sounds: paste your own ids into Id (Stand = a Roblox stand-in; "" = silence)
--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	LilyBloom = { Id = "", Stand = "", Speed = 1, Volume = 0.5 },                                          -- a lily opens
	LilyPick = { Id = "", Stand = "rbxasset://sounds/electronicpingshort.wav", Speed = 0.7, Volume = 0.35 }, -- somebody picks one
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

local SIZE = 1.5            -- how big the lilies are (1 = as the model is made)
local GROW = 0.7            -- seconds it takes to push up out of the plate
local OPEN = 0.9            -- seconds the petals take to open (after it has grown)
local CLOSED = 82           -- degrees the petals stand up while still closed (0 = flat open, 90 = straight up)
local WILT = 1.2            -- seconds it droops and fades at the end
local SCATTER = 1.2         -- seconds the petals fly when it is picked
local SPARKLE = Color3.fromRGB(214, 240, 226)

return FX.Module({
	Lily = {
		Init = function(self: any, props: any)
			self.Follow = FX.OnPlate(props.Tag, self.Origin)
			self.Delay = tonumber(props.Delay) or 0
			local inverse = self.Origin:Inverse()
			local head = self.Inst:FindFirstChild("Head")
			self.HeadAt = if head and head:IsA("BasePart") then inverse * head.CFrame else CFrame.new(0, 2.25, 0)
			self.Parts = {}
			self.Petals = {}
			for _, part in self.Inst:GetChildren() do
				if part:IsA("BasePart") and part.Name ~= "Root" then
					local entry = { Part = part, Offset = inverse * part.CFrame, Size = part.Size, Transparency = part.Transparency }
					if string.sub(part.Name, 1, 5) == "Petal" then
						entry.Yaw = math.rad(tonumber(part:GetAttribute("Yaw")) or 0)
						entry.Open = tonumber(part:GetAttribute("Open")) or 55
						entry.Spin = Vector3.new(math.random() - 0.5, math.random() - 0.5, math.random() - 0.5) * 8
						table.insert(self.Petals, entry)
					else
						table.insert(self.Parts, entry)
					end
					part.Transparency = 1
				end
			end
			local glow = head and head:FindFirstChildOfClass("PointLight")
			self.Light = glow
			self.Brightness = glow and glow.Brightness or 0.8
			self.Pollen = head and head:FindFirstChild("Pollen")
		end,

		Step = function(self: any, dt: number, t: number)
			local base, there = self.Follow()
			local duration = tonumber(self.Props.Duration) or 18
			local since = t - self.Delay
			local grown = FX.Ease.Back(FX.Clamp01(since / GROW))
			local open = FX.Ease.Out(FX.Clamp01((since - GROW * 0.6) / OPEN))
			local wilt = FX.Clamp01((t - (duration - WILT)) / WILT)
			if not there and self.WasThere then
				wilt = 1 -- (its plate is gone)
			end
			self.WasThere = self.WasThere or there
			local picked = if self.PickedAt then FX.Clamp01((t - self.PickedAt) / SCATTER) else 0
			if not self.Bloomed and open > 0.5 then
				self.Bloomed = true
				FX.Sound("LilyBloom", base.Position)
			end
			local alpha = math.max(wilt, picked) -- (0 = all there, 1 = gone)
			local scale = math.max(grown, 0.02) * (1 - 0.6 * picked) * SIZE
			for _, entry in self.Parts do
				local o: CFrame = entry.Offset
				local part: BasePart = entry.Part
				part.Size = entry.Size * scale
				part.CFrame = base * CFrame.new(o.Position * scale) * (o - o.Position)
				part.Transparency = if since <= 0 then 1 else entry.Transparency + (1 - entry.Transparency) * alpha
			end
			local head = base * CFrame.new(self.HeadAt.Position * scale)
			for index, petal in self.Petals do
				local part: BasePart = petal.Part
				local lean = CLOSED + (petal.Open - CLOSED) * open - 45 * wilt
				local cf = head * CFrame.Angles(0, petal.Yaw, 0) * CFrame.Angles(math.rad(lean), 0, 0) * CFrame.new(0, 0, -0.5 * scale)
				if picked > 0 then
					-- (picked: the petals fly up and out, tumbling)
					local out = (cf.Position - head.Position).Unit
					cf = CFrame.new(cf.Position + out * 4 * picked + Vector3.new(0, 3 * picked - 2 * picked * picked, 0))
						* CFrame.fromEulerAnglesXYZ(petal.Spin.X * picked, petal.Spin.Y * picked + index, petal.Spin.Z * picked)
				end
				part.Size = petal.Size * scale
				part.CFrame = cf
				part.Transparency = if since <= 0 then 1 else petal.Transparency + (1 - petal.Transparency) * alpha
			end
			local light: PointLight? = self.Light
			if light then
				local flare = if self.PickedAt then 2.5 * (1 - picked) else 1
				light.Brightness = self.Brightness * open * (1 - wilt) * flare
			end
		end,

		-- somebody picked it
		Picked = function(self: any, userId: number)
			self.PickedAt = self:Time()
			local pollen = self.Pollen
			if pollen and pollen:IsA("ParticleEmitter") and not FX.Off("DisableParticles") then
				pollen:Emit(tonumber(pollen:GetAttribute("EmitCount")) or 8)
			end
			FX.Sound("LilyPick", self.Origin.Position)
			local root = FX.Root(userId)
			if root then
				FX.Burst(root.Position, "Star", 6, { Color = SPARKLE, Scale = 0.6 })
			end
		end,
	},
})
