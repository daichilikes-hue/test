-- ModuleScript: ReplicatedStorage > EventClients > withering     (NEW: Oct 11 Update 19, The Withering)
-- What The Withering looks like on each client. The server (Events > TheWithering) makes the real plate thinner, a
-- strip off both long sides at a time, down to a narrow beam (never destroyed). This draws it dying: an ashen film
-- spreads over it; before each strip falls a jagged crack opens where the new edge will be (the tell: get off that
-- strip); then the strip breaks away as tumbling stones with dust, a crumbling sound and a little shake (less the
-- farther you are). The pieces are the model Wither under ServerScriptService > Events > TheWithering (Ash, Crack,
-- Crumbs): restyle them freely, keep the names.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not (FX.Tagged and FX.UseSounds) then
	warn("[withering] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end

-- Sounds: paste your own ids into Id (the Stand ones are Roblox stand-ins)
--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	WitherCrack = { Id = "", Stand = "rbxasset://sounds/unsheath.wav", Speed = 0.4, Volume = 0.8 },         -- a strip cracks (the tell)
	WitherCrumble = { Id = "", Stand = "rbxasset://sounds/action_jump_land.mp3", Speed = 0.5, Volume = 1.3 }, -- it breaks off and falls
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

local SHAKE = 0.8           -- each crumble shakes the camera of whoever is near it (0 = none)
local FALL = 1.4            -- seconds the stones of a strip are seen falling
local GRAVITY = 60          -- how fast they fall
local DUST = Color3.fromRGB(104, 94, 100)

-- the plate's width along the axis it withers on, its length along the other
local function measure(plate: BasePart, axis: string): (number, number)
	if axis == "X" then
		return plate.Size.X, plate.Size.Z
	end
	return plate.Size.Z, plate.Size.X
end

-- a CFrame on the plate's top: `across` studs from its middle line along the withering axis, `up` above the top,
-- turned so that its X runs ALONG the plate's length (the way an edge runs)
local function onTop(plate: BasePart, axis: string, across: number, up: number): CFrame
	local top = plate.CFrame * CFrame.new(0, plate.Size.Y / 2 + up, 0)
	if axis == "X" then
		return top * CFrame.new(across, 0, 0) * CFrame.Angles(0, math.rad(90), 0)
	end
	return top * CFrame.new(0, 0, across)
end

-- a copy of a template group (Crack / Crumbs: built 20 studs long along X round the model's Root), stretched to
-- `length`. origin = where the model's Root was when the template was taken out of it
local function stretched(template: Instance, origin: CFrame, parent: Instance, length: number): { { Part: BasePart, Offset: CFrame, Transparency: number } }
	local copy = template:Clone()
	local k = length / 20
	local pieces = {}
	for _, item in copy:GetChildren() do
		if item:IsA("BasePart") and item.Name ~= "Root" then
			local offset = origin:ToObjectSpace(item.CFrame)
			offset = offset.Rotation + Vector3.new(offset.Position.X * k, offset.Position.Y, offset.Position.Z)
			if string.sub(item.Name, 1, 3) == "Seg" then
				item.Size = Vector3.new(item.Size.X * k, item.Size.Y, item.Size.Z)
			end
			item.Parent = parent
			table.insert(pieces, { Part = item, Offset = offset, Transparency = item.Transparency })
		end
	end
	copy:Destroy()
	return pieces
end

return FX.Module({
	Wither = {
		Init = function(self: any, props: any)
			local inst: Instance = self.Inst
			-- the templates leave the model (they are only copied); the ash stays and follows the plate
			for _, name in { "Crack", "Crumbs" } do
				local template = inst:FindFirstChild(name)
				if template then
					template.Parent = nil
					self[name] = template
					self:Keep(template)
				end
			end
			local ash = inst:FindFirstChild("Ash")
			if ash and ash:IsA("BasePart") then
				self.Ash, self.AshTransparency = ash, ash.Transparency
				ash.Transparency = 1
			end
			self.Cracks = {} -- [step] = pieces
			self.Falling = {} -- stones on their way down
			self.Axis = if props.Axis == "X" then "X" else "Z"
		end,

		Step = function(self: any, dt: number, t: number)
			local p = self.Props
			local plate: Instance? = self.Plate
			if not (plate and plate.Parent) then
				plate = FX.Tagged(p.Tag)
				self.Plate = plate
			end
			if plate and plate:IsA("BasePart") then
				local part: BasePart = plate
				local axis: string = self.Axis
				local width, length = measure(part, axis)
				self.Width = self.Width or width
				-- the ash spreads over it while it cracks for the first time, and keeps to its shrinking size
				local ash: BasePart? = self.Ash
				if ash then
					local cover = FX.Clamp01(t / math.max(p.Warn or 1.6, 0.1))
					ash.Transparency = 1 - (1 - (self.AshTransparency or 0.45)) * cover
					ash.Size = Vector3.new(part.Size.X - 0.02, ash.Size.Y, part.Size.Z - 0.02)
					ash.CFrame = part.CFrame * CFrame.new(0, part.Size.Y / 2 + ash.Size.Y / 2 + 0.005, 0)
				end
				-- the tell: before each strip falls, a crack opens along where the new edge will be (both sides)
				local steps: number = p.Steps or 6
				for step = 1, steps do
					local at = (p.Warn or 1.6) + (step - 1) * (p.StepTime or 1.15)
					local opening = FX.Span(t, at - (p.Crack or 0.7), at)
					local newWidth = (p.From or width) - ((p.From or width) - (p.To or 4)) * step / steps
					local cracks = self.Cracks[step]
					if opening > 0 and opening < 1 and not cracks and self.Crack and width > newWidth + 0.05 then
						cracks = {}
						for _, side in { -1, 1 } do
							for _, piece in stretched(self.Crack, self.Origin, self.Inst, length) do
								piece.Side = side
								table.insert(cracks, piece)
							end
						end
						self.Cracks[step] = cracks
						local middle = onTop(part, axis, newWidth / 2, 0).Position
						FX.Sound("WitherCrack", middle, 0.8 * FX.Near(middle, 30, 120), 0.9 + step * 0.05)
					end
					if cracks then
						if width <= newWidth + 0.05 or t > at + 0.5 then
							-- (that strip has fallen: its crack is the new edge)
							for _, piece in cracks do
								piece.Part:Destroy()
							end
							self.Cracks[step] = false
						else
							for _, piece in cracks do
								local across = piece.Side * (newWidth / 2)
								piece.Part.CFrame = onTop(part, axis, across, 0) * piece.Offset
								piece.Part.Transparency = piece.Transparency + (1 - piece.Transparency) * (1 - FX.Clamp01(opening * 2.5))
							end
						end
					end
				end
				-- a strip fell (the server made it thinner): it breaks away as stones, with dust and a crumble
				if width < self.Width - 0.05 then
					local was: number = self.Width
					self.Width = width
					local rng = Random.new(math.floor(t * 1000))
					for _, side in { -1, 1 } do
						local across = side * (was + width) / 4 -- (the middle of the strip that fell)
						if self.Crumbs then
							for _, piece in stretched(self.Crumbs, self.Origin, self.Inst, length) do
								local start = onTop(part, axis, across, -part.Size.Y / 2 + 0.3) * piece.Offset
								table.insert(self.Falling, {
									Part = piece.Part, Start = start, Transparency = piece.Transparency, Since = 0,
									Push = onTop(part, axis, 0, 0):VectorToWorldSpace(Vector3.new(0, 0, side * rng:NextNumber(1.5, 4))),
									Spin = Vector3.new(rng:NextNumber(-3, 3), rng:NextNumber(-3, 3), rng:NextNumber(-3, 3)),
								})
								piece.Part.CFrame = start
							end
						end
						for _, along in { -0.35, 0, 0.35 } do
							local spot = (onTop(part, axis, across, 0) * CFrame.new(along * length, 0, 0)).Position
							FX.Burst(spot, "Dust", 5, { Color = DUST, Scale = 1.2 })
						end
					end
					local middle = part.Position
					FX.Sound("WitherCrumble", middle, FX.Near(middle, 35, 140), rng:NextNumber(0.9, 1.1))
					FX.Shake(SHAKE, 9, 0.02, 0.3, middle, 25, 100)
				elseif width > self.Width + 0.05 then
					self.Width = width -- (it grew back: PERMANENT = false at the end)
				end
			end
			-- the stones fall, tumble and fade
			for index = #self.Falling, 1, -1 do
				local stone = self.Falling[index]
				stone.Since += dt
				local s: number = stone.Since
				if s >= FALL then
					stone.Part:Destroy()
					table.remove(self.Falling, index)
				else
					local drop = Vector3.new(0, -0.5 * GRAVITY * s * s, 0) + stone.Push * s
					local spin: Vector3 = stone.Spin
					stone.Part.CFrame = (stone.Start + drop) * CFrame.Angles(spin.X * s, spin.Y * s, spin.Z * s)
					stone.Part.Transparency = stone.Transparency + (1 - stone.Transparency) * FX.Span(s, FALL * 0.55, FALL)
				end
			end
		end,
	},
})
