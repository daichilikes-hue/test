-- ModuleScript: ReplicatedStorage > EventClients > thepact     (Oct 8 2026 update 3; renamed from "pact" on Oct 10,
-- because The Pact's Id is "thepact" now: "pact" is your Blood Pact. Nothing else in here changed.)
-- Draws The Pact (server: ServerScriptService > Events > ThePact): a tall black candle on a rusted iron stand
-- rises on each of two far-apart plates, wax running down it, unlit. Lighting one gives it a dull red flame.
-- When both are lit they flare, a red thread snaps between the two players for a moment, and they burn down.

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local FX = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("EventFX"))

-- Your sound ids go in Id. While Id is "", Stand plays (a built-in Roblox sound; "" = silent).
--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	CandleLight = { Id = "", Stand = "rbxasset://sounds/unsheath.wav", Speed = 0.5, Volume = 0.6 }, -- a candle is lit
	PactSeal = { Id = "", Stand = "", Speed = 1, Volume = 1 },                                      -- the pact is sealed
}
--[[DMP:END]]
FX.UseSounds(SOUNDS)

local WAX = Color3.fromRGB(26, 22, 24)
local DRIP = Color3.fromRGB(46, 40, 42)
local IRON = Color3.fromRGB(70, 46, 34)
local FLAME = Color3.fromRGB(190, 50, 34)
local THREAD = Color3.fromRGB(150, 30, 30)

return FX.Module({
	Candle = {
		Init = function(self, props)
			self.Arrive = tonumber(props.Arrive) or 1.5
			self.Lit = false
			local rig = FX.Rig(self.Inst)
			self.Rig = rig
			rig:Cyl("Dish", 1.8, 0.2, CFrame.new(0, 0.1, 0), IRON, Enum.Material.CorrodedMetal)
			for i = 0, 2 do
				local a = i * math.pi * 2 / 3
				rig:Line("Leg", Vector3.new(math.cos(a) * 0.4, 1.8, math.sin(a) * 0.4), Vector3.new(math.cos(a) * 1.0, 0.1, math.sin(a) * 1.0), 0.14, IRON, Enum.Material.CorrodedMetal)
			end
			rig:Cyl("Cup", 1.0, 0.3, CFrame.new(0, 1.9, 0), IRON, Enum.Material.CorrodedMetal)
			rig:Cyl("Wax", 0.75, 3.2, CFrame.new(0, 3.6, 0), WAX)
			rig:Egg("Drip", Vector3.new(0.2, 1.2, 0.2), CFrame.new(0.34, 3.3, 0.1), DRIP)
			rig:Egg("Drip", Vector3.new(0.18, 0.8, 0.18), CFrame.new(-0.3, 4.2, -0.16), DRIP)
			rig:Line("Wick", Vector3.new(0, 5.2, 0), Vector3.new(0, 5.5, 0), 0.06, Color3.fromRGB(10, 10, 10))
			FX.AddFlame(rig, "Flame", CFrame.new(0, 5.45, 0), 0.32, FLAME)
			rig:Hide("Flame")
			self.Light = FX.Light(rig:Get("Wax") :: BasePart, FLAME, 16, 0)
			rig:Move(self.Origin * CFrame.new(0, -6, 0))
		end,

		Step = function(self, _dt, t)
			local up = FX.Ease.Out(FX.Clamp01(t / self.Arrive))
			local down = if self.EndAt then FX.Ease.In(FX.Clamp01((t - self.EndAt) / 2.5)) else 0
			if self.Lit then
				FX.Flicker(self.Rig, "Flame", 0.32 * (if self.SealAt and t - self.SealAt < 0.6 then 2.2 else 1), t, 4)
				self.Light.Brightness = 1.4 + FX.Noise(3, t * 4) * 0.4
			end
			self.Rig:Move(self.Origin * CFrame.new(0, -6 * (1 - up) - 6 * down, 0))
		end,

		Lit = function(self, userId)
			self.Lit = true
			self.Rig:Hide("Flame", false)
			local tip = self.Origin.Position + Vector3.new(0, 5.6, 0)
			FX.Sound("CandleLight", tip)
			FX.Burst(tip, "Ember", 8, { Color = FLAME })
			self.UserId = tonumber(userId) or 0
		end,

		Sealed = function(self)
			self.SealAt = self:Time()
			self.EndAt = self:Time() + 3
			local tip = self.Origin.Position + Vector3.new(0, 5.6, 0)
			FX.Sound("PactSeal", tip)
			FX.Glint(tip, FLAME, 20, 3, 0.6)
			local root = self.UserId and FX.Root(self.UserId)
			if root then
				FX.Lightning(tip, root.Position, THREAD, 0.12, 0.6, 0.6)
			end
		end,

		Fade = function(self)
			self.EndAt = self:Time()
			FX.Burst(self.Origin.Position + Vector3.new(0, 5, 0), "Smoke", 10, { Color = Color3.fromRGB(40, 34, 38) })
		end,
	},
})
