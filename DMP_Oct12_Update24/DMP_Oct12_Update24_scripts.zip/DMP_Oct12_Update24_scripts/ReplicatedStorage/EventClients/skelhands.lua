-- ModuleScript: ReplicatedStorage > EventClients > skelhands     (NEW, Oct 10 2026 update 10)
-- (New script: Skeleton Hands was built part by part on the server; it is drawn here now, from a model.)
-- What Skeleton Hands looks like on each client: the model Hand under ServerScriptService > Events > SkeletonHands
-- (a real skeleton hand: a thumb, and four fingers of different lengths).
-- THE WARNING (no red circle): cracks with a pale glow in them run out over the plate as far as the hand will
-- reach, and its fingertips push up through the stone, a little further every moment. Then it bursts out, palm
-- up, snatches whoever is still inside the cracks and closes its fingers round them. Every jump jolts it; six and
-- it springs open. Too slow and it squeezes.
-- Restyle the model in Studio as you like. The code bends the fingers at the joints, so keep the names:
--   Bones > Pinky1..3, Ring1..3, Middle1..3, Index1..3, Thumb1..2 (the finger bones, from the palm outward),
--   the same with K (PinkyK1 ...) for the knuckle under each bone, and PinkyTip ... for the fingertips.
--   Cracks > anything (they are grown and faded as one).
-- Finger lengths and where each finger sits are read off the model, so longer bones just work.
-- The server (Events > SkeletonHands) decides who is grabbed and who gets squeezed.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not FX.RigFrom then
	warn("[skelhands] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end

-- YOUR SOUNDS: put an id in Id. While Id is "" the built-in Roblox sound in Stand plays ("" = silence).
--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	BoneScratch = { Id = "", Stand = "rbxasset://sounds/action_get_up.mp3", Speed = 1.6, Volume = 0.3 },  -- fingers scratching up through the plate
	BoneBurst = { Id = "", Stand = "rbxasset://sounds/action_jump_land.mp3", Speed = 0.5, Volume = 1.2 }, -- the hand breaks through
	BoneGrab = { Id = "", Stand = "rbxasset://sounds/action_jump_land.mp3", Speed = 0.85, Volume = 0.9 }, -- it closes round somebody
	BoneCrunch = { Id = "", Stand = "rbxasset://sounds/action_jump_land.mp3", Speed = 0.6, Volume = 1.1 }, -- the squeeze
	BoneFree = { Id = "", Stand = "rbxasset://sounds/action_jump.mp3", Speed = 1.8, Volume = 0.6 },       -- somebody wriggled out
}
--[[DMP:END]]
FX.UseSounds(SOUNDS)

local C = FX.Colors
local BONE = Color3.fromRGB(214, 204, 178)
local STONE = Color3.fromRGB(96, 92, 100)
local FINGERS = { "Pinky", "Ring", "Middle", "Index", "Thumb" }
-- how far each joint is bent up out of the palm's plane, in degrees
local PEEK = { 84, 3, 2 }      -- pushing up through the plate: straight up
local OPEN = { 52, 12, 8 }     -- out of the plate, open
local CLOSED = { 98, 62, 50 }  -- closed round somebody
local PEEK_OUT = 0.5           -- studs a fingertip is through the stone when it first shows / the shortest finger at the end of the warning
local SNATCH = 0.18            -- seconds the hand takes to slide under whoever it grabbed and close
local BUILT_FOR = 5.4          -- the grab radius the model was made for (a bigger GRAB_RADIUS on the server makes the hand bigger)

type Finger = { Name: string, Base: Vector3, Yaw: number, Lengths: { number } }

-- puts one finger's bones where its joint angles say (rig space); returns how high its tip ends up
local function poseFinger(rig: FX.Rig, finger: Finger, angles: { number }, wiggle: number): number
	local joint = CFrame.new(finger.Base) * CFrame.Angles(0, finger.Yaw, 0) * CFrame.Angles(math.rad(-90), 0, 0)
	for index, length in finger.Lengths do
		joint = joint * CFrame.Angles(math.rad(angles[index] + (if index == 1 then wiggle else wiggle * 0.5)), 0, 0)
		rig:Pose(finger.Name .. "K" .. index, CFrame.new(joint.Position))
		rig:Pose(finger.Name .. index, joint * CFrame.new(0, length / 2, 0))
		joint = joint * CFrame.new(0, length, 0)
	end
	rig:Pose(finger.Name .. "Tip", CFrame.new(joint.Position))
	return joint.Position.Y
end

local function blend(a: { number }, b: { number }, alpha: number): { number }
	return { a[1] + (b[1] - a[1]) * alpha, a[2] + (b[2] - a[2]) * alpha, a[3] + (b[3] - a[3]) * alpha }
end

return FX.Module({
	Hand = {
		Init = function(self: any, props: any)
			local inst: Instance = self.Inst
			local bones, cracks = inst:FindFirstChild("Bones"), inst:FindFirstChild("Cracks")
			if not bones then
				FX.WarnOnce("skelhand", "the model 'Hand' is missing under ServerScriptService > Events > SkeletonHands (install the update again): the hands are invisible")
			end
			local rig = FX.RigFrom(bones, self.Origin)
			self.Rig = rig
			self.Cracks = FX.RigFrom(cracks, self.Origin)
			self.Size = (props.Radius or BUILT_FOR) / BUILT_FOR
			-- every finger, read off the model: where its first knuckle is, which way it points, how long its bones are
			local fingers: { Finger } = {}
			local lowTip, highTip = math.huge, 0
			for _, name in FINGERS do
				local first, second = rig:Get(name .. "K1"), rig:Get(name .. "K2")
				if first and second then
					local base: Vector3 = rig:Offset(name .. "K1").Position
					local toward = rig:Offset(name .. "K2").Position - base
					local lengths: { number } = {}
					for index = 1, 3 do
						local bone = rig:Get(name .. index)
						if bone then
							lengths[index] = math.max(bone.Size.X, bone.Size.Y, bone.Size.Z)
						end
					end
					local finger: Finger = { Name = name, Base = base, Yaw = math.atan2(-toward.X, -toward.Z), Lengths = lengths }
					table.insert(fingers, finger)
					local tip = poseFinger(rig, finger, PEEK, 0)
					if name ~= "Thumb" then
						lowTip = math.min(lowTip, tip)
					end
					highTip = math.max(highTip, tip)
				end
			end
			self.Fingers = fingers
			if lowTip == math.huge then
				lowTip = 6
			end
			highTip = math.max(highTip, lowTip)
			-- how deep the hand sits (studs under the top of the plate, at this hand's size):
			self.FirstDepth = (highTip - PEEK_OUT) * self.Size     -- only its longest fingertip is through
			self.PeekDepth = (lowTip - PEEK_OUT) * self.Size       -- every finger is through: the moment before it bursts out
			self.HiddenDepth = (highTip + 12) * self.Size          -- all of it under the plate
			-- where the fingers come through, for the dust (in front of the palm)
			local front = if fingers[3] then fingers[3].Base else Vector3.new(0, 0, -2.5)
			self.Front = (self.Origin * CFrame.new(front.X * self.Size, 0.3, front.Z * self.Size)).Position
			self.Held = {}          -- userIds in its grip
			self.GrabAt, self.OpenAt, self.SinkAt, self.SqueezeAt, self.JoltAt = nil, nil, nil, nil, -10
			self.Reach = Vector3.zero -- how far it slid from where it came up, to get under whoever it grabbed
			self.Burst, self.NextScratch = false, 0
			self.Banner = nil
			rig:Move(self.Origin * CFrame.new(0, -self.HiddenDepth, 0), self.Size)
			self.Cracks:Move(self.Origin, 0.02)
		end,

		-- (K.Signal) it has closed round these players
		Grab = function(self: any, userIds: { number }, _at: number)
			self.GrabAt = self:Time()
			local spot: Vector3 = self.Origin.Position
			-- it slides under them (they are NOT moved: the hand goes to them), so its fingers close round the
			-- player and not round the air next to them
			local sum, count = Vector3.zero, 0
			for _, userId in userIds do
				self.Held[userId] = true
				local root = FX.Root(userId)
				if root then
					sum += Vector3.new(root.Position.X - spot.X, 0, root.Position.Z - spot.Z)
					count += 1
				end
				if FX.IsMe(userId) then
					self.Banner = FX.Banner("GRABBED!", "MASH JUMP to break free!", BONE, (self.Props.Hold or 4) + 0.5)
					self.Banner.Bar(0)
					FX.Shake(1.2, 14, 0.03, 0.3)
				end
			end
			if count > 0 then
				local reach = sum / count
				local limit = (self.Props.Radius or BUILT_FOR)
				if reach.Magnitude > limit then
					reach = reach.Unit * limit
				end
				self.Reach = reach
			end
			FX.Sound("BoneGrab", spot + self.Reach, FX.Near(spot, 16, 80))
		end,

		-- (K.Signal) one of them jumped: the hand jolts (and their bar fills)
		Jolt = function(self: any, userId: number, jumps: number)
			self.JoltAt = self:Time()
			if FX.IsMe(userId) and self.Banner then
				self.Banner.Bar(math.clamp(jumps / (self.Props.Jumps or 6), 0, 1))
			end
			local root = FX.Root(userId)
			if root then
				FX.Burst(root.Position - Vector3.new(0, 2, 0), "Dust", 3, { Color = BONE, Scale = 0.8 })
			end
		end,

		-- (K.Signal) that player wriggled out
		Free = function(self: any, userId: number)
			self.Held[userId] = nil
			if next(self.Held) == nil then
				self.OpenAt = self:Time()
			end
			if FX.IsMe(userId) then
				if self.Banner then
					self.Banner.Close()
					self.Banner = nil
				end
				FX.Sound("BoneFree")
			end
		end,

		-- (K.Signal) too slow: it squeezes these players, then lets go
		Squeeze = function(self: any, userIds: { number })
			self.SqueezeAt = self:Time()
			local spot: Vector3 = self.Origin.Position + self.Reach
			FX.Sound("BoneCrunch", spot, FX.Near(spot, 16, 80))
			FX.Burst(spot + Vector3.new(0, 3, 0), "Dust", 8, { Color = BONE, Scale = 1.2 })
			for _, userId in userIds do
				self.Held[userId] = nil
				if FX.IsMe(userId) then
					if self.Banner then
						self.Banner.Close()
						self.Banner = nil
					end
					FX.Shake(1.8, 16, 0.03, 0.35)
					FX.Pulse(C.Blood, 0.6, 0.3)
				end
			end
		end,

		-- (K.Signal) it lets go of everything and goes back down
		Sink = function(self: any, _at: number)
			self.SinkAt = self:Time()
			table.clear(self.Held)
			if self.Banner then
				self.Banner.Close()
				self.Banner = nil
			end
		end,

		Done = function(self: any)
			if self.Banner then
				self.Banner.Close()
				self.Banner = nil
			end
		end,

		Step = function(self: any, _dt: number, t: number)
			local p = self.Props
			local warn: number, burst: number, sinkTime: number = p.Warn or 1.4, p.Burst or 0.3, p.Sink or 0.5
			local rig: FX.Rig, cracks: FX.Rig = self.Rig, self.Cracks
			local origin: CFrame = self.Origin
			local size: number = self.Size
			local spot: Vector3 = origin.Position

			-- how deep it sits, and how its fingers are held
			local depth: number
			local angles: { number }
			local wiggle = 0
			if t < warn then
				-- the warning: the longest fingertip comes through first, then they all push further and further up
				local first = math.min(0.25, warn * 0.3)
				if t < first then
					depth = self.HiddenDepth + (self.FirstDepth - self.HiddenDepth) * FX.Ease.Out(t / first)
				else
					depth = self.FirstDepth + (self.PeekDepth - self.FirstDepth) * ((t - first) / (warn - first)) ^ 1.5
				end
				angles = PEEK
				wiggle = 5
				if t >= self.NextScratch then
					self.NextScratch = t + 0.28
					FX.Sound("BoneScratch", self.Front, FX.Near(spot, 12, 60), 0.9 + (t * 7 % 1) * 0.3)
					FX.Burst(self.Front, "Dust", 2, { Color = STONE, Scale = 0.7 })
				end
			else
				local out = FX.Ease.Back((t - warn) / burst)
				depth = self.PeekDepth * (1 - out)
				angles = blend(PEEK, OPEN, FX.Clamp01((t - warn) / burst))
				if not self.Burst then
					self.Burst = true
					if t < warn + 0.6 then
						-- it breaks through
						FX.Chunks(spot + Vector3.new(0, 0.5, 0), 9, { STONE, Color3.fromRGB(70, 66, 74) }, { Size = 0.8, Speed = 13, Up = 20, Life = 1.1 })
						FX.Burst(spot + Vector3.new(0, 1, 0), "Dust", 10, { Color = STONE, Scale = 1.6 })
						FX.Sound("BoneBurst", spot, FX.Near(spot, 18, 90))
						FX.Punch(spot, 0.7)
					end
				end
			end
			-- closed round somebody (every jump jolts it loose a little), squeezing, or open again
			local grabAt: number?, openAt: number?, squeezeAt: number? = self.GrabAt, self.OpenAt, self.SqueezeAt
			local slide = Vector3.zero
			if grabAt then
				local grip = FX.Ease.Out((t - grabAt) / SNATCH)
				slide = self.Reach * grip
				grip -= 0.22 * math.max(1 - (t - self.JoltAt) / 0.18, 0)
				if squeezeAt then
					grip += 0.16 * math.sin(math.min((t - squeezeAt) / 0.3, 1) * math.pi)
					openAt = openAt or squeezeAt + 0.3
				end
				if openAt and t >= openAt then
					grip *= 1 - FX.Ease.Out((t - openAt) / 0.2)
				end
				angles = blend(OPEN, CLOSED, grip)
				wiggle = math.sin(t * 31) * 1.2 * math.clamp(grip, 0, 1)
			elseif t >= warn + burst and not self.SinkAt then
				-- nobody there: it gropes about
				angles = blend(OPEN, CLOSED, 0.25 + 0.25 * math.sin((t - warn) * 5))
			end
			local sinkAt: number? = self.SinkAt
			local fade = 0
			if sinkAt then
				local down = FX.Ease.In((t - sinkAt) / sinkTime)
				depth += self.HiddenDepth * down
				fade = FX.Clamp01((t - sinkAt) / sinkTime)
			end
			for index, finger in self.Fingers do
				poseFinger(rig, finger, angles, if t < warn then math.sin(t * 19 + index * 1.7) * wiggle else wiggle)
			end
			local jolt = math.max(1 - (t - self.JoltAt) / 0.18, 0) * 0.25
			rig:Move((origin + slide) * CFrame.new(FX.Noise(1, t * 40) * jolt, -depth, FX.Noise(2, t * 40) * jolt), size)
			-- the cracks: they run out during the warning (as far as it will reach), stay, and close up as it goes
			cracks:Move(origin, math.max(size * FX.Ease.Out(t / (warn * 0.85)), 0.02))
			cracks:Fade(fade)
		end,
	},
})
