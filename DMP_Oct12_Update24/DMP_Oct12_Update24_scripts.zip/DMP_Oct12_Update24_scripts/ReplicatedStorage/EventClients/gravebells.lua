-- ModuleScript: ReplicatedStorage > EventClients > gravebells     (Oct 11 Update 17: the tolls hit your screen)
-- Client visuals for Grave Bells: candles on the doomed plates and the tolling bell.
-- Each toll: the bell shudders, swings from its top (dying out) and rings (Bell > Bell > Sound).
-- The bell fades in as it lowers and fades out as it leaves.
-- [Update 17] YOUR SCREEN: while the bell comes down your view slowly tightens and a faint green creeps in; then every
-- toll goes IN and OUT three times (a big one, then two smaller ones), each with a camera shake, a green tint, the
-- colour drained, more contrast, the vignette and a little blur, dying away before the next toll. When the bell
-- leaves it all eases back. Everything goes through ReplicatedStorage > Utility, so the Settings switches count
-- (shake, FOV, tint, post effects). Strengths: the SCREEN block below. The farther you are, the less you feel it.

local TweenService = game:GetService("TweenService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local FX = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not (FX.Tint and FX.FOV and FX.Blur) then
	warn("[gravebells] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end

-- [Update 17] HOW HARD EACH TOLL HITS YOUR SCREEN (the first of its three beats; the next two are smaller)
local SCREEN = true        -- false = no screen effects at all (the old event)
local BEATS = 3            -- in and out this many times per toll
local BEAT_GAP = 0.42      -- seconds between them
local FADE_BEAT = 0.58     -- each beat this much of the one before
local FOV_IN = 6           -- degrees the view tightens on a beat ...
local FOV_OUT = 2.5        -- ... and opens past normal right after
local WIND_FOV = 3         -- degrees it tightens while the bell comes down
local SHAKE = 2            -- camera shake on a beat
local BLUR = 4             -- a little blur on a beat
local TINT = Color3.fromRGB(195, 255, 205) -- the green
local DRAIN = 0.45         -- colour drained on a beat (0..1)
local CONTRAST = 0.22      -- more contrast on a beat
local VIGNETTE = 0.5       -- how far the vignette closes in on a beat (0 = not at all, 1 = black)
local VIGNETTE_COLOR = Color3.fromRGB(10, 32, 16)
local NEAR, FAR = 120, 420 -- full strength within NEAR studs of the bell, nothing past FAR

local GraveBells = {}

-- Bell swing feel
local SWING_ANGLE = 22    -- degrees, first swing
local SWING_SPEED = 7     -- how fast it swings back and forth
local SWING_DAMPING = 1.4 -- how quickly the swing dies out
local SHUDDER_ANGLE = 3   -- degrees, the sharp shake right at the strike
local SHUDDER_DAMPING = 7
local FADE_IN_TIME = 1.5

local function part(props): Part
	local p = Instance.new("Part")
	p.Anchored = true
	p.CanCollide = false
	p.CanQuery = false
	p.CanTouch = false
	for key, value in props do
		(p :: any)[key] = value
	end
	return p
end

function GraveBells.Build(asset: string): Model?
	local model = Instance.new("Model")
	model.Name = asset
	if asset == "Candle" then
		local wax = part({ Name = "Wax", Size = Vector3.new(1.2, 3, 1.2), CFrame = CFrame.new(0, 1.5, 0), Color = Color3.fromRGB(235, 225, 200), Material = Enum.Material.SmoothPlastic, Parent = model })
		part({ Name = "Holder", Size = Vector3.new(2.2, 0.3, 2.2), CFrame = CFrame.new(0, 0.15, 0), Color = Color3.fromRGB(150, 120, 60), Material = Enum.Material.Metal, Parent = model })
		model.PrimaryPart = wax
	elseif asset == "Bell" then
		local center = part({ Name = "Center", Size = Vector3.new(0.2, 0.2, 0.2), Transparency = 1, Parent = model })
		part({ Name = "Body", Shape = Enum.PartType.Cylinder, Size = Vector3.new(8, 7, 7), CFrame = CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, math.rad(90)), Color = Color3.fromRGB(110, 85, 45), Material = Enum.Material.Metal, Parent = model })
		part({ Name = "Rim", Shape = Enum.PartType.Cylinder, Size = Vector3.new(1, 9, 9), CFrame = CFrame.new(0, -4, 0) * CFrame.Angles(0, 0, math.rad(90)), Color = Color3.fromRGB(95, 72, 38), Material = Enum.Material.Metal, Parent = model })
		part({ Name = "Crown", Size = Vector3.new(2, 2, 2), CFrame = CFrame.new(0, 5, 0), Color = Color3.fromRGB(80, 60, 30), Material = Enum.Material.Metal, Parent = model })
		model.PrimaryPart = center
	else
		return nil
	end
	return model
end

---------------------------------------------------------------------- [Update 17] your screen
local screen: any = nil -- (one bell at a time)

local function nearness(position: Vector3): number
	return FX.Near(position, NEAR, FAR)
end

local function windUp(position: Vector3)
	if not SCREEN or screen then
		return
	end
	local near = nearness(position)
	if near <= 0.02 then
		return
	end
	screen = { Near = near, Tint = FX.Tint(), Beat = 0, Alive = true, Position = position }
	FX.FOV(-WIND_FOV * near, 2.6)
	screen.Tint.To({ TintColor = Color3.new(1, 1, 1):Lerp(TINT, 0.25 * near), Saturation = -0.12 * near, Contrast = 0.04 * near }, 2.6)
	FX.Vignette(1 - VIGNETTE * 0.35 * near, 2.6, VIGNETTE_COLOR)
end

-- one beat: in, then out past normal, then back to the wind-up's level
local function beat(strength: number)
	local current = screen
	if not current or not current.Alive then
		return
	end
	local a = strength * current.Near
	FX.FOV(-(WIND_FOV * current.Near + FOV_IN * a), 0.07)
	task.delay(0.1, function()
		if screen == current and current.Alive then
			FX.FOV(FOV_OUT * a - WIND_FOV * 0.5, 0.16)
			task.delay(0.18, function()
				if screen == current and current.Alive then
					FX.FOV(-WIND_FOV * current.Near, 0.3)
				end
			end)
		end
	end)
	FX.Shake(SHAKE * strength, 11, 0.02, 0.38, current.Position, NEAR, FAR) -- (it fades with distance by itself)
	FX.Blur(BLUR * a, 0.42)
	current.Tint.To({ TintColor = Color3.new(1, 1, 1):Lerp(TINT, math.min(1, 0.35 + 0.65 * a)), Saturation = -DRAIN * a - 0.12 * current.Near, Contrast = CONTRAST * a + 0.04 * current.Near, Brightness = -0.04 * a }, 0.06)
	FX.Vignette(1 - VIGNETTE * math.max(a, 0.35 * current.Near), 0.06, VIGNETTE_COLOR)
	task.delay(0.12, function()
		if screen == current and current.Alive then
			current.Tint.To({ TintColor = Color3.new(1, 1, 1):Lerp(TINT, 0.25 * current.Near), Saturation = -0.12 * current.Near, Contrast = 0.04 * current.Near, Brightness = 0 }, 0.34)
			FX.Vignette(1 - VIGNETTE * 0.35 * current.Near, 0.34, VIGNETTE_COLOR)
		end
	end)
end

local function tollScreen(position: Vector3)
	if not SCREEN then
		return
	end
	if not screen then
		windUp(position)
	end
	local current = screen
	if not current then
		return
	end
	for index = 1, BEATS do
		task.delay((index - 1) * BEAT_GAP, function()
			if screen == current and current.Alive then
				beat(FADE_BEAT ^ (index - 1))
			end
		end)
	end
end

local function letGo(seconds: number?)
	local current = screen
	screen = nil
	if not current then
		return
	end
	current.Alive = false
	local time = seconds or 1
	FX.FOVReset(time)
	current.Tint.Back(time)
	current.Tint.Remove(time + 0.1)
	FX.VignetteOff(time)
end

local function getBox(model: PVInstance): (CFrame, Vector3)
	if model:IsA("Model") then
		return model:GetBoundingBox()
	end
	return (model :: BasePart).CFrame, (model :: BasePart).Size
end

local function lift(model: PVInstance): number
	local boxCFrame, boxSize = getBox(model)
	return model:GetPivot().Position.Y - (boxCFrame.Position.Y - boxSize.Y / 2)
end

function GraveBells.Spawned(model: PVInstance, state)
	if state.Asset == "Candle" then
		state.Kind = "Candle"
		state.Lift = lift(model)
		-- Flame on top, on its own upright holder so it always burns straight up
		local _, size = getBox(model)
		local holder = part({ Name = "Flame", Size = Vector3.new(0.2, 0.2, 0.2), Transparency = 1, Parent = model })
		state.FlameHolder = holder
		state.FlameHeight = size.Y
		local fire = Instance.new("Fire")
		fire.Size = 3
		fire.Heat = 6
		fire.Color = Color3.fromRGB(255, 150, 50)
		fire.SecondaryColor = Color3.fromRGB(255, 70, 20)
		fire.Parent = holder
		local light = Instance.new("PointLight")
		light.Color = Color3.fromRGB(255, 160, 70)
		light.Range = 14
		light.Brightness = 2
		light.Parent = holder
		state.Fire, state.Light = fire, light
	else
		state.Kind = "Bell"
		state.Tolls = {}

		-- Start invisible and fade in while it lowers
		state.Visible = {}
		local parts = if model:IsA("BasePart") then { model } else model:GetDescendants()
		for _, p in parts do
			if p:IsA("BasePart") then
				p.Anchored = true
				p.CanCollide = false
				p.CanQuery = false
				p.CanTouch = false
			end
			if p:IsA("BasePart") or p:IsA("Decal") then
				state.Visible[p] = p.Transparency
				p.Transparency = 1
				TweenService:Create(p, TweenInfo.new(FADE_IN_TIME), { Transparency = state.Visible[p] }):Play()
			end
		end

		local body = model:FindFirstChild("Bell")
		state.Sound = body and body:FindFirstChildOfClass("Sound") or model:FindFirstChildOfClass("Sound")
		-- [Update 17] your view starts to tighten as it comes down
		state.Screen = true
		pcall(windUp, model:GetPivot().Position - Vector3.new(0, 30, 0))

		-- Swing from the top of the bell (in the pivot's own space)
		local boxCFrame, boxSize = getBox(model)
		local top = boxCFrame.Position + Vector3.new(0, boxSize.Y / 2, 0)
		state.Hinge = model:GetPivot():PointToObjectSpace(top)
	end
end

function GraveBells.Render(model: PVInstance, state, base: CFrame, _dt: number)
	if state.Kind == "Candle" then
		local pivot = base + Vector3.new(0, state.Lift or 0, 0)
		model:PivotTo(pivot)
		if state.FlameHolder then
			state.FlameHolder.CFrame = CFrame.new(base.Position + Vector3.new(0, state.FlameHeight + 0.3, 0))
		end
	else
		-- Add up every recent toll so back-to-back tolls blend instead of snapping
		local now = os.clock()
		local swingX, shakeX, shakeZ = 0, 0, 0
		for i = #state.Tolls, 1, -1 do
			local t = now - state.Tolls[i]
			if t > 5 then
				table.remove(state.Tolls, i)
			else
				swingX += math.rad(SWING_ANGLE) * math.exp(-t * SWING_DAMPING) * math.sin(t * SWING_SPEED)
				local shudder = math.rad(SHUDDER_ANGLE) * math.exp(-t * SHUDDER_DAMPING)
				shakeX += math.sin(t * 55) * shudder
				shakeZ += math.cos(t * 47) * shudder
			end
		end
		local hinge = state.Hinge or Vector3.zero
		local rotation = CFrame.Angles(swingX + shakeX, 0, shakeZ)
		model:PivotTo(base * CFrame.new(hinge) * rotation * CFrame.new(-hinge))
	end
end

function GraveBells.Toll(model: PVInstance, state)
	table.insert(state.Tolls, os.clock())
	-- [Update 17] the toll hits your screen
	pcall(tollScreen, model:GetPivot().Position)

	-- DONG (a copy, so tolls can overlap)
	if state.Sound then
		local sound = state.Sound:Clone()
		sound.Parent = state.Sound.Parent
		sound:Play()
		task.delay(math.max(sound.TimeLength, 3) + 0.5, function()
			sound:Destroy()
		end)
	end
end

-- Server: Call(bell, "FadeOut", time)
function GraveBells.FadeOut(_model: PVInstance, state, time: number)
	-- [Update 17] the bell leaves: your screen eases back
	if state.Screen then
		state.Screen = nil
		pcall(letGo, (time or 1.2) + 0.3)
	end
	for p in state.Visible or {} do
		if p.Parent then
			TweenService:Create(p, TweenInfo.new(time or 1.2), { Transparency = 1 }):Play()
		end
	end
end

function GraveBells.BlowOut(_model: PVInstance, state)
	if state.Fire then
		state.Fire.Enabled = false
	end
	if state.Light then
		TweenService:Create(state.Light, TweenInfo.new(0.3), { Brightness = 0 }):Play()
	end
	-- A little puff of smoke where the flame was
	if state.FlameHolder then
		local smoke = Instance.new("Smoke")
		smoke.Size = 1
		smoke.RiseVelocity = 3
		smoke.Opacity = 0.4
		smoke.Color = Color3.fromRGB(150, 150, 160)
		smoke.Parent = state.FlameHolder
		task.delay(0.6, function()
			smoke.Enabled = false
		end)
	end
end

-- [Update 17] the event ended before the bell left (or Render broke): never leave the screen tinted
function GraveBells.Destroyed(_model: PVInstance, state)
	if state and state.Screen then
		state.Screen = nil
		pcall(letGo, 0.6)
	end
end

return GraveBells