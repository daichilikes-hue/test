-- ModuleScript: ReplicatedStorage > EventClients > batnet     (NEW: Oct 12 Update 23, Bat Net)
-- What the Bat Net looks like on each client. The server (Events > BatNet) catches falling players and tosses them
-- back up; this draws the swarm (the model Bats under ServerScriptService > Events > BatNet: Bat1..12): the bats
-- flutter in from below and circle under their plate, wings flapping. When one catches somebody, the swarm whirls up
-- round them as they are thrown back onto the plate, then scatters and flies off. Swarms nobody needed leave at the end.
-- Restyle the model there; keep Bat1..n with Body and WingL / WingR in each.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not (FX.Tagged and FX.UseSounds) then
	warn("[batnet] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end

-- Sounds: paste your own ids into Id (Stand = a Roblox stand-in; "" = silence)
--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	BatFlutter = { Id = "", Stand = "rbxasset://sounds/swordslash.wav", Speed = 1.6, Volume = 0.45 }, -- the swarm tosses somebody up
	BatSwarm = { Id = "", Stand = "", Speed = 1, Volume = 0.4 },                                     -- the swarm arrives under a plate
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

local DEPTH = 4             -- studs under the plate's bottom the swarm circles
local ARRIVE = 1.5          -- seconds the bats take to flutter in (and to fly off)
local FLAP = 14             -- wing beats a second (about)
local FLAP_ANGLE = 55       -- degrees the wings swing
local WHIRL = 0.9           -- seconds they whirl round whoever they caught before they scatter

return FX.Module({
	Bats = {
		Init = function(self: any, props: any)
			self.Bats = {}
			local rng = Random.new(tonumber(props.Seed) or 1)
			for _, group in self.Inst:GetChildren() do
				if group:IsA("Model") and string.sub(group.Name, 1, 3) == "Bat" then
					local root = group:FindFirstChild("Root")
					local origin = if root and root:IsA("BasePart") then root.CFrame else group:GetPivot()
					local inverse = origin:Inverse()
					local bat = {
						Parts = {},
						Radius = rng:NextNumber(3.5, 9),
						Height = rng:NextNumber(-1.5, 1.5),
						Speed = rng:NextNumber(1.2, 2.2) * (if rng:NextNumber() < 0.5 then -1 else 1),
						Phase = rng:NextNumber(0, math.pi * 2),
						Flap = rng:NextNumber(0, math.pi * 2),
						Away = Vector3.new(rng:NextNumber(-1, 1), rng:NextNumber(0.6, 1.2), rng:NextNumber(-1, 1)).Unit,
					}
					for _, part in group:GetChildren() do
						if part:IsA("BasePart") and part.Name ~= "Root" then
							local side = if part.Name == "WingL" then 1 elseif part.Name == "WingR" then -1 else 0
							table.insert(bat.Parts, { Part = part, Offset = inverse * part.CFrame, Side = side, Transparency = part.Transparency })
						end
					end
					table.insert(self.Bats, bat)
				end
			end
			self.Base = self.Origin
			FX.Sound("BatSwarm", self.Origin.Position)
		end,

		Step = function(self: any, dt: number, t: number)
			local plate = self.Plate
			if not plate then
				local found = FX.Tagged(self.Props.Tag)
				if found and found:IsA("BasePart") then
					plate = found
					self.Plate = found
				end
			end
			if plate and plate.Parent then
				self.Base = plate.CFrame * CFrame.new(0, -plate.Size.Y / 2 - DEPTH, 0)
			end
			local duration = tonumber(self.Props.Duration) or 20
			local base: CFrame = self.Base
			local arrive = FX.Ease.Out(FX.Clamp01(t / ARRIVE))
			-- flying off: after a catch (once they have whirled), at the end, or when their plate is gone
			local offAt = if self.BounceAt then self.BounceAt + WHIRL else duration - ARRIVE
			if self.Plate and not self.Plate.Parent then
				self.GoneAt = self.GoneAt or t
				offAt = math.min(offAt, self.GoneAt)
			end
			local off = FX.Ease.In(FX.Clamp01((t - offAt) / ARRIVE))
			local whirl = if self.BounceAt and t < offAt then FX.Clamp01((t - self.BounceAt) / 0.3) else 0
			local target = self.Target
			local caught: Vector3? = nil
			if whirl > 0 and target then
				local root = FX.Root(target)
				caught = root and root.Position
			end
			for _, bat in self.Bats do
				local angle = bat.Phase + bat.Speed * t * (1 + 1.5 * whirl)
				local radius = bat.Radius * (0.4 + 0.6 * arrive)
				local centre = base.Position + Vector3.new(0, bat.Height - 6 * (1 - arrive), 0)
				if caught then
					centre = centre:Lerp(caught, whirl)
					radius = radius * (1 - 0.5 * whirl) + 1
				end
				local at = centre + Vector3.new(math.cos(angle) * radius, math.sin(t * 2 + bat.Phase) * 0.4, math.sin(angle) * radius)
				at += bat.Away * 40 * off
				local ahead = Vector3.new(-math.sin(angle), 0, math.cos(angle)) * math.sign(bat.Speed)
				local body = CFrame.lookAt(at, at + ahead)
				local flap = math.rad(FLAP_ANGLE) * math.sin(t * FLAP * 2 * math.pi / 2 + bat.Flap)
				for _, piece in bat.Parts do
					local part: BasePart = piece.Part
					if piece.Side ~= 0 then
						part.CFrame = body * CFrame.Angles(0, 0, piece.Side * flap) * piece.Offset
					else
						part.CFrame = body * piece.Offset
					end
					part.Transparency = piece.Transparency + (1 - piece.Transparency) * math.max(1 - arrive, off)
				end
			end
		end,

		-- the swarm caught this player and is throwing them back up
		Bounce = function(self: any, userId: number)
			self.BounceAt = self:Time()
			self.Target = userId
			local root = FX.Root(userId)
			FX.Sound("BatFlutter", if root then root.Position else self.Origin.Position)
			if root then
				FX.Burst(root.Position, "Smoke", 8, { Color = Color3.fromRGB(60, 50, 58), Scale = 0.8 })
			end
			if FX.IsMe(userId) then
				FX.Shake(1.2, 10, 0.05, 0.4)
			end
		end,
	},
})
