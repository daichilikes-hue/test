-- ModuleScript: ReplicatedStorage > EventClients > procession     (NEW: Oct 12 Update 22, Lantern Procession)
-- What the Lantern Procession looks like on each client. The server (Events > LanternProcession) decides where the
-- bearers are and does the healing; this draws them:
--   THE BEARERS  the model Bearer under ServerScriptService > Events > LanternProcession: an R6 character in a hooded
--                robe with a pale lantern welded to his right hand. Each one rises out of the plates, walks his lap at
--                the server's pace (floating over the gaps, rising over a plate that is higher than the rest), and
--                fades away at the end. Restyle him there, keep the names the code needs (listed in the model).
--   THE LIGHT    the lantern's PointLight reaches about as far as its healing does (RADIUS on the server + LIGHT_EXTRA):
--                the pool of light on the plates IS the place to stand. No circle, no ring.
--   HEALED       a faint sparkle on whoever a lantern heals, that lantern flares a little, and on your own client a
--                soft chime (at most every CHIME_EVERY seconds)
-- HIS ANIMATION: BearerWalk, a KeyframeSequence in this module's Animations folder. In Studio it plays straight from
-- there; for the real game upload it (right-click > Save to Roblox) and paste the id into ANIMATIONS below. (Not
-- uploaded = in the game he glides with his lantern arm held out, without the walk.)
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not (FX.Actor and FX.R6Problem and FX.UseSounds and FX.SetEmitters) then
	warn("[procession] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end

-- Sounds: paste your own ids into Id (the Stand ones are Roblox stand-ins; Stand = "" is silence)
--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	LanternChime = { Id = "", Stand = "rbxasset://sounds/electronicpingshort.wav", Speed = 0.5, Volume = 0.3 }, -- a lantern heals you
	BearerRise = { Id = "", Stand = "", Speed = 1, Volume = 0.6 },                                              -- a bearer rises out of the plates
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

-- Your uploaded animation id (0 = not uploaded yet: Studio plays the KeyframeSequence from the Animations folder)
--[[DMP:KEEP Animations]]
local ANIMATIONS = {
	BearerWalk = 0, -- the procession walk, the lantern held out (looped)
}
--[[DMP:END]]

local BEARER_SCALE = 1.1    -- his size (1 = a normal R6 character)
local HOVER = 1.2           -- studs his feet float over the plate (the hem of his robe just clears it)
local RISE = 8              -- studs he climbs up out of the plate at the start (and sinks back into it at the end)
local FADE = 1.5            -- seconds he takes to climb out at the start, and to sink away at the end
local SEE_THROUGH = false   -- true = he also fades in and out (see-through while he comes and goes). false = always solid
local CLIMB = 4             -- how fast he follows the plates up and down (bigger = snappier)
local LIGHT_EXTRA = 2       -- the lantern's light reaches the healing radius + this many studs
local LIGHT_FLICKER = 0.12  -- how much the flame flickers (0 = steady)
local CHIME_EVERY = 3       -- seconds: the chime on YOUR client when a lantern heals you, at most this often
local SPARKLE = Color3.fromRGB(200, 250, 214)
-- (no animation to play: his right arm is held out like this so the lantern hangs in front of him.
--  KEEP IN SYNC with HOLD_ANGLE / HOLD_IN in DMP_tools animgen/bearer.py: `python3 animgen/bearer.py hold`)
local HOLD = CFrame.new(0, 0, 0, 0.642788, -0.758589, 0.106613, 0.766044, 0.636532, -0.089459, 0, 0.139173, 0.990268)

local lastChime = -math.huge

-- THE LAP (KEEP THE SAME as lapPoint in ServerScriptService > Events > LanternProcession)
local function lapLength(hx: number, hz: number, r: number): number
	return 4 * (hx - r) + 4 * (hz - r) + 2 * math.pi * r
end

local function lapPoint(cx: number, cz: number, hx: number, hz: number, r: number, s: number): (number, number, number, number)
	local sideX, sideZ = 2 * (hx - r), 2 * (hz - r)
	local arc = math.pi * r / 2
	s %= lapLength(hx, hz, r)
	-- (a quarter circle round (x0, z0), starting at angle a0, d studs along it)
	local function round(x0: number, z0: number, a0: number, d: number): (number, number, number, number)
		local a = a0 + d / r
		return x0 + r * math.cos(a), z0 + r * math.sin(a), -math.sin(a), math.cos(a)
	end
	local pieces = {
		{ sideZ, function(d) return cx + hx, cz - (hz - r) + d, 0, 1 end },
		{ arc, function(d) return round(cx + hx - r, cz + hz - r, 0, d) end },
		{ sideX, function(d) return cx + (hx - r) - d, cz + hz, -1, 0 end },
		{ arc, function(d) return round(cx - hx + r, cz + hz - r, math.pi / 2, d) end },
		{ sideZ, function(d) return cx - hx, cz + (hz - r) - d, 0, -1 end },
		{ arc, function(d) return round(cx - hx + r, cz - hz + r, math.pi, d) end },
		{ sideX, function(d) return cx - (hx - r) + d, cz - hz, 1, 0 end },
		{ arc, function(d) return round(cx + hx - r, cz - hz + r, 1.5 * math.pi, d) end },
	}
	for _, piece in pieces do
		if s <= piece[1] or piece == pieces[#pieces] then
			return piece[2](math.min(s, piece[1]))
		end
		s -= piece[1]
	end
	return cx + hx, cz, 0, 1
end

-- where he is on the lap at time t, and the way he faces
local function onLap(props: any, t: number): (number, number, Vector3)
	local speed = tonumber(props.Speed) or 10
	local x, z, dx, dz = lapPoint(props.Cx, props.Cz, props.Hx, props.Hz, props.Corner, (tonumber(props.Start) or 0) + speed * t)
	local sign = if speed < 0 then -1 else 1
	return x, z, Vector3.new(dx * sign, 0, dz * sign)
end

return FX.Module({
	Bearer = {
		Init = function(self: any, props: any)
			local model: Instance = self.Inst
			self.Parts = {}
			self.Base = tonumber(props.Top) or self.Origin.Position.Y
			self.Ground = self.Origin.Position.Y
			self.Seed = (tonumber(props.Index) or 1) * 7.3
			self.Flare = 0
			self.Faded = -1
			if not (model:IsA("Model") and model:FindFirstChild("HumanoidRootPart")) then
				-- (no Bearer model under Events > LanternProcession: an older install, or it was renamed)
				FX.WarnOnce("procession-model", "[procession] ServerScriptService > Events > LanternProcession has no model named Bearer (an R6 character), so the ghosts cannot be shown. Install the WHOLE update (drag its .rbxmx in) and press Play again.")
				return
			end
			local problem = FX.R6Problem(model)
			if problem then
				warn("[procession] the bearer (ServerScriptService > Events > LanternProcession > Bearer) cannot play his walk: " .. problem .. ". He is shown without it.")
			end
			if BEARER_SCALE ~= 1 and BEARER_SCALE > 0 then
				(model :: Model):ScaleTo((model :: Model):GetScale() * BEARER_SCALE) -- (relative: it may already be scaled in Studio)
			end
			self.Scale = (model :: Model):GetScale()
			for _, item in model:GetDescendants() do
				if item:IsA("BasePart") then
					table.insert(self.Parts, { Part = item, Transparency = item.Transparency })
				end
			end
			local flame = model:FindFirstChild("Flame", true)
			local light = flame and flame:FindFirstChildOfClass("PointLight")
			if light then
				self.Light = light
				self.Brightness = light.Brightness
				light.Range = math.clamp((tonumber(props.Radius) or 8) + LIGHT_EXTRA, 2, 60)
			end
			self.Motes = flame and flame:FindFirstChild("Motes")
			local shoulder = model:FindFirstChild("Right Shoulder", true)
			self.Shoulder = if shoulder and shoulder:IsA("Motor6D") then shoulder else nil
			self.Actor = FX.Actor(model :: Model, ANIMATIONS, script)
			-- he floats over the plates (his workspace > Map > Plates)
			local map = workspace:FindFirstChild("Map")
			local plates = map and map:FindFirstChild("Plates")
			if plates then
				local params = RaycastParams.new()
				params.FilterType = Enum.RaycastFilterType.Include
				params.FilterDescendantsInstances = { plates }
				self.Ray = params
			end
			FX.Sound("BearerRise", self.Origin.Position)
		end,

		Step = function(self: any, dt: number, t: number)
			local actor = self.Actor
			if not actor then
				return
			end
			local props = self.Props
			local duration = tonumber(props.Duration) or 20
			local x, z, facing = onLap(props, t)
			-- the ground under him: the plate there (he follows it up and down), else the height of an untouched plate
			local want = self.Base
			if self.Ray then
				local hit = workspace:Raycast(Vector3.new(x, self.Base + 80, z), Vector3.new(0, -160, 0), self.Ray)
				if hit and hit.Normal.Y > 0.7 then
					want = hit.Position.Y
				end
			end
			self.Ground += (want - self.Ground) * math.min(dt * CLIMB, 1)
			-- he climbs up out of the plates at the start, and sinks back into them at the end
			local fadeIn = FX.Clamp01(t / FADE)
			local fadeOut = FX.Clamp01((duration - t) / FADE)
			local shown = math.min(fadeIn, fadeOut)
			local sink = RISE * (1 - FX.Ease.Out(shown))
			local bob = math.sin(t * 2.2 + self.Seed) * 0.15
			local at = Vector3.new(x, self.Ground + 3 * self.Scale + HOVER - sink + bob, z)
			actor.Place(CFrame.lookAt(at, at + facing))
			if actor.Animated then
				if not self.Walking then
					self.Walking = actor.Play("BearerWalk", 0.3) ~= nil
				end
			elseif self.Shoulder then
				self.Shoulder.Transform = HOLD -- (no walk to play: hold the lantern out by hand)
			end
			-- fading in and out (only with SEE_THROUGH; snapped to exactly 0 / 1 so nothing is left a hair see-through)
			local look = if not SEE_THROUGH then 1 elseif shown > 0.99 then 1 elseif shown < 0.01 then 0 else shown
			if look ~= self.Faded and (math.abs(look - self.Faded) > 0.01 or look == 0 or look == 1) then
				self.Faded = look
				for _, entry in self.Parts do
					entry.Part.Transparency = entry.Transparency + (1 - entry.Transparency) * (1 - look)
				end
			end
			-- the motes off the flame, while he is out of the plate
			local motes = self.Motes
			local on = shown > 0.5 and not FX.Off("DisableParticles")
			if motes and motes:IsA("ParticleEmitter") and motes.Enabled ~= on then
				motes.Enabled = on
			end
			-- the flame flickers, and flares when it heals somebody
			self.Flare = math.max(self.Flare - dt * 1.5, 0)
			local light: PointLight? = self.Light
			if light then
				local flicker = 1 + LIGHT_FLICKER * FX.Noise(self.Seed, t * 3)
				light.Brightness = self.Brightness * shown * flicker * (1 + 0.6 * self.Flare)
			end
		end,

		-- this bearer's lantern healed that player
		Healed = function(self: any, userId: number)
			self.Flare = 1
			local root = FX.Root(userId)
			if not root then
				return
			end
			FX.Burst(root.Position + Vector3.new(0, 0.6, 0), "Star", 3, { Color = SPARKLE, Scale = 0.5 })
			if FX.IsMe(userId) then
				local now = FX.Now()
				if now - lastChime >= CHIME_EVERY then
					lastChime = now -- (one chime for all the lanterns together)
					FX.Sound("LanternChime", root.Position)
				end
			end
		end,
	},
})
