-- ModuleScript: ReplicatedStorage > EventClients > jackbox     (REPLACE)
-- What Jack-in-the-Box looks like on each client. A small toy box drops in and winds itself up: the crank turns
-- faster and faster (tick, tick, tick-tick-tick), then stops with a ding. Now it is a trap: it just sits there,
-- twitching now and then, until somebody comes near. Then the lid flies open and a pumpkin jester springs out.
-- Oct 10 2026 (update 8): the box and the jack are a MODEL (ServerScriptService > Events > JackInTheBox > Box, with
-- the groups Box and Jack inside it). It is cloned for every box; nothing is built part by part here any more.
-- Restyle the model in Studio as you like: keep the part names (Lid, CrankArm, CrankKnob, Coil1..6, Body, Star).
-- The server (Events > JackInTheBox) decides when it goes off and who gets punched.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not (FX.RigFrom) then
	warn("[jackbox] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end

local C = FX.Colors
local COILS = 6
local JACK_HEIGHT = 6.5

return FX.Module({
	Box = {
		Init = function(self: any, props: any)
			local inst: Instance = self.Inst
			local boxGroup, jackGroup = inst:FindFirstChild("Box"), inst:FindFirstChild("Jack")
			if not (boxGroup and jackGroup) then
				FX.WarnOnce("jackboxmodel", "the model 'Box' is missing under ServerScriptService > Events > JackInTheBox (install the update again): the boxes are invisible")
			end
			self.Box = FX.RigFrom(boxGroup, self.Origin)
			local jackRoot = jackGroup and jackGroup:FindFirstChild("Root")
			local jack = FX.RigFrom(jackGroup, if jackRoot and jackRoot:IsA("BasePart") then jackRoot.CFrame else self.Origin)
			self.Jack = jack
			self.Scale = props.Scale or 1
			-- the jack is folded away inside the box until it pops
			jack:Move(self.Origin * CFrame.new(0, 2 * self.Scale, 0), 0.05)
			jack:Fade(1)
			local body = self.Box:Get("Body")
			self.BodyColor = if body then body.Color else C.Purple
			self.Turns = 0
			self.Armed = false
			self.PopAt = nil
			self.Faded = false
		end,

		-- (K.Call) it has finished winding itself up: from now on it goes off when somebody comes near
		Armed = function(self: any)
			if self.Armed then
				return
			end
			self.Armed = true
			local spot: Vector3 = self.Origin.Position
			if math.abs(self:Time() - ((self.Props.Drop or 0.5) + (self.Props.Fuse or 4))) < 1 then
				FX.Sound("Ding", spot, 0.7 * FX.Near(spot, 20, 90), 0.55)
				FX.Sparks(spot + Vector3.new(0, 3 * self.Scale, 0), C.Gold, 8, 0.7)
			end
		end,

		-- (K.Call) somebody set it off at server time `at`
		Pop = function(self: any, at: number)
			if self.PopAt then
				return
			end
			self.PopAt = at - self.T0
			self.Armed = true
			if FX.Now() - at > 0.8 then
				return -- (replayed for somebody who joined later: no bang)
			end
			local spot: Vector3 = self.Origin.Position
			local scale: number = self.Scale
			FX.Confetti(spot + Vector3.new(0, 6 * scale, 0), 20)
			FX.Sparks(spot + Vector3.new(0, 5 * scale, 0), C.Gold, 16, 1.1)
			FX.Sound("Pop", spot, 1.3, 0.9)
			FX.Sound("Boing", spot, 1, 1)
			FX.Punch(spot, 0.6)
		end,

		Step = function(self: any, _dt: number, t: number)
			local p = self.Props
			local drop: number, fuse: number = p.Drop or 0.5, p.Fuse or 4
			local wound = drop + fuse
			local box: FX.Rig, jack: FX.Rig = self.Box, self.Jack
			local spot: Vector3 = self.Origin.Position
			local scale: number = self.Scale
			local popAt: number? = self.PopAt
			local f = FX.Span(t, drop, wound) -- how far it has wound itself up

			-- the crank: 4 radians a second at first, 30 by the end; a tick for every turn. Wound up, it stops.
			local cranking = math.clamp(t - drop, 0, fuse)
			local spin = 4 * cranking + 13 * cranking * cranking / fuse
			box:Pose("CrankArm", CFrame.new(3.2, 2, 0) * CFrame.Angles(spin, 0, 0) * CFrame.new(0, 0.7, 0))
			box:Pose("CrankKnob", CFrame.new(3.2, 2, 0) * CFrame.Angles(spin, 0, 0) * CFrame.new(0.3, 1.4, 0))
			local turns = math.floor(spin / (math.pi * 2))
			if turns > self.Turns and t < wound and not popAt then
				self.Turns = turns
				FX.Sound("Ding", spot, 0.5 * FX.Near(spot, 20, 90), 1 + f)
			end

			-- where the box is: falling in with a bounce, rattling harder as it winds up, then still (with a
			-- little twitch every couple of seconds while it waits)
			local fall = 22 * (1 - FX.Ease.Bounce(t / drop))
			local rattle = 0
			if not popAt then
				if t < wound then
					rattle = f * f * 0.3
				else
					local beat = (t - wound) % 2.2
					rattle = if beat < 0.18 then 0.12 else 0
				end
			end
			local frame: CFrame = self.Origin * CFrame.new(FX.Noise(1, t * 30) * rattle * scale, fall, FX.Noise(2, t * 30) * rattle * scale)

			if popAt then
				local since = t - popAt
				-- the lid flips back on its hinge and the jack shoots up on its spring, wobbling
				local open = math.rad(112) * FX.Ease.Back(since / 0.18)
				box:Pose("Lid", CFrame.new(0, 4, 2.2) * CFrame.Angles(open, 0, 0) * CFrame.new(0, 0.25, -2.2))
				local height = JACK_HEIGHT * (1 - FX.Ease.Wobble(since / 1.2, 3, 3.5))
				for i = 1, COILS do
					box:Pose("Coil" .. i, CFrame.new(0, 3.6 + height * (i - 0.5) / COILS, 0) * CFrame.Angles(0, 0, if i % 2 == 0 then 0.18 else -0.18))
				end
				local sway = FX.Ease.Wobble(since / 1.4, 2.5, 3) * 0.35
				jack:Fade(0)
				jack:Move(frame * CFrame.new(0, (3.9 + height) * scale, 0) * CFrame.Angles(sway, since * 2, sway * 0.7), scale * FX.Ease.Back(since / 0.15))
				if since >= (p.Linger or 1.2) and not self.Faded then
					self.Faded = true
					FX.FadeOut(self.Inst, 0.45)
				end
			end
			box:Move(frame, scale)
		end,

		Hit = function(self: any, userId: number)
			self:Hurt(userId, C.Purple)
		end,
	},
})
