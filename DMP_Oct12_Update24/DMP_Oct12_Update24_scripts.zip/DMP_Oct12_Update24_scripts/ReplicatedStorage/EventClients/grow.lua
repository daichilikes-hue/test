-- ModuleScript: ReplicatedStorage > EventClients > grow     (NEW: Oct 11 Update 19, Rising Tomb)
-- What Rising Tomb looks like on each client. The server (Events > PlateGrow) makes the real plate grow taller, layer
-- by layer, and sink back again; this adds the tomb to it: it stirs (a rumble and dust at its foot) before it starts,
-- every stone layer that pushes up lands with a thud, a puff of dust and a little shake (less the farther you are),
-- and it carries a tombstone up on the side that faces the middle of the arena: the model Tomb under
-- ServerScriptService > Events > PlateGrow ("R.I.P.", a skull, two candles). Restyle that model freely.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not (FX.RigFrom and FX.Tagged and FX.UseSounds) then
	warn("[grow] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end

-- Sounds: paste your own ids into Id (the Stand ones are Roblox stand-ins)
--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	TombRumble = { Id = "", Stand = "rbxasset://sounds/action_get_up.mp3", Speed = 0.22, Volume = 1.1 }, -- it stirs, before it rises
	TombThud = { Id = "", Stand = "rbxasset://sounds/action_jump_land.mp3", Speed = 0.42, Volume = 1.3 }, -- a stone layer pushes up
	TombSink = { Id = "", Stand = "rbxasset://sounds/action_get_up.mp3", Speed = 0.3, Volume = 1.2 },    -- it sinks back down
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

local SHAKE = 1.1           -- each layer shakes the camera of whoever is near it (0 = none)
local PLAQUE_DOWN = 2.6     -- studs under the top of the tomb where the tombstone sits
local SHOW_PLAQUE = 4.5     -- the tombstone shows once the tomb is this much taller
local DUST = Color3.fromRGB(122, 112, 104)

-- dust all round the foot of the plate
local function dustAt(plate: BasePart, baseY: number, count: number, scale: number)
	local half = plate.Size / 2
	for _, x in { -1, 0, 1 } do
		for _, z in { -1, 0, 1 } do
			if x ~= 0 or z ~= 0 then
				local spot = (plate.CFrame * CFrame.new(x * half.X, 0, z * half.Z)).Position
				FX.Burst(Vector3.new(spot.X, baseY, spot.Z), "Dust", count, { Color = DUST, Scale = scale })
			end
		end
	end
end

return FX.Module({
	Tomb = {
		Init = function(self: any, props: any)
			self.Face = Vector3.new(props.FaceX or 0, 0, props.FaceZ or -1)
			-- the tombstone (the model Tomb: the framework cloned it as this visual), hidden until the tomb is tall
			self.Stone = if FX.RigFrom then FX.RigFrom(self.Inst) else FX.Rig(self.Inst)
			self.Stone:Fade(1)
			self.Lights, self.Words = {}, {}
			for _, item in self.Inst:GetDescendants() do
				if item:IsA("Light") then
					item.Enabled = false
					table.insert(self.Lights, item)
				elseif item:IsA("SurfaceGui") then
					item.Enabled = false
					table.insert(self.Words, item)
				end
			end
			self.Shown, self.Layer, self.Was = 0, 0, 0
		end,

		Step = function(self: any, dt: number, t: number)
			local p = self.Props
			local plate: Instance? = self.Plate
			if not (plate and plate.Parent) then
				plate = FX.Tagged(p.Tag)
				self.Plate = plate
			end
			if not (plate and plate:IsA("BasePart")) then
				return
			end
			local part: BasePart = plate
			local top = part.Position.Y + part.Size.Y / 2
			local baseTop: number = p.BaseTop or top
			local grown = math.max(top - baseTop, 0)
			local baseY = part.Position.Y - part.Size.Y / 2 + 0.3
			local foot = Vector3.new(part.Position.X, baseY, part.Position.Z)
			-- it stirs before it rises
			if not self.Stirred and t >= 0.05 then
				self.Stirred = true
				dustAt(part, baseY, 3, 1.1)
				FX.Sound("TombRumble", foot, 0.9 * FX.Near(foot, 40, 160))
				FX.Shake(SHAKE * 0.5, 6, 0.4, 0.8, foot, 30, 110)
			end
			-- every stone layer that pushes up: a thud, dust and a little shake
			local layer = math.floor((grown + 0.05) / (p.LayerHeight or 3))
			if layer > self.Layer then
				self.Layer = layer
				dustAt(part, baseY, 4, 1.4)
				FX.Sound("TombThud", foot, FX.Near(foot, 40, 170), 0.9 + layer * 0.04)
				FX.Shake(SHAKE, 10, 0.03, 0.35, foot, 30, 120)
			end
			-- it sinks back: one grind and dust
			if p.SinkBack and not self.Sinking and t >= (p.Rise or 5) + (p.Hold or 8) then
				self.Sinking = true
				dustAt(part, baseY, 4, 1.3)
				FX.Sound("TombSink", foot, FX.Near(foot, 40, 160))
			end
			-- the tombstone, on the side that faces the middle, a little under the top (it fades in once it is tall)
			local want = if grown >= SHOW_PLAQUE then 1 else 0
			local shown: number = self.Shown
			if shown ~= want then
				shown = math.clamp(shown + (if want > shown then dt else -dt) / 0.35, 0, 1)
				self.Shown = shown
				self.Stone:Fade(1 - shown)
				local on = shown > 0.05
				for _, light in self.Lights do
					light.Enabled = on
				end
				for _, words in self.Words do
					words.Enabled = shown > 0.6
				end
			end
			if shown > 0 then
				local face: Vector3 = self.Face
				local sideways = part.CFrame:VectorToObjectSpace(face)
				local reach = math.abs(sideways.X) * part.Size.X / 2 + math.abs(sideways.Z) * part.Size.Z / 2
				local at = Vector3.new(part.Position.X, top - PLAQUE_DOWN, part.Position.Z) + face * (reach + 0.02)
				self.Stone:Move(CFrame.lookAt(at, at + face))
			end
			self.Was = grown
		end,
	},
})
