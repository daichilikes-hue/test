-- ModuleScript: ReplicatedStorage > EventClients > ward     (NEW: Oct 12 Update 23, Gargoyle Ward)
-- What the Gargoyle Ward looks like on each client. The server (Events > GargoyleWard) protects the plate and halves
-- the damage on it; this draws the plinth (the model Ward under ServerScriptService > Events > GargoyleWard) on the
-- plate's outer corner, with its cold light over the plate, and THE WARDEN (the model Warden there, an R6 stone
-- gargoyle): he glides down onto the plinth in a puff of stone dust, sits watching the arena (WardPerch), rears up
-- with his eyes blazing and the runes lit when something tries to break his plate (WardRoar), and turns back to
-- dust at the end. Whoever he shields gets a little puff of stone dust.
-- HIS ANIMATIONS: WardPerch and WardRoar, KeyframeSequences in this module's Animations folder. In Studio they play
-- straight from there; for the real game upload them (right-click > Save to Roblox) and paste the ids into ANIMATIONS
-- below. (Not uploaded = in the game he sits there in his perch pose, still as a statue.)
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not (FX.Actor and FX.HoldPose and FX.OnPlate and FX.Clone and FX.UseSounds) then
	warn("[ward] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end

-- Sounds: paste your own ids into Id (Stand = a Roblox stand-in; "" = silence)
--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	WardLand = { Id = "", Stand = "rbxasset://sounds/impact_water.mp3", Speed = 0.4, Volume = 0.6 }, -- he lands on the plinth
	WardRoar = { Id = "", Stand = "", Speed = 1, Volume = 0.8 },                                   -- the ward holds: he roars
	WardShield = { Id = "", Stand = "", Speed = 1, Volume = 0.4 },                                 -- he takes half a hit off somebody
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

-- Your uploaded animation ids (0 = not uploaded yet: Studio plays the KeyframeSequences from the Animations folder)
--[[DMP:KEEP Animations]]
local ANIMATIONS = {
	WardPerch = 0, -- crouched on the plinth, watching (looped)
	WardRoar = 0,  -- rears up: the plate was saved
}
--[[DMP:END]]

local WARDEN_SCALE = 1.15   -- his size (1 = a normal R6 character)
local SIT = 3.0             -- studs his root sits over the top of the plinth (x his size), in his perch pose
local CAP_TOP = 4.35        -- studs from the plinth's foot to the top of its Cap (as the model is made)
local LAND = 1.4            -- seconds he takes to glide down onto the plinth
local FADE = 1.2            -- seconds he takes to crumble away at the end
local DUST = Color3.fromRGB(150, 148, 140)
local REST_POSE = { -- (GENERATED: `python3 animgen/npcs.py rest ward`)
	["RootJoint"] = CFrame.new(0, -0.469472, -1.817052, 1, 0, 0, 0, 0.882948, -0.469472, 0, 0.469472, 0.882948),
	["Neck"] = CFrame.new(0, 0, 0, 1, 0, 0, 0, 0.951057, 0.309017, 0, -0.309017, 0.951057),
	["Right Shoulder"] = CFrame.new(0, 0, 0, 0.788011, -0.60967, -0.085684, 0.615661, 0.780342, 0.10967, 0, -0.139173, 0.990268),
	["Left Shoulder"] = CFrame.new(0, 0, 0, 0.788011, 0.60967, 0.085684, -0.615661, 0.780342, 0.10967, 0, -0.139173, 0.990268),
	["Right Hip"] = CFrame.new(-0.048109, -0.020421, -0.002739, -0.390731, -0.915462, -0.096219, 0.920505, -0.388591, -0.040843, 0, -0.104528, 0.994522),
	["Left Hip"] = CFrame.new(0.048109, -0.020421, -0.002739, -0.390731, 0.915462, 0.096219, -0.920505, -0.388591, -0.040843, 0, -0.104528, 0.994522),
}

-- a puff of stone dust off him
local function puff(self: any)
	local dust = self.Dust
	if dust and not FX.Off("DisableParticles") then
		dust:Emit(tonumber(dust:GetAttribute("EmitCount")) or 14)
	end
end

return FX.Module({
	Ward = {
		Init = function(self: any, props: any)
			self.Follow = FX.OnPlate(props.Tag, self.Origin)
			self.Plinth = {}
			for _, item in self.Inst:GetDescendants() do
				if item:IsA("BasePart") then
					table.insert(self.Plinth, { Part = item, Transparency = item.Transparency })
				end
			end
			self.Runes = {}
			for _, item in self.Inst:GetChildren() do
				if item:IsA("BasePart") and string.sub(item.Name, 1, 4) == "Rune" then
					table.insert(self.Runes, { Part = item, Transparency = item.Transparency })
				end
			end
			local lamp = self.Inst:FindFirstChild("Light")
			self.Lamp = lamp and lamp:FindFirstChildOfClass("PointLight")
			self.LampBrightness = self.Lamp and self.Lamp.Brightness or 0.9
			-- the gargoyle himself
			local warden = FX.Clone("ward", "Warden", self.Inst)
			if warden and warden:FindFirstChild("HumanoidRootPart") then
				local problem = FX.R6Problem(warden)
				if problem then
					warn("[ward] the gargoyle (ServerScriptService > Events > GargoyleWard > Warden) cannot play his animations: " .. problem .. ". He is shown without them.")
				end
				if WARDEN_SCALE ~= 1 and WARDEN_SCALE > 0 then
					warden:ScaleTo(warden:GetScale() * WARDEN_SCALE)
				end
				self.Scale = warden:GetScale()
				self.Warden = warden
				self.Body = {}
				for _, item in warden:GetDescendants() do
					if item:IsA("BasePart") then
						table.insert(self.Body, { Part = item, Transparency = item.Transparency })
					end
				end
				self.Eyes = {}
				for _, name in { "EyeL", "EyeR" } do
					local eye = warden:FindFirstChild(name, true)
					if eye and eye:IsA("BasePart") then
						table.insert(self.Eyes, { Part = eye, Color = eye.Color })
					end
				end
				local dust = warden:FindFirstChild("Dust", true)
				self.Dust = if dust and dust:IsA("ParticleEmitter") then dust else nil
				local glow = warden:FindFirstChild("EyeLight", true)
				self.EyeLight = if glow and glow:IsA("PointLight") then glow else nil
				self.Actor = FX.Actor(warden, ANIMATIONS, script)
			end
			self.Faded = -1
			self.Flare = 0
		end,

		Step = function(self: any, dt: number, t: number)
			local base, there = self.Follow()
			local duration = tonumber(self.Props.Duration) or 25
			if self.LastBase ~= base then
				self.LastBase = base
				self.Inst:PivotTo(base)
			end
			local landed = FX.Clamp01(t / LAND)
			local gone = FX.Clamp01((t - (duration - FADE)) / FADE)
			if not there and self.WasThere then
				self.GoneAt = self.GoneAt or t
				gone = math.max(gone, FX.Clamp01((t - self.GoneAt) / 0.6))
			end
			self.WasThere = self.WasThere or there
			if landed >= 1 and not self.Landed then
				self.Landed = true
				puff(self)
				FX.Sound("WardLand", base.Position)
			end
			self.Flare = math.max(self.Flare - dt / 1.2, 0)
			-- the plinth fades in quickly, out with him
			local shown0 = math.min(FX.Clamp01(t / 0.5), 1 - gone)
			local shown = if shown0 > 0.99 then 1 elseif shown0 < 0.01 then 0 else shown0
			if shown ~= self.Faded and (math.abs(shown - self.Faded) > 0.01 or shown == 0 or shown == 1) then
				self.Faded = shown
				for _, entry in self.Plinth do
					entry.Part.Transparency = entry.Transparency + (1 - entry.Transparency) * (1 - shown)
				end
			end
			for _, rune in self.Runes do
				rune.Part.Transparency = math.max(rune.Transparency - 0.6 * self.Flare, 0) + (1 - rune.Transparency) * (1 - shown)
			end
			if self.Lamp then
				self.Lamp.Brightness = self.LampBrightness * shown * (1 + 1.5 * self.Flare)
			end
			-- him: gliding down onto the cap, then sitting there
			local actor = self.Actor
			if not actor then
				return
			end
			local glide = 1 - FX.Ease.Out(landed)
			local seat = base * CFrame.new(0, CAP_TOP + SIT * self.Scale + 9 * glide, 4 * glide)
			actor.Place(seat)
			if actor.Animated then
				if not self.Perching then
					self.Perching = actor.Play("WardPerch", 0.3) ~= nil
				end
			else
				FX.HoldPose(self.Warden, REST_POSE) -- (no animations uploaded: he sits like a statue)
			end
			for _, eye in self.Eyes do
				eye.Part.Color = eye.Color:Lerp(Color3.fromRGB(235, 250, 255), self.Flare)
			end
			if self.EyeLight then
				self.EyeLight.Brightness = 0.6 + 3 * self.Flare
			end
			local fade0 = math.max(1 - FX.Clamp01(t / 0.6), gone)
			local fade = if fade0 > 0.99 then 1 elseif fade0 < 0.01 then 0 else fade0
			local was = self.BodyFaded or -1
			if fade ~= was and (math.abs(fade - was) > 0.01 or fade == 0 or fade == 1) then
				self.BodyFaded = fade
				for _, entry in self.Body do
					entry.Part.Transparency = entry.Transparency + (1 - entry.Transparency) * fade
				end
				if gone > 0 and not self.Crumbled then
					self.Crumbled = true
					puff(self)
				end
			end
		end,

		-- something tried to destroy his plate and the ward held
		Held = function(self: any)
			self.Flare = 1
			if self.Actor then
				self.Actor.Play("WardRoar", 0.1, 1, 0)
			end
			puff(self)
			local base = self.LastBase or self.Origin
			FX.Sound("WardRoar", base.Position)
			FX.Shake(0.8, 10, 0.05, 0.4, base.Position, 25, 90)
		end,

		-- he took half a hit off this player
		Shield = function(_self: any, userId: number)
			local root = FX.Root(userId)
			if root then
				FX.Burst(root.Position, "Smoke", 6, { Color = DUST, Scale = 0.6 })
				FX.Sound("WardShield", root.Position)
			end
		end,
	},
})
