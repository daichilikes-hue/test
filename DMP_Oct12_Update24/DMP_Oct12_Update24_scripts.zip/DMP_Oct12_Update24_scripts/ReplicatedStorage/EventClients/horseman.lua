-- ModuleScript: ReplicatedStorage > EventClients > horseman     (NEW)
-- What the Headless Horseman looks like on each client: a black horse with burning eyes, a rider with no
-- head and a flaming jack-o'-lantern held high. He turns to face his target while he winds up (the client
-- reads the target's own position, so it is perfectly smooth), rears higher when he locks on, then gallops.
-- Oct 10 2026 (update 8): no line on the ground (AIM_LINE below brings it back), the warning over his target's
-- head is your ExclamationWarning (FX.HeadWarning), and much less camera shake.
-- The server (Events > HeadlessHorseman) decides who gets trampled.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not (FX.HeadWarning) then
	warn("[horseman] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end

local C = FX.Colors
local COAT = Color3.fromRGB(34, 26, 30)
local CLOTH = Color3.fromRGB(18, 14, 18)
local LEGS: { [string]: Vector3 } = { LegFL = Vector3.new(-1.1, 3.5, -2.9), LegFR = Vector3.new(1.1, 3.5, -2.9), LegBL = Vector3.new(-1.1, 3.5, 2.9), LegBR = Vector3.new(1.1, 3.5, 2.9) }
local LEG_PHASE: { [string]: number } = { LegFL = 0, LegFR = 0.6, LegBL = math.pi, LegBR = math.pi + 0.6 }
local AIM_LINE = false   -- true = the orange / red line on the ground along his path again
local PASS_SHAKE = 1.5   -- camera shake as he thunders past your camera (was 5)
local HIT_SHAKE = 1.5    -- camera shake when he tramples YOU (was 4)

local function buildRider(parent: Instance): FX.Rig
	local rig = FX.Rig(parent)
	-- the horse (it faces -Z)
	rig:Egg("Body", Vector3.new(3.7, 3.9, 8.6), CFrame.new(0, 4.9, 0), COAT)
	rig:Egg("Neck", Vector3.new(2.3, 4.6, 2.6), CFrame.new(0, 6.9, -3.6) * CFrame.Angles(math.rad(-28), 0, 0), COAT)
	rig:Egg("Head", Vector3.new(1.9, 2.2, 3.8), CFrame.new(0, 8.7, -5.3) * CFrame.Angles(math.rad(22), 0, 0), COAT)
	rig:Block("Mane", Vector3.new(0.45, 3.6, 1.3), CFrame.new(0, 7.6, -2.8) * CFrame.Angles(math.rad(-28), 0, 0), CLOTH)
	rig:Egg("Tail", Vector3.new(0.9, 1, 3.8), CFrame.new(0, 5.2, 5.4) * CFrame.Angles(math.rad(-28), 0, 0), CLOTH)
	for _, side in { -1, 1 } do
		rig:Egg("Ear", Vector3.new(0.4, 0.9, 0.4), CFrame.new(side * 0.55, 9.9, -4.6), COAT)
		rig:Add(FX.Ball(parent, 0.45, Vector3.new(), C.Orange, Enum.Material.Neon), CFrame.new(side * 0.75, 9.1, -5.8), "Eye")
	end
	for name, hip in LEGS do
		rig:Egg(name, Vector3.new(1.05, 3.7, 1.05), CFrame.new(hip) * CFrame.new(0, -1.75, 0), COAT)
	end
	-- the rider: a coat with a tall collar and nothing above it
	rig:Block("Coat", Vector3.new(2.5, 3.2, 1.7), CFrame.new(0, 8.3, 0.5), CLOTH)
	rig:Block("Shoulders", Vector3.new(3.3, 0.8, 1.9), CFrame.new(0, 9.7, 0.5), CLOTH)
	rig:Cyl("Collar", 1.5, 0.7, CFrame.new(0, 10.4, 0.5), Color3.fromRGB(70, 20, 26))
	rig:Block("ArmReins", Vector3.new(0.7, 0.7, 2.6), CFrame.new(-1.5, 8.6, -0.9), CLOTH)
	rig:Block("ArmUp", Vector3.new(0.7, 2.9, 0.7), CFrame.new(1.9, 10.8, 0.1) * CFrame.Angles(0, 0, math.rad(-24)), CLOTH)
	for i = 1, 3 do
		rig:Block("Cape" .. i, Vector3.new(2.6 - i * 0.2, 0.2, 2.1), CFrame.new(0, 9.4 - i * 0.5, 1.4 + i * 1.7), Color3.fromRGB(96, 18, 28))
	end
	FX.AddPumpkin(rig, "Pumpkin", CFrame.new(2.7, 12.8, 0), 2.5, true)
	return rig
end

return FX.Module({
	Horseman = {
		Init = function(self: any, props: any)
			local rig = buildRider(self.Inst)
			rig:Move(self.Origin * CFrame.new(0, -90, 0))
			rig:Fade(1)
			self.Rig = rig
			self.Mode = "hidden"
			self.Reach = props.Reach or 70
			self.Width = props.Width or 6
			local pumpkin, collar, body = rig:Get("Pumpkin"), rig:Get("Collar"), rig:Get("Body")
			if pumpkin then
				FX.Trail(pumpkin, C.Orange, 2.2, 0.45)
				FX.Emitter(pumpkin, "Fire", { Color = C.Orange, Rate = 30, Scale = 1.5 })
			end
			if collar then
				FX.Emitter(collar, "Fire", { Color = Color3.fromRGB(120, 255, 150), Rate = 16, Scale = 0.9 })
			end
			if body then
				FX.Emitter(body, "Ember", { Color = C.Orange, Rate = 30, Scale = 1.6, EmissionDirection = Enum.NormalId.Bottom })
			end
			-- his aim line (only with AIM_LINE: one part, kept out of sight otherwise)
			self.Line = FX.Block(self.Inst, Vector3.new(self.Width, 0.2, self.Reach * 2), self.Origin * CFrame.new(0, -90, 0), C.Orange, Enum.Material.Neon, 1)
			self.Line.Name = "AimLine"
		end,

		-- (K.Signal) he appears at `from` and starts lining up on that player
		Aim = function(self: any, from: Vector3, userId: number, start: number, aimTime: number, lockTime: number)
			self.Mode = "aim"
			self.From, self.Target, self.AimStart, self.AimTime, self.LockTime = from, userId, start, aimTime, lockTime
			self.Dir = FX.Dir(self.Origin.Position - from)
			self.Locked = false
			self.Rig:Fade(0)
			FX.SetEmitters(self.Inst, true)
			self.Line.Color = C.Orange
			self.Line.Transparency = if AIM_LINE then 0.6 else 1
			FX.Poof(from + Vector3.new(0, 5, 0), C.Orange, 3)
			FX.Sound("Lunge", from, 1.2, 0.6)
			-- the warning over his target's head, for everybody to see (ReplicatedStorage > Assets > ExclamationWarning)
			FX.HeadWarning(userId)
		end,

		-- (K.Signal) the line stops following: this is where he will go
		Lock = function(self: any, dir: Vector3)
			self.Dir = FX.Dir(dir, self.Dir)
			self.Locked = true
			self.Line.Color = C.Warn
			self.Line.Transparency = if AIM_LINE then 0.35 else 1
			if self.From then
				FX.Sound("Shing", self.From, 1, 0.8)
			end
		end,

		-- (K.Signal) off he goes
		Charge = function(self: any, from: Vector3, dir: Vector3, go: number, speed: number, distance: number)
			self.Mode = "charge"
			self.From, self.Dir, self.Go, self.Speed, self.Distance = from, FX.Dir(dir), go, speed, distance
			self.Passed, self.NextDust, self.NextFire, self.NextHoof = false, 0, 0, 0
			self.Line.Color = C.Warn
			self.Line.Transparency = if AIM_LINE then 0.5 else 1
		end,

		Step = function(self: any, _dt: number, t: number)
			local rig: FX.Rig = self.Rig
			local line: Part = self.Line
			local mode: string = self.Mode
			if mode == "aim" then
				local from: Vector3 = self.From
				if not self.Locked then
					local root = FX.Root(self.Target)
					if root then
						self.Dir = FX.Dir(root.Position - from, self.Dir)
					end
				end
				local dir: Vector3 = self.Dir
				local far = from + dir * (self.Reach * 2)
				if AIM_LINE then
					line.CFrame = FX.Facing((from + far) / 2 + Vector3.new(0, 0.14, 0), dir)
					if not self.Locked then
						line.Transparency = 0.6 + math.sin(t * 9) * 0.12
					end
				end
				-- he rears and paws the ground (higher once the line has locked)
				local rear = (if self.Locked then 0.55 else 0.2) + math.abs(math.sin(t * 3.2)) * 0.22
				for name, hip in LEGS do
					local front = hip.Z < 0
					local swing = if front then -0.9 + math.sin(t * 9 + LEG_PHASE[name]) * 0.5 else 0.25
					rig:Pose(name, CFrame.new(hip) * CFrame.Angles(swing, 0, 0) * CFrame.new(0, -1.75, 0))
				end
				rig:Move(FX.Facing(from, dir) * CFrame.new(0, 0, 3) * CFrame.Angles(rear, 0, 0) * CFrame.new(0, 0, -3))
			elseif mode == "charge" then
				local gone = (FX.Now() - self.Go) * self.Speed
				local dir: Vector3, from: Vector3 = self.Dir, self.From
				if gone >= self.Distance then
					-- off the far edge and gone
					self.Mode = "hidden"
					local last = from + dir * self.Distance
					rig:Fade(1)
					rig:Move(self.Origin * CFrame.new(0, -90, 0))
					line.Transparency = 1
					FX.SetEmitters(self.Inst, false)
					FX.Poof(last + Vector3.new(0, 5, 0), C.Orange, 3)
					return
				end
				local position = from + dir * gone
				local gallop = gone * 0.42
				for name, hip in LEGS do
					rig:Pose(name, CFrame.new(hip) * CFrame.Angles(math.sin(gallop + LEG_PHASE[name]) * 0.95, 0, 0) * CFrame.new(0, -1.75, 0))
				end
				for i = 1, 3 do
					rig:Pose("Cape" .. i, CFrame.new(0, 9.4 - i * 0.5 + math.sin(gallop * 2 - i) * 0.35 * i, 1.4 + i * 1.7))
				end
				rig:Move(FX.Facing(position + Vector3.new(0, math.abs(math.sin(gallop)) * 0.9, 0), dir) * CFrame.Angles(math.sin(gallop) * 0.06 - 0.05, 0, 0))
				if AIM_LINE then
					line.Transparency = 0.5 + 0.5 * FX.Span(gone, self.Distance * 0.6, self.Distance)
				end
				-- dust and scorch marks under the hooves, hoofbeats, and a jolt as he thunders past your camera
				if gone >= self.NextDust then
					self.NextDust = gone + 6
					FX.Burst(position, "Dust", 5, { Color = Color3.fromRGB(150, 140, 130), Scale = 1.4 })
				end
				if gone >= self.NextFire then
					self.NextFire = gone + 11
					FX.Burst(position + Vector3.new(0, 0.5, 0), "Fire", 5, { Color = C.Orange, Scale = 1.5 })
				end
				if gone >= self.NextHoof then
					self.NextHoof = gone + 14
					FX.Sound("Thud", position, 0.7, 1.5)
				end
				if not self.Passed and FX.Near(position, 14, 34) > 0.3 then
					self.Passed = true
					FX.Shake(PASS_SHAKE, 14, 0.05, 0.4, position, 14, 40)
					FX.Sound("Whoosh", position, 1.2, 0.6)
				end
			end
		end,

		-- (K.Strike) trampled. (self:Hurt would shake the camera by 4: this does the same sparks with a small shake.)
		Hit = function(_self: any, userId: number)
			local root = FX.Root(userId)
			if root then
				FX.Burst(root.Position, "Spark", 14, { Color = C.Orange })
				FX.Burst(root.Position, "Fire", 8, { Color = C.Orange, Scale = 1.4 })
				FX.Sound("Thud", root.Position, 0.7, 1.3)
			end
			if FX.IsMe(userId) then
				FX.Shake(HIT_SHAKE, 14, 0.03, 0.3)
				FX.Pulse(C.Blood, 0.5, 0.25)
			end
		end,
	},
})
