-- ModuleScript: ReplicatedStorage > EventClients > pulse     (Oct 11 Update 16: the banshee)
-- Client visuals for the Death Pulse. The rings that spread out from the middle are THE BANSHEE'S SCREAMS: she
-- hangs over the middle of the arena (the model Pulse under ServerScriptService > Events > DeathPulse: an R6
-- character), turns to stare at YOU, and every time a ring goes out she draws in, then throws her head up, flings her
-- arms out and SCREAMS, and the ring tears out from under her (one model Ring per ring, cloned from the same place).
-- Jump over each ring. Timing, damage and the jump rule are exactly as before: the server (Events > DeathPulse) is
-- unchanged. If a ring touches YOUR character, this tells the server (which double-checks it), exactly as before.
-- HER ANIMATIONS: BansheeFloat and BansheeScream, KeyframeSequences in this module's Animations folder. In Studio they
-- play straight from there; for the real game upload them (right-click > Save to Roblox) and paste the ids into
-- ANIMATIONS below. (Not uploaded = in the game she hangs there stiff, only leaning into her screams.)
-- The code needs these names: Pulse = an R6 rig (HumanoidRootPart, Torso, Head, arms, legs on Motor6Ds) with EyeL,
-- EyeR, Mouth, MouthGlow > Breath and Glow > Light, Wail welded on; Ring > Seg1..Seg48 (Wisp emitters on some).
-- No Pulse / Ring model there (an older install): the old purple rings are built here, as before.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local FX = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not (FX.Clone and FX.Actor and FX.UseSounds) then
	warn("[pulse] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end

-- YOUR SOUNDS: put an id in Id. While Id is "" the built-in Roblox sound in Stand plays ("" = silence).
--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	BansheeScream = { Id = "", Stand = "rbxasset://sounds/swordslash.wav", Speed = 0.35, Volume = 1.2 }, -- every ring: her scream (the stand-in is only a whoosh: a real scream sells it)
	BansheeWail = { Id = "", Stand = "", Speed = 1, Volume = 0.8 },                                   -- she rises out of the arena
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

-- Your uploaded animation ids (0 = not uploaded yet: Studio plays the KeyframeSequences from the Animations folder)
--[[DMP:KEEP Animations]]
local ANIMATIONS = {
	BansheeFloat = 0,  -- hanging in the air (looped)
	BansheeScream = 0, -- one scream: the ring leaves 0.32 s into it
}
--[[DMP:END]]
local SCREAM_LEAD = 0.32    -- KEEP IN SYNC with SNAP in DMP_tools animgen/banshee.py (when in BansheeScream she screams)

local BANSHEE_SCALE = 1.8   -- her size (1 = a normal R6 character)
local STARE = true          -- she turns to stare at YOU (every player sees her looking at them)
local HOVER = 1.5           -- studs between the plate and the lowest rag of her dress
local RISE = 6              -- studs she rises out of the plate before the first scream
local SHAKE = 1.4           -- how much each scream shakes your camera (near her; less far away). 0 = none

local Pulse = {}

local SEGMENTS = 48
local RING_COLOR = Color3.fromRGB(170, 60, 230) -- (the old rings, only when the Ring model is missing)

local player = Players.LocalPlayer
local eventHitRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("EventHit") :: RemoteEvent

local function part(props): Part
	local p = Instance.new("Part")
	p.Anchored = true
	p.CanCollide = false
	p.CanQuery = false
	p.CanTouch = false
	for key, value in props do
		(p :: any)[key] = value
	end
	return p
end

-- The visual is just a center marker; the rings are made here
-- (only used when ServerScriptService > Events > DeathPulse has no model named Pulse: the framework clones that one)
function Pulse.Build(): Model
	local model = Instance.new("Model")
	model.Name = "Pulse"
	local core = part({ Name = "Core", Shape = Enum.PartType.Cylinder, Size = Vector3.new(0.3, 5, 5), CFrame = CFrame.Angles(0, 0, math.rad(90)), Color = RING_COLOR, Material = Enum.Material.Neon, Transparency = 0.3 })
	core.Parent = model
	model.PrimaryPart = core
	return model
end

-- one ring: its 48 pieces (cloned from the model Ring, else built as before)
local function makeRing(parent: Instance?, props): { Segments: { BasePart }, Model: Model?, Transparency: { number }, Wisps: { ParticleEmitter } }
	local ring = { Segments = {}, Transparency = {}, Wisps = {} }
	local copy = if FX.Clone then FX.Clone("pulse", "Ring", parent) else nil
	if copy then
		ring.Model = copy
		for s = 1, SEGMENTS do
			local segment = copy:FindFirstChild("Seg" .. s)
			if segment and segment:IsA("BasePart") then
				table.insert(ring.Segments, segment)
				table.insert(ring.Transparency, segment.Transparency)
				segment.Transparency = 1
				for _, item in segment:GetChildren() do
					if item:IsA("ParticleEmitter") then
						item.Enabled = false
						table.insert(ring.Wisps, item)
					end
				end
			end
		end
	end
	if #ring.Segments == 0 then
		if copy then
			copy:Destroy()
			ring.Model = nil
		end
		for _ = 1, SEGMENTS do
			local segment = part({
				Name = "RingSegment",
				Size = Vector3.new(props.RingWidth, props.RingHeight, 1),
				Color = RING_COLOR,
				Material = Enum.Material.Neon,
				Transparency = 1,
				Parent = parent, -- not inside the model, so moving the model doesn't drag them
			})
			table.insert(ring.Segments, segment)
			table.insert(ring.Transparency, 0.25)
		end
	end
	return ring
end

-- the banshee: the R6 model as an FX.Actor (nil when the visual is the old marker)
local function makeBanshee(model: Instance)
	if not (model:IsA("Model") and model:FindFirstChild("Head") and FX.Actor) then
		return nil
	end
	local problem = if FX.R6Problem then FX.R6Problem(model) else nil
	if problem then
		warn("[pulse] the banshee (ServerScriptService > Events > DeathPulse > Pulse) cannot play her animations: " .. problem .. ". She is shown without them.")
	end
	if BANSHEE_SCALE ~= 1 and BANSHEE_SCALE > 0 then
		model:ScaleTo(model:GetScale() * BANSHEE_SCALE) -- (relative: the model may already be scaled in Studio)
	end
	local banshee = { Parts = {}, Eyes = {}, Yaw = 0, Faded = -1, Screams = 0 }
	-- how high her root sits over her lowest point (so the hem floats HOVER studs over the plate)
	local root = model:FindFirstChild("HumanoidRootPart")
	local boxFrame, boxSize = (model :: Model):GetBoundingBox()
	local rootY = if root and root:IsA("BasePart") then root.Position.Y else (model :: Model):GetPivot().Position.Y
	banshee.Lift = rootY - (boxFrame.Position.Y - boxSize.Y / 2)
	for _, item in model:GetDescendants() do
		if item:IsA("BasePart") then
			table.insert(banshee.Parts, { Part = item, Transparency = item.Transparency })
			if item.Name == "EyeL" or item.Name == "EyeR" then
				table.insert(banshee.Eyes, { Part = item, Size = item.Size })
			elseif item.Name == "Mouth" then
				banshee.Mouth = { Part = item, Size = item.Size }
			end
		end
	end
	local glow = model:FindFirstChild("Glow", true)
	banshee.Light = glow and glow:FindFirstChildOfClass("PointLight")
	banshee.Brightness = banshee.Light and banshee.Light.Brightness or 1.5
	banshee.Wail = glow and glow:FindFirstChild("Wail")
	local mouth = model:FindFirstChild("MouthGlow", true)
	banshee.Breath = mouth and mouth:FindFirstChild("Breath")
	banshee.Actor = FX.Actor(model :: Model, ANIMATIONS, script)
	return banshee
end

function Pulse.Spawned(model: PVInstance, state, props)
	state.Props = props
	state.Origin = model:GetPivot().Position
	state.Rings = {}
	state.Reported = {}
	state.Screamed = 0
	state.SpawnedAt = workspace:GetServerTimeNow()
	local ok, err = pcall(function()
		state.Banshee = makeBanshee(model)
	end)
	if not ok then
		warn("[pulse] the banshee could not be set up: " .. tostring(err))
	end
	for index = 1, props.RingCount do
		state.Rings[index] = makeRing(model.Parent, props)
	end
	if state.Banshee then
		FX.Sound("BansheeWail", state.Origin + Vector3.new(0, 8, 0))
	end
end

local function feetY(): number?
	local character = player.Character
	local root = character and character:FindFirstChild("HumanoidRootPart") :: BasePart?
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	if not root or not humanoid then
		return nil
	end
	local legs = if humanoid.RigType == Enum.HumanoidRigType.R6 then 2 else humanoid.HipHeight
	return root.Position.Y - root.Size.Y / 2 - legs
end

-- the rings, where the server says they are
local function drawRings(state, t: number)
	local props = state.Props
	local origin = state.Origin
	local particles = not FX.Off("DisableParticles")
	for index, ring in state.Rings do
		local age = t - (index - 1) * props.RingInterval
		local radius = age * props.RingSpeed
		local active = age > 0 and radius <= props.MaxRadius
		-- (it thins out over the last stretch before it is gone)
		local fade = if active then math.clamp((radius - props.MaxRadius * 0.85) / (props.MaxRadius * 0.15), 0, 1) else 1
		local count = #ring.Segments
		for s, segment in ring.Segments do
			if active then
				local angle = (s / count) * math.pi * 2
				local length = (2 * math.pi * radius) / count + 0.3
				local position = origin + Vector3.new(math.cos(angle) * radius, props.RingHeight / 2, math.sin(angle) * radius)
				segment.Size = Vector3.new(props.RingWidth, props.RingHeight, length)
				-- Each segment runs along the ring (tangent to the circle)
				segment.CFrame = CFrame.lookAt(position, position + Vector3.new(-math.sin(angle), 0, math.cos(angle)))
				local base = ring.Transparency[s] or 0.25
				segment.Transparency = base + (1 - base) * fade
			elseif segment.Transparency ~= 1 then
				segment.Transparency = 1
			end
		end
		local wisps = active and particles and fade < 0.8
		if ring.WispsOn ~= wisps then
			ring.WispsOn = wisps
			for _, wisp in ring.Wisps do
				wisp.Enabled = wisps
			end
		end
	end
end

-- 0..1: how hard she is screaming at time t (ring i goes out at (i - 1) x RingInterval), and 0..1 of the wind-up
-- just before the next one
local function screamAt(props, t: number): (number, number)
	local interval = props.RingInterval
	local count = props.RingCount
	local last = if t >= 0 then math.min(math.floor(t / interval) + 1, count) else 0
	local scream = 0
	if last > 0 then
		local since = t - (last - 1) * interval
		scream = if since < 0.08 then since / 0.08 elseif since < 0.45 then 1 else math.max(0, 1 - (since - 0.45) / 0.5)
	end
	local windUp = 0
	if last < count then
		local untilNext = last * interval - t
		if untilNext > 0 and untilNext < 0.32 then
			windUp = 1 - untilNext / 0.32
		end
	end
	return scream, windUp
end

local function poseBanshee(state, base: CFrame, t: number, dt: number)
	local banshee = state.Banshee
	local props = state.Props
	if not banshee then
		return
	end
	local actor = banshee.Actor
	local scream, windUp = screamAt(props, t)
	-- she rises out of the plate before the first scream, and fades away after the last one
	local now = workspace:GetServerTimeNow()
	local warm = math.max(props.StartTime - (state.SpawnedAt or now), 0.4)
	local rise = FX.Ease.Out(FX.Clamp01((now - (state.SpawnedAt or now)) / warm))
	local finish = (props.RingCount - 1) * props.RingInterval + 1
	local gone = FX.Clamp01((t - finish) / 1.2)
	-- she turns to stare at you
	if STARE then
		local me = FX.MyRoot()
		if me then
			local flat = FX.Flat(me.Position - base.Position)
			if flat.Magnitude > 0.5 then
				local want = math.atan2(-flat.X, -flat.Z)
				local delta = (want - banshee.Yaw + math.pi) % (2 * math.pi) - math.pi
				banshee.Yaw += delta * math.min(dt * 2.5, 1)
			end
		end
	end
	local bob = math.sin(t * 2.1) * 0.35
	local height = HOVER + banshee.Lift - RISE * (1 - rise) + bob - 3 * gone
	local place = CFrame.new(base.Position + Vector3.new(0, height, 0)) * CFrame.Angles(0, banshee.Yaw, 0)
	if not actor.Animated then
		-- (no animations to play: she at least leans into her screams)
		place *= CFrame.Angles(-math.rad(12) * scream + math.rad(6) * windUp, 0, 0)
	end
	actor.Place(place)
	-- her animations: the float all the time, a scream SCREAM_LEAD before every ring
	if not banshee.Floating then
		banshee.Floating = actor.Play("BansheeFloat", 0.3) ~= nil
	end
	local count = props.RingCount
	local nextScream = banshee.Screams + 1
	if nextScream <= count and t >= (nextScream - 1) * props.RingInterval - SCREAM_LEAD then
		banshee.Screams = nextScream
		actor.Play("BansheeScream", 0.05, 1, 0)
	end
	-- the mouth gapes, the eyes flare, the light swells
	if banshee.Mouth then
		local size = banshee.Mouth.Size
		banshee.Mouth.Part.Size = Vector3.new(size.X * (1 + 0.45 * scream), size.Y * (1 + 1.3 * scream), size.Z)
	end
	for _, eye in banshee.Eyes do
		eye.Part.Size = eye.Size * (1 + 0.9 * scream)
	end
	if banshee.Light then
		banshee.Light.Brightness = banshee.Brightness * (1 + 1.5 * scream) * (1 - gone)
	end
	-- fading in and out
	local alpha = math.max(1 - rise, gone)
	if math.abs(alpha - banshee.Faded) > 0.01 then
		banshee.Faded = alpha
		for _, entry in banshee.Parts do
			entry.Part.Transparency = entry.Transparency + (1 - entry.Transparency) * alpha
		end
		if banshee.Wail and banshee.Wail:IsA("ParticleEmitter") then
			banshee.Wail.Enabled = alpha < 0.5 and not FX.Off("DisableParticles")
		end
	end
end

-- the moment a ring goes out: her scream
local function screamNow(state, index: number)
	local banshee = state.Banshee
	local at = state.Origin + Vector3.new(0, 14, 0)
	FX.Sound("BansheeScream", at, 1, 0.9 + 0.08 * index)
	if banshee and banshee.Breath and banshee.Breath:IsA("ParticleEmitter") and not FX.Off("DisableParticles") then
		banshee.Breath:Emit(tonumber(banshee.Breath:GetAttribute("EmitCount")) or 18)
	end
	if SHAKE > 0 then
		FX.Shake(SHAKE, 12, 0.03, 0.45, state.Origin, 30, 160)
	end
end

function Pulse.Render(model: PVInstance, state, base: CFrame?, dt: number?)
	local props = state.Props
	local origin = state.Origin
	local t = workspace:GetServerTimeNow() - props.StartTime

	-- My own position, for hit checks
	local character = player.Character
	local root = character and character:FindFirstChild("HumanoidRootPart") :: BasePart?
	local myFeet = feetY()
	local myDistance = if root then ((root.Position - origin) * Vector3.new(1, 0, 1)).Magnitude else nil

	for index in state.Rings do
		local age = t - (index - 1) * props.RingInterval
		local radius = age * props.RingSpeed
		local active = age > 0 and radius <= props.MaxRadius

		-- Did this ring just touch me? (tell the server once per ring)
		if active and not state.Reported[index] and myDistance and myFeet and player:GetAttribute("Alive") == true then
			local groundY = origin.Y
			if myFeet < groundY + props.RingHeight and math.abs(myDistance - radius) <= props.RingWidth / 2 + 1 then
				state.Reported[index] = true
				eventHitRemote:FireServer(props.EventName, index)
			end
		end
		-- the scream that sends it out
		if age >= 0 and index > state.Screamed then
			state.Screamed = index
			pcall(screamNow, state, index)
		end
	end

	-- (what you see: an error here must never stop the hit checks above)
	local ok, err = pcall(function()
		drawRings(state, t)
		if state.Banshee then
			poseBanshee(state, base or CFrame.new(origin), t, math.min(dt or 1 / 60, 0.1))
		else
			-- Center throbs
			model:PivotTo(CFrame.new(origin + Vector3.new(0, 0.1, 0)) * CFrame.Angles(0, 0, math.rad(90)))
		end
	end)
	if not ok and not state.Warned then
		state.Warned = true
		warn("[pulse] drawing failed: " .. tostring(err))
	end
end

function Pulse.Destroyed(_model: PVInstance, state)
	for _, ring in state.Rings or {} do
		if ring.Model then
			ring.Model:Destroy()
		end
		for _, segment in ring.Segments do
			segment:Destroy()
		end
	end
end

return Pulse
