-- ModuleScript: ReplicatedStorage > EventClients > trickortreat     (Oct 11 Update 18: the door on your screen)
-- What a Trick or Treat door looks like on each client: a crooked little porch pops up in a puff of smoke,
-- with a lantern, two jack-o'-lanterns and a door that rattles while its window flickers between gold and
-- purple. Knock: knock knock, it creaks open, light pours out, and then either sweets and confetti burst
-- out (TREAT) or a ghost lunges at you (TRICK).
-- [Update 18] The player who knocked gets NO pop-up window any more (no box, no text: what you got is in the toast).
-- They get the ViewportFrame on its own: the same 3D door standing on their screen (a Camera inside the ViewportFrame
-- and set as its CurrentCamera, the parts in a WorldModel, a see-through background). It knocks with your knocks,
-- creaks open towards you, and the treat flies out at you, or the ghost lunges at you.
-- The models are under ServerScriptService > Events > TrickOrTreat (restyle them there): Door (the porch: the one on
-- the plate AND the one on your screen), Ghost, Treat, and the ScreenGui DoorView (move / resize its View). Missing
-- models (an old install) = the porch and the ghost are built here as before. Knobs: the SCREEN block below.
-- The server (Events > TrickOrTreat) decides what is behind each door.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not (FX.RigFrom and FX.Clone and FX.Gui) then
	warn("[trickortreat] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so the door on your screen is not shown. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end

local C = FX.Colors
local WOOD = Color3.fromRGB(150, 90, 40)
local WOOD_DARK = Color3.fromRGB(58, 38, 30)
local PLANK = Color3.fromRGB(118, 68, 32)
local IRON = Color3.fromRGB(62, 62, 70)
local ROOF = Color3.fromRGB(60, 38, 72)
local STONE = Color3.fromRGB(96, 92, 100)
local MAT = Color3.fromRGB(110, 24, 34)
local TREAT = C.Gold
local TRICK = Color3.fromRGB(180, 110, 235)
local CANDY = { Color3.fromRGB(255, 140, 50), Color3.fromRGB(255, 110, 160), C.Gold, Color3.fromRGB(140, 220, 120), C.White }
local UP = Vector3.new(0, 1, 0)
local HINGE = CFrame.new(-2, 0, -0.14)   -- the door turns on its left edge
local OPEN = math.rad(105)
local SHOW_TIME = 4.2                    -- seconds the door stays on the knocker's screen

-- [Update 18] YOUR SCREEN when you knock (where it sits and how big it is: the View in the ScreenGui DoorView)
local SCREEN = true         -- false = nothing on your screen (the door on the plate still does everything)
local VIEW_DISTANCE = 19.5  -- how far the camera starts from the door (the door looks smaller the farther)
local VIEW_CLOSER = 1.5     -- ... and how much closer it creeps while it plays
local GHOST_REACH = 0.5     -- the ghost lunges this far towards the camera (1 = right into the lens)
local TREAT_REACH = 0.5     -- the treat flies this far towards the camera
local ID = "trickortreat"

---------------------------------------------------------------------
-- [Update 18] The porch, the ghost and the treat are MODELS under ServerScriptService > Events > TrickOrTreat
-- (copied to ReplicatedStorage > EventAssets > trickortreat when the server starts). Built here only when missing.
---------------------------------------------------------------------

-- your porch, built part by part as it always was (only when the model Door is missing: an old install)
local function buildPorch(parent: Instance, origin: CFrame): any
	local frame = FX.Rig(parent)
	for _, side in { -1, 1 } do
		frame:Block("Post", Vector3.new(0.7, 7.6, 0.9), CFrame.new(side * 2.35, 3.8, 0), WOOD_DARK, Enum.Material.Wood)
		frame:Block("Roof", Vector3.new(3.7, 0.35, 1.9), CFrame.new(side * 1.5, 8.78, 0) * CFrame.Angles(0, 0, side * -0.42), ROOF)
	end
	local lintel = frame:Block("Lintel", Vector3.new(5.8, 0.7, 1.1), CFrame.new(0, 7.75, 0), WOOD_DARK, Enum.Material.Wood)
	frame:Block("Doorstep", Vector3.new(5.6, 0.3, 2.3), CFrame.new(0, 0.15, -0.8), STONE, Enum.Material.Slate)
	frame:Block("Mat", Vector3.new(3, 0.1, 1.3), CFrame.new(0, 0.34, -1.15), MAT)
	frame:Block("Inside", Vector3.new(4, 7, 0.2), CFrame.new(0, 3.5, 0.32), C.Black)
	FX.AddPumpkin(frame, "PumpkinL", CFrame.new(-3.6, 0.85, -0.8) * CFrame.Angles(0, -0.5, 0), 1.9, true)
	FX.AddPumpkin(frame, "PumpkinR", CFrame.new(3.5, 0.65, -0.6) * CFrame.Angles(0, 0.4, 0), 1.4, true)
	frame:Line("Chain", Vector3.new(2.7, 7.5, -0.95), Vector3.new(2.7, 6.9, -0.95), 0.08, IRON)
	local lantern = frame:Block("Lantern", Vector3.new(0.55, 0.75, 0.55), CFrame.new(2.7, 6.5, -0.95), C.Orange, Enum.Material.Neon, 0.1)
	local porch: any = { Frame = frame, Hinge = HINGE, Lintel = lintel }
	porch.LampLight = FX.Light(lantern, C.Orange, 14, 1.6)

	local door = FX.Rig(parent)
	door:Block("Panel", Vector3.new(4, 7, 0.35), CFrame.new(2, 3.5, 0), WOOD, Enum.Material.Wood)
	for i = 1, 3 do
		door:Block("Gap", Vector3.new(0.08, 7, 0.38), CFrame.new(i, 3.5, 0), PLANK)
	end
	for _, y in { 1, 6.3 } do
		door:Block("Band", Vector3.new(4.06, 0.38, 0.42), CFrame.new(2, y, 0), IRON, Enum.Material.Metal)
	end
	door:Ball("Knob", 0.5, Vector3.new(3.5, 3.2, -0.32), C.Gold, Enum.Material.Metal)
	door:Block("Knocker", Vector3.new(0.6, 0.6, 0.14), CFrame.new(2, 3.9, -0.26) * CFrame.Angles(0, 0, math.rad(45)), C.Gold, Enum.Material.Metal)
	porch.Window = door:Cyl("Window", 1.3, 0.42, CFrame.new(2, 5.2, 0) * CFrame.Angles(math.pi / 2, 0, 0), TREAT, Enum.Material.Neon)
	porch.Door = door

	-- the light behind the door (dark until somebody knocks)
	porch.Glow = FX.Block(parent, Vector3.new(3.8, 6.8, 0.1), origin * CFrame.new(0, 3.5, 0.16), TREAT, Enum.Material.Neon, 1)
	porch.Glow.Name = "Glow"
	porch.GlowLight = FX.Light(porch.Glow, TREAT, 26, 0)
	porch.Sign = FX.Label(lintel, "?", C.Gold, 3.6, 4, 4)
	-- (where they stand, shut; the visual moves them every frame from its pop on)
	frame:Move(origin)
	door:Move(origin * HINGE)
	return porch
end

-- the porch from the model Door: its groups Frame and Door as rigs (the Door group's Root is the hinge, so the door
-- turns where you put the hinge in Studio). nil when the model does not have those two groups
local function porchFromModel(model: Instance, origin: CFrame): any
	local frameGroup, doorGroup = model:FindFirstChild("Frame"), model:FindFirstChild("Door")
	if not (frameGroup and doorGroup and FX.RigFrom) then
		return nil
	end
	local hingeAt = origin * HINGE
	if doorGroup:IsA("Model") and doorGroup.PrimaryPart then
		hingeAt = doorGroup.PrimaryPart.CFrame
	end
	local door = FX.RigFrom(doorGroup, hingeAt)
	local lintel = frameGroup:FindFirstChild("Lintel")
	local lantern = frameGroup:FindFirstChild("Lantern")
	local glow = model:FindFirstChild("Glow")
	local sign = lintel and lintel:FindFirstChild("Sign")
	return {
		Frame = FX.RigFrom(frameGroup, origin), Door = door, Hinge = origin:Inverse() * hingeAt, Lintel = lintel, Window = door:Get("Window"),
		Glow = if glow and glow:IsA("BasePart") then glow else nil,
		GlowLight = glow and glow:FindFirstChildOfClass("PointLight"),
		LampLight = lantern and lantern:FindFirstChildOfClass("PointLight"),
		Sign = sign and sign:FindFirstChildOfClass("TextLabel"),
	}
end

-- (a restyled model that lost one of the pieces the door needs on the plate: that piece is made here)
local function completePorch(porch: any, parent: Instance, origin: CFrame)
	if not porch.Glow then
		porch.Glow = FX.Block(parent, Vector3.new(3.8, 6.8, 0.1), origin * CFrame.new(0, 3.5, 0.16), TREAT, Enum.Material.Neon, 1)
		porch.Glow.Name = "Glow"
	end
	porch.GlowLight = porch.GlowLight or FX.Light(porch.Glow, TREAT, 26, 0)
	porch.LampLight = porch.LampLight or Instance.new("PointLight") -- (no lantern: a light that is nowhere)
	porch.Window = porch.Window or FX.Block(parent, Vector3.new(0.05, 0.05, 0.05), origin, TREAT, nil, 1)
	porch.Sign = porch.Sign or FX.Label(porch.Lintel or porch.Glow, "?", C.Gold, 3.6, 4, 4)
end

-- the ghost: a copy of the model Ghost as a rig (its parts go straight under `parent`, so rig:Destroy() takes all of
-- it); FX.AddGhost as before when the model is missing
local function makeGhost(parent: Instance): FX.Rig
	local model = if FX.Clone and FX.RigFrom then FX.Clone(ID, "Ghost", parent) else nil
	if model then
		local rig = FX.RigFrom(model)
		rig:Each(function(part: BasePart)
			part.Parent = parent
		end)
		model:Destroy()
		return rig
	end
	local rig = FX.Rig(parent)
	FX.AddGhost(rig, "G", CFrame.new(), 3.4, C.White, 0.2)
	return rig
end

---------------------------------------------------------------------
-- [Update 18] YOUR SCREEN when you knock: the ViewportFrame on its own (the ScreenGui DoorView, no window, no text).
-- Its little scene: the porch stands at the middle facing -Z, the camera is in front of it, a little to its left.
---------------------------------------------------------------------

local LOOK_AT = Vector3.new(0.2, 4.7, 0)    -- what the camera looks at (the middle of the porch)
local DOORWAY = Vector3.new(0, 3.6, 0.12)   -- where the treat / the ghost comes out from
local CANDY_POP = 0.16                      -- (seconds after the reveal the candies burst off the sweet)
local CANDY_GRAVITY = Vector3.new(0, -4, 0)

-- a ViewportFrame draws parts only: lights, emitters, sounds and the "?" sign come off the copy on your screen (a
-- BillboardGui in a ViewportFrame would float somewhere in the real world instead)
local function strip(model: Instance)
	for _, item in model:GetDescendants() do
		if item:IsA("Light") or item:IsA("ParticleEmitter") or item:IsA("BillboardGui") or item:IsA("Sound") or item:IsA("Beam") or item:IsA("Trail") then
			item:Destroy()
		end
	end
end

-- the camera at time t (seconds since the knock): it creeps in and round to the front of the door
local function lensAt(view: any, t: number): (CFrame, Vector3)
	local k = FX.Ease.Smooth(t / SHOW_TIME)
	local yaw = math.rad(14 - 6 * k)
	local distance = VIEW_DISTANCE - VIEW_CLOSER * k
	local eye = LOOK_AT + Vector3.new(math.sin(yaw) * distance, -0.8 + 0.3 * k, -math.cos(yaw) * distance)
	local cf = CFrame.lookAt(eye, LOOK_AT)
	-- each knock nudges it; the ghost bursting out shakes it
	for _, knock in { 0.05, 0.27 } do
		local since = t - knock
		if since > 0 and since < 0.2 then
			cf = cf * CFrame.new(0, 0, -0.35 * math.sin(since / 0.2 * math.pi))
		end
	end
	local scare = t - view.Reveal
	if not view.Treat and scare > 0 and scare < 0.5 then
		local fade = 1 - scare / 0.5
		cf = cf * CFrame.Angles(FX.Noise(view.Seed, t * 23) * 0.035 * fade, FX.Noise(view.Seed + 3, t * 23) * 0.035 * fade, FX.Noise(view.Seed + 5, t * 19) * 0.02 * fade)
	end
	return cf, eye
end

-- builds the door on your screen; nil when the ScreenGui DoorView is not there (then nothing is shown)
local function makeView(treat: boolean, at: number, reveal: number, seed: number): any
	if not FX.Gui then
		return nil
	end
	local gui = FX.Gui(ID, "DoorView")
	if not gui then
		return nil
	end
	local frame = gui:FindFirstChild("View")
	if not (frame and frame:IsA("ViewportFrame")) then
		gui:Destroy()
		return nil
	end
	local viewport: ViewportFrame = frame
	-- THE CAMERA: a Camera inside the ViewportFrame, and the ViewportFrame's CurrentCamera set to it
	local lens = viewport:FindFirstChildOfClass("Camera")
	if not lens then
		lens = Instance.new("Camera")
		lens.Name = "Lens"
		lens.FieldOfView = 38
		lens.Parent = viewport
	end
	viewport.CurrentCamera = lens
	-- the parts go in a WorldModel inside it
	local world = viewport:FindFirstChildOfClass("WorldModel")
	if not world then
		world = Instance.new("WorldModel")
		world.Name = "World"
		world.Parent = viewport
	end
	local pop = viewport:FindFirstChildOfClass("UIScale")
	if not pop then
		pop = Instance.new("UIScale")
		pop.Parent = viewport
	end
	local accent = if treat then TREAT else TRICK
	local view: any = {
		Gui = gui, View = viewport, Lens = lens, Pop = pop, Treat = treat, At = at, Reveal = reveal, Seed = seed, Accent = accent,
		Light = viewport.LightColor, Ambient = viewport.Ambient, Candies = {},
	}

	-- the porch: a copy of the model Door, the same one that stands on the plate
	local porch = nil
	local model = if FX.Clone then FX.Clone(ID, "Door", world) else nil
	if model then
		strip(model)
		model:PivotTo(CFrame.new())
		porch = porchFromModel(model, CFrame.new())
		if not porch then
			model:Destroy()
		end
	end
	if not porch then
		porch = buildPorch(world, CFrame.new())
		strip(world)
	end
	view.Frame, view.Door, view.Hinge, view.Glow, view.Window = porch.Frame, porch.Door, porch.Hinge, porch.Glow, porch.Window
	if view.Glow then
		view.Glow.Color = accent
		view.Glow.Transparency = 1
	end
	if view.Window then
		view.Window.Color = accent
	end

	-- what comes out: the treat (a wrapped sweet + loose candies) or the ghost
	local rng = Random.new(seed)
	if treat then
		local copy = if FX.Clone then FX.Clone(ID, "Treat", world) else nil
		local sweet = copy and copy:FindFirstChild("Sweet")
		if copy and sweet and FX.RigFrom then
			view.Prize = FX.RigFrom(sweet, copy:GetPivot())
			local candies = {}
			for _, part in copy:GetChildren() do
				if part:IsA("BasePart") and string.sub(part.Name, 1, 5) == "Candy" then
					table.insert(candies, part)
				end
			end
			-- they burst off the sweet like a fountain: out to both sides and up (evenly spread, a little shuffled; none
			-- straight down, where they would fall out of the picture)
			for index, part in candies do
				table.insert(view.Candies, {
					Part = part, Turn = part.CFrame.Rotation, Transparency = part.Transparency,
					Angle = math.rad(-25 + 230 * (index - 0.5) / #candies) + rng:NextNumber(-0.12, 0.12),
					Speed = rng:NextNumber(1.6, 2.4), Lift = rng:NextNumber(0.6, 1.4), Life = rng:NextNumber(0.6, 0.8),
					Spin = Vector3.new(rng:NextNumber(-9, 9), rng:NextNumber(-9, 9), rng:NextNumber(-9, 9)),
				})
				part.Transparency = 1
			end
		else
			if copy then
				copy:Destroy()
			end
			-- (no model Treat: the sweet the old window had)
			local rig = FX.Rig(world)
			rig:Ball("Ball", 1.8, Vector3.new(0, 0, 0), Color3.fromRGB(255, 140, 50))
			for _, side in { -1, 1 } do
				rig:Block("Wrap", Vector3.new(0.9, 0.9, 0.3), CFrame.new(side * 1.3, 0, 0) * CFrame.Angles(0, 0, math.rad(45)), C.Gold)
			end
			view.Prize = rig
		end
	else
		view.Prize = makeGhost(world)
	end
	view.Prize:Move(CFrame.new(DOORWAY), 0.3)
	view.Prize:Fade(1)

	-- (pop it in from nothing: the first frame below sets the rest)
	pop.Scale = 0.7
	viewport.ImageTransparency = 1
	return view
end

-- every frame while it is up. false = it is over (and gone)
local function stepView(view: any): boolean
	local t = FX.Now() - view.At -- (seconds since the knock, on the server's clock: in step with the door on the plate)
	if t >= SHOW_TIME or not view.Gui.Parent then
		view.Gui:Destroy()
		return false
	end
	local viewport: ViewportFrame = view.View
	if viewport.CurrentCamera ~= view.Lens then
		viewport.CurrentCamera = view.Lens
	end
	-- it pops in, and shrinks and fades away at the end
	local leave = FX.Clamp01((SHOW_TIME - t) / 0.4)
	view.Pop.Scale = (0.7 + 0.3 * FX.Ease.Back(t / 0.3)) * (0.82 + 0.18 * leave)
	viewport.ImageTransparency = 1 - FX.Clamp01(t / 0.12) * leave
	local cf, eye = lensAt(view, t)
	view.Lens.CFrame = cf

	-- the door: exactly like the one on the plate (it shakes with your two knocks, then creaks open towards you)
	local angle
	if t < 0.45 then
		angle = math.sin(t * 28) * 0.05
	else
		angle = OPEN * FX.Ease.Back((t - 0.45) / 0.65)
	end
	view.Door:Move((view.Hinge or HINGE) * CFrame.Angles(0, angle, 0))
	view.Frame:Move(CFrame.new())
	-- light pours out as it opens; a flash of gold / purple when the treat or the trick comes out
	if view.Glow then
		view.Glow.Transparency = 1 - 0.88 * FX.Span(t, 0.45, 0.95)
	end
	local since = t - view.Reveal
	local flash = if since >= 0 and not FX.Off("DisableFlashing") then 1 - FX.Clamp01(since / 0.7) else 0
	viewport.LightColor = view.Light:Lerp(view.Accent, 0.65 * flash)
	viewport.Ambient = view.Ambient:Lerp(view.Accent, 0.4 * flash)

	-- what comes out
	local prize = view.Prize
	if since < 0 then
		prize:Fade(1)
	elseif view.Treat then
		-- the sweet flies out at you and hangs there, turning
		local target = DOORWAY:Lerp(eye, TREAT_REACH) + Vector3.new(0, 0.2, 0)
		local out = FX.Ease.Back(since / 0.45)
		local at = DOORWAY:Lerp(target, out) + Vector3.new(0, math.sin(t * 3.2) * 0.12, 0)
		prize:Fade(0)
		prize:Move(CFrame.new(at) * CFrame.Angles(math.sin(t * 2.1) * 0.25, since * 2.4, math.sin(t * 1.7) * 0.2), 0.45 + 0.7 * FX.Clamp01(since / 0.35))
		-- ... and the candies burst off it all round, tumbling
		local burst = since - CANDY_POP
		if burst >= 0 and not view.From then
			view.From, view.Across, view.Upward, view.Toward = at, cf.RightVector, cf.UpVector, -cf.LookVector
		end
		for _, candy in view.Candies do
			local life = if burst >= 0 then burst / candy.Life else -1
			if life < 0 or life >= 1 then
				candy.Part.Transparency = 1
			else
				local out = view.Across * math.cos(candy.Angle) + view.Upward * math.sin(candy.Angle)
				local velocity = out * candy.Speed + Vector3.new(0, candy.Lift, 0) + view.Toward * 0.6
				local position = view.From + velocity * burst + CANDY_GRAVITY * (0.5 * burst * burst)
				candy.Part.CFrame = CFrame.new(position) * CFrame.Angles(candy.Spin.X * burst, candy.Spin.Y * burst, candy.Spin.Z * burst) * candy.Turn
				candy.Part.Transparency = candy.Transparency + (1 - candy.Transparency) * FX.Span(life, 0.4, 1)
			end
		end
	else
		-- the ghost bursts out and lunges at you, looms, and fades
		local target = DOORWAY:Lerp(eye, GHOST_REACH) + Vector3.new(0, 0.75, 0)
		local out = FX.Ease.OutCubic(since / 0.32)
		local at = DOORWAY:Lerp(target, out) + Vector3.new(math.sin(t * 7) * 0.12, math.sin(t * 3) * 0.15, 0)
		local facing = CFrame.lookAt(at, Vector3.new(eye.X, at.Y, eye.Z))
		prize:Fade(FX.Span(since, 1.25, 1.7))
		prize:Move(facing * CFrame.Angles(-0.3 * (1 - out), 0, math.sin(since * 12) * 0.2 * (1 - FX.Clamp01(since / 0.9))), 0.35 + 0.5 * out)
	end
	return true
end

---------------------------------------------------------------------
-- The door on the plate
---------------------------------------------------------------------

return FX.Module({
	Door = {
		Init = function(self: any, props: any)
			local rng = Random.new(props.Seed or 1)
			local origin: CFrame = self.Origin -- the foot of the door; its front (-Z) faces the middle of the plate
			-- [Update 18] the porch is the model Door under the event script (the framework cloned it as this visual)
			local porch = porchFromModel(self.Inst, origin)
			if not porch then
				-- (no model, or one without its Frame / Door groups: built here as before, once anything left of it is gone)
				for _, child in self.Inst:GetChildren() do
					if child.Name ~= "Root" then
						child:Destroy()
					end
				end
				porch = buildPorch(self.Inst, origin)
			end
			completePorch(porch, self.Inst, origin)
			self.Frame, self.Door, self.Hinge = porch.Frame, porch.Door, porch.Hinge
			self.Window, self.Glow, self.GlowLight, self.LampLight, self.Sign = porch.Window, porch.Glow, porch.GlowLight, porch.LampLight, porch.Sign
			self.Phase = rng:NextNumber(0, 6)
			self.Frame:Fade(1)
			self.Door:Fade(1)
			self.Sign.TextTransparency = 1
			self.Sign.TextStrokeTransparency = 1
		end,

		-- (K.Call) somebody knocked at server time `at`: it opens on a treat or a trick
		Open = function(self: any, userId: number, treat: boolean, _title: string, _text: string, at: number)
			if self.OpenedAt then
				return
			end
			self.OpenedAt = at - self.T0
			local color = if treat then TREAT else TRICK
			local glow: BasePart = self.Glow
			glow.Color = color
			self.GlowLight.Color = color
			self.Window.Color = color
			self.Sign.Text = ""
			local since = FX.Now() - at
			local reveal: number = self.Props.Reveal or 1.6
			if since > reveal + 0.8 then
				-- (someone who joined later: it just stands open)
				glow.Transparency = 0.5
				self.GlowLight.Brightness = 1
				return
			end
			local origin: CFrame = self.Origin
			local doorway = (origin * CFrame.new(0, 3.5, -0.7)).Position
			local near = FX.Near(doorway, 30, 110)
			FX.Popup(doorway + UP * 3, "KNOCK KNOCK", C.White, 1.6)
			for _, when in { 0.05, 0.27 } do
				self:After(when - since, function()
					FX.Sound("Thud", doorway, 0.8 * near, 1.5)
				end)
			end
			self:After(0.45 - since, function()
				FX.Tween(glow, { Transparency = 0.12 }, 0.5, "Quad", "Out")
				FX.Tween(self.GlowLight, { Brightness = 3 }, 0.5, "Quad", "Out")
				FX.Sound("Shuffle", doorway, 0.7 * near, 0.6)
			end)
			self:After(reveal - since, function()
				if treat then
					FX.Confetti(doorway, 26)
					FX.Chunks(doorway, 14, CANDY, { Size = 0.8, Speed = 14, Up = 22, Life = 1.6, Shape = "Ball" })
					FX.Burst(doorway, "Star", 24, { Color = TREAT, Scale = 1.6 })
					FX.Glint(doorway, TREAT, 30, 4, 0.5)
					FX.Popup(doorway + UP * 5, "TREAT!", TREAT, 3)
					FX.Sound("Ding", doorway, 0.9, 1.2)
				else
					FX.Burst(doorway, "Smoke", 12, { Color = Color3.fromRGB(70, 40, 90), Scale = 1.6 })
					FX.Burst(doorway, "Glow", 10, { Color = TRICK, Scale = 2 })
					FX.Popup(doorway + UP * 5, "TRICK!", TRICK, 3)
					FX.Sound("Lunge", doorway, 0.9, 0.7)
					-- a ghost comes out at whoever knocked
					local rig = makeGhost(self.Inst) -- [Update 18] the model Ghost (real parts); FX.AddGhost when it is missing
					rig:Move(origin * CFrame.new(0, 3.5, 0), 0.2)
					self.Spook = { Rig = rig, From = self:Time() }
					if FX.IsMe(userId) then
						FX.Shake(3.5, 14, 0.04, 0.45)
						FX.Pulse(TRICK, 0.5, 0.3)
					end
				end
				FX.Tween(glow, { Transparency = 0.5 }, 1.6, "Quad", "InOut")
				FX.Tween(self.GlowLight, { Brightness = 1 }, 1.6, "Quad", "InOut")
			end)
			-- [Update 18] the door on YOUR screen (no window any more: what you got is in the toast)
			if SCREEN and FX.IsMe(userId) and since < 1 then
				local ok, view = pcall(makeView, treat, at, reveal, self.Props.Seed or 1)
				if ok and view then
					self.View = view
					self:Keep(view.Gui)
				elseif not ok then
					warn("[trickortreat] the door on your screen could not be made: " .. tostring(view))
				end
			end
		end,

		Step = function(self: any, _dt: number, t: number)
			local p = self.Props
			local delay: number = p.Delay or 0
			local origin: CFrame = self.Origin
			local frame: FX.Rig, door: FX.Rig = self.Frame, self.Door
			-- [Update 18] the door on your screen (an error in it only takes it off your screen)
			if self.View then
				local ok, alive = pcall(stepView, self.View)
				if not ok or not alive then
					if not ok then
						warn("[trickortreat] the door on your screen stopped: " .. tostring(alive))
						pcall(function()
							self.View.Gui:Destroy()
						end)
					end
					self.View = nil
				end
			end
			if t < delay then
				return
			end
			-- it pops up out of a puff of smoke
			local size = math.max(FX.Ease.Back((t - delay) / 0.45), 0.05)
			if self.Leaving then
				size *= 1 - FX.Ease.In(FX.Span(t, self.Leaving, self.Leaving + 0.6)) * 0.95
			end
			if not self.Popped then
				self.Popped = true
				frame:Fade(0)
				door:Fade(0)
				self.Sign.TextTransparency = 0
				self.Sign.TextStrokeTransparency = 0
				if t - delay < 0.6 then
					FX.Poof((origin * CFrame.new(0, 3.5, 0)).Position, C.Orange, 2)
					FX.Sound("Pop", origin.Position, 0.7 * FX.Near(origin.Position, 30, 100), 0.9)
				end
			end
			if not self.Settled or self.Leaving then
				frame:Move(origin, size)
				if t - delay > 0.5 and not self.Leaving then
					self.Settled = true
					frame:Move(origin, 1)
				end
			end
			-- the door: it rattles now and then; knocked, it shakes twice and creaks open towards you
			local angle = 0
			local opened: number? = self.OpenedAt
			if opened then
				local since = t - opened
				if since < 0.45 then
					angle = math.sin(since * 28) * 0.05
				else
					angle = OPEN * FX.Ease.Back((since - 0.45) / 0.65)
				end
			else
				local cycle = (t + self.Phase) % 3.2
				if cycle < 0.35 then
					angle = math.sin(cycle * 60) * 0.022
				end
				-- what is in there? the window cannot make up its mind
				self.Window.Color = TREAT:Lerp(TRICK, (math.sin(t * 2.2 + self.Phase) + 1) / 2)
			end
			door:Move(origin * (self.Hinge or HINGE) * CFrame.Angles(0, angle, 0), size)
			self.LampLight.Brightness = 1.5 + FX.Noise(self.Phase, t * 5) * 0.5

			local spook = self.Spook
			if spook then
				local since = t - spook.From
				local rig: FX.Rig = spook.Rig
				if since > 1.3 then
					rig:Destroy()
					self.Spook = nil
				else
					local out = FX.Ease.Out(since / 0.5)
					local at = origin * CFrame.new(math.sin(since * 9) * 0.5, 3.5 + out * 3.5 + since * 2.5, -out * 6.5)
					rig:Fade(FX.Span(since, 0.9, 1.3))
					rig:Move(at * CFrame.Angles(-0.3, 0, math.sin(since * 12) * 0.2), 0.3 + out * 0.9)
				end
			end
		end,

		-- the end of the event: it folds away again
		Outro = function(self: any, _seconds: number?)
			if not self.Leaving and self.Popped then
				self.Leaving = self:Time()
				self.Sign.Text = ""
				self.Glow.Transparency = 1
				self.GlowLight.Brightness = 0
				local origin: CFrame = self.Origin
				self:After(0.45, function()
					FX.Poof((origin * CFrame.new(0, 3.5, 0)).Position, C.Orange, 1.6)
				end)
			end
		end,
	},
})
