-- ModuleScript: ReplicatedStorage > EventClients > stairway     (NEW)
-- What the Stairway of Spirits looks like on each client. The server makes the glowing slabs you stand on;
-- this lights them: a pair of spirit flames and a drift of sparks on every step that is solid (they go out
-- with the step as it fades from under you), three wisps racing up the spiral, and a beam of light from the
-- landing into the sky.
-- Oct 10 2026 (update 8): the chest on the landing is a NORMAL item chest now (the server drops it there through
-- Systems > ItemCrates), so this module no longer draws one; and a step that is about to go does not turn red
-- any more: it just fades, fast.
-- The server (Events > StairwayOfSpirits) decides who gets the chest.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))

local C = FX.Colors
local UP = Vector3.new(0, 1, 0)
local FLAME = 0.75
local WISPS = 3

return FX.Module({
	Stairway = {
		Init = function(self: any, props: any)
			local base: Vector3 = self.Origin.Position
			local count: number, rise: number, radius: number = props.Steps or 12, props.Rise or 2.6, props.Radius or 7
			local start: number, turn: number = props.Start or 0, props.Turn or math.rad(40)
			self.Count = count
			-- a circle of runes on the plate, and mist rolling off it
			self.Rune = FX.Disc(self.Inst, radius + 4, base, C.Ghost, 0.86, 0.14)
			FX.Stream(self.Rune, "Mist", { Color = C.Ghost, Rate = 4, Scale = 1.2 })
			-- every step: spirit flames on its two outer corners, sparks, and a soft light underneath
			self.Steps = {}
			for n = 1, count do
				local angle = start + n * turn
				local spot = base + Vector3.new(math.cos(angle) * radius, n * rise, math.sin(angle) * radius)
				local frame = CFrame.new(spot) * CFrame.Angles(0, -angle, 0) -- (+X points away from the middle)
				local rig = FX.Rig(self.Inst)
				FX.AddFlame(rig, "A", CFrame.new(2.6, 0.4, 2.6), FLAME, C.Ghost)
				FX.AddFlame(rig, "B", CFrame.new(2.6, 0.4, -2.6), FLAME, C.Ghost)
				local glow = rig:Egg("Glow", Vector3.new(5, 1.4, 5), CFrame.new(0, -0.9, 0), C.Ghost, Enum.Material.Neon, 0.82)
				local light = FX.Light(glow, C.Ghost, 12, 0)
				local sparks = FX.Emitter(glow, "Ember", { Color = C.Ghost, Rate = 5, Scale = 1.1 })
				rig:Move(frame)
				rig:Fade(1)
				self.Steps[n] = { Rig = rig, Frame = frame, Spot = spot, Solid = false, Alpha = 1, Light = light, Sparks = sparks, Going = nil, Over = 0.4 }
			end
			-- the landing: a beam into the sky and a gold glow where the chest stands (the chest itself is the
			-- game's normal item chest: the server drops it there)
			local top = base + Vector3.new(0, (count + 1) * rise + 0.4, 0)
			self.Top = top
			local glow = FX.Point(top + UP * 2)
			self:Keep(glow)
			self.ChestLight = FX.Light(glow, C.Gold, 22, 0)
			self.ChestStars = FX.Emitter(glow, "Star", { Color = C.Gold, Rate = 8, Scale = 1.3 })
			self.Beam = FX.Cyl(self.Inst, 1.6, 90, CFrame.new(top + UP * 45), C.Ghost, Enum.Material.Neon, 1)
			self.Beam.Name = "Beam"
			-- wisps that race up the spiral
			self.Wisps = {}
			for i = 1, WISPS do
				local ball = FX.Ball(self.Inst, 0.9, base, C.White, Enum.Material.Neon, 1)
				ball.Name = "Wisp"
				FX.Trail(ball, C.Ghost, 0.9, 0.5)
				self.Wisps[i] = ball
			end
			self.Spiral = function(u: number): Vector3
				local angle = start + u * turn
				return base + Vector3.new(math.cos(angle) * radius, u * rise + 2.2, math.sin(angle) * radius)
			end
			self.Up, self.Found = 0, false
			if self:Time() < 1 then
				FX.Sound("Whoosh", base, 0.8, 0.5)
			end
		end,

		-- (K.Signal) somebody is standing on step n: it fades to nothing over `seconds` (its flames go with it)
		Vanish = function(self: any, n: number, seconds: number?)
			local step = self.Steps[n]
			if step then
				step.Going = self:Time()
				step.Over = math.max(seconds or 0.4, 0.05)
			end
		end,

		-- (K.Call) that player opened the chest at server time `at`
		Claim = function(self: any, userId: number, at: number)
			if self.Claimed then
				return
			end
			self.Claimed = at - self.T0
			if FX.Now() - at > 1.5 then
				return
			end
			local top: Vector3 = self.Top
			local player = FX.Player(userId)
			FX.Confetti(top + UP * 3, 34)
			FX.Chunks(top + UP * 2, 18, C.Gold, { Size = 0.6, Speed = 12, Up = 30, Life = 1.8, Gravity = 70, Flat = true, Neon = true })
			FX.Burst(top + UP * 2, "Star", 36, { Color = C.Gold, Scale = 2 })
			FX.Glint(top + UP * 2, C.Gold, 50, 5, 0.7)
			FX.Ring(top, 1, 9, 0.5, C.Gold)
			FX.Sound("Ding", top, 1, 1.2)
			FX.Sound("Boom", top, 0.5, 1.6)
			if player then
				FX.Popup(top + UP * 5, player.DisplayName .. "!", C.Gold, 3)
			end
			if FX.IsMe(userId) then
				FX.Pulse(C.Gold, 0.5, 0.4)
				FX.Kick(6)
			else
				FX.Shake(2.5, 12, 0.05, 0.5, top, 30, 120)
			end
		end,

		Step = function(self: any, dt: number, t: number)
			local p = self.Props
			-- the real steps (made by the server), found through the tag on their folder
			if not self.Found then
				local folder = FX.Tagged(p.Tag)
				if folder then
					local all = true
					for n, step in self.Steps do
						if not step.Part then
							local part = folder:FindFirstChild("Step" .. tostring(n))
							if part and part:IsA("BasePart") then
								step.Part = part
							else
								all = false
							end
						end
					end
					self.Found = all
				end
			end
			local leaving = if self.Leaving then FX.Span(t, self.Leaving, self.Leaving + 1) else 0
			local claimed: number? = self.Claimed
			local ending = math.max(leaving, if claimed then FX.Span(t, claimed + 2.5, claimed + 3.7) else 0)
			local frameCount = (self.Frames or 0) + 1
			self.Frames = frameCount

			for n, step in self.Steps do
				local part: BasePart? = step.Part
				local solid = part ~= nil and part.Parent ~= nil and part.CanCollide and ending < 1
				if solid ~= step.Solid then
					step.Solid = solid
					step.Sparks.Enabled = solid and not FX.Off("DisableParticles")
					if FX.Near(step.Spot, 40, 140) > 0 and ending == 0 then
						if solid then
							FX.Poof(step.Spot, C.Ghost, 0.8)
							if t < 4 then
								FX.Sound("Ding", step.Spot, 0.35, 0.75 + n * 0.07) -- (a rising scale as the stairs appear)
							end
						else
							FX.Burst(step.Spot, "Glow", 8, { Color = C.Ghost, Scale = 1.6 })
							FX.Sound("Whoosh", step.Spot, 0.35, 1.5)
						end
					end
				end
				-- (a step that is going fades with the server's slab: no red, no shaking)
				local going: number? = step.Going
				if going and not solid then
					step.Going = nil
					going = nil
				end
				local want = if solid then math.max(ending, if going then FX.Clamp01((t - going) / step.Over) else 0) else 1
				if step.Alpha ~= want then
					local rate = if going then 1 else dt / 0.15
					step.Alpha = if going then want elseif want > step.Alpha then math.min(want, step.Alpha + rate) else math.max(want, step.Alpha - rate)
					step.Rig:Fade(step.Alpha)
					step.Light.Brightness = 1.3 * (1 - step.Alpha)
				end
				if step.Alpha < 1 and (frameCount + n) % 2 == 0 then
					-- flames dance (every other frame is plenty)
					FX.Flicker(step.Rig, "A", FLAME, t, n)
					FX.Flicker(step.Rig, "B", FLAME, t, n + 40)
				end
			end

			-- the landing: the beam and the glow (they arrive once the last step is there)
			if not self.LandingSeen and t > 0.5 + ((self.Count :: number) + 1) * (p.Gap or 0.12) then
				self.LandingSeen = true
				if self.ChestStars then
					self.ChestStars.Enabled = not FX.Off("DisableParticles")
				end
				if t < 4 then
					FX.Poof(self.Top + UP * 1.5, C.Gold, 1.6)
					FX.Sound("Ding", self.Top, 0.6, 1.7)
				end
			end
			local up = math.clamp(self.Up + (if self.LandingSeen then dt / 0.5 else 0), 0, 1)
			self.Up = up
			local shown = up * (1 - ending)
			if self.ChestLight then
				self.ChestLight.Brightness = shown * (if claimed then 4 else 1.6 + math.sin(t * 3) * 0.3)
			end
			self.Beam.Transparency = 1 - shown * (if claimed then 0.5 else 0.22 + math.sin(t * 2.4) * 0.05)
			self.Rune.Transparency = 1 - (1 - ending) * FX.Clamp01(t / 0.6) * (0.14 + math.sin(t * 1.7) * 0.03)
			if ending >= 1 and not self.Quiet then
				self.Quiet = true
				FX.SetEmitters(self.Inst, false)
			end

			-- wisps
			local spiral: (number) -> Vector3 = self.Spiral
			local span = (self.Count :: number) + 1.5
			for i, ball in self.Wisps do
				local u = ((t * 0.32 + i / WISPS) % 1) * span
				ball.CFrame = CFrame.new(spiral(u) + UP * math.sin(t * 5 + i * 2) * 0.5)
				ball.Transparency = 1 - shown * 0.9 * math.sin(math.pi * u / span)
			end
		end,

		Outro = function(self: any, _seconds: number?)
			if not self.Leaving then
				self.Leaving = self:Time()
			end
		end,
	},
})
