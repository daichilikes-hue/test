-- ModuleScript: ReplicatedStorage > EventClients > deadswitch     (NEW, Oct 8 2026 update 3; REWORKED Oct 11 update 15)
-- Draws Dead Man's Switch (server: ServerScriptService > Events > DeadMansSwitch).
--   THE DOOR    the model HellDoor under the event's server script: it grinds up out of the void past one edge of the
--               arena, the chains across it drop, its iron doors burst open toward the arena and hellfire lights up
--               the doorway. At the end the doors slam shut and it sinks back down.
--   THE WALL    the model FireSegment, cloned side by side across the whole arena. It pours out of the doorway and
--               spreads to both sides, sky high, then sweeps back and forth. While somebody holds the lever it sinks
--               to embers; let go and it roars back up. Over its 60 seconds it dies down, and at the end it fades.
--   THE LEVER   the model Lever: it rises out of a plate. Held = the arm is pulled down toward the holder and shakes;
--               let go = it springs back up, and while it is STUCK (5 s) it glows red-hot, smokes and rattles.
--   THE STRUGGLE (only for whoever holds it) the ScreenGui LeverGui on your screen: a ring closes in on a circle,
--               press SPACE, E, click or tap the circle when the ring is on it. And on your own character the
--               animation SwitchStruggle (this module's Animations folder): in Studio it plays straight from there;
--               for the real game upload it (right-click > Save to Roblox) and paste its id into ANIMATIONS below.
-- Restyle the models and the panel in Studio as you like; the code needs these names:
--   HellDoor > DoorL, DoorR (groups, Root on the hinge), ChainA, ChainB, Lock, Hellfire, Crack, Glow (Light, Belch,
--              Embers), EyeL, EyeR, Rune1..8
--   FireSegment > Base (Light), Low, Mid, High, Flames (its emitters)
--   Lever > Arm (a group, Root on the axle), Heat (Sparks, Smoke), ChainRing
--   LeverGui > Panel > Scale, Title, Target > Zone, Ring, Key; Status, LetGo

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")

local FX = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not (FX.Gui and FX.RigFrom and FX.Clone) then
	warn("[deadswitch] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end

-- Your sound ids go in Id. While Id is "", Stand plays (a built-in Roblox sound; "" = silent).
--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	LeverClank = { Id = "", Stand = "rbxasset://sounds/action_jump_land.mp3", Speed = 0.5, Volume = 1.1 }, -- lever pulled / let go
	FireRoar = { Id = "", Stand = "rbxasset://sounds/impact_explosion_03.mp3", Speed = 0.35, Volume = 0.7 }, -- the wall flares up
	ChainRattle = { Id = "", Stand = "", Speed = 1, Volume = 1 },                                         -- the chain shakes
	HellDoorGrind = { Id = "", Stand = "rbxasset://sounds/action_get_up.mp3", Speed = 0.25, Volume = 1.4 }, -- the door grinds up out of the void
	HellDoorOpen = { Id = "", Stand = "rbxasset://sounds/impact_explosion_03.mp3", Speed = 0.55, Volume = 1 }, -- its doors burst open
	SwitchGood = { Id = "", Stand = "rbxasset://sounds/action_jump_land.mp3", Speed = 1.2, Volume = 0.6 },  -- (only the holder) a good press
	SwitchSlip = { Id = "", Stand = "rbxasset://sounds/swordslash.wav", Speed = 0.6, Volume = 0.8 },       -- (only the holder) your hands slip
}
--[[DMP:END]]
FX.UseSounds(SOUNDS)

-- Your uploaded animation id (0 = not uploaded yet: Studio plays the KeyframeSequence from the Animations folder)
--[[DMP:KEEP Animations]]
local ANIMATIONS = {
	SwitchStruggle = 0, -- holding the lever down (whole body)
}
--[[DMP:END]]

-- KEEP IN SYNC with Events > DeadMansSwitch (the server sends its numbers along; these are only used if it does not)
local LEVER_UP = math.rad(-30)    -- the arm leaning toward the fire (as the model is built)
local LEVER_DOWN = math.rad(62)   -- held down, leaning toward the holder
local PIVOT = Vector3.new(0, 2.4, 0)
local SPACING = 6                 -- one FireSegment every this many studs across the arena
local SINK = 70                   -- how far below the plates the door starts
local DOOR_SWING = math.rad(100)  -- how far its doors open
local PHONE_BELOW = 500           -- a screen less than this many pixels high is a phone: the panel is drawn smaller
local SMALLEST = 0.62

local GOLD = Color3.fromRGB(255, 196, 92)
local RED = Color3.fromRGB(210, 40, 50)
local DARK_RED = Color3.fromRGB(150, 20, 30)
local EMBER = Color3.fromRGB(255, 120, 40)
local FIRE = Color3.fromRGB(240, 84, 26)
local HELL = Color3.fromRGB(255, 96, 30)
local SOFT = Color3.fromRGB(230, 195, 195)

local localPlayer = Players.LocalPlayer

local function smoothstep(k: number): number
	k = math.clamp(k, 0, 1)
	return k * k * (3 - 2 * k)
end

-- where the wall is at t: how far from its starting line, how tall, which way it moves. KEEP IN SYNC with the server.
local function wallAt(self: any, t: number): (number, number, number)
	local since = t - (self.Rise + self.Open)
	if since <= 0 then
		return 0, 0, 1
	end
	local life = math.clamp(since / self.Life, 0, 1)
	local height = self.Height * (1 - life * life)
	if since < self.Emerge then
		height *= smoothstep(since / self.Emerge)
	end
	local left = self.Life - since
	if left < self.Fade then
		height *= math.max(left, 0) / self.Fade
	end
	local phase = (math.max(since - self.Emerge, 0) / self.Crossing) % 2
	if phase <= 1 then
		return phase * self.Travel, height, 1
	end
	return (2 - phase) * self.Travel, height, -1
end

---------------------------------------------------------------------- the struggle animation on your own character
local animationIds: { [string]: string }? = nil
local loadedTrack: AnimationTrack? = nil
local loadedFor: Animator? = nil

local function struggleTrack(): AnimationTrack?
	local character = localPlayer.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local animator = humanoid and humanoid:FindFirstChildOfClass("Animator")
	if not animator then
		return nil
	end
	if loadedTrack and loadedFor == animator then
		return loadedTrack
	end
	if not animationIds then
		animationIds = FX.Animations(ANIMATIONS, script)
	end
	local id = (animationIds :: { [string]: string }).SwitchStruggle
	if not id then
		return nil
	end
	local animation = Instance.new("Animation")
	animation.AnimationId = id
	local ok, track = pcall(function()
		return animator:LoadAnimation(animation)
	end)
	if not ok or not track then
		return nil
	end
	track.Looped = true
	track.Priority = Enum.AnimationPriority.Action
	loadedTrack, loadedFor = track, animator
	return track
end

---------------------------------------------------------------------- the holder's panel
local function setText(label: Instance?, text: string, color: Color3?)
	if label and (label:IsA("TextLabel") or label:IsA("TextButton")) then
		local item = label :: any
		if item.Text ~= text then
			item.Text = text
		end
		if color and item.TextColor3 ~= color then
			item.TextColor3 = color
		end
	end
end

local function strokeOf(instance: Instance?): UIStroke?
	local stroke = instance and instance:FindFirstChildOfClass("UIStroke")
	return if stroke then stroke else nil
end

local function closePanel(self: any)
	local panel = self.Panel
	self.Panel = nil
	if panel then
		for _, connection in panel.Connections do
			connection:Disconnect()
		end
		panel.Gui:Destroy()
	end
	if loadedTrack and loadedTrack.IsPlaying then
		loadedTrack:Stop(0.25)
	end
end

local function fitPanel(panel: any)
	local frame: GuiObject = panel.Frame
	local height = panel.Gui.AbsoluteSize.Y
	local phone = height > 0 and height < PHONE_BELOW
	if panel.Scale then
		panel.Scale.Scale = if phone then math.max(SMALLEST, height / 560) else 1
	end
	frame.Position = if phone then UDim2.new(panel.Position.X.Scale, panel.Position.X.Offset, 1, -14) else panel.Position
end

-- a press: SPACE, E, a click or a tap on the circle
local function press(self: any)
	local panel = self.Panel
	local cue = self.Cue
	if not panel or not cue then
		return
	end
	local now = FX.Now()
	if now < cue.At - self.Lead then
		return -- (no ring on the screen yet)
	end
	self.Cue = nil
	self:Send("Pull", cue.Index, now)
	-- (the server decides; this is only how it looks to you right away)
	if now < cue.At - self.Early then
		self.Feedback = { Text = "TOO SOON!", Color = RED, Until = os.clock() + 0.8 }
	elseif now <= cue.At + self.Late then
		self.Feedback = { Text = "GOOD!", Color = GOLD, Until = os.clock() + 0.45 }
		self.Kick = 1
		FX.Sound("SwitchGood", nil, 1, 0.9 + math.random() * 0.25)
		FX.Shake(0.7, 16, 0.02, 0.18)
	else
		self.Feedback = { Text = "TOO LATE!", Color = RED, Until = os.clock() + 0.8 }
	end
end

local function openPanel(self: any)
	if self.Panel then
		return
	end
	local gui = FX.Gui("deadswitch", "LeverGui")
	local frame = gui and gui:FindFirstChild("Panel")
	if not (gui and frame and frame:IsA("GuiObject")) then
		return
	end
	local function find(name: string): Instance?
		local found = frame:FindFirstChild(name, true)
		if not found then
			FX.WarnOnce("levergui" .. name, "'" .. name .. "' is missing in the ScreenGui LeverGui (ServerScriptService > Events > DeadMansSwitch > LeverGui): that part of the lever panel does nothing")
		end
		return found
	end
	local scale = find("Scale")
	local target = find("Target")
	local panel = {
		Gui = gui, Frame = frame, Position = frame.Position, Scale = if scale and scale:IsA("UIScale") then scale else nil,
		Target = target, Zone = find("Zone"), Ring = find("Ring"), Key = find("Key"), Status = find("Status"), LetGo = find("LetGo"),
		Connections = {} :: { RBXScriptConnection },
	}
	self.Panel = panel
	panel.ZoneStroke = strokeOf(panel.Zone)
	panel.RingStroke = strokeOf(panel.Ring)
	-- what to press: SPACE on a keyboard, TAP on a phone
	setText(panel.Key, if UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled then "TAP" else "SPACE")
	fitPanel(panel)
	table.insert(panel.Connections, gui:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
		if self.Panel == panel then
			fitPanel(panel)
		end
	end))
	if target and target:IsA("GuiButton") then
		table.insert(panel.Connections, target.Activated:Connect(function()
			press(self)
		end))
	end
	if panel.LetGo and panel.LetGo:IsA("GuiButton") then
		table.insert(panel.Connections, panel.LetGo.Activated:Connect(function()
			if self.Panel == panel then
				self:Send("LetGo")
			end
		end))
	end
	table.insert(panel.Connections, UserInputService.InputBegan:Connect(function(input: InputObject, _processed: boolean)
		-- (not using `processed`: the jump binding may mark SPACE as processed; typing in chat is skipped instead)
		if self.Panel ~= panel or UserInputService:GetFocusedTextBox() then
			return
		end
		local key = input.KeyCode
		if key == Enum.KeyCode.Space or key == Enum.KeyCode.E or key == Enum.KeyCode.ButtonA or key == Enum.KeyCode.ButtonR2 then
			press(self)
		end
	end))
	local track = struggleTrack()
	if track and not track.IsPlaying then
		track:Play(0.2)
	end
end

-- the ring and the circle, every frame
local function drawPanel(self: any)
	local panel = self.Panel
	if not panel then
		return
	end
	local now = FX.Now()
	local cue = self.Cue
	local ring = panel.Ring
	local open = false
	if ring and ring:IsA("GuiObject") then
		if cue and now >= cue.At - self.Lead then
			local k = (cue.At - now) / self.Lead -- 1 = just appeared, 0 = on the circle
			local size = 1 + 0.9 * math.max(k, -0.15)
			ring.Visible = true
			ring.Size = UDim2.fromScale(size, size)
			open = now >= cue.At - self.Early and now <= cue.At + self.Late
			if panel.RingStroke then
				panel.RingStroke.Color = if open then GOLD else EMBER
				panel.RingStroke.Transparency = math.clamp(k - 0.6, 0, 0.6)
			end
		else
			ring.Visible = false
		end
	end
	if panel.ZoneStroke then
		panel.ZoneStroke.Color = if open then GOLD elseif self.Kick > 0 then GOLD:Lerp(RED, 1 - self.Kick) else RED
		panel.ZoneStroke.Thickness = 5 + 3 * self.Kick
	end
	local feedback = self.Feedback
	if feedback and os.clock() < feedback.Until then
		setText(panel.Status, feedback.Text, feedback.Color)
	elseif cue then
		setText(panel.Status, "Press when the ring hits the circle", SOFT)
	else
		setText(panel.Status, "Hold on...", SOFT)
	end
end

return FX.Module({
	HellDoor = {
		Init = function(self, props)
			self.Rise = tonumber(props.Rise) or 3
			self.Open = tonumber(props.Open) or 2.5
			self.Emerge = tonumber(props.Emerge) or 4.5
			self.Life = tonumber(props.Life) or 60
			self.Fade = tonumber(props.Fade) or 4
			self.Crossing = tonumber(props.Crossing) or 14
			self.Height = tonumber(props.Height) or 140
			self.Embers = tonumber(props.Embers) or 2.5
			self.Start = if typeof(props.Start) == "Vector3" then props.Start else self.Origin.Position
			self.Dir = if typeof(props.Dir) == "Vector3" then props.Dir else Vector3.new(1, 0, 0)
			self.Travel = tonumber(props.Travel) or 100
			self.HalfLength = tonumber(props.HalfLength) or 60
			self.DoorBack = tonumber(props.DoorBack) or 5
			self.Held = false
			self.Shown = 0
			self.Opened = false
			self.NextRoar = 0
			local inst: Instance = self.Inst
			-- the door: its stone (the model's own parts), and the two doors on their hinges
			self.Frame = FX.RigFrom(inst, self.Origin)
			self.Doors = {}
			for _, name in { "DoorL", "DoorR" } do
				local group = inst:FindFirstChild(name)
				local root = group and group:FindFirstChild("Root")
				if group and root and root:IsA("BasePart") then
					table.insert(self.Doors, {
						Rig = FX.RigFrom(group, root.CFrame),
						Hinge = self.Origin:ToObjectSpace(root.CFrame),
						Side = if name == "DoorL" then 1 else -1, -- (DoorL swings with a + turn, DoorR with a - turn)
					})
				end
			end
			local glow = inst:FindFirstChild("Glow")
			self.Light = glow and glow:FindFirstChildOfClass("PointLight")
			self.Belch = glow and glow:FindFirstChild("Belch")
			self.DoorEmbers = glow and glow:FindFirstChild("Embers")
			self.Glowing = {}
			for _, item in inst:GetDescendants() do
				if item:IsA("BasePart") and (item.Name == "EyeL" or item.Name == "EyeR" or string.match(item.Name, "^Rune%d+$") or item.Name == "Hellfire" or item.Name == "Crack") then
					table.insert(self.Glowing, { Part = item, Transparency = item.Transparency })
				end
			end
			-- the wall: one FireSegment every SPACING studs, along a line across the arena
			self.Facing = CFrame.lookAt(Vector3.zero, self.Dir) -- (X = across the arena, -Z = the way it first moves)
			self.Segments = {}
			local count = math.max(2, math.ceil(self.HalfLength * 2 / SPACING))
			local wallFolder = Instance.new("Folder")
			wallFolder.Name = "Wall"
			wallFolder.Parent = inst
			for i = 1, count do
				local x = -self.HalfLength + (i - 0.5) * (self.HalfLength * 2 / count)
				local copy = FX.Clone("deadswitch", "FireSegment", wallFolder)
				if not copy then
					break
				end
				local segment = { Model = copy, X = x, Parts = {}, Emitters = {}, Rates = {} }
				for _, name in { "Base", "Low", "Mid", "High", "Flames" } do
					local part = copy:FindFirstChild(name)
					if part and part:IsA("BasePart") then
						segment.Parts[name] = { Part = part, Size = part.Size, Transparency = part.Transparency }
					end
				end
				for _, item in copy:GetDescendants() do
					if item:IsA("ParticleEmitter") then
						table.insert(segment.Emitters, item)
						segment.Rates[item] = item.Rate
						item.Enabled = false
					elseif item:IsA("PointLight") then
						segment.Light = item
						item.Enabled = i % 3 == 2 -- (one light in three: they are costly)
						segment.Brightness = item.Brightness
					end
				end
				table.insert(self.Segments, segment)
			end
			self.Particles = not FX.Off("DisableParticles")
			FX.Sound("HellDoorGrind", self.Origin.Position + Vector3.new(0, 10, 0))
			self:Rumble(0.6, 2.4, self.Rise, 10, self.Origin.Position)
			-- hide the wall until it pours out
			for _, segment in self.Segments do
				segment.Model.Parent = nil
			end
			self.WallFolder = wallFolder
			self:Keep(function()
				for _, segment in self.Segments do
					segment.Model:Destroy()
				end
			end)
		end,

		Step = function(self, dt, t)
			-- 1. the door: up out of the void, doors open, and at the end shut and down again
			local endAt = self.DoneAt or (self.Rise + self.Open + self.Life)
			local closing = math.max(t - endAt, 0)
			local rise = FX.Ease.Out(FX.Clamp01(t / self.Rise))
			local sinkK = FX.Ease.In(FX.Clamp01((closing - 1.2) / 2.5))
			local depth = SINK * (1 - rise) + SINK * sinkK
			local base = self.Origin * CFrame.new(0, -depth, 0)
			local openK = FX.Ease.Smooth((t - self.Rise) / self.Open)
			local shutK = smoothstep(closing / 1.0)
			local swing = DOOR_SWING * openK * (1 - shutK)
			-- (only while it moves: once it stands open, nothing of the door needs placing)
			if depth ~= self.LastDepth or swing ~= self.LastSwing then
				self.LastDepth, self.LastSwing = depth, swing
				self.Frame:Move(base)
				for _, door in self.Doors do
					door.Rig:Move(base * door.Hinge * CFrame.Angles(0, door.Side * swing, 0))
				end
			end
			-- the moment they burst open: chains drop, a gout of fire, the light comes on
			if not self.Opened and t >= self.Rise + 0.2 then
				self.Opened = true
				FX.Sound("HellDoorOpen", self.Origin.Position + Vector3.new(0, 15, 0))
				FX.Sound("FireRoar", self.Origin.Position + Vector3.new(0, 15, 0), 1.2, 0.6)
				FX.Shake(2.5, 10, 0.05, 0.8, self.Origin.Position, 40, 220)
				local lock = self.Frame:Get("Lock")
				if lock then
					FX.Burst(lock.Position, "Spark", 26, { Color = EMBER })
				end
				self.Frame:Hide("Chain", true)
				self.Frame:Hide("Lock", true)
				if self.Belch and self.Belch:IsA("ParticleEmitter") and self.Particles then
					self.Belch:Emit(tonumber(self.Belch:GetAttribute("EmitCount")) or 60)
				end
				if self.DoorEmbers and self.DoorEmbers:IsA("ParticleEmitter") then
					self.DoorEmbers.Enabled = self.Particles
				end
			end
			local lit = openK * (1 - shutK)
			if self.Light then
				self.Light.Brightness = 4 * lit
			end
			for _, entry in self.Glowing do
				entry.Part.Transparency = entry.Transparency + (1 - entry.Transparency) * (if entry.Part.Name == "Hellfire" then 1 - lit else 0.5 * (1 - lit))
			end
			if closing > 0 and self.DoorEmbers and self.DoorEmbers:IsA("ParticleEmitter") then
				self.DoorEmbers.Enabled = false
			end

			-- 2. the wall
			local along, height, _moving = wallAt(self, t)
			local target = if self.Held then math.min(self.Embers, height) else height
			if self.DoneAt then
				target = 0
			end
			-- it sinks fast when the lever is pulled, and roars back up even faster
			local rate = if target > self.Shown then 9 else 5
			self.Shown += (target - self.Shown) * math.min(dt * rate, 1)
			local shown = self.Shown
			local since = t - (self.Rise + self.Open)
			local pouring = FX.Clamp01(since / self.Emerge)
			-- (while it pours out, it comes forward out of the doorway to its line)
			local line = self.Start + self.Dir * (along - self.DoorBack * (1 - smoothstep(pouring)))
			local frame = CFrame.new(line) * self.Facing
			local visible = since > 0 and shown > 0.05
			if visible ~= self.WallOn then
				self.WallOn = visible
				for _, segment in self.Segments do
					segment.Model.Parent = if visible then self.WallFolder else nil
				end
			end
			if not visible then
				return
			end
			-- it spreads from the doorway to both ends while it pours out
			local spread = smoothstep(pouring) * (self.HalfLength + 12)
			local fadeOut = FX.Clamp01((self.Life - since) / self.Fade)
			for index, segment in self.Segments do
				local reach = FX.Clamp01((spread - math.abs(segment.X)) / 12)
				local flicker = 1 + 0.08 * FX.Noise(index * 1.7, t * 2.3)
				local h = math.max(shown * reach * flicker, 0.05)
				local at = frame * CFrame.new(segment.X, 0, 0)
				segment.Model:PivotTo(at)
				local parts = segment.Parts
				local bed = parts.Base
				if bed then
					local bedHeight = math.min(4, 1 + h) * reach
					bed.Part.Size = Vector3.new(bed.Size.X, math.max(bedHeight, 0.05), bed.Size.Z)
					bed.Part.CFrame = at * CFrame.new(0, bedHeight / 2, 0)
					bed.Part.Transparency = 1 - (1 - bed.Transparency) * reach * fadeOut
				end
				local y = 0
				for _, layer in { { "Low", 0.3 }, { "Mid", 0.35 }, { "High", 0.35 } } do
					local entry = parts[layer[1]]
					local tall = h * layer[2]
					if entry then
						entry.Part.Size = Vector3.new(entry.Size.X, math.max(tall, 0.05), entry.Size.Z)
						entry.Part.CFrame = at * CFrame.new(0, y + tall / 2, 0)
						entry.Part.Transparency = 1 - (1 - entry.Transparency) * reach * fadeOut * math.clamp(h / 6, 0, 1)
					end
					y += tall
				end
				local flames = parts.Flames
				if flames then
					flames.Part.Size = Vector3.new(flames.Size.X, math.max(h, 0.2), flames.Size.Z)
					flames.Part.CFrame = at * CFrame.new(0, h / 2, 0)
				end
				local amount = math.clamp(h / self.Height, 0.04, 1) * reach * fadeOut
				for _, emitter in segment.Emitters do
					emitter.Enabled = self.Particles and amount > 0.02
					emitter.Rate = (segment.Rates[emitter] or 10) * amount
				end
				if segment.Light then
					segment.Light.Brightness = (segment.Brightness or 1.6) * (0.4 + 0.6 * math.clamp(h / 30, 0, 1)) * reach * fadeOut
				end
			end
			-- it roars while nobody holds the lever
			if not self.Held and not self.DoneAt and since > self.Emerge and t >= self.NextRoar and shown > 4 then
				self.NextRoar = t + 1.6
				FX.Sound("FireRoar", line + Vector3.new(0, 4, 0), 0.8)
			end
		end,

		-- Server: Call(id, "Held", held) whenever somebody grabs or lets go of the lever
		Held = function(self, held)
			local now = held == true
			if now == self.Held then
				return
			end
			self.Held = now
			local since = self:Time() - (self.Rise + self.Open)
			if not now and since > 0 and not self.DoneAt then
				-- let go: it roars back up
				FX.Sound("FireRoar", self.Start + self.Dir * (wallAt(self, self:Time())), 1.1, 0.75)
				FX.Shake(1.4, 8, 0.1, 0.6)
			end
		end,

		-- Server: K.Strike: somebody was burnt by the wall
		Hit = function(self, userId)
			local root = FX.Root(tonumber(userId) or 0)
			if not root then
				return
			end
			FX.Burst(root.Position, "Fire", 18, { Color = FIRE })
			FX.Burst(root.Position, "Smoke", 10, { Color = Color3.fromRGB(40, 34, 32) })
			if FX.IsMe(tonumber(userId) or 0) then
				FX.Shake(5, 12, 0.03, 0.5)
				FX.Pulse(HELL, 0.45, 0.35)
			end
		end,

		-- Server: Call(id, "Over"): the fire is dead
		Over = function(self)
			if not self.DoneAt then
				self.DoneAt = self:Time()
				FX.Sound("HellDoorGrind", self.Origin.Position + Vector3.new(0, 10, 0), 0.8, 1.4)
			end
		end,
	},

	Lever = {
		Init = function(self, props)
			self.Lead = tonumber(props.Lead) or 1.1
			self.Early = tonumber(props.Early) or 0.32
			self.Late = tonumber(props.Late) or 0.28
			self.Holder = 0
			self.JammedUntil = 0
			self.Angle = LEVER_UP
			self.Velocity = 0
			self.Kick = 0
			self.Cue = nil
			self.Feedback = nil
			local inst: Instance = self.Inst
			self.Base = FX.RigFrom(inst, self.Origin)
			local arm = inst:FindFirstChild("Arm")
			local armRoot = arm and arm:FindFirstChild("Root")
			if arm and armRoot and armRoot:IsA("BasePart") then
				self.Arm = FX.RigFrom(arm, armRoot.CFrame)
			end
			local heat = inst:FindFirstChild("Heat")
			self.Heat = if heat and heat:IsA("BasePart") then heat else nil
			self.Sparks = heat and heat:FindFirstChild("Sparks")
			self.Smoke = heat and heat:FindFirstChild("Smoke")
			-- the chain: from its ring, over the edge of the plate toward the door, down into the void
			local ring = inst:FindFirstChild("ChainRing")
			if ring and ring:IsA("BasePart") and typeof(props.DoorAt) == "Vector3" then
				local from = ring.Position
				local toward = FX.Flat(props.DoorAt - from)
				local unit = if toward.Magnitude > 0.1 then toward.Unit else -self.Origin.LookVector
				local over = from + unit * 16 + Vector3.new(0, -14, 0)
				self.Chain = self:Keep(FX.Line(inst, from, over, 0.3, Color3.fromRGB(96, 58, 38), Enum.Material.CorrodedMetal))
				self.ChainFrom, self.ChainTo = from, over
			end
			FX.Sound("ChainRattle", self.Origin.Position)
			self:Keep(function()
				closePanel(self)
			end)
		end,

		Step = function(self, dt, t)
			local now = FX.Now()
			local held = self.Holder ~= 0
			local jammed = not held and now < self.JammedUntil
			-- the arm: a spring toward DOWN (held) or UP; it shakes in the holder's hands and rattles while stuck
			local target = if held then LEVER_DOWN + math.rad(2.2) * math.sin(t * 31) + math.rad(5) * math.max(FX.Noise(3.1, t * 1.3), 0) else LEVER_UP
			if jammed then
				target = LEVER_UP + math.rad(3) * math.sin(t * 45)
			end
			-- (a spring, in small steps so it stays steady at a low frame rate)
			local left = dt
			while left > 0 do
				local step = math.min(left, 1 / 120)
				left -= step
				self.Velocity += ((target - self.Angle) * 140 - self.Velocity * 16) * step
				self.Angle += self.Velocity * step
			end
			self.Kick = math.max(0, self.Kick - dt * 3)
			local rise = FX.Ease.Out(FX.Clamp01(t / 1.4))
			local base = self.Origin * CFrame.new(0, -3.5 * (1 - rise), 0)
			self.Base:Move(base)
			if self.Arm then
				self.Arm:Move(base * CFrame.new(PIVOT) * CFrame.Angles(self.Angle - math.rad(3) * self.Kick, 0, 0))
			end
			if self.Chain and self.ChainFrom then
				local sag = if held then 0.4 * math.sin(t * 23) else 0
				FX.SetLine(self.Chain, self.ChainFrom + Vector3.new(0, -3.5 * (1 - rise) + sag * 0.1, 0), self.ChainTo + Vector3.new(0, sag, 0))
			end
			-- red-hot while it is stuck
			if self.Heat then
				local glow = if jammed then 0.15 + 0.15 * math.sin(t * 12) else 1
				self.Heat.Transparency += (glow - self.Heat.Transparency) * math.min(dt * 8, 1)
			end
			if self.Smoke and self.Smoke:IsA("ParticleEmitter") then
				self.Smoke.Enabled = jammed and not FX.Off("DisableParticles")
			end
			drawPanel(self)
		end,

		-- Server: Call(id, "Held", userId (0 = nobody), stuck until (server clock))
		Held = function(self, userId, jammedUntil)
			local id = tonumber(userId) or 0
			local before = self.Holder
			self.Holder = id
			self.JammedUntil = tonumber(jammedUntil) or 0
			local leverTop = self.Origin.Position + Vector3.new(0, 3, 0)
			if id ~= 0 and before == 0 then
				FX.Sound("LeverClank", leverTop, 1, 1)
				FX.Sound("ChainRattle", leverTop)
				self.Velocity += 6
			elseif id == 0 and before ~= 0 then
				FX.Sound("LeverClank", leverTop, 1, 0.75)
				FX.Sound("ChainRattle", leverTop)
				if self.Sparks and self.Sparks:IsA("ParticleEmitter") and not FX.Off("DisableParticles") then
					self.Sparks:Emit(tonumber(self.Sparks:GetAttribute("EmitCount")) or 24)
				end
				FX.Burst(leverTop, "Dust", 6, { Color = Color3.fromRGB(52, 50, 54) })
				self.Velocity -= 10
			end
			if FX.IsMe(id) then
				openPanel(self)
			elseif FX.IsMe(before) then
				-- (let go: the panel goes once "Slip" has said why; this is the safety net)
				self:After(0.9, function()
					if not FX.IsMe(self.Holder) then
						closePanel(self)
					end
				end)
			end
		end,

		-- Server: Signal(id, "Cue", userId, index, at): a ring for the holder, on the circle at `at` (server clock)
		Cue = function(self, userId, index, at)
			if FX.IsMe(tonumber(userId) or 0) and type(at) == "number" then
				self.Cue = { Index = tonumber(index) or 0, At = at }
			end
		end,

		-- Server: a press that counted
		Good = function(self, userId)
			if FX.IsMe(tonumber(userId) or 0) then
				self.Kick = 1
			end
		end,

		-- Server: the holder let go. why: soon / late / missed / letgo / knocked / dead / end
		Slip = function(self, userId, why)
			if not FX.IsMe(tonumber(userId) or 0) then
				return
			end
			self.Cue = nil
			local text = ({
				soon = "TOO SOON! It slipped!",
				late = "TOO LATE! It slipped!",
				missed = "It slipped out of your hands!",
				knocked = "You were knocked off it!",
				letgo = "You let go.",
			})[tostring(why)]
			if text then
				self.Feedback = { Text = text, Color = RED, Until = os.clock() + 2 }
				FX.Sound("SwitchSlip")
				FX.Shake(2, 10, 0.03, 0.4)
				if loadedTrack and loadedTrack.IsPlaying then
					loadedTrack:Stop(0.15)
				end
				self:After(0.8, function()
					if not FX.IsMe(self.Holder) then
						closePanel(self)
					end
				end)
			else
				closePanel(self)
			end
		end,

		-- Server: Call(id, "Over"): the fire is dead
		Over = function(self)
			self.Holder = 0
			self.JammedUntil = 0
			closePanel(self)
		end,
	},
})
