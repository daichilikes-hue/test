-- ModuleScript: ReplicatedStorage > EventClients > kraken     (REPLACE)
-- What the Void Kraken looks like on each client:
--   Lair  the beast itself: its head out of the water with one eye that follows you, and tentacles waving round the arena
--   Slam  a tentacle that comes up out of the water, rears up, whips down across the plates, and is reeled back in
-- Oct 10 2026 (update 9): no red strip (the reared tentacle is the warning); after the slam the tentacle is pulled
-- BACK the way it came and slides into the water where it came out, instead of sinking through the plates; and
-- everything is made of real parts now: the models Lair, Arm and Slam under ServerScriptService > Events >
-- VoidKraken are cloned, nothing is built here. Restyle them in Studio as you like. Names the code needs:
--   Lair > Head > Head, Iris, Pupil, Lid   (everything else in Head just rides along)
--   Arm, Slam > Seg1, Seg2 ... and Joint1, Joint2 ...   (as many as you like: the code counts them)
-- The server (Events > VoidKraken) decides who gets hit.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not (FX.Tube and FX.RigFrom and FX.Clone) then
	warn("[kraken] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end

local C = FX.Colors
local RAISED = math.rad(64)       -- how far a tentacle rears up before it comes down (90 = straight up)
local CURL = 0.25                 -- the tip curls back this much more than the root (so it comes down like a whip)
local RISE = 0.6                  -- seconds it takes to come up out of the water
local ARM_HEIGHT = 27             -- how tall the waving tentacles stand
local UP = Vector3.new(0, 1, 0)

return FX.Module({
	Slam = {
		Init = function(self: any, props: any)
			local tube = FX.Tube(self.Inst)
			self.Tube = tube
			if tube.Count == 0 then
				FX.WarnOnce("krakenslam", "the model 'Slam' is missing under ServerScriptService > Events > VoidKraken (install the update again): the tentacles are invisible")
			end
			tube:Hide(true) -- (it is still under water)
			self.Toward = FX.Dir(self.Origin.LookVector)
			self.Root = self.Origin.Position           -- where it comes out of the water
			self.Length = props.Length or 150
			self.Width = props.Width or 7
			self.Gap = math.max(props.Gap or 14, 2)    -- studs of water between that spot and the plates
			self.Depth = props.Depth or 17             -- how far the plate tops are above the water
			self.Splashed, self.Landed, self.Reeling, self.Gone, self.NextDust = false, false, false, false, 0
		end,

		Step = function(self: any, _dt: number, t: number)
			local tube: FX.Tube = self.Tube
			local count = tube.Count
			if count == 0 then
				return
			end
			local p = self.Props
			local warn: number, drop: number, stay: number, leave: number = p.Warn or 1.3, p.Drop or 0.16, p.Stay or 0.6, p.Leave or 1.3
			local root: Vector3, toward: Vector3, length: number, width: number = self.Root, self.Toward, self.Length, self.Width
			local gap: number, depth: number = self.Gap, self.Depth
			local impact = warn + drop
			local reelAt = impact + stay
			if not self.Splashed then
				self.Splashed = true
				if t < warn then
					FX.Splash(root, C.Void, 2.4)
					FX.Sound("Splash", root, 0.9, 0.7)
				end
			end
			-- how much of it is out of the water (0..1): it slides out tip first, and after the slam it is reeled back in
			local back = FX.Ease.In(FX.Span(t, reelAt, reelAt + leave))
			local slide = FX.Ease.Out(FX.Span(t, 0, math.min(RISE, warn * 0.6))) * (1 - back)
			-- how far it is reared up
			local phi = 0
			if t < warn then
				phi = RAISED + math.sin(t * 5) * 0.05
			elseif t < impact then
				phi = RAISED * (1 - FX.Ease.In((t - warn) / drop))
			elseif t < reelAt then
				phi = math.abs(FX.Ease.Wobble((t - impact) / 0.5, 2, 5)) * 0.05
			end
			local onPlates = root + UP * depth
			if t >= impact and not self.Landed then
				self.Landed = true
				if t < impact + 0.5 then
					-- WHAM: dust all along it, and the camera feels it by how close it landed
					for k = 0, 6 do
						FX.Burst(onPlates + toward * (gap + (length - gap) * k / 6), "Dust", 7, { Color = Color3.fromRGB(150, 130, 160), Scale = 1.7 })
					end
					local nearest = onPlates + toward * (length / 2)
					local camera = workspace.CurrentCamera
					if camera then
						nearest = onPlates + toward * math.clamp((camera.CFrame.Position - root):Dot(toward), gap, length)
					end
					FX.Sound("Slam", nearest, 1.2)
					FX.Punch(nearest, 1.5)
				end
			end
			if t >= reelAt and not self.Reeling then
				self.Reeling = true
				if t < reelAt + 0.5 then
					FX.Sound("Shuffle", onPlates + toward * (length * 0.5), 1, 0.6) -- it starts to drag
				end
			end
			if self.Reeling and not self.Gone then
				-- the tip scrapes back over the plates, then slips into the water
				local tipAt = slide * length
				if tipAt > gap and t >= self.NextDust then
					self.NextDust = t + 0.12
					FX.Burst(onPlates + toward * tipAt, "Dust", 3, { Color = Color3.fromRGB(150, 130, 160), Scale = 1.2 })
				end
				if back >= 1 then
					self.Gone = true
					FX.Splash(root, C.Void, 1.8)
					FX.Sound("Splash", root, 0.7, 0.9)
				end
			end

			-- q = how far along its own body a point is from where it leaves the water (below 0 = still under water);
			-- s = 0 at its root end, 1 at its tip
			local function pointAt(q: number, s: number, thick: number): Vector3
				if q <= 0 then
					return root + UP * q
				end
				local angle = phi * (1 + CURL * s)
				local along = math.cos(angle) * q
				local climbed = FX.Ease.Smooth(math.clamp(along / gap, 0, 1)) -- up the side, from the water onto the plates
				return root + toward * along + UP * (math.sin(angle) * q + climbed * (depth + thick * 0.5))
			end
			local previous = pointAt((slide - 1) * length, 0, width * 1.05)
			for index = 1, count do
				local s = index / count
				local thick = width * (1.05 - 0.7 * s)
				local q = (s - 1 + slide) * length
				local point = pointAt(q, s, thick)
				tube:Place(index, previous, point, thick, q < -thick)
				previous = point
			end
		end,

		Hit = function(self: any, userId: number)
			self:Hurt(userId, C.Purple)
		end,
	},

	Lair = {
		Init = function(self: any, props: any)
			-- (the server put this visual on the water, turned to look at the middle of the arena)
			local group = self.Inst:FindFirstChild("Head")
			if not group then
				FX.WarnOnce("krakenlair", "the model 'Lair' is missing under ServerScriptService > Events > VoidKraken (install the update again): the kraken is invisible")
			end
			local rig = FX.RigFrom(group, self.Origin)
			self.Rig = rig
			self.IrisHome, self.PupilHome, self.LidHome = rig:Offset("Iris"), rig:Offset("Pupil"), rig:Offset("Lid")
			local lid, white = rig:Get("Lid"), rig:Get("White")
			self.LidSize = if lid then lid.Size else Vector3.new(11, 0.3, 5)
			self.EyeSize = if white then white.Size.Y else 10
			local head = rig:Get("Head")
			if head then
				FX.Stream(head, "Mist", { Color = C.Void, Rate = 4, Scale = 2 })
			end
			-- tentacles waving out of the water round the arena (copies of the model Arm)
			self.Arms = {}
			local centre: Vector3 = if typeof(props.Centre) == "Vector3" then props.Centre else self.Origin.Position + self.Origin.LookVector * 80
			for index, base in if type(props.Arms) == "table" then props.Arms else {} do
				if typeof(base) == "Vector3" then
					local tube = FX.Tube(FX.Clone("kraken", "Arm", self.Inst))
					tube:Hide(true)
					local lean = FX.Dir(centre - base)
					table.insert(self.Arms, { Base = base, Tube = tube, Lean = lean, Side = Vector3.new(-lean.Z, 0, lean.X), Index = index })
				end
			end
			if self:Time() < 2 then
				local at: Vector3 = self.Origin.Position
				FX.Splash(at, C.Void, 4)
				FX.Sound("Slam", at, 0.9, 0.6)
				FX.Shake(3, 8, 0.4, 1.2, at, 60, 220)
			end
		end,

		Step = function(self: any, _dt: number, t: number)
			local up = FX.Ease.Smooth(t / 1.6)
			if self.Leaving then
				up *= 1 - FX.Ease.Smooth(FX.Span(t, self.Leaving, self.Leaving + 1.3))
			end
			local rig: FX.Rig = self.Rig
			-- the head: up out of the water at first, bobbing; back under at the end
			local frame: CFrame = self.Origin * CFrame.new(0, -36 * (1 - up) + math.sin(t * 0.9) * 0.8, 0) * CFrame.Angles(math.sin(t * 0.6) * 0.04, 0, math.sin(t * 0.45) * 0.05)
			-- the eye follows your camera, and blinks now and then
			local camera = workspace.CurrentCamera
			if camera then
				local seen = frame:PointToObjectSpace(camera.CFrame.Position)
				local eye: Vector3 = self.IrisHome.Position
				local reach: number = self.EyeSize * 0.16
				local dx = math.clamp((seen.X - eye.X) / 40, -1, 1) * reach
				local dy = math.clamp((seen.Y - eye.Y) / 40, -1, 1) * reach * 0.8
				rig:Pose("Iris", self.IrisHome * CFrame.new(dx, dy, 0))
				rig:Pose("Pupil", self.PupilHome * CFrame.new(dx * 1.15, dy * 1.15, 0))
			end
			local blink = (t * 0.27 + 0.3) % 1
			local closed = if blink < 0.05 then 1 - math.abs(blink / 0.025 - 1) else 0
			local lidSize: Vector3 = self.LidSize
			local tall = lidSize.Y + (self.EyeSize * 1.05 - lidSize.Y) * closed
			rig:Resize("Lid", Vector3.new(lidSize.X, tall, lidSize.Z))
			rig:Pose("Lid", self.LidHome * CFrame.new(0, -(tall - lidSize.Y) / 2, 0)) -- (it comes down from the brow)
			rig:Move(frame)

			for _, arm in self.Arms do
				local tube: FX.Tube = arm.Tube
				local count = tube.Count
				local base: Vector3, lean: Vector3, side: Vector3 = arm.Base, arm.Lean, arm.Side
				local previous = base - UP * 2
				for j = 1, count do
					local s = j / count
					local sway = math.sin(t * 1.3 + arm.Index * 1.7 + s * 2.2) * 5 * s
					local point = base + UP * (s * ARM_HEIGHT * up) + lean * (sway * 0.6 + s * s * 5) * up + side * sway * up
					tube:Place(j, previous, point, 4.4 * (1.05 - 0.75 * s), up < 0.03)
					previous = point
				end
			end
		end,

		Outro = function(self: any, _seconds: number?)
			if not self.Leaving then
				self.Leaving = self:Time()
			end
		end,
	},
})
