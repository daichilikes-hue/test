-- ModuleScript: ReplicatedStorage > EventClients > hellgate
-- What The Hellgate Lift looks like on each client.
--   Lift   a rusted iron mine cage hanging on chains out of the dark beside an outer plate, a brazier on top with a
--          dull gold chalice (the relic) in the fire; the fire is bigger the deeper the floor. An iron ladder down
--          the plate's edge. Far below: two iron doors in a stone rim, firelight leaking through the crack.
--          On the wall by the cage's door: the PANEL, five buttons. The one of the floor it is at glows; while it
--          rides, the one it is going to blinks. On the Devil's floor the chalice is gone and his FIDDLE stands in
--          the fire.
--          The trap: the shutters SLAM down over the door, the chains snap, the cage drops, the doors grind open on
--          fire and hanging chains, swallow it, and grind shut. (Nobody took anything: for the last seconds before
--          the shutters slam by themselves the cage shudders and its chains rattle.)
--          The cage floor, its walls, the shutters and the ladder are SOLID on your screen (you ride it).
--   Hell   (for whoever is down there) the screen goes black, then everything is tinted fire, a banner counts your
--          time. Patches of the floor glow and crackle, then erupt. No circles: the glow is the warning.
-- Oct 11 2026 (update 12): the cage, the panel and the doors are a MODEL now (Lift, under ServerScriptService >
-- Events > HellgateLift) instead of being built part by part every time the event runs. Restyle it in Studio as
-- you like; the code needs these names:
--   Cage  > Floor, Lip, WallBack, WallLeft, WallRight (you stand on / bump into these), WallDoor (solid once the
--           shutters are down), Shutter1, Shutter2 ... (out of sight until the trap), Chain (gone when they snap),
--           Coals (the fire stands on them), Button1, Button2 ... (the panel), every part whose name starts with
--           Relic (what burns on it) and with Fiddle (what burns on the Devil's floor instead)
--   Doors > DoorL, DoorR, StrapL1..3, StrapR1..3 (they swing open), Crack, Glow
-- The server (Events > HellgateLift) decides everything; the cage's height comes from the same liftY() maths.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

local FX = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not (FX.RigFrom and FX.UseSounds) then
	warn("[hellgate] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end

-- YOUR SOUNDS: put an id in Id. While Id is "" the built-in Roblox sound in Stand plays ("" = silence).
-- (Speed is tuned for the stand-in: set it back to 1 when you put your own sound in.)
--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	ChainRattle = { Id = "", Stand = "rbxasset://sounds/unsheath.wav", Speed = 0.4, Volume = 0.7 },          -- the cage coming down, the chains shaking, the chains snapping
	CageGroan = { Id = "", Stand = "rbxasset://sounds/unsheath.wav", Speed = 0.35, Volume = 0.7 },           -- iron groaning as it sets off for a floor
	PanelClunk = { Id = "", Stand = "rbxasset://sounds/action_jump_land.mp3", Speed = 1.5, Volume = 0.5 },   -- a floor button going in
	ShutterSlam = { Id = "", Stand = "rbxasset://sounds/action_jump_land.mp3", Speed = 0.36, Volume = 1.4 }, -- the shutters slamming shut
	HellDoor = { Id = "", Stand = "rbxasset://sounds/action_jump_land.mp3", Speed = 0.14, Volume = 1.4 },    -- the doors below grinding open / shut
	FireRoar = { Id = "", Stand = "rbxasset://sounds/swordslash.wav", Speed = 0.4, Volume = 0.8 },           -- the brazier flaring when it stops at a floor
	HellCrackle = { Id = "", Stand = "rbxasset://sounds/action_get_up.mp3", Speed = 0.6, Volume = 0.7 },     -- in hell: a patch of floor about to erupt
	HellErupt = { Id = "", Stand = "rbxasset://sounds/impact_explosion_03.mp3", Speed = 0.7, Volume = 1 },   -- in hell: it erupts
}
--[[DMP:END]]
FX.UseSounds(SOUNDS)

local localPlayer = Players.LocalPlayer
local UP = Vector3.new(0, 1, 0)
local RUST_DARK = Color3.fromRGB(58, 40, 30)
local FIRE = Color3.fromRGB(222, 112, 48)
local EMBER = Color3.fromRGB(214, 110, 52)
local DUST = Color3.fromRGB(96, 80, 64)
local METAL = Enum.Material.CorrodedMetal
local LIT = Color3.fromRGB(236, 150, 70)   -- the panel button of the floor it is at (the others keep the model's colour)
local HELL_BELOW = 22       -- the doors are this far below the deepest floor
local SOLID = { Floor = true, Lip = true, WallBack = true, WallLeft = true, WallRight = true } -- (WallDoor: once the shutters are down)

-- KEEP IN SYNC with liftY() in ServerScriptService > Events > HellgateLift (the numbers come in props).
-- ride = the last ride the cage was sent on: from height From to height To (studs above the plate top), starting At
-- (seconds since the event began) and taking Time seconds.
local function liftY(p: any, t: number, ride: any, trapAt: number?): number
	if trapAt and t >= trapAt then
		local fall = math.max(t - trapAt - p.Slam, 0)
		return liftY(p, trapAt, ride, nil) - 0.5 * p.Fall * fall * fall
	end
	if t < p.Arrive then
		return 30 * (1 - math.max(t, 0) / p.Arrive) ^ 3
	end
	if ride.Time <= 0 or t >= ride.At + ride.Time then
		return ride.To
	end
	local u = math.clamp((t - ride.At) / ride.Time, 0, 1)
	return ride.From + (ride.To - ride.From) * (u * u * (3 - 2 * u))
end

-- where a group of the model was built round (its own Root part)
local function originOf(group: Instance?, fallback: CFrame): CFrame
	local root = group and group:FindFirstChild("Root")
	return if root and root:IsA("BasePart") then root.CFrame else fallback
end

---------------------------------------------------------------------- the black-out and hell screens (yours only)
local function blackout(self: any, after: number)
	local playerGui = localPlayer:FindFirstChildOfClass("PlayerGui")
	if not playerGui then
		return
	end
	local gui = Instance.new("ScreenGui")
	gui.Name = "HellgateBlackout"
	gui.IgnoreGuiInset = true
	gui.ResetOnSpawn = false
	gui.DisplayOrder = 70
	local black = Instance.new("Frame")
	black.Size = UDim2.fromScale(1, 1)
	black.BackgroundColor3 = Color3.new(0, 0, 0)
	black.BackgroundTransparency = 1
	black.BorderSizePixel = 0
	black.Parent = gui
	gui.Parent = playerGui
	self:Keep(gui)
	task.delay(after, function()
		if gui.Parent then
			TweenService:Create(black, TweenInfo.new(0.25), { BackgroundTransparency = 0 }):Play()
			task.delay(0.9, function()
				if gui.Parent then
					TweenService:Create(black, TweenInfo.new(0.7), { BackgroundTransparency = 1 }):Play()
					task.delay(0.8, function()
						gui:Destroy()
					end)
				end
			end)
		end
	end)
end

local function hellOff(self: any)
	if not self.HellUntil then
		return
	end
	self.HellUntil = nil
	local banner = self.HellBanner
	if banner then
		banner.Close()
		self.HellBanner = nil
	end
	if self.HellTint then
		self.HellTint.Back(0.8)
	end
	self:VignetteOff(0.8)
end

return FX.Module({
	Lift = {
		Init = function(self: any, props: any)
			local p = props
			self.P = p
			if p.Levels == nil then
				FX.WarnOnce("hellgateold", "ServerScriptService > Events > HellgateLift is an OLDER copy than this script was made for, so the cage will not move right. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
				p.Levels = p.Stops or 5
			end
			local w, d, h = p.W or 10, p.D or 8, p.H or 8
			local gap = p.Gap or 2
			self.CageZ = -(gap + d / 2)
			self.Ride = { From = 0, To = 0, At = p.Arrive, Time = 0 }
			self.Level = 1          -- the floor it is at, or on its way to
			-- THE MODEL: Cage and Doors, each built round its own Root
			local inst: Instance = self.Inst
			local cage, doors = inst:FindFirstChild("Cage"), inst:FindFirstChild("Doors")
			if not (cage and doors) then
				FX.WarnOnce("hellgatemodel", "the model 'Lift' is missing under ServerScriptService > Events > HellgateLift (install the update again): the cage is invisible")
			end
			local rig = if cage then FX.RigFrom(cage, originOf(cage, self.Origin * CFrame.new(0, 0, self.CageZ))) else FX.Rig(inst)
			self.Cage = rig
			-- what you stand on and bump into (the bars are only what you see)
			rig:Each(function(part: BasePart, name: string)
				if SOLID[name] then
					part.CanCollide = true
					part.CanQuery = true
				end
			end)
			self.Door = rig:Get("WallDoor")
			-- the shutters wait out of sight; where each one sits when it is down is read off the model
			self.Shutters = {}
			for index = 1, 40 do
				if not rig:Get("Shutter" .. index) then
					break
				end
				self.Shutters[index] = rig:Offset("Shutter" .. index)
			end
			rig:Hide("Shutter", true)
			-- what burns on it: the relic; on the Devil's floor his fiddle
			rig:Hide("Fiddle", true)
			self.Burning = "Relic"
			-- the panel's buttons, as the model has them (unlit)
			self.Buttons = {}
			for index = 1, 40 do
				local button = rig:Get("Button" .. index)
				if not button then
					break
				end
				self.Buttons[index] = { Part = button, Color = button.Color, Material = button.Material }
			end
			self.Lit = 0
			-- the fire, on the coals
			local fireAt = if rig:Get("Coals") then rig:Offset("Coals").Position else Vector3.new(0, h + 1.8, 0)
			FX.AddFlame(rig, "Fire", CFrame.new(fireAt), 0.7, FIRE)
			-- the ladder down the plate's edge (climbable; dark iron)
			local depth = (p.Levels - 1) * p.Depth
			local height = math.floor((depth + 2) / 2 + 0.5) * 2
			local truss = Instance.new("TrussPart")
			truss.Name = "Ladder"
			truss.Size = Vector3.new(2, height, 2)
			truss.CFrame = self.Origin * CFrame.new(0, -height / 2, -gap / 2)
			truss.Anchored = true
			truss.CanCollide = true
			truss.Color = RUST_DARK
			truss.Material = METAL
			truss.Parent = self.Inst
			self.Ladder = truss
			-- the doors far below
			self.HellY = -depth - HELL_BELOW
			local doorsAt = self.Origin * CFrame.new(0, self.HellY, self.CageZ)
			self.Doors = if doors then FX.RigFrom(doors, originOf(doors, doorsAt)) else FX.Rig(inst)
			self.Doors:Move(doorsAt)
			local glow = self.Doors:Get("Glow")
			if glow then
				self.HellLight = FX.Light(glow, FIRE, 40, 0.6)
				FX.Stream(glow, "Ember", { Color = EMBER, Rate = 6, Scale = 1.2 })
			end
			local fire = rig:Get("FireOuter")
			if fire then
				self.FireLight = FX.Light(fire, FIRE, 18, 1.4)
				FX.Stream(fire, "Ember", { Color = EMBER, Rate = 4, Scale = 0.7 })
			end
			rig:Fade(1)
			self.Fire = 0.5
			self.Erupts = {}
			self.Slammed, self.Snapped, self.Opened, self.Shut = false, false, false, false
			if self:Time() < 1 then
				FX.Sound("ChainRattle", self.Origin.Position, 0.8 * FX.Near(self.Origin.Position, 30, 200))
			end
			self:Keep(function()
				hellOff(self)
				if self.HellTint then
					self.HellTint.Remove(0.9)
				end
			end)
		end,

		-- (K.Call) somebody picked a floor: it sets off for floor n at `at` (seconds since T0) and takes `seconds`;
		-- from / to = the heights it rides between
		Go = function(self: any, n: number, at: number, seconds: number, from: number, to: number)
			self.Ride = { From = from, To = to, At = at, Time = seconds }
			self.Level = n
			if self:Time() < at + 1.5 then
				local spot = (self.Origin * CFrame.new(0, from, self.CageZ)).Position
				FX.Sound("PanelClunk", spot, FX.Near(spot, 20, 90))
				FX.Sound("CageGroan", spot, 0.7 * FX.Near(spot, 25, 140))
				FX.Burst(spot + UP * ((self.P.H or 8) + 0.5), "Dust", 10, { Color = DUST, Scale = 1.2 })
			end
		end,

		-- (K.Signal) it came to rest at floor k: the fire in the brazier flares
		Stop = function(self: any, k: number)
			self.Level = k
			self.FlareAt = self:Time()
			local fire = self.Cage:Get("FireOuter")
			if fire then
				FX.Burst(fire.Position, "Ember", 12, { Color = EMBER, Scale = 1 })
				FX.Sound("FireRoar", fire.Position, 0.6 * FX.Near(fire.Position, 25, 120))
			end
		end,

		-- (K.Call) the trap: shutters slam at `at` (seconds since T0); grabber = who took the relic (0 = nobody)
		Trap = function(self: any, at: number, grabber: number, _tier: number)
			self.TrapAt = at
			self.Grabber = grabber
			if grabber ~= 0 then
				-- it was taken: nothing stands in the fire any more
				self.Burning = "Nothing"
				self.Cage:Hide("Relic", true)
				self.Cage:Hide("Fiddle", true)
			end
		end,

		-- (K.Signal) these players are in it
		Taken = function(self: any, ids: { number })
			for _, userId in ids do
				if FX.IsMe(userId) then
					FX.Shake(3, 16, 0.02, 0.6)
					FX.Pulse(Color3.fromRGB(40, 8, 4), 0.35, 0.5)
					blackout(self, 0.45)
				end
			end
		end,

		-- (K.Signal) that player is in hell until server time `untilTime`
		Hell = function(self: any, userId: number, untilTime: number)
			if not FX.IsMe(userId) then
				return
			end
			self.HellUntil = untilTime
			self.HellLong = math.max(untilTime - FX.Now(), 1)
			self:After(0.9, function()
				if not self.HellUntil then
					return
				end
				self.HellTint = self.HellTint or self:Tint()
				self.HellTint.To({ TintColor = Color3.fromRGB(255, 176, 140), Saturation = -0.25, Contrast = 0.15, Brightness = -0.05 }, 0.8)
				self:Vignette(0.3, 0.8, Color3.fromRGB(60, 10, 4))
				self.HellBanner = FX.Banner("THE HELLGATE", "Survive. Watch the floor.", EMBER)
			end)
		end,

		-- (K.Signal) that player is out of hell
		Out = function(self: any, userId: number)
			if FX.IsMe(userId) then
				hellOff(self)
			end
		end,

		-- (K.Signal) a patch of hell's floor at `spot` glows, and erupts at server time `at`
		Erupt = function(self: any, spot: Vector3, at: number)
			local me = FX.MyRoot()
			if not me or (me.Position - spot).Magnitude > 120 then
				return -- (only the people down there can see it)
			end
			local disc = FX.Disc(self.Inst, 0.5, spot, EMBER, 0.55, 0.15)
			table.insert(self.Erupts, { Disc = disc, Spot = spot, At = at - self.T0, Born = self:Time(), Done = false })
			FX.Sound("HellCrackle", spot, 0.5 * FX.Near(spot, 10, 60))
		end,

		-- (K.Strike) the eruption caught that player
		Hit = function(_self: any, userId: number)
			local root = FX.Root(userId)
			if not root then
				return
			end
			FX.Burst(root.Position, "Ember", 12, { Color = EMBER, Scale = 1 })
			if FX.IsMe(userId) then
				FX.Shake(2.5, 14, 0.03, 0.35)
				FX.Pulse(Color3.fromRGB(90, 30, 8), 0.45, 0.3)
			end
		end,

		Step = function(self: any, dt: number, t: number)
			local p = self.P
			local trapAt: number? = self.TrapAt
			local ride = self.Ride
			local y = liftY(p, t, ride, trapAt)
			local frame = self.Origin * CFrame.new(0, y, self.CageZ)
			local rig: FX.Rig = self.Cage
			local h: number = p.H or 8
			local level: number = self.Level
			local moving = not trapAt and t >= p.Arrive and ride.Time > 0 and t < ride.At + ride.Time

			-- out of the dark
			local fade = 1 - FX.Span(t, 0, 1.2)

			-- the panel: the button of the floor it is at glows; while it rides, the one it is going to blinks
			local lit = if trapAt or t < p.Arrive then 0 elseif moving and (t * 5) % 1 < 0.5 then 0 else level
			if lit ~= self.Lit then
				self.Lit = lit
				for index, button in self.Buttons do
					local on = index == lit
					button.Part.Color = if on then LIT else button.Color
					button.Part.Material = if on then Enum.Material.Neon else button.Material
				end
			end

			-- what burns on it: the relic, or (while it rests on the Devil's floor) his fiddle
			if not trapAt then
				local burning = if p.Devil and p.Devil ~= 0 and level == p.Devil and not moving and t >= p.Arrive then "Fiddle" else "Relic"
				if burning ~= self.Burning then
					self.Burning = burning
					rig:Hide("Fiddle", burning ~= "Fiddle")
					rig:Hide("Relic", burning ~= "Relic")
					FX.Burst(frame.Position + UP * (h + 2.4), "Fire", 14, { Color = FIRE, Scale = 1.2 })
				end
			end

			-- nobody took anything: for the last seconds before the shutters slam by themselves the cage shudders
			-- and its chains rattle, harder and harder
			local warn: number = p.Warn or 0
			if not trapAt and p.Last and warn > 0 and t > p.Last - warn then
				local how = FX.Span(t, p.Last - warn, p.Last)
				frame = frame * CFrame.new(FX.Noise(21, t * 14) * 0.07 * how, 0, 0) * CFrame.Angles(0, 0, math.rad(FX.Noise(22, t * 11) * 0.5 * how))
				if t >= (self.NextRattle or 0) then
					self.NextRattle = t + 1.1 - 0.7 * how
					FX.Sound("ChainRattle", frame.Position, (0.35 + 0.5 * how) * FX.Near(frame.Position, 25, 140), 1.6)
					FX.Burst(frame.Position + UP * (h + 0.5), "Dust", 6, { Color = DUST, Scale = 1 })
				end
			end

			-- the trap
			if trapAt then
				local since = t - trapAt
				local fresh = since < 1.5
				if not self.Slammed then
					self.Slammed = true
					rig:Hide("Shutter", false)
					if self.Door then
						self.Door.CanCollide = true
					end
					if fresh then
						FX.Sound("ShutterSlam", frame.Position, 1.1 * FX.Near(frame.Position, 30, 200))
						FX.Burst(frame.Position + UP * 2, "Dust", 16, { Color = DUST, Scale = 1.4 })
						FX.Shake(1.2, 14, 0.02, 0.3, frame.Position, 25, 120)
					end
				end
				-- the shutters drop into place in 0.12 s (from a cage's height above where the model has them)
				local drop = (1 - FX.Ease.In(math.min(since / 0.12, 1))) * h
				for index, rest in self.Shutters do
					rig:Pose("Shutter" .. index, CFrame.new(0, drop, 0) * rest)
				end
				if since >= p.Slam and not self.Snapped then
					self.Snapped = true
					if fresh then
						FX.Sound("ChainRattle", frame.Position, 1, 1.5)
						FX.Burst(frame.Position + UP * (h + 1), "Spark", 18, { Color = Color3.fromRGB(255, 180, 110), Scale = 1 })
					end
					rig:Hide("Chain", true)
				end
				-- the doors below grind open, swallow it, grind shut
				local fallDepth = liftY(p, trapAt, ride, nil) - self.HellY
				local through = p.Slam + math.sqrt(2 * math.max(fallDepth, 0) / p.Fall)
				local open = FX.Ease.Smooth(FX.Span(since, 0.2, 1.4)) * (1 - FX.Ease.Smooth(FX.Span(since, through + 0.5, through + 1.6)))
				if open > 0.05 and not self.Opened then
					self.Opened = true
					self.Doors:Hide("Crack", true)
					if fresh then
						FX.Sound("HellDoor", self.Origin.Position + UP * self.HellY, 1, 1)
					end
				end
				if since > through + 0.5 and not self.Shut then
					self.Shut = true
					if since < through + 2 then
						FX.Sound("HellDoor", self.Origin.Position + UP * self.HellY, 1, 0.8)
					end
				end
				local hw = (p.W or 10) / 2 + 1
				local angle = open * 1.45
				self.Doors:Pose("DoorL", CFrame.new(-hw, 0, 0) * CFrame.Angles(0, 0, -angle) * CFrame.new(hw / 2, 0, 0))
				self.Doors:Pose("DoorR", CFrame.new(hw, 0, 0) * CFrame.Angles(0, 0, angle) * CFrame.new(-hw / 2, 0, 0))
				for _, side in { "L", "R" } do
					local sign = if side == "L" then -1 else 1
					for index = 1, 3 do
						local z = (index - 2) * ((p.D or 8) / 3)
						self.Doors:Pose("Strap" .. side .. index, CFrame.new(sign * hw, 0, 0) * CFrame.Angles(0, 0, sign * angle) * CFrame.new(-sign * hw / 2, 0.35, z))
					end
				end
				if self.HellLight then
					self.HellLight.Brightness = 0.6 + open * 4
					self.HellLight.Range = 40 + open * 30
				end
				-- swallowed
				if y < self.HellY + 3 then
					fade = math.max(fade, FX.Span(-y, -self.HellY - 3, -self.HellY + 6))
				end
				self.Doors:Move(self.Origin * CFrame.new(0, self.HellY, self.CageZ))
			else
				local crack = self.Doors:Get("Crack")
				if crack then
					crack.Transparency = 0.35 + 0.25 * (FX.Noise(5, t * 2) + 1) / 2
				end
			end

			-- the fire on top: bigger every floor deeper
			local flare = if self.FlareAt then math.max(0, 1 - (t - self.FlareAt) / 0.6) else 0
			local want = 0.5 + 0.22 * (level - 1) + flare * 0.4
			self.Fire += (want - self.Fire) * math.min(dt * 4, 1)
			FX.Flicker(rig, "Fire", self.Fire, t, 11)
			if self.FireLight then
				self.FireLight.Brightness = (1.2 + self.Fire) * (1 + FX.Noise(9, t * 7) * 0.2)
			end
			rig:Fade(fade)
			rig:Move(frame)

			-- your time in hell
			local untilTime: number? = self.HellUntil
			if untilTime then
				local left = untilTime - FX.Now()
				local banner = self.HellBanner
				if banner then
					banner.Bar(math.clamp(left / self.HellLong, 0, 1))
					banner.Set("THE HELLGATE", "Survive " .. math.max(0, math.ceil(left)) .. "s. Watch the floor.")
				end
				if left <= -0.5 then
					hellOff(self)
				end
			end

			-- the floor of hell erupting
			for index = #self.Erupts, 1, -1 do
				local e = self.Erupts[index]
				if t < e.At then
					local grow = FX.Span(t, e.Born, e.At)
					FX.SetDisc(e.Disc, 0.5 + 4 * grow, e.Spot)
					e.Disc.Transparency = 0.6 - 0.35 * grow + FX.Noise(index, t * 12) * 0.08
				elseif not e.Done then
					e.Done = true
					e.Disc.Transparency = 0.2
					FX.Burst(e.Spot + UP, "Fire", 26, { Color = FIRE, Scale = 1.6 })
					FX.Burst(e.Spot + UP, "Ember", 18, { Color = EMBER, Scale = 1.2 })
					FX.Glint(e.Spot + UP * 2, FIRE, 22, 4, 0.5)
					FX.Sound("HellErupt", e.Spot, 0.8 * FX.Near(e.Spot, 15, 80))
				elseif t > e.At + 0.6 then
					e.Disc:Destroy()
					table.remove(self.Erupts, index)
				else
					e.Disc.Transparency = 0.2 + 0.8 * FX.Span(t, e.At, e.At + 0.6)
				end
			end
		end,

		Outro = function(self: any, _seconds: number?)
			-- (nothing: the doors below are the last thing that happens, and the visual goes with the event)
			hellOff(self)
		end,
	},
})
