-- ModuleScript: ReplicatedStorage > EventClients > gentlerain     (NEW: Oct 11 Update 21, Gentle Rain)
-- What Gentle Rain looks like on each client. The server (Events > GentleRain) does the healing and puts fires out;
-- this draws it:
--   THE RAIN    the model Rain under ServerScriptService > Events > GentleRain. Its Cloud (emitter Drops: thin dull
--               grey streaks) is kept over wherever YOU are looking, so it rains all round you; its Haze (emitter
--               Mist) drifts along the plates. Restyle the emitters there, keep the names.
--   RIPPLES     little rings where the drops hit the plates near you
--   THE GREY    your screen goes a little dull and grey while it rains (through your Utility, so it follows the
--               player's Settings) and clears again as the rain stops
--   HEALED      a faint sparkle on whoever the rain heals
--   FIRE OUT    a hiss and a puff of steam on whoever it put out
-- It comes in over FADE seconds and eases off over the last FADE seconds.
local Debris = game:GetService("Debris")
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not (FX.Tagged and FX.UseSounds and FX.SetEmitters) then
	warn("[gentlerain] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end

-- Sounds: paste your own ids into Id (the Stand ones are Roblox stand-ins)
--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	RainLoop = { Id = "", Stand = "rbxasset://sounds/action_falling.mp3", Speed = 0.6, Volume = 0.3 }, -- the rain (it loops while it falls)
	RainHiss = { Id = "", Stand = "rbxasset://sounds/impact_water.mp3", Speed = 1.6, Volume = 0.55 },  -- the rain puts a fire out
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

local AHEAD = 16          -- the rain is centred this many studs in front of your camera (where you are looking)
local ABOVE = 22          -- the drops fall from this high over your camera (never lower than this over the plates)
local SLANT = 7           -- degrees the rain leans (a breath of wind; 0 = straight down)
local FADE = 2.5          -- seconds it takes to come in, and to ease off at the end
local RIPPLES = 36        -- drops a second that may ripple round you (the ones that land on a plate do; 0 = none)
local RIPPLE_RANGE = 22   -- ... within this many studs of where you are looking
local GREY = { TintColor = Color3.fromRGB(222, 228, 236), Saturation = -0.25, Brightness = -0.04, Contrast = -0.05 }
local RIPPLE = Color3.fromRGB(196, 202, 210)
local STEAM = Color3.fromRGB(214, 218, 222)
local SPARKLE = Color3.fromRGB(196, 228, 204)

-- the rain's own looping sound (FX.Sound is for one-off sounds: it removes them after a few seconds)
local function startLoop(self: any)
	local entry = (FX.Sounds :: any).RainLoop
	if not (FX.Settings.Sounds and type(entry) == "table") then
		return
	end
	local id = tostring(entry.Id or "")
	if id:match("^%d+$") then
		id = "rbxassetid://" .. id
	end
	if id == "" then
		return
	end
	local sound = Instance.new("Sound")
	sound.Name = "RainLoop"
	sound.SoundId = id
	sound.Looped = true
	sound.Volume = 0
	sound.PlaybackSpeed = math.clamp(tonumber(entry.Speed) or 1, 0.1, 4)
	sound.Parent = self.Inst -- (in the model, not in a part: heard the same everywhere, and gone with the rain)
	sound:Play()
	self.Loop = sound
	self.LoopVolume = math.clamp((tonumber(entry.Volume) or 1) * FX.Settings.Volume, 0, 4)
end

-- puts the rain round the spot AHEAD studs in front of your camera. Returns that spot, the height the drops fall
-- from and the top of the plates
local function place(self: any): (Vector3, number, number)
	local top = tonumber(self.Props.Top) or self.Origin.Position.Y
	local camera = workspace.CurrentCamera
	local eye = if camera then camera.CFrame else CFrame.new(self.Origin.Position + Vector3.new(0, 12, 20))
	local ahead = eye.Position + FX.Dir(eye.LookVector) * AHEAD
	local cloudY = math.max(eye.Position.Y, top) + ABOVE
	local cloud: BasePart? = self.Cloud
	if cloud then
		cloud.CFrame = CFrame.new(ahead.X, cloudY, ahead.Z) * self.Lean
	end
	local haze: BasePart? = self.Haze
	if haze then
		haze.CFrame = CFrame.new(ahead.X, top + 2.5, ahead.Z)
	end
	return ahead, cloudY, top
end

-- a ripple where a drop hits a plate
local function ripple(parent: Instance, at: Vector3, rng: Random)
	local radius = rng:NextNumber(0.6, 1.1)
	local disc = FX.Cyl(parent, 0.2, 0.05, CFrame.new(at + Vector3.new(0, 0.03, 0)), RIPPLE, Enum.Material.SmoothPlastic, 0.45)
	disc.Name = "Ripple"
	FX.Tween(disc, { Size = Vector3.new(0.05, radius * 2, radius * 2), Transparency = 1 }, 0.45, "Quad", "Out")
	Debris:AddItem(disc, 0.6)
end

return FX.Module({
	Rain = {
		Init = function(self: any, _props: any)
			local inst: Instance = self.Inst
			local cloud = inst:FindFirstChild("Cloud")
			local haze = inst:FindFirstChild("Haze")
			self.Cloud = if cloud and cloud:IsA("BasePart") then cloud else nil
			self.Haze = if haze and haze:IsA("BasePart") then haze else nil
			-- every emitter's own Rate (as you set it in the model): the rain comes in and eases off from there
			self.Rates = {}
			for _, item in inst:GetDescendants() do
				if item:IsA("ParticleEmitter") then
					self.Rates[item] = item.Rate
					item.Rate = 0
				end
			end
			FX.SetEmitters(inst, true)
			self.Lean = CFrame.Angles(math.rad(SLANT), 0, math.rad(SLANT * 0.35))
			self.Grey = self:Tint()
			self.Rng = Random.new()
			self.Owed = 0
			-- the ripples only land on the plates (his workspace > Map > Plates)
			local map = workspace:FindFirstChild("Map")
			local plates = map and map:FindFirstChild("Plates")
			if plates then
				local params = RaycastParams.new()
				params.FilterType = Enum.RaycastFilterType.Include
				params.FilterDescendantsInstances = { plates }
				self.Ray = params
			end
			startLoop(self)
			place(self)
		end,

		Step = function(self: any, dt: number, t: number)
			local duration = tonumber(self.Props.Duration) or 15
			-- how hard it rains: it comes in over FADE seconds and eases off over the last FADE
			local strength = math.min(FX.Clamp01(t / FADE), FX.Clamp01((duration - t) / FADE))
			local ahead, cloudY, top = place(self)
			for emitter, rate in self.Rates do
				emitter.Rate = rate * strength
			end
			local loop: Sound? = self.Loop
			if loop then
				loop.Volume = self.LoopVolume * strength
			end
			-- the grey on your screen
			if not self.Greyed and t < duration - FADE then
				self.Greyed = true
				self.Grey.To(GREY, math.max(FADE - t, 0.3))
			end
			if not self.Clearing and t >= duration - FADE then
				self.Clearing = true
				self.Grey.Back(math.max(duration - t, 0.3))
			end
			-- ripples on the plates round you
			if RIPPLES > 0 and self.Ray then
				self.Owed += RIPPLES * strength * dt
				local rng: Random = self.Rng
				while self.Owed >= 1 do
					self.Owed -= 1
					local angle = rng:NextNumber(0, math.pi * 2)
					local reach = RIPPLE_RANGE * math.sqrt(rng:NextNumber())
					local from = Vector3.new(ahead.X + math.cos(angle) * reach, cloudY, ahead.Z + math.sin(angle) * reach)
					local hit = workspace:Raycast(from, Vector3.new(0, top - cloudY - 60, 0), self.Ray)
					if hit and hit.Normal.Y > 0.7 then
						ripple(self.Inst, hit.Position, rng)
					end
				end
			end
		end,

		-- the rain healed this player
		Healed = function(_self: any, userId: number)
			local root = FX.Root(userId)
			if root then
				FX.Burst(root.Position + Vector3.new(0, 0.6, 0), "Star", 3, { Color = SPARKLE, Scale = 0.5 })
			end
		end,

		-- the rain put this player's fire out
		Hiss = function(_self: any, userId: number)
			local root = FX.Root(userId)
			if not root then
				return
			end
			FX.Burst(root.Position, "Smoke", 12, { Color = STEAM, Scale = 0.9 })
			FX.Burst(root.Position + Vector3.new(0, 1, 0), "Mist", 3, { Color = STEAM, Scale = 0.4 })
			FX.Sound("RainHiss", root.Position)
			if FX.IsMe(userId) then
				FX.Pulse(Color3.fromRGB(170, 188, 206), 0.75, 0.3)
			end
		end,
	},
})
