-- ModuleScript: ReplicatedStorage > EventClients > moss     (NEW: Oct 12 Update 23, Moss Bloom)
-- What Moss Bloom looks like on each client. The server (Events > MossBloom) picks the plates and heals; this grows
-- the moss: the model Moss under ServerScriptService > Events > MossBloom (made for a 20 x 20 plate), stretched to
-- each plate's real size, every mat, tuft and little flower growing in one after the other from the middle out;
-- faint spores drift off it; it withers away at the end (or at once when its plate is destroyed). A faint sparkle on
-- whoever it heals. Restyle the model there; keep the name prefixes Patch / Tuft / Bloom and the part Spores.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not (FX.OnPlate and FX.UseSounds and FX.Tagged) then
	warn("[moss] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end

-- Sounds: paste your own ids into Id (Stand = a Roblox stand-in; "" = silence)
--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	MossGrow = { Id = "", Stand = "", Speed = 1, Volume = 0.5 }, -- the moss creeps over a plate
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

local PIECE_TIME = 0.9      -- seconds one piece takes to grow in
local FADE = 2              -- seconds it takes to wither away at the end
local SPARKLE = Color3.fromRGB(176, 230, 150)
local MADE_FOR = 20         -- the model is made for a plate this wide

return FX.Module({
	Moss = {
		Init = function(self: any, props: any)
			local grow = tonumber(props.Grow) or 2.5
			local rng = Random.new(tonumber(props.Seed) or 1)
			local inverse = self.Origin:Inverse()
			self.Pieces = {}
			for _, part in self.Inst:GetChildren() do
				if part:IsA("BasePart") and part.Name ~= "Root" and part.Name ~= "Spores" then
					local offset = inverse * part.CFrame
					local reach = Vector3.new(offset.X, 0, offset.Z).Magnitude
					local delay = math.clamp(reach / 9, 0, 1) * grow * 0.75 + rng:NextNumber(0, 0.25)
					if string.sub(part.Name, 1, 4) ~= "Patc" then
						delay += grow * 0.25 -- (tufts and flowers come after the mats)
					end
					table.insert(self.Pieces, { Part = part, Offset = offset, Size = part.Size, Transparency = part.Transparency, Delay = delay })
					part.Transparency = 1
				end
			end
			local spores = self.Inst:FindFirstChild("Spores", true)
			self.Spores = if spores and spores:IsA("ParticleEmitter") then spores else nil
			if self.Spores then
				self.Spores.Enabled = false
			end
			FX.Sound("MossGrow", self.Origin.Position)
		end,

		Step = function(self: any, dt: number, t: number)
			local plate = self.Plate
			if not plate then
				local found = FX.Tagged(self.Props.Tag)
				if found and found:IsA("BasePart") then
					plate = found
					self.Plate = found
				end
			end
			local duration = tonumber(self.Props.Duration) or 20
			local alive = 1 - FX.Clamp01((t - (duration - FADE)) / FADE)
			-- (its plate was destroyed: it withers at once)
			if self.Seen and (not plate or not plate.Parent) then
				self.GoneAt = self.GoneAt or t
				alive = math.min(alive, 1 - FX.Clamp01((t - self.GoneAt) / 0.5))
			end
			local top: CFrame = self.Top or self.Origin
			local sx, sz = 1, 1
			if plate and plate.Parent then
				self.Seen = true
				top = plate.CFrame * CFrame.new(0, plate.Size.Y / 2, 0)
				self.Top = top
				sx, sz = plate.Size.X / MADE_FOR, plate.Size.Z / MADE_FOR
			end
			local spread = (sx + sz) / 2
			for _, piece in self.Pieces do
				local grown = FX.Ease.Out(FX.Clamp01((t - piece.Delay) / PIECE_TIME))
				local part: BasePart = piece.Part
				if grown <= 0 or alive <= 0 then
					part.Transparency = 1
				else
					local o: CFrame = piece.Offset
					local size: Vector3 = piece.Size
					part.Size = Vector3.new(size.X * grown * spread, math.max(size.Y * grown, 0.05), size.Z * grown * spread)
					part.CFrame = top * CFrame.new(o.X * sx, o.Y * grown, o.Z * sz) * (o - o.Position)
					part.Transparency = piece.Transparency + (1 - piece.Transparency) * (1 - alive)
				end
			end
			local spores = self.Spores
			if spores then
				local on = t > (tonumber(self.Props.Grow) or 2.5) and alive > 0.5 and not FX.Off("DisableParticles")
				if spores.Enabled ~= on then
					spores.Enabled = on
				end
				if on and spores.Parent and spores.Parent:IsA("BasePart") then
					spores.Parent.CFrame = top * CFrame.new(0, 0.4, 0)
				end
			end
		end,

		-- the moss healed this player
		Healed = function(_self: any, userId: number)
			local root = FX.Root(userId)
			if root then
				FX.Burst(root.Position - Vector3.new(0, 2.2, 0), "Star", 3, { Color = SPARKLE, Scale = 0.5 })
			end
		end,
	},
})
