-- ModuleScript: ReplicatedStorage > EventClients > mimic     (NEW, Oct 10 2026 update 10)
-- (New script: Mimic Plate was built part by part on the server; it is drawn here now, from a model.)
-- What a Mimic Plate's bite looks like on each client: the model Jaws under ServerScriptService > Events >
-- MimicPlate. Nothing is shown before somebody steps on a mimic. Then a copy of the plate's top, cut in two right
-- under their feet, swings up on both sides and slams shut on them like a book with fangs ("fold in on itself").
-- The real plate is never touched. A moment later the jaws fold back down and are gone.
-- The model is made for a 20 x 20 plate with the cut through the middle. Here the cut is put under the player, so
-- the two pieces are stretched: the parts named Slab and Gum are resized, everything else (the teeth) keeps its
-- size and stays at its piece's far edge. Restyle the model as you like, keep those two names and the groups A / B.
-- The two Slabs take the real plate's colour and material.
-- The server (Events > MimicPlate) decides who is bitten.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))

-- YOUR SOUNDS: put an id in Id. While Id is "" the built-in Roblox sound in Stand plays ("" = silence).
--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	MimicCrack = { Id = "", Stand = "rbxasset://sounds/action_get_up.mp3", Speed = 0.6, Volume = 0.8 },     -- the plate splits under you
	MimicChomp = { Id = "", Stand = "rbxasset://sounds/action_jump_land.mp3", Speed = 0.42, Volume = 1.5 }, -- the jaws slam shut
	MimicOpen = { Id = "", Stand = "", Speed = 1, Volume = 1 },                                             -- they fold back down
}
--[[DMP:END]]
FX.UseSounds(SOUNDS)

local C = FX.Colors
local STONE = Color3.fromRGB(96, 92, 100)
local TOOTH = Color3.fromRGB(226, 216, 190)
local BUILT_WIDE, BUILT_LONG = 10, 20 -- the model: each jaw is 10 wide (hinge to far edge) and 20 long
local SHUT_GAP = 0.45                 -- how far a jaw's far edge stays from the middle when shut, in tooth lengths
local CHEW = 0.035                    -- how much the shut jaws grind (0 = they stay still)
local STRETCH = { Slab = true, Gum = true }

type Piece = { Part: BasePart, Offset: CFrame, Stretch: boolean, Shown: number }
type Jaw = { Pieces: { Piece }, Width: number, Frame: CFrame, Shut: number, Shrink: number }

-- puts one jaw's pieces where they belong when it is swung up by `angle`
local function place(jaw: Jaw, angle: number, long: number, fade: number)
	local hinge = jaw.Frame * CFrame.Angles(0, 0, angle)
	local wide = jaw.Width / BUILT_WIDE
	local shrink = jaw.Shrink
	for _, piece in jaw.Pieces do
		local at: Vector3 = piece.Offset.Position
		local where: CFrame
		if piece.Stretch then
			where = hinge * CFrame.new(at.X * wide, at.Y, at.Z * long)
		else
			-- (the teeth: as far from this jaw's far edge as they were made)
			where = hinge * CFrame.new(jaw.Width - (BUILT_WIDE - at.X) * shrink, at.Y * shrink, at.Z * long)
		end
		piece.Part.CFrame = where * piece.Offset.Rotation
		piece.Part.Transparency = piece.Shown + (1 - piece.Shown) * fade
	end
end

return FX.Module({
	Jaws = {
		Init = function(self: any, props: any)
			local inst: Instance = self.Inst
			local root = inst:FindFirstChild("Root")
			local rootFrame: CFrame = if root and root:IsA("BasePart") then root.CFrame else self.Origin
			local size: Vector3 = if typeof(props.Size) == "Vector3" then props.Size else Vector3.new(20, 1, 20)
			local alongX = props.Along == "X"
			local offset: number = tonumber(props.At) or 0
			local half = (if alongX then size.Z else size.X) / 2 -- across the hinge
			local long = (if alongX then size.X else size.Z) / BUILT_LONG
			-- the hinge: its X axis points across it (toward jaw A), its Z axis runs along it
			local base: CFrame = self.Origin * (if alongX then CFrame.new(0, 0, offset) * CFrame.Angles(0, -math.pi / 2, 0) else CFrame.new(offset, 0, 0))
			self.Long = long
			self.Hinge = base
			local jaws: { Jaw } = {}
			for index, name in { "A", "B" } do
				local side = if index == 1 then 1 else -1
				local turn = if side == 1 then CFrame.new() else CFrame.Angles(0, math.pi, 0)
				local width = math.max(half - side * offset, 0.2)
				local shrink = math.clamp(math.min(width / 6, long), 0.35, 1) -- (a narrow jaw, or a small plate: smaller teeth)
				local pieces: { Piece } = {}
				local tooth = 0
				local group = inst:FindFirstChild(name)
				if not group then
					FX.WarnOnce("mimicjaws", "the model 'Jaws' under ServerScriptService > Events > MimicPlate has no group '" .. name .. "' (install the update again): the bite is invisible")
				end
				for _, part in (if group then group:GetChildren() else {}) do
					if part:IsA("BasePart") and part.Name ~= "Root" then
						local stretch = STRETCH[part.Name] == true
						local made: Vector3 = part.Size
						if stretch then
							part.Size = Vector3.new(made.X * width / BUILT_WIDE, made.Y, made.Z * long)
						else
							part.Size = made * shrink
							tooth = math.max(tooth, made.Y * shrink)
						end
						if part.Name == "Slab" then
							if typeof(props.Color) == "Color3" then
								part.Color = props.Color
							end
							if typeof(props.Material) == "EnumItem" then
								part.Material = props.Material
							end
						end
						table.insert(pieces, { Part = part, Offset = (rootFrame * turn):ToObjectSpace(part.CFrame), Stretch = stretch, Shown = part.Transparency })
					end
				end
				-- it swings up until its far edge is SHUT_GAP tooth lengths from the middle: the fangs reach across
				local shut = math.acos(math.clamp(SHUT_GAP * math.max(tooth, 1) / width, 0.03, 0.75))
				local jaw: Jaw = { Pieces = pieces, Width = width, Frame = base * turn, Shut = shut, Shrink = shrink }
				table.insert(jaws, jaw)
				place(jaw, 0, long, 0)
			end
			self.Jaws = jaws
			self.Bit, self.Opened = false, false
			-- the stone splits along the hinge
			local spot: Vector3 = base.Position
			FX.Sound("MimicCrack", spot, FX.Near(spot, 16, 70))
			for step = -1, 1 do
				FX.Chunks((base * CFrame.new(0, 0.4, step * 6 * long)).Position, 2, { STONE, Color3.fromRGB(70, 66, 74) }, { Size = 0.6, Speed = 9, Up = 16, Life = 0.8 })
			end
		end,

		-- (K.Strike) the server bit this player. (No ring, no red: chips of tooth and stone.)
		Hit = function(_self: any, userId: number)
			local root = FX.Root(userId)
			if not root then
				return
			end
			FX.Burst(root.Position, "Dust", 6, { Color = STONE, Scale = 1.1 })
			FX.Chunks(root.Position, 4, { TOOTH, STONE }, { Size = 0.45, Speed = 10, Up = 14, Life = 0.7 })
			if FX.IsMe(userId) then
				FX.Shake(1.5, 15, 0.02, 0.3)
				FX.Pulse(C.Blood, 0.55, 0.25)
			end
		end,

		Step = function(self: any, _dt: number, t: number)
			local p = self.Props
			local snap: number, hold: number, open: number = p.Snap or 0.22, p.Hold or 0.7, p.Open or 0.5
			local spot: Vector3 = self.Hinge.Position
			-- 0 = lying flat on the plate, 1 = shut
			local shut: number
			local fade = 0
			if t < snap then
				shut = FX.Ease.In(t / snap)
			elseif t < snap + hold then
				local since = t - snap
				shut = 1 - CHEW * math.abs(math.sin(since * 21)) * (1 - since / hold)
			else
				local since = (t - snap - hold) / open
				shut = 1 - FX.Ease.Smooth(since / 0.75)
				fade = FX.Clamp01((since - 0.55) / 0.45)
			end
			for _, jaw in self.Jaws do
				place(jaw, jaw.Shut * shut, self.Long, fade)
			end
			if t >= snap and not self.Bit then
				self.Bit = true
				if t < snap + 0.5 then
					local top: Vector3 = spot + Vector3.new(0, math.min(self.Jaws[1].Width, self.Jaws[2].Width) * 0.9, 0)
					FX.Sound("MimicChomp", spot, FX.Near(spot, 20, 100))
					FX.Burst(top, "Dust", 10, { Color = STONE, Scale = 1.5 })
					FX.Burst(spot + Vector3.new(0, 1, 0), "Dust", 6, { Color = STONE, Scale = 1.2 })
					FX.Shake(1.2, 15, 0.02, 0.25, spot, 12, 45)
				end
			end
			if t >= snap + hold and not self.Opened then
				self.Opened = true
				FX.Sound("MimicOpen", spot, FX.Near(spot, 16, 70))
			end
		end,
	},
})
