-- ModuleScript: ReplicatedStorage > EventClients > bridges     (REPLACE)
-- What Bone Bridges looks like on each client.
-- Oct 10 2026 (update 9): every bridge is a copy of YOUR normal Bone Bridge model (ServerScriptService > Events >
-- BoneBridge > Bridge, which the game copies to ReplicatedStorage > EventAssets > bridge), sized to the gap exactly
-- the way the Bone Bridge event sizes it. It rises out of the void, shakes harder and harder before it goes (no
-- red flashing any more), and falls away. Restyle that one model and both events change.
-- The server (Events > BoneBridges) makes the invisible deck you stand on and decides when they fall.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not (FX.Clone) then
	warn("[bridges] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end

local C = FX.Colors
local RISE_FROM = 8      -- studs below its place a bridge starts
local SHAKE_NEAR = 110   -- bridges farther than this from your camera do not bother to shake

return FX.Module({
	Bridge = {
		Init = function(self: any, props: any)
			-- self.Origin: the middle of the deck, -Z runs along the bridge (the pivot of your model is its Deck)
			self.Model = nil
			if props.Model ~= false then
				local model = FX.Clone("bridge", "Bridge", self.Inst)
				if model then
					local ok = pcall(function()
						model:ScaleTo(model:GetScale() * (props.Scale or 1))
					end)
					if ok then
						self.Model = model
						model:PivotTo(self.Origin * CFrame.new(0, -RISE_FROM, 0))
					else
						model:Destroy()
					end
				end
			end
			self.Fell, self.Settled, self.Creaked = false, false, false
		end,

		Step = function(self: any, _dt: number, t: number)
			local model: Model? = self.Model
			if not model then
				return
			end
			local p = self.Props
			local rise: number, life: number, warn: number = p.Rise or 0.8, p.Life or 24, p.Warn or 3
			local origin: CFrame = self.Origin
			if t >= life then
				-- it goes: down into the void, tipping over as it falls
				local fall = t - life
				if not self.Fell then
					self.Fell = true
					if fall < 0.6 then
						FX.Chunks(origin.Position + Vector3.new(0, 1.5, 0), 6, C.Bone, { Size = 1.1, Speed = 10, Up = 12, Life = 1.2 })
						FX.Sound("Thud", origin.Position, 0.9 * FX.Near(origin.Position, 20, 100), 0.9)
					end
				end
				if fall < 1.4 then
					model:PivotTo(origin * CFrame.new(0, -38 * fall * fall, 0) * CFrame.Angles(fall * 0.9, 0, fall * 0.5))
				elseif not self.Gone then
					self.Gone = true
					model:Destroy()
					self.Model = nil
				end
				return
			end
			local shaking = FX.Span(t, life - warn, life) -- 0..1 over the warning
			if t > rise + 0.1 and shaking <= 0 then
				-- nothing moves between the moment it has settled and the moment it starts to shake
				if not self.Settled then
					self.Settled = true
					model:PivotTo(origin)
				end
				return
			end
			self.Settled = false
			if shaking > 0 then
				if not self.Creaked then
					self.Creaked = true
					FX.Sound("Shuffle", origin.Position, 0.7 * FX.Near(origin.Position, 16, 80), 0.7)
				end
				if FX.Near(origin.Position, SHAKE_NEAR * 0.5, SHAKE_NEAR) <= 0 then
					return
				end
				local jitter = shaking * shaking * 0.3
				model:PivotTo(origin * CFrame.new(FX.Noise(3, t * 26) * jitter, FX.Noise(4, t * 26) * jitter - shaking * 0.25, 0) * CFrame.Angles(0, 0, FX.Noise(5, t * 20) * jitter * 0.12))
				return
			end
			-- rising out of the void (it overshoots a little, like the Bone Bridge)
			model:PivotTo(origin * CFrame.new(0, -RISE_FROM * (1 - FX.Ease.Back(t / rise)), 0))
		end,
	},
})
