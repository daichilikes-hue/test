-- ModuleScript: ReplicatedStorage > EventClients > tree     (Oct 11 Update 14: your tree model, the dread)
-- Client visuals for Cursed Tree.
--   THE TREE    your model ReplicatedStorage > Assets > CursedTreeModel, cloned and stood on the plate by the bottom of
--               its part named Trunk (the model's own pivot is not used, it is tilted). It tears up out of the plate.
--               No circle on the ground: a low mist drifts round its foot, with no edge. (No CursedTreeModel there:
--               the old tree built from parts, and one warning in Output.)
--   THE DREAD   only on YOUR screen, the longer you stay in a tree's reach: your Vignette closes in, the colour drains,
--               the world goes darker, a little blur, and a heartbeat that speeds up. When it has you (5 seconds, the
--               server's TurnAfter) it CLICKS: a jolt, and it stays dark while you turn to wood. Step away in time and
--               it fades back. Everything through ReplicatedStorage > Utility, so your Settings switches count.
local Lighting = game:GetService("Lighting")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local FX = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not FX.UseSounds then
	warn("[tree] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end
local Utility: any = nil
do
	local module = ReplicatedStorage:FindFirstChild("Utility")
	if module and module:IsA("ModuleScript") then
		local ok, result = pcall(require, module)
		if ok then
			Utility = result
		end
	end
end

-- YOUR SOUNDS: put an id in Id. While Id is "" the built-in Roblox sound in Stand plays ("" = silence).
--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	TreeGrow = { Id = "", Stand = "rbxasset://sounds/action_get_up.mp3", Speed = 0.3, Volume = 1.2 },    -- the tree tearing up out of the plate
	Heartbeat = { Id = "", Stand = "rbxasset://sounds/action_jump_land.mp3", Speed = 0.3, Volume = 0.7 }, -- (only you) your heart, faster the longer you stay
	TreeSnap = { Id = "", Stand = "rbxasset://sounds/action_jump_land.mp3", Speed = 0.55, Volume = 1.4 }, -- (only you) the moment it has you
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

-- HOW BAD THE DREAD GETS at its worst (when it has you). It grows smoothly from nothing.
--[[DMP:KEEP Settings]]
local TREE_SCALE = 1      -- your CursedTreeModel at this size (1 = as you made it; small trees are smaller again: SmallScale)
local VIGNETTE = 0.6      -- how far your Vignette closes in (0 = not at all, 1 = black)
local DARKEN = 0.16       -- how much darker the world gets
local DRAIN = 0.45        -- how much colour drains out
local BLUR = 6            -- a little blur
--[[DMP:END]]
local DREAD_COLOR = Color3.fromRGB(22, 8, 30)     -- the vignette's colour: a very dark purple
local DREAD_TINT = Color3.fromRGB(205, 190, 225)  -- the world takes a faint sickly purple
local MODEL_NAME = "CursedTreeModel"

local Client = {}
local localPlayer = Players.LocalPlayer
local warned = false
local dread: any
local clearDread: (number) -> ()
local snap: () -> ()
local stepDread: (number) -> ()

local BARK = Color3.fromRGB(46, 33, 30)
local BARK_DARK = Color3.fromRGB(30, 22, 22)
local LEAF = Color3.fromRGB(58, 36, 70)
local EVIL = Color3.fromRGB(255, 60, 70)

local function add(parent: Instance, props): Part
	local part = Instance.new("Part")
	part.Name = props.Name
	part.Shape = props.Shape or Enum.PartType.Block
	part.Size = props.Size
	part.CFrame = props.CFrame
	part.Color = props.Color or BARK
	part.Material = props.Material or Enum.Material.Wood
	part.Transparency = props.Transparency or 0
	part.Anchored = true
	part.CanCollide = false
	part.CanQuery = false
	part.CanTouch = false
	part.CastShadow = false
	part.Parent = parent
	return part
end

local function ball(parent: Instance, name: string, diameter: number, position: Vector3, color: Color3, material: Enum.Material?): Part
	return add(parent, {
		Name = name,
		Shape = Enum.PartType.Ball,
		Size = Vector3.new(diameter, diameter, diameter),
		CFrame = CFrame.new(position),
		Color = color,
		Material = material,
	})
end

-- A cylinder running from point a to point b
local function rod(parent: Instance, name: string, a: Vector3, b: Vector3, thick: number, color: Color3, material: Enum.Material?): Part
	local length = (b - a).Magnitude
	local direction = (b - a).Unit
	local cframe
	if math.abs(direction.Y) > 0.999 then
		cframe = CFrame.new((a + b) / 2) * CFrame.Angles(0, 0, math.rad(90))
	else
		cframe = CFrame.lookAt((a + b) / 2, b) * CFrame.Angles(0, math.rad(90), 0)
	end
	return add(parent, {
		Name = name,
		Shape = Enum.PartType.Cylinder,
		Size = Vector3.new(length, thick, thick),
		CFrame = cframe,
		Color = color,
		Material = material,
	})
end

---------------------------------------------------------------- THE DREAD (your own screen only)
dread = { Target = 0, Value = 0, Has = false, Updated = 0, Pulse = 0, LastBeat = 0, Vignette = 1, VignetteAt = 0, Color = nil :: any, Blur = nil :: BlurEffect?, On = false, Warned = false }

function clearDread(time: number)
	dread.Target = 0
	dread.Value = 0
	dread.Has = false
	dread.Pulse = 0
	if dread.On then
		dread.On = false
		if Utility then
			pcall(Utility.HideVignette, time)
		end
		dread.Vignette = 1
	end
	local handle = dread.Color
	dread.Color = nil
	if handle then
		pcall(function()
			handle:Reset(time)
			handle:Destroy(time + 0.1)
		end)
	end
	local blur = dread.Blur
	dread.Blur = nil
	if blur then
		blur:Destroy()
	end
end

-- the click: it has you
function snap()
	FX.Sound("Heartbeat", nil, 1.4, 1.3)
	FX.Sound("TreeSnap")
	dread.Pulse = 0.35
	if Utility then
		pcall(Utility.Shake, 2.2, 14, 0.02, 0.45)
	end
end

function stepDread(dt: number)
	-- (no word from the server for a while = it is over for you)
	if os.clock() - dread.Updated > 1.5 then
		dread.Target = 0
		dread.Has = false
	end
	local target = dread.Target
	local rate = if target > dread.Value then 3 else 2
	dread.Value += (target - dread.Value) * math.min(1, dt * rate)
	if target <= 0 and dread.Value < 0.01 then
		if dread.On or dread.Color or dread.Blur then
			clearDread(0.5)
		end
		return
	end
	local v = dread.Value
	-- a heartbeat that speeds up: each beat darkens it for a moment
	local now = os.clock()
	if v > 0.12 then
		local gap = 1.15 - 0.75 * v
		if now - dread.LastBeat >= gap then
			dread.LastBeat = now
			dread.Pulse = math.max(dread.Pulse, 0.08 + 0.1 * v)
			FX.Sound("Heartbeat", nil, 0.35 + 0.8 * v, 1 + 0.25 * v)
		end
	end
	dread.Pulse = math.max(0, dread.Pulse - dt * 1.2)
	local shown = math.clamp(v + dread.Pulse, 0, 1.3)
	if not Utility then
		return
	end
	dread.On = true
	-- your Vignette closes in (tweened, so only when it really changes)
	local vignette = 1 - VIGNETTE * math.clamp(shown, 0, 1)
	if math.abs(vignette - dread.Vignette) > 0.02 or now - dread.VignetteAt > 0.5 then
		dread.Vignette = vignette
		dread.VignetteAt = now
		pcall(Utility.ShowVignette, vignette, 0.18, DREAD_COLOR)
	end
	-- the world goes darker and loses its colour (nothing when tinting is switched off)
	if not dread.Color then
		dread.Color = Utility.ColorCorrection(nil)
	end
	local effect = dread.Color and dread.Color.Effect
	if effect and effect.Parent then
		effect.Brightness = -DARKEN * shown
		effect.Saturation = -DRAIN * shown
		effect.Contrast = 0.08 * shown
		effect.TintColor = Color3.new(1, 1, 1):Lerp(DREAD_TINT, math.clamp(shown, 0, 1))
	end
	-- a little blur (nothing when post effects are switched off)
	if BLUR > 0 and Utility.CanPostEffects and Utility.CanPostEffects() then
		if not dread.Blur then
			local blur = Instance.new("BlurEffect")
			blur.Name = "CursedTreeBlur"
			blur.Size = 0
			blur.Parent = Lighting
			dread.Blur = blur
		end
		dread.Blur.Size = BLUR * math.clamp(shown, 0, 1.2)
	end
end

local function light(parent: Instance, color: Color3, range: number, brightness: number)
	local l = Instance.new("PointLight")
	l.Color = color
	l.Range = range
	l.Brightness = brightness
	l.Parent = parent
end

local function emitter(parent: Instance, props): ParticleEmitter
	local e = Instance.new("ParticleEmitter")
	for key, value in props do
		(e :: any)[key] = value
	end
	e.Parent = parent
	return e
end

-- the lowest point of a part (it may be turned)
local function bottomOf(part: BasePart): number
	local cf, half = part.CFrame, part.Size / 2
	return cf.Position.Y - (math.abs(cf.RightVector.Y) * half.X + math.abs(cf.UpVector.Y) * half.Y + math.abs(cf.LookVector.Y) * half.Z)
end
local function topOf(part: BasePart): number
	local cf, half = part.CFrame, part.Size / 2
	return cf.Position.Y + (math.abs(cf.RightVector.Y) * half.X + math.abs(cf.UpVector.Y) * half.Y + math.abs(cf.LookVector.Y) * half.Z)
end

-- HIS TREE: a clone of ReplicatedStorage > Assets > CursedTreeModel with an upright Root at the bottom of its trunk
local function hisTree(): Model?
	local assets = ReplicatedStorage:FindFirstChild("Assets")
	local source = assets and assets:FindFirstChild(MODEL_NAME)
	if not (source and source:IsA("Model")) then
		return nil
	end
	local model = source:Clone()
	model.Name = "CursedTree"
	local parts = {}
	for _, item in model:GetDescendants() do
		if item:IsA("BasePart") then
			table.insert(parts, item)
			item.CastShadow = true
		end
	end
	if #parts == 0 then
		model:Destroy()
		return nil
	end
	-- where it stands: the bottom of the part named Trunk (else of the whole model), under the middle of that part
	local trunk = model:FindFirstChild("Trunk", true)
	local footY, footXZ = math.huge, nil
	if trunk and trunk:IsA("BasePart") then
		footY = bottomOf(trunk)
		footXZ = trunk.Position
	else
		local sum = Vector3.zero
		for _, part in parts do
			footY = math.min(footY, bottomOf(part))
			sum += part.Position
		end
		footXZ = sum / #parts
	end
	local top = -math.huge
	for _, part in parts do
		top = math.max(top, topOf(part))
	end
	local root = Instance.new("Part")
	root.Name = "Root"
	root.Size = Vector3.new(1, 0.2, 1)
	root.Transparency = 1
	root.CanCollide = false
	root.CanQuery = false
	root.CanTouch = false
	root.Anchored = true
	root.CFrame = CFrame.new(footXZ.X, footY, footXZ.Z) -- (upright: his model's own pivot is tilted)
	root.Parent = model
	model.PrimaryPart = root
	local scale = 1
	if TREE_SCALE ~= 1 and TREE_SCALE > 0 then
		scale = TREE_SCALE
		model:ScaleTo(model:GetScale() * TREE_SCALE) -- (relative: his model is already scaled in Studio)
	end
	model:SetAttribute("TreeHeight", math.max((top - footY) * scale, 4))
	return model
end

-- the old tree, built from parts (only when his model is missing)
local function partsTree(): Model
	local model = Instance.new("Model")
	model.Name = "CursedTree"
	-- Unrotated invisible PrimaryPart at the ground, so PivotTo never turns the tree sideways
	local root = add(model, { Name = "Root", Size = Vector3.new(1, 0.2, 1), CFrame = CFrame.new(), Transparency = 1 })
	model.PrimaryPart = root

	-- Twisted trunk
	local points = { Vector3.new(0, 0, 0), Vector3.new(0.9, 7, 0.3), Vector3.new(-0.7, 14, -0.3), Vector3.new(0.4, 21, 0.5) }
	local thick = { 5.4, 4.4, 3.4 }
	for i = 1, #points - 1 do
		rod(model, "Trunk", points[i], points[i + 1], thick[i], BARK_DARK)
		ball(model, "Knot", thick[i], points[i + 1], BARK_DARK, Enum.Material.Wood)
	end

	-- Roots flaring out of the base
	for i = 1, 6 do
		local angle = (i / 6) * math.pi * 2
		local dir = Vector3.new(math.cos(angle), 0, math.sin(angle))
		rod(model, "Root", dir * 0.8 + Vector3.new(0, 2.6, 0), dir * 6.5 + Vector3.new(0, 0.2, 0), 1.7, BARK_DARK)
	end

	-- Branches, canopy and hanging cursed fruit
	local top = Vector3.new(0.4, 19, 0.5)
	local tips = {
		Vector3.new(7, 26, 2), Vector3.new(-7, 25, -3), Vector3.new(3, 28, -6),
		Vector3.new(-4, 27, 6), Vector3.new(0, 31, 0.5), Vector3.new(9, 22, -4),
	}
	for index, tip in tips do
		rod(model, "Branch", top, tip, 1.3, BARK)
		ball(model, "Canopy", 7 + (index % 3) * 1.6, tip + Vector3.new(0, 1, 0), LEAF, Enum.Material.Fabric).Transparency = 0.1
		if index <= 5 then
			local hang = tip + Vector3.new(0, -2.2, 0)
			rod(model, "Vine", tip, hang, 0.2, BARK_DARK)
			local fruit = ball(model, "Fruit", 1.1, hang + Vector3.new(0, -0.6, 0), EVIL, Enum.Material.Neon)
			light(fruit, EVIL, 10, 1)
		end
	end

	-- A face on the trunk (front is -Z)
	for _, side in { -1, 1 } do
		local eye = ball(model, "Eye", 0.9, Vector3.new(side * 0.95, 11.6, -2.0), EVIL, Enum.Material.Neon)
		light(eye, EVIL, 14, 1.5)
	end
	add(model, { Name = "Mouth", Size = Vector3.new(2.4, 0.55, 0.5), CFrame = CFrame.new(0, 9.9, -2.15), Color = Color3.fromRGB(10, 6, 6) })
	for x = -0.8, 0.8, 0.8 do
		add(model, { Name = "Tooth", Size = Vector3.new(0.22, 0.5, 0.12), CFrame = CFrame.new(x, 10.1, -2.4), Color = Color3.fromRGB(235, 225, 200), Material = Enum.Material.SmoothPlastic })
	end

	-- Mist at the base, falling leaves, and a burst emitter used when the tree arms
	emitter(root, {
		Rate = 18,
		Lifetime = NumberRange.new(2, 3),
		Speed = NumberRange.new(0.5, 2),
		SpreadAngle = Vector2.new(180, 180),
		LightEmission = 0.2,
		Color = ColorSequence.new(Color3.fromRGB(120, 60, 160), Color3.fromRGB(30, 10, 45)),
		Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 4), NumberSequenceKeypoint.new(1, 10) }),
		Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.7), NumberSequenceKeypoint.new(1, 1) }),
		Acceleration = Vector3.new(0, 1.5, 0),
	})
	local canopy = model:FindFirstChild("Canopy") :: Part
	if canopy then
		emitter(canopy, {
			Rate = 6,
			Lifetime = NumberRange.new(3, 5),
			Speed = NumberRange.new(0.5, 1.5),
			SpreadAngle = Vector2.new(60, 60),
			Color = ColorSequence.new(Color3.fromRGB(90, 50, 110)),
			Size = NumberSequence.new(0.6),
			Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) }),
			Acceleration = Vector3.new(0, -4, 0),
			RotSpeed = NumberRange.new(-90, 90),
		})
	end
	local pulse = emitter(root, {
		Name = "Pulse",
		Enabled = false,
		Lifetime = NumberRange.new(0.6, 1),
		Speed = NumberRange.new(20, 35),
		SpreadAngle = Vector2.new(180, 20),
		LightEmission = 1,
		Color = ColorSequence.new(Color3.fromRGB(255, 90, 120), Color3.fromRGB(120, 20, 80)),
		Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 2), NumberSequenceKeypoint.new(1, 0) }),
	})
	pulse.Name = "Pulse"
	model:SetAttribute("TreeHeight", 32)
	return model
end

-- the mist at its foot (no edge) and the burst when it wakes: on the Root of either tree
local function addEffects(root: BasePart)
	if not root:FindFirstChild("Pulse") then
		emitter(root, {
			Name = "Pulse",
			Enabled = false,
			Lifetime = NumberRange.new(0.6, 1),
			Speed = NumberRange.new(20, 35),
			SpreadAngle = Vector2.new(180, 20),
			LightEmission = 1,
			Color = ColorSequence.new(Color3.fromRGB(150, 70, 190), Color3.fromRGB(40, 10, 50)),
			Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 2), NumberSequenceKeypoint.new(1, 0) }),
		})
	end
end

function Client.Build(_asset)
	local model = hisTree()
	if not model then
		if not warned then
			warned = true
			warn("[tree] ReplicatedStorage > Assets > " .. MODEL_NAME .. " is missing: the Cursed Tree uses the old tree made of parts.")
		end
		model = partsTree()
	end
	addEffects(model.PrimaryPart :: BasePart)
	return model
end

function Client.Spawned(inst: Model, state, props)
	state.Home = inst:GetPivot()
	state.Start = props.Start or workspace:GetServerTimeNow()
	state.Grow = props.Grow or 2
	state.Scale = props.Scale or 1
	state.Armed = false
	state.Main = props.Main == true -- (the first tree: it carries the dread)
	state.Height = (tonumber(inst:GetAttribute("TreeHeight")) or 32) * state.Scale
	if state.Scale ~= 1 then
		inst:ScaleTo(inst:GetScale() * state.Scale) -- (relative to the tree as it is)
	end

	-- NO circle: a low mist that drifts round its foot, thinning out with no edge (about its reach across)
	local position: Vector3 = props.Position or state.Home.Position
	local radius: number = props.Radius or 28
	local mist = Instance.new("Part")
	mist.Name = "TreeMist"
	mist.Size = Vector3.new(radius * 1.5, 0.4, radius * 1.5)
	mist.CFrame = CFrame.new(position + Vector3.new(0, 0.6, 0))
	mist.Transparency = 1
	mist.Anchored = true
	mist.CanCollide = false
	mist.CanQuery = false
	mist.CanTouch = false
	mist.CastShadow = false
	emitter(mist, {
		Rate = 10 + radius * 0.4,
		Lifetime = NumberRange.new(3, 5),
		Speed = NumberRange.new(0.3, 1.2),
		SpreadAngle = Vector2.new(180, 180),
		Texture = "rbxasset://textures/particles/smoke_main.dds",
		LightEmission = 0.05,
		Color = ColorSequence.new(Color3.fromRGB(70, 46, 84), Color3.fromRGB(24, 14, 30)),
		Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 5), NumberSequenceKeypoint.new(1, 11) }),
		Transparency = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.3, 0.82), NumberSequenceKeypoint.new(1, 1),
		}),
		Acceleration = Vector3.new(0, 0.4, 0),
		RotSpeed = NumberRange.new(-20, 20),
	})
	mist.Parent = inst
	state.Mist = mist
	FX.Sound("TreeGrow", position)
end

function Client.Render(inst: Model, state, base: CFrame, _dt)
	if not state.Home then
		return
	end
	local now = workspace:GetServerTimeNow()

	-- Grow out of the ground (by its whole height: it tears up through the plate)
	local grow = math.clamp((now - state.Start) / state.Grow, 0, 1)
	local eased = 1 - (1 - grow) ^ 3
	local height = state.Height or 32
	inst:PivotTo(base * CFrame.new(0, -height * (1 - eased), 0))
	if state.Mist then
		state.Mist.CFrame = CFrame.new(base.Position + Vector3.new(0, 0.6, 0)) -- (the mist stays on the plate)
	end

	if state.Main then
		local ok, err = pcall(stepDread, _dt)
		if not ok and not dread.Warned then
			dread.Warned = true
			warn("[tree] the dread: " .. tostring(err))
		end
	end
end

-- Server: Call(id, "Arm") when the aura goes live
function Client.Arm(inst: Model, state)
	state.Armed = true
	local root = inst.PrimaryPart
	local pulse = root and root:FindFirstChild("Pulse")
	if pulse and pulse:IsA("ParticleEmitter") then
		pulse:Emit(70)
	end
end

-- Server: Call(id, "Dread", { [UserId] = 0..1 (how far gone), 2 = it has you }) about 5 times a second, to the main tree
function Client.Dread(_inst: Model, state, payload)
	state.Main = true
	local mine = type(payload) == "table" and tonumber(payload[tostring(localPlayer.UserId)]) or 0
	dread.Updated = os.clock()
	if mine >= 2 then
		dread.Target = 1
		if not dread.Has then
			dread.Has = true
			snap()
		end
	else
		dread.Target = math.clamp(mine, 0, 1)
		dread.Has = false
	end
end

function Client.Destroyed(_inst: Model, state)
	if state.Main then
		clearDread(0.6)
	end
end

return Client