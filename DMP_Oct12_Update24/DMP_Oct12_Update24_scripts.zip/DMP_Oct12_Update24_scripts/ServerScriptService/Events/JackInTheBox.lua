-- ModuleScript: ServerScriptService > Events > JackInTheBox     (REPLACE)
-- Oct 10 2026 (update 8): the boxes are TRAPS now. A music box drops onto a plate and winds itself up; once it is
-- wound up it just sits there and does NOT go off by itself. The moment anybody steps near it (TRIGGER) it pops,
-- and the jack inside punches everyone standing close (RADIUS). They are smaller (SIZE) and a quarter as many
-- turn up (BETWEEN). A box nobody sets off simply fades when the event ends.
-- The box and the jack are a MODEL now ("Box", under this script): it is cloned, not built part by part.
-- This script decides the hits. What it looks like: ReplicatedStorage > EventClients > jackbox.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local SIZE = 0.6                   -- how big a box is (1 = the old size)
local TRIGGER = 5                  -- how near somebody has to come to set a wound-up box off
local RADIUS = 7                   -- how far the punch reaches (was 9)
local FUSE_MIN, FUSE_MAX = 3, 6    -- seconds a box takes to wind itself up after it lands
local BETWEEN = 9.6                -- seconds between boxes (was 2.4: a quarter as many)
local DAMAGE, PUSH, LIFT = 18, 55, 28
local DROP = 0.5                   -- seconds a box takes to land
local LINGER = 1.2                 -- seconds the jack bobs about after the pop
local ARMED_FOR = 4                -- a box is only sent if it will be wound up at least this long before the event ends

return {
	Name = "Jack-in-the-Box",
	Id = "jackbox",
	Weight = 1,
	Duration = 30,                 -- (was 24: the traps need time to sit and wait)
	Target = "Arena",
	Run = function(context: any)
		K.Start(context)
		local plates = K.Plates()
		if #plates == 0 then
			return
		end
		K.TellAll("Jack-in-the-Box!", "Once a box has wound itself up, it waits. Don't go near it!", K.Colors.Purple)
		local waiting: { [number]: boolean } = {} -- the boxes that have not gone off yet

		local function near(spot: Vector3, range: number): { Player }
			local list = {}
			K.Each(function(player, root, _, feetY)
				if K.Flat(root.Position - spot).Magnitude <= range and math.abs(feetY - spot.Y) <= 6 then
					table.insert(list, player)
				end
			end)
			return list
		end

		local function box()
			plates = K.Plates()
			local _, busy = K.Occupied(plates)
			local plate = (math.random() < 0.7 and K.Pick(busy)) or K.Pick(plates)
			if not (plate and plate.Parent) then
				return
			end
			local fuse = FUSE_MIN + math.random() * (FUSE_MAX - FUSE_MIN)
			if K.Elapsed(context) + DROP + fuse > context.Event.Duration - ARMED_FOR then
				return -- it would hardly be wound up before the event ends
			end
			local spot = K.PointOn(plate, 4)
			local now = K.Now()
			local id = K.Show(context, "Box", CFrame.new(spot) * CFrame.Angles(0, math.random() * math.pi * 2, 0), {
				T0 = now, Drop = DROP, Fuse = fuse, Radius = RADIUS, Linger = LINGER, Scale = SIZE,
			})
			if id == nil then
				return
			end
			waiting[id] = true
			if not K.WaitUntil(context, now + DROP + fuse) then
				return
			end
			-- wound up. It waits here until somebody comes near (or its plate goes, or the event ends).
			K.Call(context, id, "Armed")
			local victims: { Player } = {}
			while context.IsRunning() and plate.Parent and waiting[id] do
				victims = near(spot, TRIGGER)
				if #victims > 0 then
					break
				end
				task.wait(0.1)
			end
			if not waiting[id] then
				return -- (the event is ending: it has already been told to fade)
			end
			waiting[id] = nil
			if #victims == 0 or not context.IsRunning() then
				K.Hide(context, id)
				return
			end
			-- POP: everyone close to it gets punched, not just whoever set it off
			K.Call(context, id, "Pop", K.Now())
			for _, player in near(spot, RADIUS) do
				local root = K.Root(player)
				if root then
					K.Strike(context, id, player, DAMAGE, K.Dir(K.Flat(root.Position - spot)) * PUSH + Vector3.new(0, LIFT, 0), 0.4)
				end
			end
			K.Hide(context, id, LINGER + 0.6)
		end

		-- the boxes nobody set off bow out just before the event is over
		K.Outro(context, 1, function()
			for id in waiting do
				K.Signal(context, id, "Outro", 0.8)
			end
			table.clear(waiting)
		end)

		while context.IsRunning() do
			task.spawn(box)
			task.wait(BETWEEN)
		end
	end,
}
