-- ModuleScript: ServerScriptService > Events > StairwayOfSpirits     (REPLACE)
-- Ghostly steps wind up above one plate to a landing with a chest on it. A step fades away under whoever
-- stands on it (and comes back a few seconds later). The first player to open the chest gets its item and
-- some candles; then the stairway fades away.
-- Oct 10 2026 (update 8): a step no longer turns red before it goes: it simply fades to nothing, and much
-- faster (VANISH_AFTER). The chest is a NORMAL item chest now (K.Chest -> Systems > ItemCrates): same model,
-- same "hold E to open", same items as the ones that drop between events.
-- This script makes the steps you stand on (plain glowing slabs) and decides who gets the chest. The spirit
-- flames, the wisps and the light: ReplicatedStorage > EventClients > stairway.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local STEPS = 12
local RISE = 2.6            -- studs each step is higher than the one before
local RADIUS = 7            -- the stairs wind around the plate's middle
local TURN = math.rad(40)   -- how far round each step is from the one before
local VANISH_AFTER = 0.4    -- seconds a step takes to fade to nothing once someone stands on it (was 0.9 of red, then 0.4 of fading)
local RETURN_AFTER = 4.5    -- seconds until a vanished step comes back
local REWARD_CANDLES = 20
local APPEAR_GAP = 0.12     -- seconds between one step appearing and the next (at the start)
local LINGER = 2.5          -- seconds the stairway stays after the chest is opened

type Step = { Part: BasePart, Spot: Vector3, Top: number, Gone: boolean, Timer: number?, Ready: boolean }

return {
	Name = "Stairway of Spirits",
	Id = "stairway",
	Weight = 0.7,
	Duration = 30,
	Target = "Arena",
	Run = function(context: any)
		-- (plain words instead of a red error when Systems > EventUtil is an older copy than this script was made for)
		if not (K.Chest) then
			warn("[Stairway of Spirits] ServerScriptService > Systems > EventUtil is an OLDER copy than this event was made for, so the event is skipped. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
			return
		end
		local t0 = K.Start(context)
		local plate = K.Pick(K.Plates())
		if not plate then
			return
		end
		local base = K.TopCentre(plate)
		local steps: { Step } = {}
		local start = math.random() * math.pi * 2
		for n = 1, STEPS do
			local angle = start + n * TURN
			local spot = base + Vector3.new(math.cos(angle) * RADIUS, n * RISE, math.sin(angle) * RADIUS)
			-- (they appear one after another: see the loop below)
			local part = K.Part({ Name = "Step" .. n, Size = Vector3.new(6, 0.8, 6), CFrame = CFrame.new(spot) * CFrame.Angles(0, -angle, 0), Color = K.Colors.Ghost, Material = Enum.Material.Neon, Transparency = 1, Parent = context.Folder })
			steps[n] = { Part = part, Spot = spot, Top = spot.Y + 0.4, Gone = false, Timer = nil, Ready = false }
		end
		local landingAt = base + Vector3.new(0, (STEPS + 1) * RISE, 0)
		local landing = K.Part({ Name = "Landing", Size = Vector3.new(9, 0.8, 9), CFrame = CFrame.new(landingAt), Color = K.Colors.Ghost, Material = Enum.Material.Neon, Transparency = 1, Parent = context.Folder })
		local chestAt = landingAt + Vector3.new(0, 0.4, 0) -- (the top of the landing: where the chest stands)
		-- the client module finds the real steps through this tag (it lights up the ones that are solid)
		local look = K.Show(context, "Stairway", CFrame.new(base), {
			T0 = t0, Tag = K.Tag(context, context.Folder), Steps = STEPS, Rise = RISE, Radius = RADIUS, Start = start, Turn = TURN, Gap = APPEAR_GAP,
		})
		K.TellAll("Stairway of Spirits!", "Climb the ghostly steps to the chest. They vanish behind you!", K.Colors.Ghost)

		local claimed = false
		K.Outro(context, 1.2, function()
			K.Signal(context, look, "Outro", 1.1)
			if not claimed then
				for _, child in context.Folder:GetChildren() do
					if child:IsA("BasePart") then
						K.Tween(child, { Transparency = 1 }, 1)
					end
				end
			end
		end)

		-- whoever opens the chest: the item is already theirs (ItemCrates), this adds the rest
		local function opened(player: Player, item: string?)
			if claimed then
				return
			end
			claimed = true
			K.Candles(player, REWARD_CANDLES)
			K.Complete(context, player) -- Event Journal: you have opened the chest
			K.TellAll(player.DisplayName .. " opened the Spirit Chest!", if item then "Inside: " .. item else "+" .. REWARD_CANDLES .. " candles", K.Colors.Gold)
			K.Call(context, look, "Claim", player.UserId, K.Now())
			task.delay(LINGER, function()
				if context.IsRunning() then
					for _, child in context.Folder:GetChildren() do
						K.Fade(child, 1.2)
					end
				end
			end)
		end

		local landed = false
		K.Loop(context, function(_, t)
			if claimed then
				return
			end
			-- the steps appear from the bottom up, then the landing
			for n, step in steps do
				if not step.Ready and t >= 0.5 + n * APPEAR_GAP then
					step.Ready = true
					step.Part.Transparency = 0.35
					K.Solid(step.Part)
				end
			end
			if not landed and t >= 0.5 + (STEPS + 1) * APPEAR_GAP then
				landed = true
				landing.Transparency = 0.3
				K.Solid(landing)
				-- a normal chest drops onto the landing; it stays until somebody opens it or the event ends
				K.Chest(context, chestAt, { Name = "Spirit Chest", Lifetime = context.Event.Duration, OnOpened = opened })
			end
			K.Each(function(player, root, _, feetY)
				for n, step in steps do
					if step.Ready and not step.Gone and not step.Timer and math.abs(feetY - step.Top) <= 1.2 and K.Flat(root.Position - step.Spot).Magnitude <= 4.2 then
						-- it fades to nothing under them (no red): still solid until it is gone
						step.Timer = t + VANISH_AFTER
						K.Tween(step.Part, { Transparency = 1 }, VANISH_AFTER, "Linear")
						K.Signal(context, look, "Vanish", n, VANISH_AFTER)
					end
				end
			end)
			if claimed then
				return
			end
			for _, step in steps do
				local timer = step.Timer
				if timer and t >= timer then
					if step.Gone then
						step.Gone, step.Timer = false, nil
						step.Part.CanCollide = true
						K.Tween(step.Part, { Transparency = 0.35 }, 0.4)
					else
						step.Gone, step.Timer = true, t + RETURN_AFTER
						step.Part.CanCollide = false
						step.Part.Transparency = 1
					end
				end
			end
		end)
		K.Hold(context)
	end,
}
