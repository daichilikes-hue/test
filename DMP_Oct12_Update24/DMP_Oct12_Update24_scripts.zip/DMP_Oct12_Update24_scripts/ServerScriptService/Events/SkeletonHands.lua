-- ModuleScript: ServerScriptService > Events > SkeletonHands     (/setevent skelhands)
-- Something scratches under the plate where you stand: cracks run out over the stone and bony fingertips push up
-- through it. A moment later a giant skeleton hand bursts out and GRABS anyone still inside the cracks: they can't
-- walk, and have to MASH JUMP to wriggle free. Too slow and the hand squeezes (damage) before letting go. Three rounds.
-- Oct 10 2026 (update 10), your list:
--   * a REAL hand: a thumb, and four fingers of different lengths (the model Hand under this script);
--   * a bigger grab (GRAB_RADIUS 5.4, was 3.6);
--   * NO red circle. The new indicator is the cracks: they spread out exactly as far as the hand will reach, with a
--     pale glow in them, while its fingertips come up through the plate.
-- It is drawn on the clients now (ReplicatedStorage > EventClients > skelhands) and uses Systems > EventUtil like
-- the other events (it was one of the last on the old EventKit). Breaking free is counted from the player's Jumping
-- state changes, as before (the grab leaves a tiny hop so a jump still happens). Nobody is moved by the grab: the
-- hand slides under whoever it caught.
-- Toasts: the one announcement. "MASH JUMP" is the banner with the bar that the grabbed player gets (client).
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local ROUNDS = 3
local HANDS_MIN = 1
local HANDS_MAX = 4
local WARN_TIME = 1.4       -- seconds the cracks spread and the fingertips come up before the hand bursts out
local BURST = 0.3           -- seconds the burst itself takes: whoever is still there after it is grabbed
local GRAB_RADIUS = 5.4     -- anyone this close to the middle of the hand is grabbed (was 3.6)
local JUMPS_TO_BREAK = 6
local GRAB_TIME = 4         -- seconds before the hand squeezes
local SQUEEZE_DAMAGE = 30
local REST_TIME = 1.0       -- pause between rounds
local SINK_TIME = 0.5       -- seconds the hand takes to go back down

local BONE = Color3.fromRGB(214, 204, 178)

type Victim = { Player: Player, Jumps: number, Released: boolean, Connection: RBXScriptConnection? }

return {
	Name = "Skeleton Hands",
	Id = "skelhands",
	Weight = 0.8,
	Duration = 30,
	Target = "Arena",
	Run = function(context: any)
		K.Start(context)
		if #K.Alive() == 0 then
			return
		end
		local active: { Victim } = {}

		local function release(victim: Victim)
			if victim.Released then
				return
			end
			victim.Released = true
			if victim.Connection then
				victim.Connection:Disconnect()
			end
			if victim.Player.Parent then
				K.Unmod(victim.Player, "SkeletonHandWalk")
				K.Unmod(victim.Player, "SkeletonHandJump")
			end
			local index = table.find(active, victim)
			if index then
				table.remove(active, index)
			end
		end
		-- if the event ends mid-grab, everyone is let go
		context.Trash.Add(function()
			for _, victim in table.clone(active) do
				release(victim)
			end
		end)

		-- One hand: the fingertips scratch through (the warning), it bursts out, grabs whoever is still there, waits
		-- for them to break free (or squeezes), then goes back down
		local function runHand(site: Vector3)
			local now = K.Now()
			local hand = K.Show(context, "Hand", CFrame.new(site) * CFrame.Angles(0, math.random() * math.pi * 2, 0), {
				T0 = now, Warn = WARN_TIME, Burst = BURST, Radius = GRAB_RADIUS, Sink = SINK_TIME, Jumps = JUMPS_TO_BREAK, Hold = GRAB_TIME,
			})
			if not K.WaitUntil(context, now + WARN_TIME + BURST) then
				return
			end
			local victims: { Victim } = {}
			local ids: { number } = {}
			K.Each(function(player, root, humanoid)
				if K.Flat(root.Position - site).Magnitude <= GRAB_RADIUS and math.abs(root.Position.Y - site.Y) < 6 then
					for _, other in active do
						if other.Player == player then
							return -- (another hand already has them)
						end
					end
					local victim: Victim = { Player = player, Jumps = 0, Released = false, Connection = nil }
					K.Mod(player, "WalkSpeed", { Mult = 0 }, "SkeletonHandWalk")
					K.Mod(player, "Jump", { Mult = 0.3 }, "SkeletonHandJump")
					victim.Connection = humanoid.StateChanged:Connect(function(_, newState)
						if newState == Enum.HumanoidStateType.Jumping and not victim.Released then
							victim.Jumps += 1
							K.Signal(context, hand, "Jolt", player.UserId, victim.Jumps)
						end
					end)
					table.insert(active, victim)
					table.insert(victims, victim)
					table.insert(ids, player.UserId)
					K.Blame(context, player)
				end
			end)

			if #victims > 0 then
				K.Signal(context, hand, "Grab", ids, K.Now())
				local deadline = os.clock() + GRAB_TIME
				while context.IsRunning() and os.clock() < deadline do
					local remaining = 0
					for _, victim in victims do
						if not victim.Released then
							if not K.IsAlive(victim.Player) then
								release(victim)
							elseif victim.Jumps >= JUMPS_TO_BREAK then
								release(victim)
								K.Push(victim.Player, Vector3.new(0, 38, 0), 0.25)
								K.Signal(context, hand, "Free", victim.Player.UserId)
							else
								remaining += 1
							end
						end
					end
					if remaining == 0 then
						break
					end
					task.wait(0.1)
				end
				-- anyone still stuck gets squeezed
				local squeezed: { number } = {}
				for _, victim in victims do
					if not victim.Released then
						if K.IsAlive(victim.Player) then
							K.Hurt(victim.Player, SQUEEZE_DAMAGE, context)
							table.insert(squeezed, victim.Player.UserId)
						end
						release(victim)
					end
				end
				if #squeezed > 0 then
					K.Signal(context, hand, "Squeeze", squeezed)
					task.wait(0.35)
				end
			else
				task.wait(1.0) -- (it gropes about, finds nobody)
			end
			K.Signal(context, hand, "Sink", K.Now())
			K.Hide(context, hand, SINK_TIME + 0.2)
			task.wait(SINK_TIME)
		end

		K.TellAll("Skeleton Hands", "Something is scratching under the plates... get off the cracks!", BONE)

		for _ = 1, ROUNDS do
			if not context.IsRunning() then
				return
			end
			local players = K.Shuffle(K.Alive())
			if #players == 0 then
				break
			end
			-- under some of the players, right where they stand now (step away to dodge)
			local count = math.clamp(math.ceil(#players / 2), HANDS_MIN, HANDS_MAX)
			local plates = K.Plates()
			local sites: { Vector3 } = {}
			for index = 1, math.min(count, #players) do
				local root, humanoid = K.Root(players[index])
				if root and humanoid then
					local plate = K.PlateUnder(root, K.FeetY(root, humanoid), plates)
					if plate then
						table.insert(sites, Vector3.new(root.Position.X, K.Top(plate), root.Position.Z))
					end
				end
			end
			local finished = 0
			for _, site in sites do
				task.spawn(function()
					runHand(site)
					finished += 1
				end)
			end
			while finished < #sites and context.IsRunning() do
				task.wait(0.1)
			end
			task.wait(REST_TIME)
		end
		K.Hold(context)
	end,
}
