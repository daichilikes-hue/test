-- ModuleScript: ServerScriptService > Events > TheWithering     (NEW: Oct 11 Update 19, /setevent withering)
-- THE WITHERING: a plate somebody is standing on withers away. Its two long sides crack and crumble off, a strip at a
-- time, until all that is left is a narrow beam down its middle. It is NEVER destroyed: it just gets thinner, and stays
-- that thin for the rest of the round (like your Gremlins' plates). Whoever stands near an edge has to get to the
-- middle before the ground under them falls away.
-- Plates are physical, so the plate shrinks here, on the server. The cracks, the ash and the falling stones:
-- ReplicatedStorage > EventClients > withering (and the model Wither under this script).
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local MIN_WIDTH = 4         -- studs: the beam it withers down to (never thinner; it is never destroyed)
local STEPS = 6             -- it crumbles this many times
local WARN = 1.6            -- seconds of cracking before the first strip falls
local STEP_TIME = 1.15      -- seconds from one crumble to the next
local CRACK = 0.7           -- seconds a strip cracks before it falls (the tell, on the client)
local PERMANENT = true      -- true = it stays thin for the rest of the round; false = it grows back when the event ends

return {
	Name = "The Withering",
	Id = "withering",
	Weight = 1,
	Duration = math.ceil(WARN + (STEPS - 1) * STEP_TIME + 2),
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local plates = K.Plates()
		local plate, player = K.PickPlate(plates)
		if not plate then
			return
		end
		-- it narrows across its SHORTER side (a square plate: either way), towards a beam down its middle
		local axis = if plate.Size.X > plate.Size.Z + 0.01 then "Z" elseif plate.Size.Z > plate.Size.X + 0.01 then "X" else (if math.random() < 0.5 then "X" else "Z")
		local from = if axis == "X" then plate.Size.X else plate.Size.Z
		local to = math.min(MIN_WIDTH, from)
		if from - to < 0.5 then
			return -- (already a beam)
		end
		if player then
			ReplicatedStorage:SetAttribute("ActiveEventTarget", player.DisplayName)
		end
		local full = plate.Size
		if not PERMANENT then
			context.Trash.Add(function()
				if plate.Parent then
					plate.Size = if axis == "X" then Vector3.new(full.X, plate.Size.Y, plate.Size.Z) else Vector3.new(plate.Size.X, plate.Size.Y, full.Z)
				end
			end)
		end
		K.Show(context, "Wither", CFrame.new(K.TopCentre(plate)) * plate.CFrame.Rotation, {
			T0 = t0, Tag = K.Tag(context, plate), Axis = axis, From = from, To = to, Steps = STEPS, Warn = WARN, StepTime = STEP_TIME, Crack = CRACK,
		})
		K.TellAll("The Withering!", "A plate is withering away. Get to the middle of it!", K.Colors.Purple)

		for step = 1, STEPS do
			if not K.WaitUntil(context, t0 + WARN + (step - 1) * STEP_TIME) then
				return
			end
			if not plate.Parent then
				return
			end
			-- a strip falls off both long sides (it stays centred where it was)
			local width = from - (from - to) * step / STEPS
			local size = plate.Size
			plate.Size = if axis == "X" then Vector3.new(width, size.Y, size.Z) else Vector3.new(size.X, size.Y, width)
		end
		-- (the Event Journal: still standing on what is left of it)
		task.wait(0.6)
		K.Each(function(somebody: Player, root: BasePart, _, feetY: number)
			if plate.Parent and K.StandingOn(plate, root, feetY) then
				K.Complete(context, somebody)
			end
		end)
		K.Hold(context)
	end,
}
