-- ModuleScript: ServerScriptService > Events > SpiritTrain     (NEW)
-- A ghost train thunders straight across the arena. First the rails run out and the crossing lights flash
-- (WARN seconds), then it comes through: anyone still standing on the track is hit and thrown down the
-- line. Later on, two trains at once (they cross each other). Step off the track: you cannot jump it.
-- Oct 10 2026 (update 8): it always runs at the SAME height (K.BaseTop: the top of an untouched plate), whatever
-- has happened to the plates, and the red strip on the track is gone (see EventClients > spirittrain).
-- This script picks the tracks and decides the hits. What it looks like: ReplicatedStorage > EventClients > spirittrain.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local FIRST = 1.5          -- seconds before the first warning
local EVERY = 4.6          -- seconds between trains
local DOUBLE_AFTER = 12    -- seconds until two trains come at once
local WARN = 2.4           -- seconds the crossing lights flash before the train sets off
local SPEED = 140          -- studs per second (was 105)
local SIZE = 1.45          -- how big the train is (1 = the old one): wider, taller and longer, and so is its track
local LENGTH = 62 * SIZE   -- how long the train is (engine + 3 carriages): fixed by how the client module draws it
local WIDTH = 9 * SIZE     -- how wide its track is
local HEIGHT = 13 * SIZE   -- how tall it is
local RUN_UP = 70          -- how far outside the arena it starts
local RUN_OUT = 30         -- how far past the arena it keeps hitting
local AIM_CHANCE = 0.7     -- how often the track goes right through where somebody is standing
local DAMAGE = 50          -- (was 25)
local PUSH_ALONG, PUSH_UP, PUSH_TIME = 45, 26, 0.4   -- how hard it throws you down the line (and up)

type Train = { Id: number?, Entry: Vector3, Dir: Vector3, Side: Vector3, Leaves: number, Travel: number, Hit: { [Player]: boolean } }

return {
	Name = "Spirit Train",
	Id = "spirittrain",
	Weight = 1,
	Duration = 28,
	Target = "Arena",
	Run = function(context: any)
		-- (plain words instead of a red error when Systems > EventUtil is an older copy than this script was made for)
		if not (K.BaseTop) then
			warn("[Spirit Train] ServerScriptService > Systems > EventUtil is an OLDER copy than this event was made for, so the event is skipped. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
			return
		end
		K.Start(context)
		local plates = K.Plates()
		if #plates == 0 then
			return
		end
		K.TellAll("Spirit Train!", "Get off the tracks when the crossing lights flash!", K.Colors.Ghost)
		local trains: { Train } = {}

		-- alongX: true = it runs along X, false = along Z
		local function send(alongX: boolean)
			plates = K.Plates()
			if #plates == 0 then
				return
			end
			local dir = if alongX then Vector3.new(1, 0, 0) else Vector3.new(0, 0, 1)
			if math.random() < 0.5 then
				dir = -dir
			end
			local side = Vector3.new(-dir.Z, 0, dir.X)
			-- the track goes through a plate: through a player on it, or anywhere across it
			local through: Vector3? = nil
			local victim = K.Pick(K.Alive())
			local victimRoot = victim and K.Root(victim)
			if victimRoot and math.random() < AIM_CHANCE then
				local plate = K.PlateAt(victimRoot.Position, plates, 0)
				if plate then
					local across = (if alongX then plate.Size.Z else plate.Size.X) / 2
					local offset = math.clamp((victimRoot.Position - plate.Position):Dot(side), -math.max(across - WIDTH / 2, 0), math.max(across - WIDTH / 2, 0))
					through = K.TopCentre(plate) + side * offset
				end
			end
			if not through then
				local plate = K.Pick(plates)
				if not plate then
					return
				end
				local across = (if alongX then plate.Size.Z else plate.Size.X) / 2
				through = K.TopCentre(plate) + side * ((math.random() * 2 - 1) * math.max(across - WIDTH / 2, 0))
			end
			local point = through :: Vector3
			-- how far the arena reaches along the track, before and after that point
			local first, last = math.huge, -math.huge
			for _, plate in plates do
				local middle = (plate.Position - point):Dot(dir)
				local half = (if alongX then plate.Size.X else plate.Size.Z) / 2
				first = math.min(first, middle - half)
				last = math.max(last, middle + half)
			end
			-- (always the same height: the top of an untouched plate, not the top of the tallest plate right now)
			local entry = Vector3.new(point.X, K.BaseTop(), point.Z) + dir * (first - RUN_UP)
			local span = last - first
			local travel = RUN_UP + span + RUN_OUT + LENGTH
			local now = K.Now()
			local id = K.Show(context, "Train", CFrame.lookAt(entry, entry + dir), {
				T0 = now, Warn = WARN, Speed = SPEED, Length = LENGTH, Width = WIDTH, RunUp = RUN_UP, Span = span, Travel = travel, Scale = SIZE,
			})
			table.insert(trains, { Id = id, Entry = entry, Dir = dir, Side = side, Leaves = now + WARN, Travel = travel, Hit = {} })
			K.Hide(context, id, WARN + travel / SPEED + 0.7)
		end

		K.Loop(context, function()
			local now = K.Now()
			for index = #trains, 1, -1 do
				local train = trains[index]
				local front = (now - train.Leaves) * SPEED -- how far its nose is from where it started
				if front > train.Travel then
					table.remove(trains, index)
				elseif front > 0 then
					K.Each(function(player, root, _, feetY)
						if train.Hit[player] then
							return
						end
						local offset = root.Position - train.Entry
						local along = offset:Dot(train.Dir)
						if math.abs(offset:Dot(train.Side)) <= WIDTH / 2 + 0.8 and along <= front + 1 and along >= front - LENGTH
							and feetY <= train.Entry.Y + HEIGHT and feetY >= train.Entry.Y - 4 then
							train.Hit[player] = true
							K.Strike(context, train.Id, player, DAMAGE, train.Dir * PUSH_ALONG + Vector3.new(0, PUSH_UP, 0), PUSH_TIME)
						end
					end)
				end
			end
		end)

		task.wait(FIRST)
		-- (a train that could not get all the way across before the event ends is not sent)
		local lastStart = context.Event.Duration - (WARN + 4)
		while context.IsRunning() and K.Elapsed(context) < lastStart do
			local alongX = math.random() < 0.5
			send(alongX)
			if K.Elapsed(context) > DOUBLE_AFTER then
				send(not alongX) -- a second one across the first: the corners between them stay safe
			end
			task.wait(EVERY)
		end
		K.Hold(context)
	end,
}
