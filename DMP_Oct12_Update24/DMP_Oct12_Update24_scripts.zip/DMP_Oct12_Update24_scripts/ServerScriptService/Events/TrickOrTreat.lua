-- ModuleScript: ServerScriptService > Events > TrickOrTreat     (REPLACE)
-- A mystery door appears on the plates players are standing on. Knock (the prompt) and it opens:
-- a TREAT (candles, health, an item, a speed boost) or a TRICK (frog hex, no jumping, cobwebs, a shove,
-- sour candy). One knock per player, one player per door.
-- This script makes the prompts and decides what is behind each door. What the doors look like (and the
-- door on the knocker's screen): ReplicatedStorage > EventClients > trickortreat.
-- [Oct 11 Update 18] The models are UNDER this script: Door (the porch), Ghost, Treat and the ScreenGui DoorView
-- (the knocker's screen). Restyle them here; keep their names. "One knock each!" is said once per player.
-- (The old LocalScript StarterPlayerScripts > TrickOrTreatClient is not used any more: delete it.)
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local TREAT_CHANCE = 0.5
local REVEAL_TIME = 1.6    -- seconds between the knock and the treat / trick happening (the door opening)
local MAX_DOORS = 8
local EFFECT_TIME = 30     -- seconds every buff / debuff behind a door lasts (Sugar Rush, frog, sticky candy, cobwebs)

local function frog(player: Player)
	local FrogSpell = K.Sys("FrogSpell")
	if FrogSpell and FrogSpell.Apply then
		pcall(FrogSpell.Apply, player, EFFECT_TIME)
	else
		K.Mod(player, "WalkSpeed", { Mult = 0.5 }, "TrickFrog", EFFECT_TIME)
	end
end

type Outcome = { Title: string, Text: string, Do: (player: Player, door: Vector3) -> () }

-- Do(player, doorPosition) is what happens. Title / Text are what the player is shown.
local TREATS: { Outcome } = {
	{ Title = "Candy Stash", Text = "+15 candles", Do = function(player)
		K.Candles(player, 15)
	end },
	{ Title = "Sweet Heal", Text = "+30 health", Do = function(player)
		K.Heal(player, 30)
	end },
	{ Title = "Lucky Find", Text = "A random item!", Do = function(player)
		if not K.GiveItem(player) then
			K.Candles(player, 15)
		end
	end },
	{ Title = "Sugar Rush", Text = "Extra speed for " .. EFFECT_TIME .. " seconds", Do = function(player)
		K.Mod(player, "WalkSpeed", { Mult = 1.3 }, "TreatSugarRush", EFFECT_TIME)
	end },
}
local TRICKS: { Outcome } = {
	{ Title = "Frog Hex", Text = "Ribbit! You're a frog for " .. EFFECT_TIME .. " seconds", Do = frog },
	{ Title = "Sticky Candy", Text = "No jumping for " .. EFFECT_TIME .. " seconds", Do = function(player)
		K.Mod(player, "Jump", { Mult = 0 }, "TrickSticky", EFFECT_TIME)
	end },
	{ Title = "Cobwebs", Text = "Slowed for " .. EFFECT_TIME .. " seconds", Do = function(player)
		K.Mod(player, "WalkSpeed", { Mult = 0.55 }, "TrickCobweb", EFFECT_TIME)
	end },
	{ Title = "Jump Scare", Text = "The door shoves you away", Do = function(player, door)
		local root = K.Root(player)
		if root then
			K.Push(player, K.Dir(root.Position - door) * 55 + Vector3.new(0, 22, 0), 0.4)
		end
	end },
	{ Title = "Sour Candy", Text = "-15 health", Do = function(player)
		K.Hurt(player, 15, "Trick or Treat")
	end },
}

local SIDES = { Vector3.new(1, 0, 0), Vector3.new(-1, 0, 0), Vector3.new(0, 0, 1), Vector3.new(0, 0, -1) }

return {
	Name = "Trick or Treat",
	Id = "trickortreat",
	Weight = 0.8,
	Duration = 24,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local plates = K.Plates()
		local _, occupied = K.Occupied(plates)
		if #occupied == 0 then
			return
		end
		K.TellAll("Trick or Treat!", "Knock on a mystery door. Treat... or trick?", K.Colors.Orange)
		local knocked: { [Player]: boolean } = {}
		local told: { [Player]: boolean } = {} -- [Update 18] (told once that they have had their door)
		local doors: { number? } = {}
		K.Outro(context, 0.9, function()
			for _, door in doors do
				K.Signal(context, door, "Outro", 0.8)
			end
		end)
		for index, plate in K.Shuffle(occupied) do
			if index > MAX_DOORS then
				break
			end
			-- the door stands at one edge of the plate and faces its middle
			local side = SIDES[math.random(1, #SIDES)]
			local inset = math.max(math.min(plate.Size.X, plate.Size.Z) / 2 - 2.4, 0)
			local base = K.TopCentre(plate) + side * inset
			local id = K.Show(context, "Door", CFrame.lookAt(base, base - side), {
				T0 = t0, Reveal = REVEAL_TIME, Delay = 0.3 + index * 0.18, Seed = math.random(1, 100000),
			})
			table.insert(doors, id)
			local _, prompt = K.Prompt(base - side * 1.8 + Vector3.new(0, 3.5, 0), "Knock", "Mystery Door", 0, context.Folder)
			local used = false
			prompt.Triggered:Connect(function(player: Player)
				if used or not context.IsRunning() or player:GetAttribute("Alive") ~= true then
					return
				end
				if knocked[player] then
					if not told[player] then
						told[player] = true
						K.Tell(player, "One knock each!", "You have already had your door.", K.Colors.Orange)
					end
					return
				end
				used = true
				knocked[player] = true
				prompt.Enabled = false
				local treat = math.random() < TREAT_CHANCE
				local list = if treat then TREATS else TRICKS
				local outcome = list[math.random(1, #list)]
				K.Complete(context, player) -- Event Journal: you have knocked on a door
				-- (K.Call: someone who joins later sees this door standing open)
				K.Call(context, id, "Open", player.UserId, treat, outcome.Title, outcome.Text, K.Now())
				task.delay(REVEAL_TIME, function()
					if player:GetAttribute("Alive") == true and K.Root(player) then
						outcome.Do(player, base)
						K.Tell(player, (if treat then "TREAT: " else "TRICK: ") .. outcome.Title, outcome.Text, if treat then K.Colors.Gold else K.Colors.Purple)
					end
				end)
			end)
		end
		K.Hold(context)
	end,
}
