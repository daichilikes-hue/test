-- ModuleScript: ServerScriptService > Events > VoidKraken     (REPLACE)
-- The kraken looks out of the water beside the arena. Every few seconds a tentacle comes up out of the water at the
-- edge, rears up and whips down across the plates. Later on, two at a time.
-- Oct 10 2026 (update 9), your list:
--   * NO red lines any more. The warning is the tentacle itself: it comes out of the water and stands reared up for
--     WARNING seconds, leaning the way it is going to fall.
--   * After it hits it does not sink through the plates: it is REELED BACK the way it came, over the plates and down
--     into the water where it came out (LEAVE seconds).
--   * The head and the tentacles come up in the empty strip between the outermost plates and the border wall now
--     (HEAD_GAP / ROOT_GAP / ARM_GAP studs out from the plates, never in the wall). Before, they stood a fixed
--     distance from the middle of the arena, which on some sides was inside the wall.
--   * The kraken is made of real parts (the models Lair, Arm and Slam under this script), not sphere meshes.
-- This script decides the hits. What it looks like: ReplicatedStorage > EventClients > kraken.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local EVERY = 3.2        -- seconds between slams
local WARNING = 1.3      -- seconds a tentacle stands reared up before it comes down (the only warning there is)
local WIDTH = 7          -- how wide a tentacle is
local DOUBLE_AFTER = 11  -- seconds until two tentacles come at once
local DAMAGE, LIFT, SIDE = 22, 40, 16
local DROP, STAY, LEAVE = 0.16, 0.6, 1.3   -- seconds: the slam itself, how long it lies there, how long it takes to reel back into the water (was 0.5)
local ROOT_GAP = 14      -- studs between the outermost plates and the spot a tentacle comes out of the water
local HEAD_GAP = 16      -- studs between the outermost plates and the middle of the kraken's head (its eye is then about 3 studs from the plates)
local HEAD_ROOM = 17.5   -- the middle of the head stays this far from the border wall (the back of its head is 16 studs behind it)
local ARM_GAP = 10       -- studs between the outermost plates and the four tentacles that just wave about
local WALL_ROOM = 6      -- no tentacle comes up closer to the border wall than this
local WATER: number? = nil -- how far below the plate tops the water is. nil = found by itself (the top of the part tagged "Void")

-- Where a tentacle that lies along `direction` through `from` comes out of the water: `gap` studs beyond the plates
-- going that way (less when the border wall is nearer), at height y. Also returns how much water there is between
-- that spot and the plates.
local function beyond(plates: { BasePart }, from: Vector3, direction: Vector3, gap: number, room: number, y: number): (Vector3, number)
	local toPlates, toWall = K.RingAlong(plates, from, direction)
	local out = math.max(math.min(toPlates + gap, toWall - room), toPlates + 2)
	local spot = from + direction * out
	return Vector3.new(spot.X, y, spot.Z), out - toPlates
end

return {
	Name = "Void Kraken",
	Id = "kraken",
	Weight = 1,
	Duration = 28,   -- (was 26: the last tentacle gets the time to reel back in before the event is over)
	Target = "Arena",
	Run = function(context: any)
		-- (plain words instead of a red error when Systems > EventUtil is an older copy than this script was made for)
		if not (K.Beside and K.RingAlong and K.WaterY and K.Box and K.BaseTop) then
			warn("[Void Kraken] ServerScriptService > Systems > EventUtil is an OLDER copy than this event was made for, so the event is skipped. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
			return
		end
		local t0 = K.Start(context)
		local plates = K.Plates()
		if #plates == 0 then
			return
		end
		local centre = K.Arena(plates)
		local top = centre.Y -- (the tallest plate top: what a tentacle comes down on)
		local water = if WATER then K.BaseTop() - WATER else K.WaterY()
		local depth = math.max(top - water, 4)

		-- the kraken itself (its head and four waving tentacles beside the arena): only for show. The head comes up
		-- beside the plates on one side; two tentacles wave on the opposite side and one on each of the other two.
		local headSpot, toMiddle, headSide = K.Beside(plates, HEAD_GAP, HEAD_ROOM, nil, 0.25 + math.random() * 0.5)
		local headAt = Vector3.new(headSpot.X, water, headSpot.Z)
		local opposite = if headSide % 2 == 1 then headSide + 1 else headSide - 1
		local arms: { Vector3 } = {}
		for side = 1, 4 do
			if side ~= headSide then
				local spots: { number } = if side == opposite then { 0.22, 0.78 } else { 0.3 + math.random() * 0.4 }
				for _, along in spots do
					local spot = K.Beside(plates, ARM_GAP, WALL_ROOM, side, along)
					table.insert(arms, Vector3.new(spot.X, water, spot.Z))
				end
			end
		end
		local lair = K.Show(context, "Lair", CFrame.lookAt(headAt, headAt + toMiddle), { T0 = t0, Arms = arms, Centre = centre })
		K.TellAll("Void Kraken!", "Watch the tentacles: get out from under one before it comes down.", K.Colors.Purple)
		K.Outro(context, 1.5, function()
			K.Signal(context, lair, "Outro", 1.4)
		end)

		local function slam()
			-- a line through a random player who is on the plates (nobody there: through a random plate), in one of
			-- 4 directions
			plates = K.Plates()
			if #plates == 0 then
				return
			end
			local minX, maxX, minZ, maxZ = K.Box(plates)
			local standing: { Vector3 } = {}
			K.Each(function(_, playerRoot, _, feetY)
				local at = playerRoot.Position
				if at.X > minX - 4 and at.X < maxX + 4 and at.Z > minZ - 4 and at.Z < maxZ + 4 and feetY > top - 12 then
					table.insert(standing, at)
				end
			end)
			local aim: Vector3 = K.Pick(standing) or K.TopCentre(K.Pick(plates) :: BasePart)
			aim = Vector3.new(math.clamp(aim.X, minX, maxX), top, math.clamp(aim.Z, minZ, maxZ))
			local turn = math.random(0, 3) * math.pi / 4 + (math.random() - 0.5) * 0.3
			local dir = Vector3.new(math.cos(turn), 0, math.sin(turn))
			if math.random() < 0.5 then
				dir = -dir -- (it can come from either end of its line)
			end
			local perp = Vector3.new(-dir.Z, 0, dir.X)
			-- it comes out of the water behind the plates on one side and reaches just past them on the other
			local root, gap = beyond(plates, aim, -dir, ROOT_GAP, WALL_ROOM, water)
			local toFarEdge = K.RingAlong(plates, aim, dir)
			local length = K.Flat(aim - root).Magnitude + toFarEdge + 5
			local now = K.Now()
			local id = K.Show(context, "Slam", CFrame.lookAt(root, root + dir), {
				T0 = now, Warn = WARNING, Drop = DROP, Stay = STAY, Leave = LEAVE, Width = WIDTH, Length = length, Gap = gap, Depth = depth,
			})
			if not K.WaitUntil(context, now + WARNING + DROP) then
				return
			end
			K.Each(function(player, playerRoot, _, feetY)
				local offset = K.Flat(playerRoot.Position - root)
				local side = offset:Dot(perp)
				local along = offset:Dot(dir)
				if math.abs(side) <= WIDTH / 2 + 1 and along >= 0 and along <= length and feetY <= top + 5 and feetY >= top - 3 then
					K.Strike(context, id, player, DAMAGE, perp * (if side >= 0 then SIDE else -SIDE) + Vector3.new(0, LIFT, 0), 0.4)
				end
			end)
			K.Hide(context, id, STAY + LEAVE + 0.3)
		end

		task.wait(1.5)
		local lastStart = context.Event.Duration - (WARNING + DROP + STAY + LEAVE + 0.4) -- (a slam that could not finish and reel back in is not started)
		while context.IsRunning() and K.Elapsed(context) < lastStart do
			task.spawn(slam)
			if K.Elapsed(context) > DOUBLE_AFTER then
				task.wait(0.5)
				task.spawn(slam)
			end
			task.wait(EVERY)
		end
		K.Hold(context)
	end,
}
