-- ModuleScript: ServerScriptService > Events > DeadMansSwitch     (NEW, Oct 8 2026 update 3; REWORKED Oct 11 update 15)
-- Dead Man's Switch: a DOOR TO HELL grinds up out of the void just past one edge of the arena, its iron doors burst
-- open and a wall of fire pours out of it, slowly, until it spans the whole arena. It is SKY HIGH (nobody jumps it)
-- and it sweeps back and forth across the arena. A heavy lever rises on one plate. Grab it (hold the prompt a
-- moment) and you are put behind it with both hands on it, and you can't walk or jump: while somebody holds it the
-- fire sinks to embers and burns nobody. Holding it is a struggle: a ring closes in on a circle on your screen, press
-- when it is on the circle. Easy, but press too soon or too late and your hands slip: you let go, the lever is STUCK
-- for 5 seconds (nobody can grab it) and the fire roars back up. Over its 60 seconds the wall dies down, and at the
-- end it fades away. Whoever is holding the lever when the fire dies gets an item.
-- Nobody holding = the wall burns everyone it passes (28 Fire damage, thrown back through the flames).
-- Client: ReplicatedStorage > EventClients > deadswitch (the door, the wall, the lever, the panel, the struggle).
-- The models under this script: HellDoor, Lever, FireSegment (one piece of the wall) and the ScreenGui LeverGui.

local ServerScriptService = game:GetService("ServerScriptService")

local K = require(ServerScriptService:WaitForChild("Systems"):WaitForChild("EventUtil"))
-- (plain words instead of a red error when Systems > EventUtil is an older copy than this script was made for)
if not (K.Listen and K.Show and K.Signal) then
	warn("[DeadMansSwitch] ServerScriptService > Systems > EventUtil is an OLDER copy than this script was made for. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end

local Event = {
	Name = "Dead Man's Switch",
	Id = "deadswitch",
	Weight = 0.6,
	Duration = 72,
	Target = "Arena",
}

-- THE DOOR AND THE WALL (seconds from the start). KEEP IN SYNC with the same numbers in EventClients > deadswitch:
-- the server sends them along, so the client draws the wall exactly where it burns.
local DOOR_RISE = 3         -- the door grinds up out of the void
local DOOR_OPEN = 2.5       -- its doors burst open
local EMERGE = 4.5          -- the fire pours out of the doorway and spreads across the arena (it burns nobody yet)
local WALL_LIFE = 60        -- from pouring out to gone: it dies down over this time ...
local FADE = 4              -- ... and fades away in its last seconds (it burns nobody then)
local CROSSING = 14         -- seconds to cross the arena once (then it turns and comes back)
local WALL_HEIGHT = 140     -- how tall it is at first: sky high
local EMBER_HEIGHT = 2.5    -- how low it sinks while somebody holds the lever
local MARGIN = 6            -- the wall turns this far outside the plates
local DOOR_BACK = 5         -- the door stands this far behind the line the wall starts from
local WALL_DAMAGE = 28      -- a burn from the wall at full height; it burns less as it dies down (WEAKEST at the end)
local WEAKEST = 0.4         -- (at the end of its life the burn and the shove are this much of the full one)
local WALL_THICK = 3        -- studs either side of the wall's line that burn
local SHOVE, HOP = 18, 20   -- a burnt player is shoved back through the flames (studs/s back, up)
local HIT_COOLDOWN = 2
-- THE LEVER
local REACH = 9             -- prompt distance
local GRAB_HOLD = 0.4       -- hold the prompt this long to grab it
local HOLDER_BACK = 3.25    -- the holder is put this far behind the lever, facing it (KEEP IN SYNC with DMP_tools animgen/switch_anims.py)
local JAM_TIME = 5          -- after it is let go, the lever is stuck this long
local KNOCKED_OFF = 4       -- pushed this far from the lever = you let go
-- THE STRUGGLE: an easy quick-time game. A ring closes in on a circle; press when it is on the circle.
local CUE_LEAD = 1.1        -- seconds the ring takes to close in
local FIRST_RING = 0.6      -- after grabbing it, the first ring comes this soon
local RING_GAP_MIN, RING_GAP_MAX = 0.4, 1.1  -- the pause between a good press and the next ring
local EARLY = 0.32          -- a press counts from this long before the ring reaches the circle ...
local LATE = 0.28           -- ... to this long after
local GRACE = 0.35          -- (lag) a ring nobody pressed counts as missed this long after LATE

-- where the wall is at t (seconds since the start): how far from the line it starts from (0..travel), how tall,
-- and which way it is moving (1 = away from the door, -1 = back toward it). KEEP IN SYNC with wallAt in the client.
local function wallAt(t: number, travel: number): (number, number, number)
	local since = t - (DOOR_RISE + DOOR_OPEN)
	if since <= 0 then
		return 0, 0, 1
	end
	local life = math.clamp(since / WALL_LIFE, 0, 1)
	local height = WALL_HEIGHT * (1 - life * life)
	if since < EMERGE then
		local k = since / EMERGE
		height *= k * k * (3 - 2 * k)
	end
	local left = WALL_LIFE - since
	if left < FADE then
		height *= math.max(left, 0) / FADE
	end
	local sweep = math.max(since - EMERGE, 0) / CROSSING
	local phase = sweep % 2
	if phase <= 1 then
		return phase * travel, height, 1
	end
	return (2 - phase) * travel, height, -1
end

function Event.Run(context)
	local t0 = K.Start(context)
	local plates = K.Plates()
	if #plates == 0 then
		return
	end
	local minX, maxX, minZ, maxZ, top = math.huge, -math.huge, math.huge, -math.huge, -math.huge
	for _, plate in plates do
		minX = math.min(minX, plate.Position.X - plate.Size.X / 2)
		maxX = math.max(maxX, plate.Position.X + plate.Size.X / 2)
		minZ = math.min(minZ, plate.Position.Z - plate.Size.Z / 2)
		maxZ = math.max(maxZ, plate.Position.Z + plate.Size.Z / 2)
		top = math.max(top, K.Top(plate))
	end
	local centre = Vector3.new((minX + maxX) / 2, top, (minZ + maxZ) / 2)
	local dirs = { Vector3.new(1, 0, 0), Vector3.new(-1, 0, 0), Vector3.new(0, 0, 1), Vector3.new(0, 0, -1) }
	local dir = dirs[math.random(1, #dirs)]
	local right = Vector3.new(-dir.Z, 0, dir.X)
	local halfDepth = (if dir.X ~= 0 then maxX - minX else maxZ - minZ) / 2 + MARGIN
	local halfLength = (if dir.X ~= 0 then maxZ - minZ else maxX - minX) / 2 + MARGIN
	local start = centre - dir * halfDepth
	local travel = halfDepth * 2

	-- the door (facing the arena), just behind the line the wall starts from
	local doorAt = start - dir * DOOR_BACK
	local doorId = K.Show(context, "HellDoor", CFrame.lookAt(doorAt, doorAt + dir), {
		T0 = t0,
		Rise = DOOR_RISE,
		Open = DOOR_OPEN,
		Emerge = EMERGE,
		Life = WALL_LIFE,
		Fade = FADE,
		Crossing = CROSSING,
		Height = WALL_HEIGHT,
		Embers = EMBER_HEIGHT,
		Start = start,
		Dir = dir,
		Travel = travel,
		HalfLength = halfLength,
		DoorBack = DOOR_BACK,
	})

	-- the lever: on a random plate, lever and holder either side of its middle, facing the door
	local plate = K.Pick(plates) :: BasePart
	local leverAt = K.TopCentre(plate) - dir * (HOLDER_BACK / 2)
	local leverFrame = CFrame.lookAt(leverAt, leverAt - dir)
	local leverId = K.Show(context, "Lever", leverFrame, {
		T0 = t0,
		DoorAt = doorAt,
		Lead = CUE_LEAD,
		Early = EARLY,
		Late = LATE,
		Back = HOLDER_BACK,
	})

	local holder: Player? = nil
	local holdSpot: Vector3? = nil
	local jammedUntil = 0
	local finished = false
	local cue: { Index: number, At: number }? = nil
	local cues = 0
	local rng = Random.new()

	local _, prompt = K.Prompt(leverAt + Vector3.new(0, 3.2, 0), "Grab the lever", "Dead Man's Switch", GRAB_HOLD, context.Folder)
	prompt.MaxActivationDistance = REACH
	prompt.Enabled = false

	-- every client hears who holds it (0 = nobody) and until when it is stuck; the wall only needs "held"
	local function tell()
		K.Call(context, leverId, "Held", if holder then holder.UserId else 0, jammedUntil)
		K.Call(context, doorId, "Held", holder ~= nil)
	end

	local function ring(after: number)
		local player = holder
		if not player then
			return
		end
		cues += 1
		local at = K.Now() + after + CUE_LEAD
		cue = { Index = cues, At = at }
		K.Signal(context, leverId, "Cue", player.UserId, cues, at)
	end

	-- lets go of the lever. why: "soon" / "late" / "missed" (the struggle), "letgo" (their own button), "knocked",
	-- "dead", "end" (the fire died: no jam then)
	local function release(why: string)
		local player = holder
		if not player then
			return
		end
		holder = nil
		holdSpot = nil
		cue = nil
		K.Unmod(player, "SwitchHoldWalk")
		K.Unmod(player, "SwitchHoldJump")
		K.Signal(context, leverId, "Slip", player.UserId, why)
		if why ~= "end" then
			jammedUntil = K.Now() + JAM_TIME
			prompt.Enabled = false
			task.delay(JAM_TIME, function()
				if context.IsRunning() and not finished and holder == nil and K.Now() >= jammedUntil - 0.05 then
					prompt.Enabled = true
					tell()
				end
			end)
		end
		tell()
	end
	context.Trash.Add(function()
		local player = holder
		if player then
			holder = nil
			K.Unmod(player, "SwitchHoldWalk")
			K.Unmod(player, "SwitchHoldJump")
		end
	end)

	local function grab(player: Player)
		if holder or finished or K.Now() < jammedUntil or not K.IsAlive(player) then
			return
		end
		local root, humanoid = K.Root(player)
		local character = player.Character
		if not (root and humanoid and character) then
			return
		end
		holder = player
		-- behind the lever, facing it, both hands on the grip (the client plays the struggle on them)
		local lift = root.Position.Y - K.GetFeetY(root, humanoid)
		local spot = leverFrame * CFrame.new(0, lift, HOLDER_BACK)
		character:PivotTo(spot)
		holdSpot = spot.Position
		K.Mod(player, "WalkSpeed", { Mult = 0 }, "SwitchHoldWalk")
		K.Mod(player, "Jump", { Mult = 0 }, "SwitchHoldJump")
		prompt.Enabled = false
		tell()
		ring(FIRST_RING)
	end
	context.Trash.Add(prompt.Triggered:Connect(grab))

	-- what the holder's panel sends: "Pull" (a press: which ring, and when by the server's clock) and "LetGo"
	K.Listen(context, function(player: Player, action: any, index: any, at: any)
		if player ~= holder then
			return
		end
		if action == "LetGo" then
			release("letgo")
			return
		end
		local current = cue
		if action ~= "Pull" or not current then
			return
		end
		if type(index) == "number" and index ~= current.Index then
			return -- (a press meant for a ring that is already done)
		end
		local now = K.Now()
		local t = if type(at) == "number" and at == at then math.clamp(at, now - 1, now + 0.1) else now
		if t < current.At - CUE_LEAD then
			return -- (no ring on the screen yet: not counted either way)
		end
		if t < current.At - EARLY then
			release("soon")
		elseif t <= current.At + LATE then
			K.Signal(context, leverId, "Good", player.UserId, current.Index)
			ring(rng:NextNumber(RING_GAP_MIN, RING_GAP_MAX))
		else
			release("late")
		end
	end)

	task.delay(2, function()
		if context.IsRunning() and not finished and holder == nil then
			prompt.Enabled = true
		end
	end)
	K.TellAll("Dead Man's Switch", "The door to hell is open! Grab the lever and hold the fire down.", K.Colors.Orange)

	local ready = K.Cooldown()
	K.Loop(context, function(_dt, t)
		local player = holder
		if player then
			local root = K.Root(player)
			if not (root and K.IsAlive(player)) then
				release("dead")
			elseif holdSpot and (root.Position - holdSpot).Magnitude > KNOCKED_OFF then
				release("knocked")
			elseif cue and K.Now() > cue.At + LATE + GRACE then
				release("missed")
			end
		end
		if finished then
			return
		end
		local since = t - (DOOR_RISE + DOOR_OPEN)
		if since >= WALL_LIFE then
			-- the fire is dead: whoever holds the lever now gets an item
			finished = true
			prompt.Enabled = false
			local winner = holder
			if winner and K.IsAlive(winner) then
				local item = K.GiveItem(winner)
				K.Complete(context, winner)
				K.Tell(winner, "Dead Man's Switch", "The fire died. Your hands are numb" .. (if item then ", but you got: " .. item .. "." else "."), K.Colors.Gold)
			end
			release("end")
			K.Call(context, leverId, "Over")
			K.Call(context, doorId, "Over")
			return
		end
		if holder ~= nil or since < EMERGE or since > WALL_LIFE - FADE then
			return -- (held down / still pouring out / fading away: it burns nobody)
		end
		local along, height, moving = wallAt(t, travel)
		if height < 1 then
			return
		end
		local wall = start + dir * along
		local strength = WEAKEST + (1 - WEAKEST) * math.clamp(height / WALL_HEIGHT, 0, 1)
		for _, victim in K.Alive() do
			local root = K.Root(victim)
			if root then
				local rel = root.Position - wall
				if math.abs(rel:Dot(dir)) <= WALL_THICK and math.abs(rel:Dot(right)) <= halfLength and rel.Y > -6 and rel.Y < height + 3 and ready(victim, HIT_COOLDOWN) then
					-- thrown back through the flames (the way it came from)
					K.Strike(context, doorId, victim, math.floor(WALL_DAMAGE * strength + 0.5), -dir * moving * (SHOVE * strength) + Vector3.new(0, HOP, 0), 0.25, "Fire")
				end
			end
		end
	end)
	K.Hold(context)
end

return Event
