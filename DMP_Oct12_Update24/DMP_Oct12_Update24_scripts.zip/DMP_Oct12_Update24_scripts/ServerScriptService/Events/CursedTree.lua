-- ModuleScript: ServerScriptService > Events > CursedTree     (/setevent tree)     (Oct 11 Update 14: the dread)
-- A cursed tree (your ReplicatedStorage > Assets > CursedTreeModel) tears up out of a random plate. There is NO circle
-- and no countdown: its reach (about one plate around it) is vague on purpose. The longer you stay in its reach, the
-- darker YOUR screen gets (vignette, colour draining, a little blur, a heartbeat); after TurnAfter seconds in it, it
-- CLICKS and you are ROOTED: no walking, no jumping. Step out before that and it runs back down (Drain times faster).
-- Over WoodTime seconds a rooted body turns to wood (legs, then torso and arms, then head). When they're fully wood
-- they die and a SMALL tree grows where they stood, with its own (smaller) reach. Chain reaction, capped at MaxTrees.
-- If the event ends first, everyone still turning is released.
-- SERVER: timing, who is in reach and for how long, rooting (Stats modifiers), body colours, roots.
-- CLIENT (EventClients/tree): the trees, the mist at their foot, and the dread on each player's own screen.

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerScriptService = game:GetService("ServerScriptService")
local TweenService = game:GetService("TweenService")

local GameConfig = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("GameConfig"))
local Systems = ServerScriptService:WaitForChild("Systems")
local Damage = require(Systems:WaitForChild("Damage"))
local Stats = require(Systems:WaitForChild("Stats"))
local EventUtil = require(Systems:WaitForChild("EventUtil"))
local PlateSpawner = require(Systems:WaitForChild("PlateSpawner"))

local Event = {
	Name = "Cursed Tree",
	Id = "tree",
	Weight = 1,
	Duration = 36,
	Target = "Arena",

	GrowTime = 2,            -- the first tree tearing up out of the plate (it reaches for nobody before that)
	SmallGrowTime = 1.2,     -- the same for the small trees
	TurnAfter = 5,           -- seconds in a tree's reach until it has you (your screen darkens all that time)
	Drain = 1.5,             -- out of its reach, that time runs back down this many times faster
	WoodTime = 9,            -- from rooted to fully wood
	SmallScale = 0.45,
	SmallRadiusMult = 0.45,
	MaxTrees = 7,
	AuraHeight = 12,         -- vertical reach of the aura
}
-- "1 plate radius": one plate-to-plate spacing around the tree
Event.AuraRadius = math.max(GameConfig.PlateSize.X, GameConfig.PlateSize.Z) + (GameConfig.MaxPlateGap or 7.5)

local BARK = Color3.fromRGB(88, 62, 42)
local ROOT_COLOR = Color3.fromRGB(46, 33, 30)
local CURSE = Color3.fromRGB(170, 90, 220)

-- Which body parts turn to wood at each stage (R6 and R15 names)
local STAGES = {
	{
		At = 0.1,
		Message = "Your legs are turning to wood...",
		Names = {
			["Left Leg"] = true, ["Right Leg"] = true, LowerTorso = true,
			LeftUpperLeg = true, LeftLowerLeg = true, LeftFoot = true,
			RightUpperLeg = true, RightLowerLeg = true, RightFoot = true,
		},
	},
	{
		At = 0.45,
		Message = "Your body is hardening...",
		Names = {
			Torso = true, UpperTorso = true, ["Left Arm"] = true, ["Right Arm"] = true,
			LeftUpperArm = true, LeftLowerArm = true, LeftHand = true,
			RightUpperArm = true, RightLowerArm = true, RightHand = true,
		},
	},
	{ At = 0.78, Message = "Your face is turning to bark...", Names = { Head = true } },
}

function Event.Run(context)
	local Visuals = context.Visuals

	local plates = PlateSpawner.GetAllPlates()
	if #plates == 0 then
		return
	end
	local plate = plates[math.random(#plates)]
	local ground = Vector3.new(plate.Position.X, EventUtil.GetPlateTop(plate), plate.Position.Z)

	local trees = {}
	local rooted = {}
	local exposure: { [Player]: number } = {} -- seconds in reach (it runs back down out of reach)
	local told: { [Player]: boolean } = {}     -- (one toast per player per event)

	---------------------------------------------------------------- trees
	local function plant(position: Vector3, radius: number, small: boolean)
		local grow = if small then Event.SmallGrowTime else Event.GrowTime
		local yaw = math.rad(math.random(0, 359))
		local id = Visuals.Spawn("Tree", CFrame.new(position) * CFrame.Angles(0, yaw, 0), {
			Position = position,
			Radius = radius,
			Scale = if small then Event.SmallScale else 1,
			Start = workspace:GetServerTimeNow(),
			Grow = grow,
			Main = not small,
		})
		local tree = { Id = id, Position = position, Radius = radius, Armed = false }
		table.insert(trees, tree)

		task.delay(grow, function()
			if not context.IsRunning() then
				return
			end
			tree.Armed = true
			pcall(Visuals.Call, id, "Arm")
		end)
		return tree
	end

	---------------------------------------------------------------- rooted players
	local function release(entry)
		if entry.Released then
			return
		end
		entry.Released = true
		rooted[entry.Player] = nil
		for _, id in entry.Mods do
			pcall(Stats.RemoveModifier, entry.Player, id)
		end
		for part, original in entry.Originals do
			if part.Parent then
				part.Color = original.Color
				part.Material = original.Material
			end
		end
		for _, rootPart in entry.RootParts do
			rootPart:Destroy()
		end
	end

	local function rootPlayer(player: Player)
		local character = player.Character
		local root, humanoid = EventUtil.GetRoot(player)
		if not (character and root and humanoid) or rooted[player] then
			return
		end
		local entry = {
			Player = player,
			Character = character,
			Start = os.clock(),
			Stage = 0,
			Mods = {},
			Originals = {},
			RootParts = {},
			Released = false,
		}
		rooted[player] = entry

		table.insert(entry.Mods, Stats.AddModifier(player, "WalkSpeed", { Mult = 0 }))
		table.insert(entry.Mods, Stats.AddModifier(player, "Jump", { Mult = 0 }))
		for _, part in character:GetChildren() do
			if part:IsA("BasePart") then
				entry.Originals[part] = { Color = part.Color, Material = part.Material }
			end
		end

		-- Roots grab the feet
		local feet = Vector3.new(root.Position.X, EventUtil.GetFeetY(root, humanoid), root.Position.Z)
		for i = 1, 7 do
			local angle = (i / 7) * math.pi * 2 + math.random() * 0.4
			local outward = Vector3.new(math.cos(angle), 0, math.sin(angle))
			local a = feet + Vector3.new(0, 0.3, 0)
			local b = feet + outward * (3 + math.random() * 1.5) + Vector3.new(0, -0.7, 0)
			local rootPart = EventUtil.MakePart({
				Name = "TreeRoot",
				Shape = Enum.PartType.Cylinder,
				Size = Vector3.new((b - a).Magnitude, 0.8, 0.8),
				CFrame = CFrame.lookAt((a + b) / 2, b) * CFrame.Angles(0, math.rad(90), 0),
				Color = ROOT_COLOR,
				Material = Enum.Material.Wood,
				Transparency = 1,
				Parent = context.Folder,
			})
			TweenService:Create(rootPart, TweenInfo.new(0.8), { Transparency = 0 }):Play()
			table.insert(entry.RootParts, rootPart)
		end
		if not told[player] then
			told[player] = true
			EventUtil.Notify(player, "Cursed Tree", "It has you. You're turning to wood...", CURSE)
		end
	end

	local function applyStage(entry, stage)
		for part in entry.Originals do
			if part.Parent and stage.Names[part.Name] then
				part.Material = Enum.Material.Wood
				TweenService:Create(part, TweenInfo.new(1.2), { Color = BARK }):Play()
			end
		end
		-- (no toast per stage: the bark creeping up the body says it)
	end

	-- Fully wood: the body is replaced by a small tree
	local function finish(entry)
		local player = entry.Player
		local root, humanoid = EventUtil.GetRoot(player)
		local position: Vector3? = nil
		if root and humanoid then
			position = Vector3.new(root.Position.X, EventUtil.GetFeetY(root, humanoid), root.Position.Z)
		end
		for _, descendant in entry.Character:GetDescendants() do
			if descendant:IsA("BasePart") and descendant.Name ~= "HumanoidRootPart" then
				descendant.Transparency = 1
			elseif descendant:IsA("Decal") then
				descendant.Transparency = 1
			end
		end
		release(entry)
		Damage.Kill(player, { Source = Event.Name })
		if position and #trees < Event.MaxTrees then
			plant(position, Event.AuraRadius * Event.SmallRadiusMult, true)
		end
	end

	-- Anything still turning to wood is released when the event ends
	context.Trash.Add(function()
		for _, entry in table.clone(rooted) do
			release(entry)
		end
	end)

	EventUtil.GetRemote("ClientEffect"):FireAllClients("Notify", {
		Title = "Cursed Tree",
		Text = "A cursed tree has sprouted. Don't linger near it.",
		Color = CURSE,
	})
	local main = plant(ground, Event.AuraRadius, false)

	-- each client is told how far gone EVERY player is (it shows only its own): 0..1, 2 = it has you
	local sentSomething = false
	local function tellClients()
		local payload = {}
		for player, value in exposure do
			payload[tostring(player.UserId)] = math.floor(math.clamp(value / Event.TurnAfter, 0, 1) * 100 + 0.5) / 100
		end
		for player in rooted do
			payload[tostring(player.UserId)] = 2
		end
		local any = next(payload) ~= nil
		if any or sentSomething then
			pcall(Visuals.Call, main.Id, "Dread", payload)
		end
		sentSomething = any
	end

	---------------------------------------------------------------- main loop
	while context.IsRunning() do
		local dt = task.wait(0.2)

		-- who is in reach of a tree that has grown
		local near: { [Player]: boolean } = {}
		for _, tree in trees do
			if tree.Armed then
				for _, player in EventUtil.GetPlayersInRadius(tree.Position, tree.Radius, Event.AuraHeight) do
					near[player] = true
				end
			end
		end
		-- in reach: the time adds up until it has you; out of reach: it runs back down
		for player in near do
			if not rooted[player] then
				local value = (exposure[player] or 0) + dt
				if value >= Event.TurnAfter then
					exposure[player] = nil
					rootPlayer(player)
				else
					exposure[player] = value
				end
			end
		end
		for player, value in table.clone(exposure) do
			if not near[player] then
				value -= dt * Event.Drain
				exposure[player] = if value > 0 then value else nil
			end
			if not EventUtil.IsAlive(player) then
				exposure[player] = nil
			end
		end

		for player, entry in table.clone(rooted) do
			if not EventUtil.IsAlive(player) or player.Character ~= entry.Character then
				release(entry)
			else
				local alpha = (os.clock() - entry.Start) / Event.WoodTime
				for index, stage in STAGES do
					if entry.Stage < index and alpha >= stage.At then
						entry.Stage = index
						applyStage(entry, stage)
					end
				end
				if alpha >= 1 then
					finish(entry)
				end
			end
		end
		tellClients()
	end
	pcall(Visuals.Call, main.Id, "Dread", {})
end

return Event