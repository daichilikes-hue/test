-- ModuleScript: ServerScriptService > Events > GhostGuardian     (NEW: Oct 12 Update 23, /setevent guardian)
-- GHOST GUARDIAN (your backlog, protection event 6): a little friendly ghost (the model Guardian under this script)
-- floats at one random player's shoulder and takes their NEXT HIT for them: the damage never lands (a Damage handler
-- at priority 10, with the shields). Then it fades away. If nothing hits them, it leaves when the event ends.
-- It does not stop being knocked out instantly (the void, a guillotine): BLOCK_KILLS = true makes it stop those too.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local DURATION = 25
local BLOCK_KILLS = false
local FADE = 1.5            -- seconds it takes to fade after it took the hit

return {
	Name = "Ghost Guardian",
	Id = "guardian",
	Weight = 1,
	Duration = DURATION,
	Target = "Arena", -- picks its own player in Run (any alive player; a Black Cat does not turn a friend away)
	Run = function(context: any)
		local t0 = K.Start(context)
		local Damage = K.Sys("Damage")
		local player = K.Pick(K.Alive())
		if not player or not (Damage and Damage.AddHandler) then
			return
		end
		game:GetService("ReplicatedStorage"):SetAttribute("ActiveEventTarget", player.DisplayName)
		local root = K.Root(player)
		local id = K.Show(context, "Guardian", if root then root.CFrame else CFrame.new(), {
			T0 = t0, Duration = DURATION, UserId = player.UserId,
		})
		K.Tell(player, "Ghost Guardian", "A friendly ghost is watching over you. It will take your next hit.", K.Colors.Ghost)
		local character = player.Character
		local used = false
		Damage.AddHandler(player, "GhostGuardian", 10, function(hit: any)
			if used or (hit.InstantKill and not BLOCK_KILLS) then
				return
			end
			used = true
			hit.Cancelled = true
			Damage.RemoveHandler(player, "GhostGuardian")
			K.Call(context, id, "Absorb", math.floor((tonumber(hit.Amount) or 0) + 0.5))
			K.Hide(context, id, FADE + 0.3)
			K.Complete(context, player) -- (the Event Journal: it saved you)
		end)
		context.Trash.Add(function()
			if not used and player.Character == character then
				Damage.RemoveHandler(player, "GhostGuardian")
			end
		end)
		-- it leaves with its player (knocked out, gone)
		while context.IsRunning() and not used do
			if not K.IsAlive(player) or player.Character ~= character then
				K.Call(context, id, "Leave")
				K.Hide(context, id, 1)
				return
			end
			task.wait(0.25)
		end
	end,
}
