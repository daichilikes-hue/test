-- ModuleScript: ServerScriptService > Events > TheBidding     (/setevent bidding)
-- The Bidding: a black altar on a pillar grinds up out of the void OFF the plates (in the empty strip between the
-- outermost plates and the border walls) with ONE prize on it. Players bid MAX HP.
-- Everybody alive in the round gets the bidding panel on their screen (the ScreenGui BidGui under this script):
-- pick how much you want to bid with the V and the up arrow (STEP at a time, always more than the top bid), press
-- BID. OPEN bids: everyone sees the top bid and who holds it. Whoever holds the top bid cannot bid again: only
-- somebody who was outbid (or has not bid yet) can place a higher one. When the clock runs out, the leader PAYS
-- (loses that much max HP for the rest of the round, Stats MaxHealth Add like Vampiette) and takes the prize.
-- Everyone who was outbid pays NOTHING. A real trade, no chance involved. No bids = the Devil keeps the prize.
-- Oct 11 2026 (update 12), your list: "Should be a UI (make a new one) that people can have a V and a up arrow as
-- to how much they want to bid, only if outbid can they place a higher one. the pedastol doesnt need to spawn in
-- the center of the arena should be off the plates but still in the arena yk like on the border outside the
-- outermost plates". (Before: a prompt on an altar on the middle plate, +10 a press.) The altar and the prizes are
-- a model now (Altar, under this script), and the prize "two round items" is a NORMAL chest (EventUtil.Chest).
-- [MY CALL on the doc's open details] open bids; you can't bid what would leave you under 20 max HP;
-- 15 s on the clock, a bid with less than 4 s left puts it back to 4 s (25 s at most); prizes: two round items,
-- 40 candles, or a second life (revive once at 30 HP; it does not catch falls into the void).
-- Client: ReplicatedStorage > EventClients > bidding

local Players = game:GetService("Players")
local ServerScriptService = game:GetService("ServerScriptService")

local K = require(ServerScriptService:WaitForChild("Systems"):WaitForChild("EventUtil"))

local Event = {
	Name = "The Bidding",
	Id = "bidding",
	Weight = 0.5,
	Duration = 34,
	Target = "Arena",
}

local ARRIVE = 2            -- seconds the altar takes to grind up out of the void
local WINDOW = 15           -- seconds on the clock
local EXTEND = 4            -- a bid with less than this left puts the clock back to this
local MAX_WINDOW = 25       -- ... but the whole thing never lasts longer than this
local STEP = 10             -- max HP a press of the V / the up arrow changes your bid by; the first bid is at least this
local FLOOR = 20            -- nobody can bid what would leave them under this much max HP
local REVIVE_HP = 30
local RING_DEPTH = 0.45     -- where in the strip between the plates and the walls the altar stands: 0 = at the plates, 1 = at the wall
local ALTAR_DOWN = 6.3      -- the altar's foot is this far BELOW the tops of the plates: its cushion is then 1.5 studs above
                            -- them, so you look AT the prize from your plate, not up at a wall of stone
local CHEST_UP = 7.8        -- the top of the altar's cushion, in studs above the altar's foot (read off the model Altar when it is there)

type Prize = { Id: string, Name: string }
local PRIZES: { Prize } = {
	{ Id = "Items", Name = "Two round items" },
	{ Id = "Candles", Name = "40 candles" },
	{ Id = "Revive", Name = "A second life" },
}

-- how high the top of the cushion is above the altar's foot, read off the model (so a restyled altar still gets
-- its chest on the cushion)
local function cushionTop(): number
	local model = script:FindFirstChild("Altar")
	local root = model and model:IsA("Model") and model.PrimaryPart
	local cushion = model and model:FindFirstChild("Cushion", true)
	if root and cushion and cushion:IsA("BasePart") then
		return (cushion.Position.Y + cushion.Size.Y / 2) - root.Position.Y
	end
	return CHEST_UP
end

local priceCount = 0

local function giveRevive(player: Player)
	local Damage = K.Sys("Damage")
	if not (Damage and type(Damage.AddHandler) == "function") then
		return
	end
	Damage.AddHandler(player, "BiddingRevive", 100, function(ctx)
		local humanoid = ctx.Humanoid
		if ctx.Cancelled or ctx.InstantKill or not humanoid or ctx.Amount < humanoid.Health then
			return
		end
		ctx.Cancelled = true
		if type(Damage.RemoveHandler) == "function" then
			Damage.RemoveHandler(player, "BiddingRevive")
		end
		humanoid.Health = math.min(REVIVE_HP, humanoid.MaxHealth)
		player:SetAttribute("RevivedThisRound", true)
		K.Tell(player, "The Bidding", "Your second life saved you.", K.Colors.Gold)
	end)
end

local function givePrize(player: Player, prize: Prize)
	if prize.Id == "Items" then
		local a = K.GiveItem(player)
		local b = K.GiveItem(player)
		local names = {}
		for _, name in { a, b } do
			if name then
				table.insert(names, name)
			end
		end
		K.Tell(player, "The Bidding", if #names > 0 then "You got: " .. table.concat(names, " and ") .. "." else "The prize crumbled to dust.", K.Colors.Gold)
	elseif prize.Id == "Candles" then
		K.Candles(player, 40)
		K.Tell(player, "The Bidding", "+40 candles.", K.Colors.Gold)
	else
		giveRevive(player)
		K.Tell(player, "The Bidding", "The next hit that would knock you out leaves you on " .. REVIVE_HP .. " HP instead.", K.Colors.Gold)
	end
end

function Event.Run(context)
	-- (plain words instead of a red error when Systems > EventUtil is an older copy than this event was made for)
	if not (K.Listen and K.RingSpot and K.Chest) then
		warn("[The Bidding] ServerScriptService > Systems > EventUtil is an OLDER copy than this event was made for, so the event is skipped. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
		return
	end
	local t0 = K.Start(context)
	local plates = K.Plates()
	if #plates == 0 then
		return
	end
	-- off the plates, still in the arena: in the strip between the outermost plates and the walls, looking in
	local spot, inward = K.RingSpot(plates, RING_DEPTH)
	local frame = CFrame.lookAt(spot, spot + inward) * CFrame.new(0, -ALTAR_DOWN, 0)
	local prize = PRIZES[math.random(1, #PRIZES)]
	local id = K.Show(context, "Altar", frame, {
		T0 = t0,
		Arrive = ARRIVE,
		Prize = prize.Id,
		PrizeName = prize.Name,
		Ends = t0 + ARRIVE + WINDOW,
		Window = WINDOW,
		Step = STEP,
		Floor = FLOOR,
	})
	if not K.WaitUntil(context, t0 + ARRIVE) then
		return
	end

	-- the prize "two round items" is a normal chest on the cushion (nobody can open it: it is the prize). The
	-- chest's front is its +Z side: it faces the arena.
	local chest: any = nil
	if prize.Id == "Items" then
		chest = K.Chest(context, (frame * CFrame.new(0, cushionTop(), 0)).Position, {
			Drop = false, Lifetime = MAX_WINDOW + 20, Name = "The prize", Yaw = math.atan2(inward.X, inward.Z), NoItem = true,
			CanOpen = function()
				return false
			end,
		})
	end

	local top = 0
	local leader: Player? = nil
	local ends = t0 + ARRIVE + WINDOW
	local hardEnd = t0 + ARRIVE + MAX_WINDOW
	local closed = false

	-- a bid from somebody's panel: K.Listen only hears players alive in the round
	K.Listen(context, function(player: Player, action: any, amount: any)
		if closed or action ~= "Bid" or type(amount) ~= "number" or amount ~= amount then
			return
		end
		if player == leader then
			return -- (only somebody who was outbid, or has not bid yet, can place a higher one: the leader's button is grey)
		end
		local _, humanoid = K.Root(player)
		if not humanoid then
			return
		end
		local bid = math.floor(amount / STEP + 0.5) * STEP
		if bid < top + STEP or humanoid.MaxHealth - bid < FLOOR then
			return -- (somebody else was faster, or it is more than they can pay: their panel shows that already)
		end
		top, leader = bid, player
		ends = math.max(ends, math.min(K.Now() + EXTEND, hardEnd))
		K.Call(context, id, "Bid", player.UserId, bid, ends)
	end)

	while context.IsRunning() and K.Now() < ends do
		task.wait(0.1)
	end
	if not context.IsRunning() then
		return
	end
	closed = true

	local winner = leader
	if winner and K.IsAlive(winner) then
		priceCount += 1
		K.Mod(winner, "MaxHealth", { Add = -top }, "BiddingPrice" .. priceCount)
		givePrize(winner, prize)
		K.Complete(context, winner)
		K.Call(context, id, "Sold", winner.UserId, top)
		if chest then
			if chest.Open then
				chest.Open()
			else
				chest.Remove()
			end
		end
		K.Announce("The Bidding", "SOLD to " .. winner.DisplayName .. " for " .. top .. " max HP: " .. prize.Name .. ".", K.Colors.Gold)
	else
		K.Call(context, id, "Unsold")
		if chest then
			chest.Remove()
		end
		K.TellAll("The Bidding", if winner then "The top bidder is gone. The Devil keeps it." else "No bids. The Devil keeps it.", K.Colors.Warn)
	end
	K.Hide(context, id, 4)
end

return Event
