-- ModuleScript: ServerScriptService > Events > DevilsFiddle     (Oct 8 2026 update 4: REWORKED)
-- Oct 10 2026 (update 8): the tune picks up at your charge (50% charge = it starts halfway through the song, so the
-- later part of the song gets heard too), and Event.Give(player) hands the fiddle over with no contract and no
-- price: the command /givefiddle [target] uses it, and so does the 5th floor of the Hellgate Lift.
-- The Devil's Fiddle (the dev's own design):
--   * The Devil leaves ONE fiddle and a contract on a plate. First come, first served: whoever takes it signs the
--     contract, and the PRICE is hidden until they sign. Only one fiddle can exist (if somebody still has one,
--     this event does nothing).
--   * The fiddle is a round item: the bow is the tool's handle (right hand), the fiddle itself rides on your LEFT
--     arm (held by the neck at your side; under your chin while you play). Idle and playing animations are played
--     by the client module (EventClients > fiddle).
--   * PLAY it (click / PLAY): notes slide along a lane toward a gold box. THIS SCRIPT decides every note and judges
--     every click (the client only shows them):
--       a note hit while it is in the box   = +1% charge, costs nothing
--       a MISS = 10 HP, and it CAN knock you out: a click with nothing in the box (early, late or random), or a note
--       that slips past the box unclicked
--     The more charge you have, the faster it goes (notes come closer together and slide faster), and the rhythm
--     changes all the time (patterns of short, long and dotted notes, rests). You stand still while you play.
--   * Spend charge on a song (buttons on the panel):
--       Scarecrow Jig          6%  one random other player goes stiff for 5 s (speed -50%, no jumping)
--       Imp Pickpocket March  12%  imps snatch 1 item each from the 2 players holding the most and drop them on plates
--       Hellhound's Howl      15%  the Hellhound hunts one random other player for 8 s (two bites of 10)
--       Danse Macabre         75%  EVERY other player is seized by the tune and dances on the spot for 6 s: no walking,
--                                  no jumping, no items (nobody is knocked out by it, no event is sent at anybody)
--   * Contract prices (rolled on signing): -20 max HP for the round / every held item destroyed / the Hellhound
--     hunts YOU for 10 s / half speed or no jumping for 10 s / nothing (10%). No candles, no Soul, no outline.
--   * The fiddle burns away if its holder is knocked out, leaves, or the round ends.
-- Remote: ReplicatedStorage > Remotes > DevilsFiddle
--   client -> server: "Start" | "Stop" | "Click", serverTime | "Cast", songId
--   server -> client: "Note", id, hitTime, travel | "Judged", id?, hit, why | "Cast", songId | "Refused", text |
--                     "Stopped" | "Dance", seconds

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local ServerScriptService = game:GetService("ServerScriptService")

local K = require(ServerScriptService:WaitForChild("Systems"):WaitForChild("EventUtil"))

local Event = {
	Name = "The Devil's Fiddle",
	Id = "fiddle",
	Weight = 0.7,
	Duration = 24,
	Target = "Arena",
}

--[[DMP:KEEP Settings]]
local TUNE_ID = "113763591225213"      -- your fast fiddle tune (looped while someone plays; it speeds up with the charge). "" = silent
local SCREECH_ID = "9113888027"   -- a sour screech for a missed note. "" = a built-in stand-in
local PLUCK_ID = ""     -- a plucked note for every note hit (only heard while TUNE_ID is ""). "" = a built-in stand-in
--[[DMP:END]]

local OFFER_TIME = 20
local MISS_DAMAGE = 10
local WINDOW = 0.12           -- a hit counts this many seconds before / after a note reaches the box
local LATE_WINDOW = 0.35      -- a click up to this long after a note went by is "late" on THAT note (one miss, not two)
local GRACE = 0.3             -- a note that slipped past counts once it is this far past the window (lag)
local BEAT_SLOW, BEAT_FAST = 0.5, 0.22       -- seconds per beat at 0% / 100% charge
local TRAVEL_SLOW, TRAVEL_FAST = 1.3, 0.85   -- seconds a note slides before it reaches the box, at 0% / 100%
local MIN_GAP = 0.15          -- never two notes closer than this
local LEAD_IN = 0.6
local MAX_CLICKS_PER_SECOND = 12
local DANCE_TIME = 6

-- rhythm patterns: the beats between one note and the next, and the charge (%) a pattern starts showing up at.
-- A pattern is picked at random again and again, so the gaps keep changing; the tricky ones come in as you charge.
local PATTERNS = {
	{ Beats = { 1 }, From = 0 }, { Beats = { 1, 1 }, From = 0 }, { Beats = { 2 }, From = 0 }, { Beats = { 1.5, 0.5 }, From = 0 },
	{ Beats = { 0.5, 0.5 }, From = 0 }, { Beats = { 0.5, 0.5, 1 }, From = 0 }, { Beats = { 1, 0.5, 0.5, 1 }, From = 10 },
	{ Beats = { 0.33, 0.33, 0.34 }, From = 20 }, { Beats = { 0.75, 0.25 }, From = 35 }, { Beats = { 0.25, 0.75 }, From = 35 },
	{ Beats = { 0.5, 0.25, 0.25 }, From = 45 }, { Beats = { 0.25, 0.25, 0.5, 1 }, From = 55 },
}

-- The fiddle on the left arm and the bow in the right hand (worked out with the animation tools, see the brief)
local GRIP_IDLE = CFrame.new(0, 0, 1, 1, 0, 0, 0, 0.848, -0.5299, 0, 0.5299, 0.848)
local GRIP_PLAY = CFrame.new(0, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0)
local WELD_REST = CFrame.new(0, -2.33, -0.28, -1, 0, 0, 0, -1, 0, 0, 0, 1)
local WELD_CHIN = CFrame.new(0.9585, -0.292, 0.0132, 0.5161, 0.7706, 0.374, -0.6893, 0.6329, -0.3527, -0.5085, -0.0757, 0.8577)

export type Song = { Id: string, Name: string, Cost: number }
local SONGS: { Song } = {
	{ Id = "Scarecrow", Name = "Scarecrow Jig", Cost = 6 },
	{ Id = "Pickpocket", Name = "Imp Pickpocket March", Cost = 12 },
	{ Id = "Howl", Name = "Hellhound's Howl", Cost = 15 },
	{ Id = "Danse", Name = "Danse Macabre", Cost = 75 },
}
Event.Songs = SONGS

local PRICES = {
	{ Id = "MaxHP", Weight = 0.225 },
	{ Id = "Items", Weight = 0.225 },
	{ Id = "Hound", Weight = 0.225 },
	{ Id = "Curse", Weight = 0.225 },
	{ Id = "Nothing", Weight = 0.1 },
}

local WOOD = Color3.fromRGB(96, 36, 24)
local WOOD_DARK = Color3.fromRGB(60, 22, 16)
local EBONY = Color3.fromRGB(22, 18, 18)

---------------------------------------------------------------------
-- The one fiddle
---------------------------------------------------------------------

type Note = { Id: number, HitAt: number, Judged: boolean }
type Session = { Player: Player, Notes: { Note }, NextId: number, NextHitAt: number, Queue: { number }, Clicks: { number }, Connection: RBXScriptConnection? }

local holder: Player? = nil
local fiddle: Tool? = nil
local charge = 0
local session: Session? = nil
local tune: Sound? = nil
local rng = Random.new()
local remote = K.GetRemote("DevilsFiddle")

-- "123" or 123 -> "rbxassetid://123"; anything else as it is
local function asset(id: any): string
	local text = tostring(id or "")
	if text:match("^%d+$") then
		return "rbxassetid://" .. text
	end
	return text
end

-- puts a Tool somewhere in the world (PivotTo, or its Handle if PivotTo isn't there)
local function place(tool: Tool, cframe: CFrame)
	local ok = pcall(function()
		(tool :: any):PivotTo(cframe)
	end)
	if not ok then
		local handle = tool:FindFirstChild("Handle")
		if handle and handle:IsA("BasePart") then
			handle.CFrame = cframe
		end
	end
end

local function setCharge(value: number)
	charge = math.clamp(value, 0, 100)
	if fiddle then
		fiddle:SetAttribute("Charge", charge)
	end
end

local function oneShot(id: string, fallback: string, speed: number, volume: number)
	local handle = fiddle and fiddle:FindFirstChild("Handle")
	if not (handle and handle:IsA("BasePart")) then
		return
	end
	local sound = Instance.new("Sound")
	sound.SoundId = if id ~= "" then asset(id) else fallback
	sound.PlaybackSpeed = if id ~= "" then 1 else speed
	sound.Volume = volume
	sound.RollOffMinDistance = 10
	sound.RollOffMaxDistance = 140
	sound.Parent = handle
	sound:Play()
	game:GetService("Debris"):AddItem(sound, 3)
end

local function fiddleWeld(): Weld?
	local body = fiddle and fiddle:FindFirstChild("FiddleBody")
	local weld = body and body:FindFirstChild("ArmWeld")
	return if weld and weld:IsA("Weld") then weld else nil
end

local function stopPlaying(tell: boolean?)
	local current = session
	if not current then
		return
	end
	session = nil
	if current.Connection then
		current.Connection:Disconnect()
	end
	if tune then
		tune:Stop()
	end
	K.Unmod(current.Player, "FiddlePlayingWalk")
	K.Unmod(current.Player, "FiddlePlayingJump")
	local weld = fiddleWeld()
	if weld then
		weld.C0 = WELD_REST
	end
	if fiddle then
		fiddle.Grip = GRIP_IDLE
		fiddle:SetAttribute("Playing", false)
	end
	if tell and current.Player.Parent == Players then
		remote:FireClient(current.Player, "Stopped")
	end
end

local function burnFiddle(reason: string?)
	stopPlaying(true)
	local tool = fiddle
	local owner = holder
	fiddle, holder, tune = nil, nil, nil
	charge = 0
	if tool then
		tool:Destroy()
	end
	if owner and reason and owner.Parent == Players then
		K.Tell(owner, "The Devil's Fiddle", reason, K.Colors.Warn)
	end
end

local function makePart(name: string, size: Vector3, color: Color3, material: Enum.Material): Part
	local part = Instance.new("Part")
	part.Name = name
	part.Size = size
	part.Color = color
	part.Material = material
	part.CanCollide = false
	part.CanQuery = false
	part.CanTouch = false
	part.Massless = true
	part.CastShadow = false
	part.TopSurface = Enum.SurfaceType.Smooth
	part.BottomSurface = Enum.SurfaceType.Smooth
	return part
end

local function weldTo(base: BasePart, part: BasePart, offset: CFrame, parent: Instance)
	part.CFrame = base.CFrame * offset
	local weld = Instance.new("WeldConstraint")
	weld.Part0 = base
	weld.Part1 = part
	weld.Parent = part
	part.Parent = parent
end

local function makeFiddle(): Tool
	local tool = Instance.new("Tool")
	tool.Name = "Devil's Fiddle"
	tool.ToolTip = "Click to play. Hit every note: a miss costs 10 HP"
	tool.CanBeDropped = false
	tool.RequiresHandle = true
	tool.Grip = GRIP_IDLE
	tool:SetAttribute("DMPFiddle", true)
	tool:SetAttribute("Charge", 0)
	tool:SetAttribute("Playing", false)
	-- the bow (the Handle is its stick)
	local handle = makePart("Handle", Vector3.new(0.08, 0.08, 2.4), EBONY, Enum.Material.Wood)
	handle.CanTouch = true
	handle.Parent = tool
	weldTo(handle, makePart("BowHair", Vector3.new(0.04, 0.03, 2.05), Color3.fromRGB(226, 220, 200), Enum.Material.Fabric), CFrame.new(0, -0.13, -0.1), tool)
	weldTo(handle, makePart("BowFrog", Vector3.new(0.12, 0.2, 0.24), Color3.fromRGB(30, 24, 24), Enum.Material.Wood), CFrame.new(0, -0.07, 1.0), tool)
	-- the fiddle (rides on the left arm while equipped, see attach / detach)
	local body = makePart("FiddleBody", Vector3.new(0.62, 0.5, 0.2), WOOD, Enum.Material.Wood)
	body.CFrame = handle.CFrame * CFrame.new(0, 0, -1.5)
	body.Parent = tool
	local pieces = {
		{ "FiddleUpper", Vector3.new(0.5, 0.38, 0.2), Vector3.new(0, -0.54, 0), WOOD },
		{ "FiddleWaist", Vector3.new(0.4, 0.22, 0.18), Vector3.new(0, -0.28, 0), WOOD_DARK },
		{ "FiddleNeck", Vector3.new(0.1, 0.7, 0.1), Vector3.new(0, -1.08, -0.04), WOOD_DARK },
		{ "FiddleBoard", Vector3.new(0.12, 0.95, 0.04), Vector3.new(0, -0.83, -0.13), EBONY },
		{ "FiddleScroll", Vector3.new(0.14, 0.24, 0.16), Vector3.new(0, -1.52, -0.02), WOOD_DARK },
		{ "FiddleTail", Vector3.new(0.18, 0.18, 0.05), Vector3.new(0, 0.2, -0.12), EBONY },
		{ "FiddleStrings", Vector3.new(0.06, 1.25, 0.02), Vector3.new(0, -0.48, -0.16), Color3.fromRGB(200, 196, 180) },
	}
	for _, piece in pieces do
		weldTo(body, makePart(piece[1], piece[2], piece[4], Enum.Material.Wood), CFrame.new(piece[3]), tool)
	end
	local hold = Instance.new("WeldConstraint") -- keeps the fiddle with the bow while it is in the backpack
	hold.Name = "BodyHold"
	hold.Part0 = handle
	hold.Part1 = body
	hold.Parent = body
	local sound = Instance.new("Sound")
	sound.Name = "Tune"
	sound.SoundId = asset(TUNE_ID)
	sound.Looped = true
	sound.Volume = 0.8
	sound.RollOffMinDistance = 12
	sound.RollOffMaxDistance = 140
	sound.Parent = handle
	tune = sound
	return tool
end

-- the fiddle onto the left arm while equipped (and back onto the bow when it goes into the backpack)
local function attach(tool: Tool)
	local character = tool.Parent
	local arm = character and character:FindFirstChild("Left Arm")
	local body = tool:FindFirstChild("FiddleBody")
	if not (arm and arm:IsA("BasePart") and body and body:IsA("BasePart")) then
		return
	end
	local hold = body:FindFirstChild("BodyHold")
	if hold then
		hold:Destroy()
	end
	local weld = body:FindFirstChild("ArmWeld") :: Weld?
	if not weld then
		weld = Instance.new("Weld")
		weld.Name = "ArmWeld"
	end
	local armWeld = weld :: Weld
	armWeld.Part0 = arm
	armWeld.Part1 = body
	armWeld.C0 = if session then WELD_CHIN else WELD_REST
	armWeld.C1 = CFrame.new()
	armWeld.Parent = body
	tool.Grip = if session then GRIP_PLAY else GRIP_IDLE
end

local function detach(tool: Tool)
	local body = tool:FindFirstChild("FiddleBody")
	local handle = tool:FindFirstChild("Handle")
	if not (body and body:IsA("BasePart") and handle and handle:IsA("BasePart")) then
		return
	end
	local weld = body:FindFirstChild("ArmWeld")
	if weld then
		weld:Destroy()
	end
	if not body:FindFirstChild("BodyHold") then
		body.CFrame = handle.CFrame * CFrame.new(0, 0, -1.5)
		local hold = Instance.new("WeldConstraint")
		hold.Name = "BodyHold"
		hold.Part0 = handle
		hold.Part1 = body
		hold.Parent = body
	end
end

---------------------------------------------------------------------
-- Playing: the notes, the clicks, the misses
---------------------------------------------------------------------

local function fraction(): number
	return math.clamp(charge / 100, 0, 1)
end

local function nextGap(current: Session): number
	if #current.Queue == 0 then
		local open = {}
		for _, pattern in PATTERNS do
			if charge >= pattern.From then
				table.insert(open, pattern)
			end
		end
		for _, beats in open[rng:NextInteger(1, #open)].Beats do
			table.insert(current.Queue, beats)
		end
	end
	local beats = table.remove(current.Queue, 1) :: number
	local beat = BEAT_SLOW + (BEAT_FAST - BEAT_SLOW) * fraction()
	return math.max(MIN_GAP, beats * beat)
end

local function hit(player: Player, note: Note)
	note.Judged = true
	setCharge(charge + 1)
	remote:FireClient(player, "Judged", note.Id, true, "hit")
	if TUNE_ID == "" then
		oneShot(PLUCK_ID, "rbxasset://sounds/electronicpingshort.wav", 0.8 + rng:NextNumber() * 0.6, 0.35)
	end
end

local function miss(player: Player, note: Note?, why: string)
	if note then
		note.Judged = true
	end
	remote:FireClient(player, "Judged", if note then note.Id else 0, false, why)
	oneShot(SCREECH_ID, "rbxasset://sounds/swordslash.wav", 2.2, 0.6)
	local _, humanoid = K.Root(player)
	if humanoid and K.IsAlive(player) then
		-- exactly 10, straight off your health: playing it wrong CAN knock you out
		humanoid.Health = math.max(humanoid.Health - MISS_DAMAGE, 0)
	end
end

local function step()
	local current = session
	if not current then
		return
	end
	local player = current.Player
	local tool = fiddle
	if not (tool and K.IsAlive(player) and tool.Parent == player.Character) then
		stopPlaying(true)
		return
	end
	local now = K.Now()
	local travel = TRAVEL_SLOW + (TRAVEL_FAST - TRAVEL_SLOW) * fraction()
	while current.NextHitAt - now <= travel + 0.1 do
		current.NextId += 1
		local note: Note = { Id = current.NextId, HitAt = current.NextHitAt, Judged = false }
		table.insert(current.Notes, note)
		remote:FireClient(player, "Note", note.Id, note.HitAt, travel)
		current.NextHitAt += nextGap(current)
	end
	for index = #current.Notes, 1, -1 do
		local note = current.Notes[index]
		if not note.Judged and now > note.HitAt + WINDOW + GRACE then
			miss(player, note, "passed")
			if session ~= current then
				return
			end
		end
		if note.Judged and now > note.HitAt + 2 then
			table.remove(current.Notes, index)
		end
	end
	if tune then
		tune.PlaybackSpeed = 1 + 0.5 * fraction()
	end
end

-- The tune starts where your charge is: 50% charge = halfway through the song. (Sound:Play() always starts at 0, so
-- this is set right after it. The server may still be loading the sound the first time: then it waits for that.)
local function seekTune(sound: Sound)
	local function seek()
		local length = sound.TimeLength
		if length > 0 and sound.IsPlaying and session then
			sound.TimePosition = math.clamp(fraction(), 0, 0.97) * length
		end
	end
	if sound.TimeLength > 0 then
		seek()
	else
		sound.Loaded:Once(seek)
	end
end

local function startPlaying(player: Player)
	if session or not fiddle then
		return
	end
	local tool = fiddle :: Tool
	session = {
		Player = player, Notes = {}, NextId = 0, NextHitAt = K.Now() + LEAD_IN + TRAVEL_SLOW, Queue = {}, Clicks = {}, Connection = nil,
	}
	K.Mod(player, "WalkSpeed", { Mult = 0 }, "FiddlePlayingWalk")
	K.Mod(player, "Jump", { Mult = 0 }, "FiddlePlayingJump")
	local weld = fiddleWeld()
	if weld then
		weld.C0 = WELD_CHIN
	end
	tool.Grip = GRIP_PLAY
	tool:SetAttribute("Playing", true)
	if tune and tune.SoundId ~= "" then
		tune.PlaybackSpeed = 1 + 0.5 * fraction()
		tune:Play()
		seekTune(tune)
	end
	local current = session :: Session
	current.Connection = RunService.Heartbeat:Connect(step)
end

local function click(player: Player, at: any)
	local current = session
	if not current or current.Player ~= player then
		return
	end
	local now = K.Now()
	local t = if type(at) == "number" and at == at then math.clamp(at, now - 1, now + 0.1) else now
	local clock = os.clock()
	while #current.Clicks > 0 and clock - current.Clicks[1] > 1 do
		table.remove(current.Clicks, 1)
	end
	if #current.Clicks >= MAX_CLICKS_PER_SECOND then
		return
	end
	table.insert(current.Clicks, clock)
	local best: Note? = nil
	local bestGap = math.huge
	for _, note in current.Notes do
		local gap = math.abs(t - note.HitAt)
		if not note.Judged and gap <= WINDOW and gap < bestGap then
			best, bestGap = note, gap
		end
	end
	if best then
		hit(player, best)
		return
	end
	for _, note in current.Notes do
		local late = t - note.HitAt
		if not note.Judged and late > WINDOW and late <= LATE_WINDOW then
			miss(player, note, "late")
			return
		end
	end
	miss(player, nil, "nothing")
end

---------------------------------------------------------------------
-- Songs and prices
---------------------------------------------------------------------

local function others(player: Player): { Player }
	local list = {}
	for _, other in K.Alive() do
		if other ~= player then
			table.insert(list, other)
		end
	end
	return list
end

local function burst(player: Player, color: Color3, count: number)
	local root = K.Root(player)
	if not root then
		return
	end
	local emitter = Instance.new("ParticleEmitter")
	emitter.Texture = "rbxasset://textures/particles/sparkles_main.dds"
	emitter.Color = ColorSequence.new(color)
	emitter.Lifetime = NumberRange.new(0.4, 0.8)
	emitter.Speed = NumberRange.new(4, 10)
	emitter.SpreadAngle = Vector2.new(180, 180)
	emitter.Size = NumberSequence.new(0.4, 0)
	emitter.Enabled = false
	emitter.Parent = root
	emitter:Emit(count)
	game:GetService("Debris"):AddItem(emitter, 1.2)
end

local function hound(prey: Player, seconds: number, bites: number, damage: number, name: string)
	local events = ServerScriptService:FindFirstChild("Events")
	local module = events and events:FindFirstChild("Hellhound", true)
	if not (module and module:IsA("ModuleScript")) then
		warn("[The Devil's Fiddle] Events > Hellhound is missing")
		return
	end
	local ok, Hellhound = pcall(require, module)
	if not (ok and type(Hellhound) == "table" and type(Hellhound.Hunt) == "function") then
		warn("[The Devil's Fiddle] Events > Hellhound has no Hunt (use the Oct 8 update 3 copy)")
		return
	end
	local context = K.Detached("hellhound", name, seconds + 3)
	task.spawn(Hellhound.Hunt, context, { Prey = prey, Seconds = seconds, Bites = bites, Damage = damage, Intro = 1 })
end

-- a round item that can lie on a plate (Tools with a Handle only)
local function heldItems(player: Player): { Tool }
	local list: { Tool } = {}
	for _, container in { player:FindFirstChildOfClass("Backpack"), player.Character } do
		if container then
			for _, item in container:GetChildren() do
				if item:IsA("Tool") and not item:GetAttribute("DMPFiddle") and item:FindFirstChild("Handle") then
					table.insert(list, item)
				end
			end
		end
	end
	return list
end

local function dropOnPlate(tool: Tool)
	local plate = K.Pick(K.Plates())
	local handle = tool:FindFirstChild("Handle")
	if not (plate and handle and handle:IsA("BasePart")) then
		tool:Destroy()
		return
	end
	local spot = K.PointOn(plate, 3)
	tool.Parent = workspace
	local wasCollide = handle.CanCollide
	handle.CanCollide = true
	handle.Anchored = false
	place(tool, CFrame.new(spot + Vector3.new(0, 1.5, 0)))
	local connection: RBXScriptConnection
	connection = tool.AncestryChanged:Connect(function()
		if tool.Parent ~= workspace then
			connection:Disconnect()
			handle.CanCollide = wasCollide
		end
	end)
end

local function danseMacabre(player: Player): (boolean, string?)
	local victims = others(player)
	if #victims == 0 then
		return false, "Nobody to dance."
	end
	for _, victim in victims do
		K.Mod(victim, "WalkSpeed", { Mult = 0 }, "DanseMacabreWalk", DANCE_TIME)
		K.Mod(victim, "Jump", { Mult = 0 }, "DanseMacabreJump", DANCE_TIME)
		remote:FireClient(victim, "Dance", DANCE_TIME)
		burst(victim, Color3.fromRGB(120, 60, 160), 26)
		K.Tell(victim, "Danse Macabre", player.DisplayName .. "'s fiddle has you: you dance on the spot for " .. DANCE_TIME .. " seconds. No walking, no jumping, no items.", K.Colors.Purple)
	end
	-- no items while they dance
	task.spawn(function()
		local ends = os.clock() + DANCE_TIME
		while os.clock() < ends do
			for _, victim in victims do
				if K.IsAlive(victim) then
					local _, humanoid = K.Root(victim)
					if humanoid then
						humanoid:UnequipTools()
					end
				end
			end
			task.wait(0.15)
		end
	end)
	return true, nil
end

-- returns false (and why) when the song could not be played; the charge is only spent when it returns true
local function playSong(player: Player, song: Song): (boolean, string?)
	if song.Id == "Scarecrow" then
		local victim = K.Pick(others(player))
		if not victim then
			return false, "Nobody to play it for."
		end
		K.Mod(victim, "WalkSpeed", { Mult = 0.5 }, "ScarecrowJigWalk", 5)
		K.Mod(victim, "Jump", { Mult = 0 }, "ScarecrowJigJump", 5)
		burst(victim, Color3.fromRGB(200, 170, 90), 30)
		K.Tell(victim, "Scarecrow Jig", "The fiddle plays and you go stiff as straw for 5 seconds.", K.Colors.Warn)
		return true
	elseif song.Id == "Pickpocket" then
		local counts: { { Player: Player, Items: { Tool } } } = {}
		for _, other in others(player) do
			local items = heldItems(other)
			if #items > 0 then
				table.insert(counts, { Player = other, Items = items })
			end
		end
		if #counts == 0 then
			return false, "Nobody has anything to snatch."
		end
		table.sort(counts, function(a, b)
			return #a.Items > #b.Items
		end)
		for index = 1, math.min(2, #counts) do
			local entry = counts[index]
			local item = entry.Items[math.random(1, #entry.Items)]
			local itemName = item.Name
			burst(entry.Player, Color3.fromRGB(60, 50, 50), 20)
			dropOnPlate(item)
			K.Tell(entry.Player, "Imp Pickpocket March", "An imp snatched your " .. itemName .. " and dropped it on a plate somewhere!", K.Colors.Warn)
		end
		return true
	elseif song.Id == "Howl" then
		local victim = K.Pick(others(player))
		if not victim then
			return false, "Nobody to play it for."
		end
		K.Tell(victim, "Hellhound's Howl", "Something heard the fiddle. Keep moving.", K.Colors.Warn)
		hound(victim, 8, 2, 10, "Hellhound's Howl")
		return true
	elseif song.Id == "Danse" then
		return danseMacabre(player)
	end
	return false, "Unknown song."
end

local function pickPrice(): string
	local total = 0
	for _, price in PRICES do
		total += price.Weight
	end
	local roll = math.random() * total
	for _, price in PRICES do
		roll -= price.Weight
		if roll <= 0 then
			return price.Id
		end
	end
	return "Nothing"
end

local function payPrice(player: Player): string
	local price = pickPrice()
	if price == "MaxHP" then
		K.Mod(player, "MaxHealth", { Add = -20 }, "FiddlePrice")
		return "The price: 20 max HP, until the round ends."
	elseif price == "Items" then
		local lost = 0
		for _, container in { player:FindFirstChildOfClass("Backpack"), player.Character } do
			if container then
				for _, item in container:GetChildren() do
					if item:IsA("Tool") and not item:GetAttribute("DMPFiddle") then
						item:Destroy()
						lost += 1
					end
				end
			end
		end
		return if lost > 0 then "The price: every item you were holding." else "The price: every item you were holding. (You had none. Lucky.)"
	elseif price == "Hound" then
		hound(player, 10, 2, 10, "The Devil's Fiddle")
		return "The price: something is hunting you. Keep moving."
	elseif price == "Curse" then
		if math.random() < 0.5 then
			K.Mod(player, "WalkSpeed", { Mult = 0.5 }, "FiddleCurseWalk", 10)
			return "The price: half speed for 10 seconds."
		end
		K.Mod(player, "Jump", { Mult = 0 }, "FiddleCurseJump", 10)
		return "The price: no jumping for 10 seconds."
	end
	return "The price: nothing. The Devil is in a good mood today."
end

-- makes the one fiddle and puts it in that player's Backpack
local function give(player: Player): Tool
	local tool = makeFiddle()
	fiddle = tool
	holder = player
	setCharge(0)
	tool.Equipped:Connect(function()
		attach(tool)
	end)
	tool.Unequipped:Connect(function()
		stopPlaying(true)
		detach(tool)
	end)
	tool.AncestryChanged:Connect(function()
		if fiddle == tool and not tool:IsDescendantOf(game) then
			burnFiddle(nil)
		end
	end)
	local backpack = player:FindFirstChildOfClass("Backpack")
	tool.Parent = backpack or player.Character
	return tool
end

local function sign(player: Player)
	local priceText = payPrice(player)
	give(player)
	K.Tell(player, "You signed.", priceText .. " Equip the fiddle and click to play. Hit the notes: every miss costs 10 HP.", K.Colors.Warn)
end

-- Hands the fiddle to a player with no contract and no price (/givefiddle, the 5th floor of the Hellgate Lift).
-- There is only ever ONE fiddle: whoever had it loses it. Returns the Tool, or nil when it could not be given
-- (no character and no Backpack yet). Like the offered one, it can only be played by somebody alive in a round.
function Event.Give(player: Player): Tool?
	if holder == player and fiddle then
		return fiddle
	end
	if not (player:FindFirstChildOfClass("Backpack") or player.Character) then
		return nil
	end
	if fiddle then
		burnFiddle("The Devil took his fiddle back.")
	end
	return give(player)
end

-- who has the fiddle right now (nil = nobody)
function Event.Holder(): Player?
	return if fiddle then holder else nil
end

---------------------------------------------------------------------
-- The fiddle's panel talks to us through the remote
---------------------------------------------------------------------

remote.OnServerEvent:Connect(function(player: Player, action: any, value: any)
	if player ~= holder or not fiddle or not K.IsAlive(player) then
		return
	end
	local tool = fiddle :: Tool
	local equipped = tool.Parent == player.Character
	if action == "Start" then
		if equipped then
			startPlaying(player)
		end
	elseif action == "Stop" then
		stopPlaying(false)
	elseif action == "Click" then
		if equipped then
			click(player, value)
		end
	elseif action == "Cast" then
		local song: Song? = nil
		for _, entry in SONGS do
			if entry.Id == value then
				song = entry
			end
		end
		if not song then
			return
		end
		if charge < song.Cost then
			remote:FireClient(player, "Refused", "Not enough charge for " .. song.Name .. ".")
			return
		end
		local ok, why = playSong(player, song)
		if ok then
			setCharge(charge - song.Cost)
			remote:FireClient(player, "Cast", song.Id)
		else
			remote:FireClient(player, "Refused", why or "It didn't work.")
		end
	end
end)

-- (a frame later: Systems are not required while EventSystem is still loading the events)
task.defer(function()
	-- /givefiddle [target]   (admins only, like every command registered through Systems > Commands)
	local Commands = K.Sys("Commands")
	if Commands and type(Commands.Register) == "function" then
		local ok, problem = pcall(Commands.Register, "/givefiddle", function(player: Player, args: { string })
			local target = Commands.TakeTarget(player, args)
			if not target then
				return
			end
			if Event.Give(target) then
				Commands.Reply(player, ("Gave The Devil's Fiddle to %s (no contract, no price). It can only be played in a round."):format(target.DisplayName))
			else
				Commands.Reply(player, "Couldn't give the fiddle to " .. target.DisplayName .. " (no Backpack yet?).", true)
			end
		end)
		if not ok then
			warn("[The Devil's Fiddle] couldn't register /givefiddle: " .. tostring(problem))
		end
	end
	local RoundHooks = K.Sys("RoundHooks")
	if RoundHooks then
		if type(RoundHooks.OnEliminated) == "function" then
			RoundHooks.OnEliminated(function(player: Player)
				if player == holder then
					burnFiddle("Your fiddle burned away.")
				end
			end)
		end
		if type(RoundHooks.OnEnd) == "function" then
			RoundHooks.OnEnd(function()
				burnFiddle(nil)
			end)
		end
	end
end)
Players.PlayerRemoving:Connect(function(player: Player)
	if player == holder then
		burnFiddle(nil)
	end
end)

---------------------------------------------------------------------
-- The event: the offer
---------------------------------------------------------------------

function Event.Run(context)
	local t0 = K.Start(context)
	if holder and fiddle then
		return -- only one fiddle can exist
	end
	local plates = K.Plates()
	local plate = K.Pick(plates)
	if not plate then
		return
	end
	local spot = K.PointOn(plate, 4)
	local facing = CFrame.lookAt(spot, spot + K.Dir(K.Arena(plates) - spot, Vector3.new(0, 0, -1)))
	local id = K.Show(context, "Offer", facing, { T0 = t0, Open = OFFER_TIME })
	if not K.WaitUntil(context, t0 + 1.5) then
		return
	end
	local _, prompt = K.Prompt(spot + Vector3.new(0, 2.5, 0), "Take the fiddle", "The Devil's contract (price hidden)", 0.8, context.Folder)
	prompt.MaxActivationDistance = 9
	local taken = false
	context.Trash.Add(prompt.Triggered:Connect(function(player: Player)
		if taken or holder or not K.IsAlive(player) then
			return
		end
		taken = true
		prompt.Enabled = false
		K.Call(context, id, "Taken", player.UserId)
		K.Complete(context, player)
		sign(player)
	end))
	local deadline = t0 + 1.5 + OFFER_TIME
	while context.IsRunning() and not taken and K.Now() < deadline do
		task.wait(0.2)
	end
	if not taken and context.IsRunning() then
		prompt.Enabled = false
		K.Call(context, id, "Fade")
	end
	K.Hold(context)
end

return Event
