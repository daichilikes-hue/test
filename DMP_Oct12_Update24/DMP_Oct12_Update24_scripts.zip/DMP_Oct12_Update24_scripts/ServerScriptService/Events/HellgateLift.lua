-- ModuleScript: ServerScriptService > Events > HellgateLift     (/setevent hellgate)
-- THE HELLGATE LIFT (the Haunted Elevator, made gritty). A rusted iron cage comes down out of the dark on chains
-- and stops beside an outer plate, its floor level with the plate. A brazier burns on top of it with a RELIC in
-- the fire. Far below, in the dark, a pair of iron doors sits closed, firelight leaking through the cracks.
--   Walk in. On the wall by the door is a PANEL with five buttons: use it and pick the floor you want, and the cage
--   goes straight there (LEVELS floors, STOP_DEPTH studs apart). An iron ladder runs down beside it from the
--   plate's edge: climb out at any floor, or drop in from above.
--   From INSIDE the cage you can reach up and take the relic (hold the prompt). The deeper the floor, the bigger
--   the prize. But taking it springs the trap: the iron shutters SLAM, the chains snap and the cage drops through
--   the Hellgate with everybody inside it (the one who took it too). The deeper the floor, the worse that is.
--   FLOOR 5 is the Devil's: what burns on the cage there is his FIDDLE. Taking it costs HALF your max health for
--   the rest of the round, and nothing else: nobody goes to hell from floor 5.
--   Nobody takes anything? After STAY seconds the shutters slam anyway: don't be in it. (The cage shudders and its
--   chains rattle for the last WARN seconds, so nobody is caught by a clock they cannot see.)
-- Oct 11 2026 (update 12), your list: "the players can choose the direct destination they want to go to, 1,2,3,4
-- etc. And ... a 5th level, costing HALF your max hp and in return, it grants you the devil's fiddle". (Before, the
-- cage ground one stop deeper by itself every 6 seconds.) The floor is picked with the game's own choice buttons
-- (Systems > EventChoice). The cage, the panel and the doors are a model now (Lift, under this script).
-- Punishment (by floor): a trip to the Pocket Dimension (workspace.Map.PocketDimension, the Old Man's) turned into
-- hell: survive the timer while the floor erupts under you, then you crawl back out onto a plate; and / or a max
-- health loss for the rest of the round. No Pocket Dimension in the map: a bigger max health loss instead.
-- Nothing marks the danger: the doors below, the shutters and your own greed.
-- The cage, the ladder and the walls are solid on every client (like the Flying Dutchman's deck); the server
-- works out who is inside with the same maths. What it looks like: ReplicatedStorage > EventClients > hellgate.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

-- THE CAGE AND ITS TIMES (sent to the clients in props; liftY() below is copied there: KEEP IN SYNC)
local LEVELS = 5            -- floors. 1 = level with the plate; 5 = the Devil's floor (the fiddle)
local STOP_DEPTH = 1        -- studs between floors
local CAGE_W, CAGE_D, CAGE_H = 10, 8, 8   -- inside: wide (along the plate's edge), deep, tall. (The model Lift is built to these.)
local GAP = 2               -- the ladder hangs in this gap between the plate's edge and the cage
local ARRIVE = 3            -- seconds it takes to come down out of the dark to floor 1
local TRAVEL = 1.0          -- seconds per floor it travels (it goes STRAIGHT to the floor that was picked: 1 to 4 takes 3 s)
local PAUSE = 1.5           -- seconds it rests at a floor before it obeys the panel again (time to grab what burns on it)
local STAY = 30             -- seconds it waits for somebody to take what burns on it. Then the shutters slam anyway
local WARN = 5              -- ... and for this many seconds before that the cage shudders and the chains rattle
local ASK_TIME = 8          -- seconds you get to pick a floor once you have used the panel
local SLAM = 0.6            -- seconds from the shutters slamming to the chains snapping
local FALL = 70             -- how fast it falls (studs / second / second)
local LAST = ARRIVE + STAY  -- the shutters slam anyway
local FIDDLE_FLOOR = 5      -- the floor where the Devil's Fiddle is what burns on the cage (LEVELS = 4: there is no such floor)
local FIDDLE_COST = 0.5     -- ... and what it costs: this much of your MAX health, for the rest of the round
local FIDDLE_STEALS = true  -- somebody already has the fiddle (there is only ever one): taking it here takes it off them.
                            -- false = the Devil's floor is shut while somebody has it
local COST_WORDS = if FIDDLE_COST == 0.5 then "HALF" else math.floor(FIDDLE_COST * 100 + 0.5) .. "% of"   -- ("It cost HALF your max health")

-- what taking the relic is worth, by floor (1 = level with the plate). Floor 5 is the fiddle (FIDDLE_COST above).
local REWARDS = {
	{ Candles = 10, Items = 0, Words = "10 candles" },
	{ Candles = 20, Items = 1, Words = "20 candles and an item" },
	{ Candles = 35, Items = 1, Words = "35 candles and an item" },
	{ Candles = 50, Items = 2, Words = "50 candles and two items" },
	{ Candles = 0, Items = 0, Words = "the Devil's Fiddle" },
}
-- what the drop costs everybody in the cage, by floor: seconds in hell, and max health lost for the round
-- (floor 5: nothing. The one who takes the fiddle pays for it, nobody else does.)
local PUNISH = {
	{ Trip = 0, MaxHealth = 10 },
	{ Trip = 10, MaxHealth = 10 },
	{ Trip = 15, MaxHealth = 15 },
	{ Trip = 20, MaxHealth = 25 },
	{ Trip = 0, MaxHealth = 0 },
}
local NO_ROOM = { 15, 20, 30, 40, 0 }   -- max health lost instead, when the map has no Pocket Dimension
local ERUPT_EVERY = 1.2     -- in hell: seconds between eruptions near each player
local ERUPT_TELL = 0.8      -- the floor glows and crackles this long first
local ERUPT_RADIUS = 4.5
local ERUPT_DAMAGE = 8      -- (Fire: Vampires take double, Ghosts half)
local EMBER = Color3.fromRGB(214, 110, 52)

-- A ride: the cage goes from height From to height To (studs above the plate top), starting At (seconds since the
-- event began) and taking Time seconds. Before the first one it rests at 0.
type Ride = { From: number, To: number, At: number, Time: number }

-- the cage floor's height (studs above the plate top) at time t. ride = the last ride it was sent on;
-- trapAt = when the shutters slammed (or nil).
-- KEEP IN SYNC with liftY() in EventClients > hellgate.
local function liftY(t: number, ride: Ride, trapAt: number?): number
	if trapAt and t >= trapAt then
		local fall = math.max(t - trapAt - SLAM, 0)
		return liftY(trapAt, ride, nil) - 0.5 * FALL * fall * fall
	end
	if t < ARRIVE then
		return 30 * (1 - math.max(t, 0) / ARRIVE) ^ 3
	end
	if ride.Time <= 0 or t >= ride.At + ride.Time then
		return ride.To
	end
	local u = math.clamp((t - ride.At) / ride.Time, 0, 1)
	return ride.From + (ride.To - ride.From) * (u * u * (3 - 2 * u))
end

-- the plates on the outside of the arena, and which way is "out" from each
local function outerSpots(plates: { BasePart }): { { Plate: BasePart, Out: Vector3 } }
	local minX, maxX, minZ, maxZ = math.huge, -math.huge, math.huge, -math.huge
	for _, plate in plates do
		minX = math.min(minX, plate.Position.X - plate.Size.X / 2)
		maxX = math.max(maxX, plate.Position.X + plate.Size.X / 2)
		minZ = math.min(minZ, plate.Position.Z - plate.Size.Z / 2)
		maxZ = math.max(maxZ, plate.Position.Z + plate.Size.Z / 2)
	end
	local spots = {}
	for _, plate in plates do
		local hx, hz = plate.Size.X / 2, plate.Size.Z / 2
		if plate.Position.X + hx >= maxX - 0.5 then
			table.insert(spots, { Plate = plate, Out = Vector3.new(1, 0, 0) })
		end
		if plate.Position.X - hx <= minX + 0.5 then
			table.insert(spots, { Plate = plate, Out = Vector3.new(-1, 0, 0) })
		end
		if plate.Position.Z + hz >= maxZ - 0.5 then
			table.insert(spots, { Plate = plate, Out = Vector3.new(0, 0, 1) })
		end
		if plate.Position.Z - hz <= minZ + 0.5 then
			table.insert(spots, { Plate = plate, Out = Vector3.new(0, 0, -1) })
		end
	end
	return spots
end

local hellCount = 0
type Hell = { Character: Model, MaxHealth: number, NextErupt: number }

-- (a list that is shorter than LEVELS: the deeper floors use its last line)
local function tierOf<T>(list: { T }, floor: number): T
	return list[math.clamp(floor, 1, #list)]
end

-- The Devil's Fiddle event (Events > DevilsFiddle) hands the fiddle over: its Give() came with update 8.
-- nil = it cannot, so the Devil's floor stays shut (and Output says why, in plain words).
local function fiddleEvent(): any
	if FIDDLE_FLOOR > LEVELS then
		return nil
	end
	local module = script.Parent:FindFirstChild("DevilsFiddle")
	local ok, event = pcall(function()
		return (require :: any)(module)
	end)
	if ok and type(event) == "table" and type(event.Give) == "function" then
		return event
	end
	warn("[Hellgate Lift] ServerScriptService > Events > DevilsFiddle is missing or an OLDER copy than this event was made for, so floor " .. FIDDLE_FLOOR
		.. " (the fiddle) stays shut. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
	return nil
end

return {
	Name = "The Hellgate Lift",
	Id = "hellgate",
	Weight = 0.6,
	Duration = 56,   -- (long enough for somebody trapped at the bottom to serve their whole time in hell)
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		-- (plain words instead of a cage nobody can see or stand on, when the update was not installed whole)
		local assets = game:GetService("ReplicatedStorage"):FindFirstChild("EventAssets")
		local mine = assets and assets:FindFirstChild("hellgate")
		if not (mine and mine:FindFirstChild("Lift")) then
			warn("[Hellgate Lift] the model 'Lift' is missing under ServerScriptService > Events > HellgateLift, so the event is skipped. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
			return
		end
		local spot = K.Pick(outerSpots(K.Plates()))
		if not spot then
			return
		end
		local plate, out = spot.Plate, spot.Out
		local half = math.abs(out.X) * plate.Size.X / 2 + math.abs(out.Z) * plate.Size.Z / 2
		local edge = K.TopCentre(plate) + out * half
		local frame = CFrame.lookAt(edge, edge + out) -- -Z = out over the void, where the cage hangs
		local cageZ = -(GAP + CAGE_D / 2)
		local room = K.PocketRoom()
		local devil = fiddleEvent()                                  -- (nil: there is no Devil's floor this time)
		local EventChoice = K.Sys("EventChoice")                     -- the game's own choice buttons

		local id = K.Show(context, "Lift", frame, {
			T0 = t0, Levels = LEVELS, Depth = STOP_DEPTH, W = CAGE_W, D = CAGE_D, H = CAGE_H, Gap = GAP,
			Arrive = ARRIVE, Slam = SLAM, Fall = FALL, Last = LAST, Warn = WARN, Devil = if devil then FIDDLE_FLOOR else 0,
		})
		K.TellAll("The Hellgate Lift", "A rusted cage has come down out of the dark. Something burns on top of it.", EMBER)

		local trapAt: number? = nil
		local inHell: { [Player]: Hell } = {}
		local level = 1                                              -- the floor it is at, or on its way to
		local ride: Ride = { From = 0, To = 0, At = ARRIVE, Time = 0 }
		local wanted: number? = nil                                  -- a floor somebody picked that it has not set off for yet
		local stopped = 0                                            -- the floor the clients were last told it came to rest at
		local obeyAt = ARRIVE                                        -- when it next does what the panel says (PAUSE after every ride)
		local asking: { [Player]: boolean } = {}                     -- (the floor buttons are on their screen right now)
		-- every toast of this event at most once per player
		local told: { [string]: { [Player]: boolean } } = { Ride = {}, Devil = {}, Reach = {}, Panel = {}, Have = {} }
		local function tellOnce(kind: string, player: Player, title: string, text: string)
			if not told[kind][player] then
				told[kind][player] = true
				K.Tell(player, title, text, EMBER)
			end
		end

		local anchor, prompt = K.Prompt(frame.Position, "Take the relic", "The Hellgate Lift", 1, context.Folder)
		prompt.MaxActivationDistance = 12
		prompt.Enabled = false
		-- the panel on the cage wall: use it to pick a floor. (Its own key, F / Y on a gamepad, and always shown,
		-- so it and the relic's prompt can both be on your screen: with the same key Roblox shows only the nearer one.)
		local panelAnchor, panelPrompt = K.Prompt(frame.Position, "Pick a floor", "The panel", 0, context.Folder)
		panelPrompt.MaxActivationDistance = 6
		panelPrompt.KeyboardKeyCode = Enum.KeyCode.F
		panelPrompt.GamepadKeyCode = Enum.KeyCode.ButtonY
		panelPrompt.Exclusivity = Enum.ProximityPromptExclusivity.AlwaysShow
		panelPrompt.Enabled = false

		-- is that player inside the cage right now?
		local function inside(root: BasePart, feetY: number, t: number): boolean
			local rel = frame:PointToObjectSpace(root.Position)
			local floor = frame.Position.Y + liftY(t, ride, trapAt)
			return math.abs(rel.X) <= CAGE_W / 2 + 0.5 and rel.Z <= -GAP + 0.15 and rel.Z >= -(GAP + CAGE_D) - 0.5
				and feetY >= floor - 2 and feetY <= floor + CAGE_H
		end
		local function riders(t: number): { Player }
			local list = {}
			K.Each(function(player, root, _, feetY)
				if not inHell[player] and inside(root, feetY, t) then
					table.insert(list, player)
				end
			end)
			return list
		end

		local function loseMaxHealth(player: Player, amount: number)
			if amount > 0 then
				hellCount += 1
				K.Mod(player, "MaxHealth", { Add = -amount }, "HellgateMaxHealth" .. hellCount)
			end
		end

		-- back out of hell onto a plate
		local function release(player: Player)
			local entry = inHell[player]
			if not entry then
				return
			end
			inHell[player] = nil
			K.Signal(context, id, "Out", player.UserId)
			if player.Character ~= entry.Character or not K.IsAlive(player) then
				return
			end
			K.ReturnToPlates(player)
			loseMaxHealth(player, entry.MaxHealth)
			K.Tell(player, "You crawled out of the Hellgate",
				if entry.MaxHealth > 0 then "It kept a piece of you: -" .. entry.MaxHealth .. " max health for the rest of the round." else "Barely.", EMBER)
		end
		-- everybody still down there comes back when the event ends
		context.Trash.Add(function()
			for player in table.clone(inHell) do
				pcall(release, player)
			end
		end)

		-- quiet = no toast when it costs nothing (the one who took the fiddle has just been told what it cost)
		local function punish(player: Player, tier: number, quiet: boolean?)
			local root = K.Root(player)
			local character = player.Character
			if not (root and character) then
				return
			end
			local cost = tierOf(PUNISH, tier)
			if room and cost.Trip > 0 then
				character:PivotTo(CFrame.new(room.SpawnPoint()))
				root.AssemblyLinearVelocity = Vector3.zero
				local entry: Hell = { Character = character, MaxHealth = cost.MaxHealth, NextErupt = os.clock() + 1.5 }
				inHell[player] = entry
				K.Signal(context, id, "Hell", player.UserId, K.Now() + cost.Trip)
				K.Tell(player, "THE HELLGATE", "Survive " .. cost.Trip .. " seconds. Watch the floor.", EMBER)
				task.delay(cost.Trip, function()
					if inHell[player] == entry then
						local ok = pcall(release, player)
						if not ok then
							inHell[player] = nil
							pcall(K.ReturnToPlates, player)
						end
					end
				end)
			else
				K.ReturnToPlates(player)
				local loss = if room then cost.MaxHealth else tierOf(NO_ROOM, tier)
				loseMaxHealth(player, loss)
				if loss > 0 then
					K.Tell(player, "The Hellgate spat you back out", "-" .. loss .. " max health for the rest of the round.", EMBER)
				elseif not quiet then
					K.Tell(player, "The Hellgate spat you back out", "It kept nothing of you. This time.", EMBER)
				end
			end
		end

		-- the shutters slam and the cage drops through the Hellgate with everybody in it
		local function trap(grabber: Player?)
			if trapAt then
				return
			end
			local t = K.Elapsed(context)
			local victims = riders(t)
			trapAt = t
			prompt.Enabled = false
			panelPrompt.Enabled = false
			if grabber and not table.find(victims, grabber) then
				table.insert(victims, grabber)
			end
			local tier = level
			K.Call(context, id, "Trap", t, if grabber then grabber.UserId else 0, tier)
			local ids = {}
			for _, victim in victims do
				table.insert(ids, victim.UserId)
				K.Mod(victim, "WalkSpeed", { Mult = 0 }, "HellgateHeld", SLAM + 0.4)
				K.Mod(victim, "Jump", { Mult = 0 }, "HellgateHeldJump", SLAM + 0.4)
				K.Blame(context, victim)
			end
			if #ids > 0 then
				K.Signal(context, id, "Taken", ids)
			end
			if grabber and devil and tier == FIDDLE_FLOOR then
				-- THE DEVIL'S DEAL: his fiddle for half your max health. (Nothing else: nobody goes to hell from his floor.)
				local ok, tool = pcall(devil.Give, grabber)
				if ok and tool then
					hellCount += 1
					K.Mod(grabber, "MaxHealth", { Mult = math.clamp(1 - FIDDLE_COST, 0.05, 1) }, "HellgateFiddle" .. hellCount)
					K.Complete(context, grabber) -- Event Journal: you took it
					K.Tell(grabber, "The Devil's Fiddle is yours", "It cost " .. COST_WORDS .. " your max health for the rest of the round. Equip it and click to play.", EMBER)
				else
					warn("[Hellgate Lift] the fiddle could not be handed over, so nothing was paid: " .. tostring(tool))
				end
			elseif grabber then
				local reward = tierOf(REWARDS, tier)
				K.Candles(grabber, reward.Candles)
				for _ = 1, reward.Items do
					K.GiveItem(grabber)
				end
				K.Complete(context, grabber) -- Event Journal: you took the relic
				K.Tell(grabber, "You took the relic: " .. reward.Words, "...and the shutters slam shut.", EMBER)
			end
			task.delay(SLAM + 0.15, function()
				for _, victim in victims do
					local ok, err = pcall(punish, victim, tier, victim == grabber)
					if not ok then
						warn("[Hellgate Lift] " .. tostring(err))
						pcall(K.ReturnToPlates, victim)
					end
				end
			end)
		end

		-- who has the fiddle right now (nil = nobody, or there is no Devil's floor)
		local function fiddler(): Player?
			if devil and type(devil.Holder) == "function" then
				local ok, holder = pcall(devil.Holder)
				return if ok then holder else nil
			end
			return nil
		end

		prompt.Triggered:Connect(function(player: Player)
			if trapAt or not K.IsAlive(player) then
				return
			end
			local root, humanoid = K.Root(player)
			if not (root and humanoid) then
				return
			end
			if not inside(root, K.GetFeetY(root, humanoid), K.Elapsed(context)) then
				tellOnce("Reach", player, "Out of reach", "You have to be inside the cage to reach it.")
				return
			end
			if devil and level == FIDDLE_FLOOR then
				local holder = fiddler()
				if holder == player then
					tellOnce("Have", player, "You already have his fiddle", "The Devil does not sell it twice.")
					return
				elseif holder and not FIDDLE_STEALS then
					tellOnce("Have", player, "Somebody has his fiddle already", "There is only ever one.")
					return
				end
			end
			trap(player)
		end)

		-- THE PANEL: whoever uses it (from inside) gets the floor buttons on their screen. What they pick is where the
		-- cage goes next (the newest pick wins when two people disagree).
		panelPrompt.Triggered:Connect(function(player: Player)
			if trapAt or asking[player] or not K.IsAlive(player) then
				return
			end
			local root, humanoid = K.Root(player)
			if not (root and humanoid) then
				return
			end
			if not inside(root, K.GetFeetY(root, humanoid), K.Elapsed(context)) then
				tellOnce("Panel", player, "Step in first", "The panel only works from inside the cage.")
				return
			end
			if not (EventChoice and EventChoice.Ask) then
				warn("[Hellgate Lift] ServerScriptService > Systems > EventChoice is missing, so nobody can pick a floor.")
				return
			end
			local shut = devil == nil or (not FIDDLE_STEALS and fiddler() ~= nil)
			local options: { string } = {}
			local floorOf: { [string]: number } = {}
			for floor = 1, LEVELS do
				if floor ~= FIDDLE_FLOOR or not shut then
					local text = "Floor " .. floor .. (if floor == FIDDLE_FLOOR then ": the Devil's" elseif floor == level then "  (here)" else "")
					table.insert(options, text)
					floorOf[text] = floor
				end
			end
			asking[player] = true
			-- (no Subtitle on purpose: the game's choice panel has room for five buttons only without one)
			local ok, answer = pcall(EventChoice.Ask, player, "Options", { Title = "Which floor?", Options = options }, ASK_TIME)
			asking[player] = nil
			local floor = if ok and type(answer) == "string" then floorOf[answer] else nil
			if floor and not trapAt and context.IsRunning() then
				wanted = floor
			end
		end)

		-- the cage sets off for that floor, straight there
		local function go(floor: number, t: number)
			local seconds = math.max(math.abs(floor - level) * TRAVEL, 0.6)
			ride = { From = liftY(t, ride, nil), To = -(floor - 1) * STOP_DEPTH, At = t, Time = seconds }
			level = floor
			prompt.Enabled = false -- (nothing is taken while it moves)
			K.Call(context, id, "Go", floor, t, seconds, ride.From, ride.To)
		end

		-- a patch of the hell floor glows, then erupts
		local params = RaycastParams.new()
		params.FilterType = Enum.RaycastFilterType.Include
		if room then
			params.FilterDescendantsInstances = { room.Folder }
		end
		local function erupt(near: Vector3)
			local offset = K.Dir(Vector3.new(math.random() * 2 - 1, 0, math.random() * 2 - 1)) * math.random() * 5
			local from = near + offset + Vector3.new(0, 4, 0)
			local hit = workspace:Raycast(from, Vector3.new(0, -16, 0), params)
			local spot = if hit then hit.Position else near + offset - Vector3.new(0, 3, 0)
			K.Signal(context, id, "Erupt", spot, K.Now() + ERUPT_TELL)
			task.delay(ERUPT_TELL, function()
				if not context.IsRunning() then
					return
				end
				for player in inHell do
					local root = K.Root(player)
					if root and K.Flat(root.Position - spot).Magnitude <= ERUPT_RADIUS and math.abs(root.Position.Y - spot.Y) <= 7 then
						K.Strike(context, id, player, ERUPT_DAMAGE, nil, nil, "Fire")
					end
				end
			end)
		end

		local nextLook = 0
		K.Loop(context, function(_dt: number, t: number)
			-- the two prompts ride along: the relic's on top of the cage, the panel's on the wall by the door
			local y = liftY(t, ride, trapAt)
			anchor.CFrame = frame * CFrame.new(0, y + CAGE_H + 1.5, cageZ)
			panelAnchor.CFrame = frame * CFrame.new(-CAGE_W / 2 + 0.6, y + 3.6, cageZ + CAGE_D / 2 - 1.5)
			if not trapAt and t >= ARRIVE then
				panelPrompt.Enabled = true
				local moving = ride.Time > 0 and t < ride.At + ride.Time
				if not moving then
					if stopped ~= level then
						-- it has come to rest at a floor: what burns on it can be taken, and its prompt says what it is worth
						if stopped ~= 0 then
							obeyAt = t + PAUSE -- (not after coming down out of the dark: nothing was picked yet)
						end
						stopped = level
						if devil and level == FIDDLE_FLOOR then
							prompt.ActionText = "Take the Devil's Fiddle"
							prompt.ObjectText = "Costs " .. COST_WORDS .. " your max health"
						else
							prompt.ActionText = "Take the relic"
							prompt.ObjectText = "Floor " .. level .. ": " .. tierOf(REWARDS, level).Words
						end
						prompt.Enabled = true
						K.Signal(context, id, "Stop", level)
					end
					if wanted == level then
						wanted = nil
					elseif wanted and t >= obeyAt then
						local floor = wanted
						wanted = nil
						go(floor, t)
					end
				end
				-- how it works, once, to whoever steps in; and what the Devil's floor is, once, to whoever is in it there
				if t >= nextLook then
					nextLook = t + 0.25
					for _, rider in riders(t) do
						tellOnce("Ride", rider, "The floor panel", "It is by the door, and takes the cage straight to the floor you pick. Deeper: a bigger prize, and a worse trap for everybody inside.")
						if devil and stopped == FIDDLE_FLOOR and level == FIDDLE_FLOOR then
							tellOnce("Devil", rider, "The Devil's floor", "That is his fiddle in the fire. Taking it costs " .. COST_WORDS .. " your max health.")
						end
					end
				end
				if t >= LAST then
					trap(nil)
				end
			end
			-- hell: the floor erupts near everybody down there
			local now = os.clock()
			for player, entry in inHell do
				if now >= entry.NextErupt then
					entry.NextErupt = now + ERUPT_EVERY * (0.8 + math.random() * 0.4)
					local root = K.Root(player)
					if root then
						erupt(root.Position)
					end
				end
			end
		end)
		K.Hold(context)
	end,
}
