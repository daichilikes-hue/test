-- ModuleScript: ServerScriptService > Events > ThePact     (NEW, Oct 8 2026 update 3)
-- The Pact (like Shackled Souls, but you volunteer): two tall black candles rise on two plates far apart.
-- Light one (prompt). When a SECOND player lights the other one, the two of you are bound for the rest of the
-- round: both get +20 max HP and +10% speed. But if either of you is knocked out, the pact breaks and the one
-- left loses the +20 AND another 30 max HP. Light a candle and nobody lights the other = nothing happens.
-- [MY CALL: the doc said "two players are offered a joint deal"; it is two candles anyone can light instead,
-- so nobody is forced into a choice window, and the numbers above are mine.]
-- Client: ReplicatedStorage > EventClients > thepact
-- Oct 10 2026 (update 9): its Id is "thepact" now (/setevent thepact). It was "pact", the same Id as your Blood
-- Pact: my mistake in update 3. Two events with one Id get in each other's way (only one of them answers to
-- /setevent, and one cannot start while the other runs).

local Players = game:GetService("Players")
local ServerScriptService = game:GetService("ServerScriptService")

local K = require(ServerScriptService:WaitForChild("Systems"):WaitForChild("EventUtil"))

local Event = {
	Name = "The Pact",
	Id = "thepact",
	Weight = 0.5,
	Duration = 24,
	Target = "Arena",
}

local ARRIVE = 1.5
local OPEN_TIME = 18
local HOLD = 1.0
local BONUS_HP = 20
local BONUS_SPEED = 1.1
local BROKEN_HP = 30

-- partner of each bound player, for the rest of the round
local partnerOf: { [Player]: Player } = {}

local function unbind(player: Player)
	local partner = partnerOf[player]
	partnerOf[player] = nil
	if partner and partnerOf[partner] == player then
		partnerOf[partner] = nil
	end
	return partner
end

-- (a frame later: Systems are not required while EventSystem is still loading the events)
task.defer(function()
	local RoundHooks = K.Sys("RoundHooks")
	if RoundHooks then
		if type(RoundHooks.OnEliminated) == "function" then
			RoundHooks.OnEliminated(function(player: Player)
				local partner = unbind(player)
				if partner and K.IsAlive(partner) then
					K.Unmod(partner, "PactHeart")
					K.Unmod(partner, "PactStride")
					K.Mod(partner, "MaxHealth", { Add = -BROKEN_HP }, "PactBroken")
					K.Tell(partner, "The pact is broken", player.DisplayName .. " is gone. You lose " .. (BONUS_HP + BROKEN_HP) .. " max HP.", K.Colors.Warn)
				end
			end)
		end
		if type(RoundHooks.OnEnd) == "function" then
			RoundHooks.OnEnd(function()
				table.clear(partnerOf)
			end)
		end
	end
end)
Players.PlayerRemoving:Connect(function(player: Player)
	unbind(player)
end)

local function twoPlatesApart(plates: { BasePart }): (BasePart?, BasePart?)
	local a = K.Pick(plates)
	if not a then
		return nil, nil
	end
	local best, bestDistance = nil, -1
	for _, plate in plates do
		local distance = K.Flat(plate.Position - a.Position).Magnitude
		if plate ~= a and distance > bestDistance then
			best, bestDistance = plate, distance
		end
	end
	return a, best
end

function Event.Run(context)
	local t0 = K.Start(context)
	local plates = K.Plates()
	local plateA, plateB = twoPlatesApart(plates)
	if not (plateA and plateB) then
		return
	end
	local candles = {}
	for index, plate in { plateA, plateB } do
		local spot = K.PointOn(plate, 4)
		local id = K.Show(context, "Candle", CFrame.new(spot), { T0 = t0, Arrive = ARRIVE, Index = index })
		candles[index] = { Spot = spot, Id = id, By = nil :: Player? }
	end
	if not K.WaitUntil(context, t0 + ARRIVE) then
		return
	end

	local sealed = false
	local prompts: { ProximityPrompt } = {}
	for index, candle in candles do
		local _, prompt = K.Prompt(candle.Spot + Vector3.new(0, 3, 0), "Light the candle", "The Pact", HOLD, context.Folder)
		prompt.MaxActivationDistance = 9
		prompts[index] = prompt
		context.Trash.Add(prompt.Triggered:Connect(function(player: Player)
			if sealed or candle.By or not K.IsAlive(player) then
				return
			end
			if partnerOf[player] then
				K.Tell(player, "The Pact", "You are already bound to someone.", K.Colors.Purple)
				return
			end
			local other = candles[3 - index]
			if other.By == player then
				K.Tell(player, "The Pact", "It takes two. Somebody else has to light the other candle.", K.Colors.Purple)
				return
			end
			candle.By = player
			prompt.Enabled = false
			K.Call(context, candle.Id, "Lit", player.UserId)
			local partner = other.By
			if not partner then
				K.Tell(player, "The Pact", "Your candle is lit. Somebody has to light the other one.", K.Colors.Purple)
				return
			end
			if not K.IsAlive(partner) or partnerOf[partner] then
				return
			end
			sealed = true
			for _, p in prompts do
				p.Enabled = false
			end
			partnerOf[player] = partner
			partnerOf[partner] = player
			for _, bound in { player, partner } do
				K.Mod(bound, "MaxHealth", { Add = BONUS_HP }, "PactHeart")
				K.Mod(bound, "WalkSpeed", { Mult = BONUS_SPEED }, "PactStride")
				K.Complete(context, bound)
			end
			K.Tell(player, "The Pact is sealed", "You and " .. partner.DisplayName .. ": +" .. BONUS_HP .. " max HP and +10% speed. If one of you falls, the other pays.", K.Colors.Purple)
			K.Tell(partner, "The Pact is sealed", "You and " .. player.DisplayName .. ": +" .. BONUS_HP .. " max HP and +10% speed. If one of you falls, the other pays.", K.Colors.Purple)
			for _, c in candles do
				K.Call(context, c.Id, "Sealed")
			end
		end))
	end

	if not K.WaitUntil(context, t0 + ARRIVE + OPEN_TIME) then
		return
	end
	for _, p in prompts do
		p.Enabled = false
	end
	if not sealed then
		for _, c in candles do
			K.Call(context, c.Id, "Fade")
		end
	end
	K.Hold(context)
end

return Event
