-- ModuleScript: ServerScriptService > Events > DeathPulse     (/setevent pulse)
--
-- Glowing rings of death pulse out from the center of the arena, one after another,
-- skimming just above the plates. Jump over each ring as it passes.
--
-- Rings are drawn on every client from a shared clock (no lag). A client tells the
-- server when a ring touches it; the server checks it could really have.
--
-- SERVER: ring timing, validating hits, damage.
-- CLIENT (ReplicatedStorage > EventClients > pulse): drawing the rings, detecting hits.

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerScriptService = game:GetService("ServerScriptService")

local GameConfig = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("GameConfig"))
local Systems = ServerScriptService:WaitForChild("Systems")
local Damage = require(Systems:WaitForChild("Damage"))
local EventUtil = require(Systems:WaitForChild("EventUtil"))

local Event = {
	Name = "Death Pulse",
	Id = "pulse",
	Weight = 1,
	Duration = 12,
	Target = "Arena",

	WarmUp = 1,            -- the center glows before the first ring
	RingCount = 6,
	RingInterval = 1.4,    -- seconds between rings
	RingSpeed = 32,        -- studs per second outward
	RingHeight = 1.6,      -- how tall the ring is above the plate surface (jump over it)
	RingWidth = 1.2,       -- how thick the ring is
	Damage = 20,

	-- Hit validation (lag forgiveness)
	MaxRewind = 0.5,
	PositionSlack = 4,
}

function Event.Run(context)
	local Visuals = context.Visuals
	local center: BasePart = context.Center
	local plateTop = center.Position.Y + GameConfig.PlateSize.Y / 2
	local origin = Vector3.new(center.Position.X, plateTop, center.Position.Z)
	local maxRadius = GameConfig.ArenaSize * 0.8
	local startTime = workspace:GetServerTimeNow() + Event.WarmUp

	Visuals.Spawn("Pulse", CFrame.new(origin), {
		StartTime = startTime,
		RingCount = Event.RingCount,
		RingInterval = Event.RingInterval,
		RingSpeed = Event.RingSpeed,
		RingHeight = Event.RingHeight,
		RingWidth = Event.RingWidth,
		MaxRadius = maxRadius,
		EventName = Event.Name,
	})

	-- Radius of ring `index` at time t (nil if it isn't out right now)
	local function ringRadius(index: number, t: number): number?
		local age = t - (index - 1) * Event.RingInterval
		local radius = age * Event.RingSpeed
		return if age > 0 and radius <= maxRadius then radius else nil
	end

	local hitBy: { [string]: boolean } = {} -- "<userId>:<ring>" so each ring hits a player once

	context.ListenForHits(function(player: Player, ringIndex)
		if typeof(ringIndex) ~= "number" or ringIndex < 1 or ringIndex > Event.RingCount then
			return
		end
		local key = player.UserId .. ":" .. ringIndex
		if hitBy[key] then
			return
		end
		local root = EventUtil.GetRoot(player)
		local feetY = EventUtil.GetVerticalSpan(player)
		if not root or not feetY or feetY > plateTop + Event.RingHeight + 2 then
			return
		end

		local distance = ((root.Position - origin) * Vector3.new(1, 0, 1)).Magnitude
		local now = workspace:GetServerTimeNow() - startTime
		for rewind = 0, Event.MaxRewind, 0.05 do
			local radius = ringRadius(ringIndex, now - rewind)
			if radius and math.abs(distance - radius) <= Event.RingWidth / 2 + 1.5 + Event.PositionSlack then
				hitBy[key] = true
				Damage.Deal(player, Event.Damage, { Source = Event.Name })
				return
			end
		end
	end)
end

return Event