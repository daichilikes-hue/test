-- ModuleScript: ServerScriptService > Events > MossBloom     (NEW: Oct 12 Update 23, /setevent moss)
-- MOSS BLOOM (your backlog, healing event 3): soft moss grows over about a third of the plates. Standing on moss
-- heals you slowly (HEAL HP every TICK seconds). It withers away when the event ends. The first time you stand on
-- moss you also get ONE small random stat buff for the rest of the round (a boon: Systems > EventUtil.Boons, a stat
-- shift through Systems > StatShift). BOON = false: none.
-- This script picks the plates and heals. The moss itself (the model Moss under this script, stretched to each
-- plate) grows in ReplicatedStorage > EventClients > moss.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local DURATION = 20
local SHARE = 0.3           -- part of the plates that grow moss (at least one)
local HEAL = 1              -- HP every TICK seconds while you stand on moss
local TICK = 0.75
local BOON = true           -- the first time you stand on moss: one small random stat buff (false = none)
local GROW = 2.5            -- seconds the moss takes to grow in (it starts healing halfway)

return {
	Name = "Moss Bloom",
	Id = "moss",
	Weight = 1,
	Duration = DURATION,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local Damage = K.Sys("Damage")
		local plates = K.Shuffle(K.Plates())
		local count = math.min(#plates, math.max(1, math.floor(#plates * SHARE + 0.5)))
		local mossy: { BasePart } = {}
		local ids: { [BasePart]: number? } = {}
		for i = 1, count do
			local plate = plates[i]
			table.insert(mossy, plate)
			ids[plate] = K.Show(context, "Moss", CFrame.new(K.TopCentre(plate)), {
				T0 = t0, Duration = DURATION, Grow = GROW, Tag = K.Tag(context, plate), Seed = i,
			})
		end
		K.TellAll("Moss Bloom", "Moss is growing on some of the plates. Stand on it to heal.", K.Colors.Green)
		K.WaitUntil(context, t0 + GROW / 2)

		local healed: { [Player]: boolean } = {}
		while context.IsRunning() do
			local left: { BasePart } = {}
			for _, plate in mossy do
				if plate.Parent then
					table.insert(left, plate)
				end
			end
			K.Each(function(player, root, _, feetY)
				local plate = K.PlateUnder(root, feetY, left)
				if not plate then
					return
				end
				if BOON then
					K.Boon(context, player)
				end
				if not (Damage and Damage.Heal) then
					return
				end
				local ok, amount = pcall(Damage.Heal, player, HEAL, { Source = "Moss Bloom" })
				if ok and type(amount) == "number" and amount > 0 then
					K.Signal(context, ids[plate], "Healed", player.UserId)
					if not healed[player] then
						healed[player] = true
						K.Complete(context, player) -- (the Event Journal: the moss healed you)
					end
				end
			end)
			task.wait(TICK)
		end
	end,
}
