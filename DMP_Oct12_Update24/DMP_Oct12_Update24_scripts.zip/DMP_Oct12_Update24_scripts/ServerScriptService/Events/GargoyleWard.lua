-- ModuleScript: ServerScriptService > Events > GargoyleWard     (NEW: Oct 12 Update 23, /setevent ward)
-- GARGOYLE WARD (your backlog, protection event 8): a stone gargoyle (the model Warden under this script, an R6
-- character) settles on a plinth (the model Ward) at one corner of a random plate. While it is there:
--   * that plate CANNOT BE DESTROYED by any event (Systems > PlateSpawner.DestroyPlate leaves it alone; the gargoyle
--     rears up when it holds),
--   * whoever stands on it takes HALF DAMAGE (DAMAGE_TAKEN; a Damage handler at priority 50, with the reductions).
-- (Not the same as your Gargoyle Attack: this one is a friend, and it is my own model, not yours.)
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local DURATION = 25
local DAMAGE_TAKEN = 0.5    -- what is left of a hit on the warded plate
local INSET = 2.6           -- studs in from the plate's corner where the plinth stands
local SHIELD_EVERY = 1.5    -- seconds between two "it shielded you" puffs on the same player

return {
	Name = "Gargoyle Ward",
	Id = "ward",
	Weight = 1,
	Duration = DURATION,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local Damage = K.Sys("Damage")
		local PlateSpawner = K.Sys("PlateSpawner")
		local plates = K.Plates()
		local plate = K.PickPlate(plates)
		if not plate then
			return
		end
		-- the plinth: on the corner of the plate that looks out over the arena's edge
		local centre = K.Arena(plates)
		local sx = if plate.Position.X >= centre.X then 1 else -1
		local sz = if plate.Position.Z >= centre.Z then 1 else -1
		local corner = Vector3.new(plate.Position.X + sx * (plate.Size.X / 2 - INSET), K.Top(plate), plate.Position.Z + sz * (plate.Size.Z / 2 - INSET))
		local outward = Vector3.new(sx, 0, sz).Unit
		local id = K.Show(context, "Ward", CFrame.lookAt(corner, corner + outward), {
			T0 = t0, Duration = DURATION, Tag = K.Tag(context, plate),
		})
		K.Protect(context, plate)
		K.TellAll("Gargoyle Ward", "A stone gargoyle guards one plate. It can't break, and it halves the damage you take on it.", K.Colors.Ghost)

		-- the ward holds: the gargoyle rears up
		if PlateSpawner and PlateSpawner.Saved then
			context.Trash.Add(PlateSpawner.Saved:Connect(function(saved, why)
				if saved == plate and why == "Protected" then
					K.Signal(context, id, "Held")
				end
			end))
		end

		-- half damage on the plate (a handler on everyone; Damage gives every new character an empty list)
		local guarded: { [Player]: Model? } = {}
		local puffed: { [Player]: number } = {}
		local touched: { [Player]: boolean } = {}
		context.Trash.Add(function()
			for player in guarded do
				pcall(Damage.RemoveHandler, player, "GargoyleWard")
			end
		end)
		local function guard(player: Player)
			if not (Damage and Damage.AddHandler) or guarded[player] == player.Character then
				return
			end
			guarded[player] = player.Character
			Damage.AddHandler(player, "GargoyleWard", 50, function(hit: any)
				if hit.InstantKill or not plate.Parent then
					return
				end
				local root, humanoid = K.Root(player)
				if root and humanoid and K.StandingOn(plate, root, K.FeetY(root, humanoid)) then
					hit.Amount *= DAMAGE_TAKEN
					if not puffed[player] or K.Now() - puffed[player] >= SHIELD_EVERY then
						puffed[player] = K.Now()
						K.Signal(context, id, "Shield", player.UserId)
					end
					if not touched[player] then
						touched[player] = true
						K.Complete(context, player) -- (the Event Journal: the ward took the edge off a hit)
					end
				end
			end)
		end
		while context.IsRunning() do
			for _, player in K.Alive() do
				guard(player)
			end
			task.wait(0.5)
		end
	end,
}
