-- ModuleScript: ServerScriptService > Events > GentleRain     (NEW: Oct 11 Update 21, /setevent gentlerain)
-- GENTLE RAIN (your backlog, healing event 1): a soft, dull grey rain falls over the whole arena for 15 seconds.
-- Everyone alive heals HEAL HP every TICK seconds while it falls, and it WASHES FIRE OFF: a burning player's flames
-- go out at once (with a hiss of steam), and no Fire damage lands on anybody while it rains.
-- This script heals and washes. The rain itself, the ripples, the grey on your screen: ReplicatedStorage >
-- EventClients > gentlerain (and the model Rain under this script).
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local DURATION = 15
local HEAL = 1              -- HP every TICK seconds, for everyone alive
local TICK = 1
local WASH_FIRE = true      -- false = the rain only heals

-- is this player on fire right now? (Systems > Damage: Status_Fire = the server time the flames show until)
local function burning(player: Player): boolean
	local ends = player:GetAttribute("Status_Fire")
	return type(ends) == "number" and ends > workspace:GetServerTimeNow()
end

return {
	Name = "Gentle Rain",
	Id = "gentlerain",
	Weight = 1,
	Duration = DURATION,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local Damage = K.Sys("Damage")
		local centre = K.Arena(K.Plates())
		local id = K.Show(context, "Rain", CFrame.new(centre), { T0 = t0, Duration = DURATION, Top = centre.Y })
		K.TellAll("Gentle Rain", "A soft rain is falling. It heals you and puts out fire.", K.Colors.Ghost)

		-- while it rains no Fire damage lands: a damage handler on everyone in the round (Damage gives every new
		-- character an empty list, so it goes on again after a respawn), all taken off when the rain stops
		local guarded: { [Player]: Model? } = {}
		context.Trash.Add(function()
			for player in guarded do
				pcall(Damage.RemoveHandler, player, "GentleRain")
			end
		end)
		local function guard(player: Player)
			if not WASH_FIRE or not (Damage and Damage.AddHandler) or guarded[player] == player.Character then
				return
			end
			guarded[player] = player.Character
			Damage.AddHandler(player, "GentleRain", 5, function(hit: any)
				if hit.Type == "Fire" and not hit.InstantKill then
					hit.Cancelled = true
				end
			end)
		end

		local healed: { [Player]: boolean } = {}
		while context.IsRunning() do
			for _, player in K.Alive() do
				guard(player)
				-- the rain heals ...
				if Damage and Damage.Heal then
					local ok, amount = pcall(Damage.Heal, player, HEAL, { Source = "Gentle Rain" })
					if ok and type(amount) == "number" and amount > 0 then
						K.Signal(context, id, "Healed", player.UserId)
						if not healed[player] then
							healed[player] = true
							K.Complete(context, player) -- (the Event Journal: the rain healed you)
						end
					end
				end
				-- ... and puts out a fire
				if WASH_FIRE and burning(player) and Damage and Damage.Unmark then
					Damage.Unmark(player, "Fire")
					K.Signal(context, id, "Hiss", player.UserId)
				end
			end
			task.wait(TICK)
		end
	end,
}
