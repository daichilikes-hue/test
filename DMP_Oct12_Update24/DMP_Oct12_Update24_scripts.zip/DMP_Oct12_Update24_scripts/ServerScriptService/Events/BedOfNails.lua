-- ModuleScript: ServerScriptService > Events > BedOfNails     (REPLACE)
-- Every plate is split in four squares. Each round of spikes THREE of the four squares glow and then spike, and
-- only ONE is safe: a different, random one every round (and on every plate). Find the dark one and stand on it!
-- Every spiking square has its own kind of spike. They all LOOK the same (the old red); what you got shows on your
-- character once it has stabbed you:
--   BLEED     you bleed: BLEED_DOT damage over DOT_TIME seconds (Ghosts only take half)
--   TOXIC     poison: TOXIC_DOT over DOT_TIME seconds, and you are slowed (Ghosts take double, Vampires half)
--   FLAMING   you burn: FIRE_DOT over DOT_TIME seconds (Vampires take double, Ghosts half)
-- On top of that the spikes stab you for STAB every half second while you stand on them. Stepping on the same
-- kind again starts its bleed / poison / burn over (it does not stack); different kinds do stack.
-- Oct 10 2026 (update 9): ONE toast per player per event (the first time the spikes get you), not one every round;
-- no words over your head; bleeding / poison / fire show ON the character instead (drops of blood, green fumes,
-- flames: Systems > Damage + StatusEffectsClient, the same for every event that deals that kind of damage).
-- The server and every client work out the safe square and the kinds from the same numbers (each plate's Seed
-- and the round number), so nothing has to be sent while it runs.
-- This script decides the hits. What it looks like: ReplicatedStorage > EventClients > nails.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local LEAD = 1.2      -- seconds before the first warning
local PHASE = 2.8     -- seconds for one round of spikes (warning, spikes up, spikes down)
local WARNING = 1.3   -- seconds the squares glow before the spikes pop (enough to cross the plate to the safe one)
local STAB = 4        -- every 0.5 s while you stand on raised spikes
local DOT_TIME = 4    -- seconds a bleed / poison / burn lasts
local BLEED_DOT, TOXIC_DOT, FIRE_DOT = 10, 10, 10   -- damage each one does over DOT_TIME
local TOXIC_SLOW = 0.7  -- walk speed while poisoned (0.7 = 70%)
local SPIKE = 3       -- how tall the spikes are

local KINDS = { "Bleed", "Toxic", "Flaming" } -- kind 1, 2, 3 (EventClients > nails uses the same numbers)
local TYPES = { "Bleed", "Poison", "Fire" }   -- the damage type of each kind (Systems > Damage)
local DOTS = { BLEED_DOT, TOXIC_DOT, FIRE_DOT }

-- The safe square (1..4) of round `cycle` on a plate, and the kind of spike (1..3) on each square.
-- KEEP IN SYNC with layout() in ReplicatedStorage > EventClients > nails (same maths = same answer everywhere).
-- Squares: 1 = -X -Z, 2 = -X +Z, 3 = +X -Z, 4 = +X +Z.
local function layout(seed: number, cycle: number): (number, { number })
	local rng = Random.new(seed * 1000 + cycle)
	local safe = rng:NextInteger(1, 4)
	local kinds = {}
	for tile = 1, 4 do
		kinds[tile] = rng:NextInteger(1, 3)
	end
	return safe, kinds
end

type Bed = { Id: number?, Seed: number }

return {
	Name = "Bed of Nails",
	Id = "nails",
	Weight = 1,
	Duration = 20,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local plates = K.Plates()
		local beds: { [BasePart]: Bed } = {}
		for _, plate in plates do
			local seed = math.random(1, 1000000)
			beds[plate] = {
				Seed = seed,
				Id = K.Show(context, "Bed", CFrame.new(K.TopCentre(plate)), {
					T0 = t0, SX = plate.Size.X, SZ = plate.Size.Z, Lead = LEAD, Phase = PHASE, Warn = WARNING, Spike = SPIKE, Seed = seed,
				}),
			}
		end
		K.TellAll("Bed of Nails!", "Only ONE square on your plate is safe each time. Get to the dark one!", K.Colors.Warn)

		local over = false
		K.Outro(context, 0.9, function()
			over = true -- the spikes sink back: no more hits
			for _, bed in beds do
				K.Signal(context, bed.Id, "Outro", 0.8)
			end
		end)

		local lastTick = -1
		local told: { [Player]: boolean } = {} -- (who has had the one toast)
		K.Loop(context, function(_, t)
			local sinceFirst = t - LEAD
			if sinceFirst < 0 or over then
				return
			end
			local cycle = math.floor(sinceFirst / PHASE)
			local into = sinceFirst - cycle * PHASE
			-- (the spikes are only up after the warning, and the client pulls them back in over the last 0.22 s)
			if into < WARNING or into > PHASE - 0.22 or t - lastTick < 0.5 then
				return
			end
			lastTick = t
			for plate, bed in beds do
				if not plate.Parent then
					K.Hide(context, bed.Id) -- the plate is gone (another event broke it)
					beds[plate] = nil
				end
			end
			K.Each(function(player, root, _, feetY)
				local plate = K.PlateAt(root.Position, plates, 0)
				local bed = plate and beds[plate]
				if not (plate and bed) or feetY > K.Top(plate) + 1.5 or feetY < K.Top(plate) - 1.5 then
					return -- (not on a plate, or jumping over the spikes)
				end
				local i = if root.Position.X >= plate.Position.X then 1 else 0
				local j = if root.Position.Z >= plate.Position.Z then 1 else 0
				local tile = i * 2 + j + 1
				local safe, kinds = layout(bed.Seed, cycle)
				if tile == safe then
					return
				end
				local kind = kinds[tile]
				local damageType = TYPES[kind]
				K.Strike(context, bed.Id, player, STAB, nil, nil, damageType)
				K.Dot(player, DOTS[kind], DOT_TIME, context, damageType, "Nails" .. KINDS[kind])
				if kind == 2 then
					K.Mod(player, "WalkSpeed", { Mult = TOXIC_SLOW }, "NailsToxic", DOT_TIME)
				end
				if not told[player] then
					told[player] = true
					K.Tell(player, "Spiked!", "Only one square is safe each time: the dark one.", K.Colors.Warn)
				end
			end)
		end)
		K.Hold(context)
	end,
}
