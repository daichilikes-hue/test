-- ModuleScript: ServerScriptService > Events > BoneBaker     (NEW: Oct 12 Update 23, /setevent baker)
-- BONE BAKER (your backlog, healing event 5): a skeleton baker (the model Baker under this script, an R6 character)
-- climbs out of a plate and hurries from plate to plate, setting down a tray of treats on each (4 to 6 trays: the
-- model Tray under this script, cloned HERE because players eat from it). Hold E at a tray to eat a treat: it heals
-- HEAL HP and now and then gives you a random item (the same pool as the chests: Cloud in a Bottle is in it). A tray
-- holds 3 treats; each player can eat ONE from each tray. Trays stay until the event ends. Your first treat also
-- gives you ONE small random stat buff for the rest of the round (a boon: Systems > EventUtil.Boons, a stat shift
-- through Systems > StatShift). BOON = false: none.
-- He walks over the plates and hops the gaps. His route is worked out here and sent to the clients, which draw him
-- (ReplicatedStorage > EventClients > baker); a tray appears at the moment his BakerSet animation sets it down.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local DURATION = 26         -- (the last tray still has a good few seconds before the end)
local MIN_TRAYS = 4
local MAX_TRAYS = 6
local HEAL = 20             -- HP a treat heals
local ITEM_CHANCE = 0.25    -- chance a treat also has an item baked into it
local SPEED = 14            -- studs a second he walks
local RISE = 1.2            -- seconds he takes to climb out of the first plate
local SET = 1.0             -- seconds he stops at each plate (the BakerSet animation) ...
local SET_AT = 0.45         -- ... and the tray touches down this far into it (KEEP IN SYNC with SET_AT in EventClients > baker)
local LEAVE = 1.2           -- seconds he takes to sink away after the last tray
local BOON = true           -- your first treat: one small random stat buff (false = none)
local HOLD = 0.3            -- seconds to hold E at a tray

-- his route: tray plates, each next to the last one where it can be (he hurries across the arena, not to and fro)
local function route(plates: { BasePart }, count: number): { BasePart }
	local pairs_ = K.Neighbours(plates)
	local near: { [BasePart]: { BasePart } } = {}
	for _, pair in pairs_ do
		near[pair[1]] = near[pair[1]] or {}
		near[pair[2]] = near[pair[2]] or {}
		table.insert(near[pair[1]], pair[2])
		table.insert(near[pair[2]], pair[1])
	end
	local list: { BasePart } = {}
	local used: { [BasePart]: boolean } = {}
	local at = K.Pick(plates)
	while at and #list < count do
		table.insert(list, at)
		used[at] = true
		local options: { BasePart } = {}
		local around: { BasePart } = near[at] or {}
		for _, other in around do
			if not used[other] then
				table.insert(options, other)
			end
		end
		local nextPlate = K.Pick(options)
		if not nextPlate then
			-- (boxed in: the nearest plate he has not been to)
			local best, bestD = nil, math.huge
			for _, other in plates do
				local d = (other.Position - at.Position).Magnitude
				if not used[other] and d < bestD then
					best, bestD = other, d
				end
			end
			nextPlate = best
		end
		at = nextPlate
	end
	return list
end

return {
	Name = "Bone Baker",
	Id = "baker",
	Weight = 1,
	Duration = DURATION,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local Damage = K.Sys("Damage")
		local template = script:FindFirstChild("Tray")
		if not (template and template:IsA("Model")) then
			warn("[Bone Baker] the model Tray is missing under ServerScriptService > Events > BoneBaker: install the WHOLE update (drag its .rbxmx in).")
		end
		local plates = K.Plates()
		if #plates == 0 then
			return
		end
		local stops = route(plates, math.random(MIN_TRAYS, math.max(MIN_TRAYS, MAX_TRAYS)))
		-- where he stops on each plate (a little off the middle) and when
		local points: { number } = {}
		local spots: { Vector3 } = {}
		local times: { number } = {}
		local clock = RISE
		for i, plate in stops do
			local spot = K.PointOn(plate, 4)
			if i > 1 then
				local last = spots[i - 1]
				clock += Vector3.new(spot.X - last.X, 0, spot.Z - last.Z).Magnitude / SPEED
			end
			table.insert(spots, spot)
			table.insert(points, spot.X)
			table.insert(points, spot.Z)
			table.insert(times, clock) -- (he arrives: BakerSet starts)
			clock += SET
		end
		local id = K.Show(context, "Baker", CFrame.new(spots[1]), {
			T0 = t0, Duration = DURATION, Route = points, Speed = SPEED, Rise = RISE, Set = SET, SetAt = SET_AT,
			Leave = LEAVE, Top = K.BaseTop(),
		})
		K.TellAll("Bone Baker", "A skeleton baker is setting out trays of treats. Eat one to heal!", K.Colors.Bone)

		local told: { [Player]: boolean } = {}
		local function eat(player: Player, tray: Model, eaten: { [Player]: boolean })
			if eaten[player] or not context.IsRunning() or not K.IsAlive(player) then
				return
			end
			local treats: { Instance } = {}
			for _, child in tray:GetChildren() do
				if string.sub(child.Name, 1, 5) == "Treat" then
					table.insert(treats, child)
				end
			end
			local treat = K.Pick(treats)
			if not treat then
				return
			end
			eaten[player] = true
			local at = tray:GetPivot().Position
			treat:Destroy()
			K.Signal(context, id, "Ate", player.UserId, at)
			if Damage and Damage.Heal then
				pcall(Damage.Heal, player, HEAL, { Source = "Bone Baker" })
			end
			if BOON then
				K.Boon(context, player)
			end
			local item = if math.random() < ITEM_CHANCE then K.GiveItem(player) else nil
			K.Complete(context, player) -- (the Event Journal: you ate a treat)
			if item then
				K.Tell(player, "Something crunchy!", "There was a " .. item .. " baked into it.", K.Colors.Gold)
			elseif not told[player] then
				told[player] = true
				K.Tell(player, "Bone Baker", "Freshly baked: +" .. HEAL .. " HP.", K.Colors.Bone)
			end
			if #treats <= 1 then
				K.Fade(tray, 0.6)
				K.Remove(tray, 0.7)
			end
		end

		for i, plate in stops do
			if not K.WaitUntil(context, t0 + times[i] + SET_AT) then
				return
			end
			if plate.Parent and template and template:IsA("Model") then
				local tray = template:Clone()
				local spot = Vector3.new(spots[i].X, K.Top(plate), spots[i].Z)
				tray:PivotTo(CFrame.new(spot) * CFrame.Angles(0, math.random() * math.pi * 2, 0))
				for _, part in tray:GetDescendants() do
					if part:IsA("BasePart") then
						part.Anchored = true
						part.CanCollide = false
						part.CanTouch = false
						part.CanQuery = false
					end
				end
				tray.Parent = context.Folder
				K.Pin(context, tray, plate)
				local eaten: { [Player]: boolean } = {}
				local prompt = tray:FindFirstChildWhichIsA("ProximityPrompt", true)
				if prompt then
					prompt.HoldDuration = HOLD
					prompt.Triggered:Connect(function(player: Player)
						eat(player, tray, eaten)
					end)
				end
			end
		end
	end,
}
