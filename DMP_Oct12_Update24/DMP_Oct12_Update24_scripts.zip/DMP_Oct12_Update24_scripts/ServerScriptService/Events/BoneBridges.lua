-- ModuleScript: ServerScriptService > Events > BoneBridges     (REPLACE)
-- Bridges of bone join every plate to its neighbours for a while, so everyone can roam. Then they shake, and
-- they fall.
-- Oct 10 2026 (update 9), your list: every bridge is YOUR normal Bone Bridge model now (ServerScriptService >
-- Events > BoneBridge > Bridge), sized exactly the way the Bone Bridge event sizes it, and the event is way rarer
-- (Weight 0.2, was 0.8). No red flashing before they go any more: they shake.
-- How it is put together: this script makes what you stand on, one plain invisible deck per bridge (the size of
-- your model's Deck). The model itself is copied on every client (EventClients > bridges): 40 bridges of 70 pieces
-- each would be 2800 things for the server to send to everybody at once.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local OVERLAP = 3           -- studs a bridge is longer than the gap it spans (it rests 1.5 on each plate, like the Bone Bridge)
local RISE_TIME = 0.8       -- seconds a bridge takes to rise into place
local CRUMBLE_WARNING = 3   -- seconds they shake before they fall
local AT_ONCE = 4           -- bridges that come up in the same instant (the rest follow a moment later)
local WIDTH = 6             -- only when your Bridge model is missing: how wide the plain plank bridges are
local PLANK = Color3.fromRGB(104, 88, 76)

-- your Bone Bridge model: how big its Deck is and how long the whole thing is (nil when it is not there)
local function bridgeModel(): (Vector3?, number?)
	local event = script.Parent and script.Parent:FindFirstChild("BoneBridge")
	local model = event and event:FindFirstChild("Bridge")
	if not (model and model:IsA("Model")) then
		return nil, nil
	end
	local deck = model.PrimaryPart or model:FindFirstChild("Deck")
	if not (deck and deck:IsA("BasePart")) then
		return nil, nil
	end
	local _, size = model:GetBoundingBox()
	return deck.Size, math.max(size.Z, 0.1)
end

return {
	Name = "Bone Bridges",
	Id = "bridges",
	Weight = 0.2,               -- (was 0.8: way rarer)
	Duration = 26,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local life = context.Event.Duration - 1.8 -- seconds until they fall
		local deckSize, modelLength = bridgeModel()
		local bridges: { BasePart } = {}
		local links = K.Shuffle(K.Neighbours(K.Plates()))
		if #links == 0 then
			return
		end
		K.TellAll("Bone Bridges!", "Bridges join the plates for a while. Get off them when they shake!", K.Colors.Bone)
		for index, link in links do
			local a, b = link[1], link[2]
			if not (a.Parent and b.Parent) then
				continue
			end
			local top = math.min(K.Top(a), K.Top(b))
			local alongX = math.abs(a.Position.X - b.Position.X) > math.abs(a.Position.Z - b.Position.Z)
			local gap: number, middle: Vector3, along: Vector3
			if alongX then
				local first = if a.Position.X < b.Position.X then a else b
				gap = math.abs(a.Position.X - b.Position.X) - a.Size.X / 2 - b.Size.X / 2
				middle = Vector3.new(first.Position.X + first.Size.X / 2 + gap / 2, top - 0.5, (a.Position.Z + b.Position.Z) / 2)
				along = Vector3.new(1, 0, 0)
			else
				local first = if a.Position.Z < b.Position.Z then a else b
				gap = math.abs(a.Position.Z - b.Position.Z) - a.Size.Z / 2 - b.Size.Z / 2
				middle = Vector3.new((a.Position.X + b.Position.X) / 2, top - 0.5, first.Position.Z + first.Size.Z / 2 + gap / 2)
				along = Vector3.new(0, 0, 1)
			end
			if gap > 0.5 then
				local length = gap + OVERLAP
				local frame = CFrame.lookAt(middle, middle + along) -- (-Z runs along the bridge, like your model)
				-- what you stand on: the size of your model's Deck once the model is sized to this gap
				local scale = if deckSize and modelLength then length / modelLength else 1
				local size = if deckSize then deckSize * scale else Vector3.new(WIDTH, 1, length)
				local deck = K.Part({
					Name = "Bridge", Size = size, CFrame = frame + Vector3.new(0, -8, 0), Color = PLANK, Material = Enum.Material.WoodPlanks,
					Transparency = 1, Parent = context.Folder,
				})
				K.Tween(deck, { CFrame = frame, Transparency = if deckSize then 1 else 0 }, RISE_TIME)
				task.delay(RISE_TIME, function()
					if deck.Parent and context.IsRunning() then
						K.Solid(deck)
					end
				end)
				table.insert(bridges, deck)
				local now = K.Now()
				K.Show(context, "Bridge", frame, {
					T0 = now, Scale = scale, Model = deckSize ~= nil, Rise = RISE_TIME, Life = t0 + life - now, Warn = CRUMBLE_WARNING, Length = length,
				})
				if index % AT_ONCE == 0 then
					task.wait(0.06)
				end
			end
		end
		if #bridges == 0 then
			return
		end

		-- Event Journal: you have used a bridge once you stand on one
		local crossed: { [Player]: boolean } = {}
		while context.IsRunning() and K.Now() < t0 + life do
			K.Each(function(player, root, _, feetY)
				if crossed[player] then
					return
				end
				for _, deck in bridges do
					local top = deck.Position.Y + deck.Size.Y / 2
					local at = deck.CFrame:PointToObjectSpace(root.Position) -- (the decks lie both ways round)
					if deck.CanCollide and math.abs(at.X) <= deck.Size.X / 2 and math.abs(at.Z) <= deck.Size.Z / 2 and feetY >= top - 1 and feetY <= top + 4 then
						crossed[player] = true
						K.Complete(context, player)
						break
					end
				end
			end)
			task.wait(0.25)
		end
		for _, deck in bridges do
			deck.CanCollide = false
			deck.CanQuery = false
			K.Tween(deck, { CFrame = deck.CFrame + Vector3.new(0, -14, 0), Transparency = 1 }, 0.8, "Quad", "In")
		end
		K.Hold(context)
	end,
}
