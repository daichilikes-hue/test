-- ModuleScript: ServerScriptService > Events > WhackAGhoul     (REPLACE)
-- Ghouls pop out of the plates. Step on one for candles. A ghoul nobody steps on turns red and nips
-- everybody near it before it sinks back.
-- This script decides who whacked what. What the ghouls look like: ReplicatedStorage > EventClients > ghouls.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local EVERY = 0.9                -- seconds between ghouls
local UP_TIME = 2.4              -- seconds a ghoul stays up
local REWARD = 3                 -- candles for stepping on one
local NIP_DAMAGE, NIP_RANGE = 8, 18    -- (the range was 9: a ghoul you miss reaches twice as far now)
local MAX_AT_ONCE = 8

type Ghoul = { Id: number?, Spot: Vector3, Born: number }

return {
	Name = "Whack-a-Ghoul",
	Id = "ghouls",
	Weight = 0.8,
	Duration = 24,
	Target = "Arena",
	Run = function(context: any)
		K.Start(context)
		local plates = K.Plates()
		if #plates == 0 then
			return
		end
		K.TellAll("Whack-a-Ghoul!", "Step on the ghouls for candles. The ones you miss will nip!", K.Colors.Purple)
		local ghouls: { Ghoul } = {}
		local nextGhoul = 1
		local lastOne = context.Event.Duration - UP_TIME - 1 -- (so the last ghoul still has time to go back down)
		K.Loop(context, function(_, t)
			if t >= nextGhoul and t < lastOne and #ghouls < MAX_AT_ONCE then
				nextGhoul = t + EVERY
				local _, occupied = K.Occupied(plates)
				local plate = (math.random() < 0.7 and K.Pick(occupied)) or K.Pick(plates)
				if plate and plate.Parent then
					local spot = K.PointOn(plate, 3)
					table.insert(ghouls, {
						Id = K.Show(context, "Ghoul", CFrame.new(spot) * CFrame.Angles(0, math.random() * math.pi * 2, 0), { T0 = K.Now(), Up = UP_TIME, Range = NIP_RANGE, Seed = math.random(1, 100000) }),
						Spot = spot, Born = t,
					})
				end
			end
			for index = #ghouls, 1, -1 do
				local ghoul = ghouls[index]
				local done = false
				if t - ghoul.Born > 0.25 then
					K.Each(function(player, root, _, feetY)
						if not done and K.Flat(root.Position - ghoul.Spot).Magnitude <= 3.2 and math.abs(feetY - ghoul.Spot.Y) <= 4 then
							done = true
							K.Candles(player, REWARD)
							K.Complete(context, player) -- Event Journal: you have whacked one
							K.Signal(context, ghoul.Id, "Whack", player.UserId, REWARD)
						end
					end)
				end
				if not done and t - ghoul.Born >= UP_TIME then
					done = true
					K.Signal(context, ghoul.Id, "Nip")
					K.Each(function(player, root, _, feetY)
						if K.Flat(root.Position - ghoul.Spot).Magnitude <= NIP_RANGE and math.abs(feetY - ghoul.Spot.Y) <= 5 then
							K.Strike(context, ghoul.Id, player, NIP_DAMAGE)
						end
					end)
				end
				if done then
					K.Hide(context, ghoul.Id, 0.9)
					table.remove(ghouls, index)
				end
			end
		end)
		K.Hold(context)
	end,
}
