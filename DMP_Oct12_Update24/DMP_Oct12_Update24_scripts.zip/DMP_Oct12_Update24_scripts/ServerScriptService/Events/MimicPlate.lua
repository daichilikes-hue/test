-- ModuleScript: ServerScriptService > Events > MimicPlate     (/setevent mimic)
-- A few plates are secretly MIMICS. Nothing gives them away. Set foot on one and the plate folds shut on you like
-- a pair of jaws: 40 damage, no way out once you have touched it. Each mimic bites once.
-- Oct 10 2026 (update 10), your list:
--   * "completely invisible until its too late": the hairline crack is gone, and nothing at all exists on a mimic
--     (not on the server, not on the clients) until somebody is on it;
--   * "unavoidable once ur on it": it goes off the moment you land (no half second of standing, no time to jump
--     off), and whoever touched it is bitten SNAP seconds later wherever they have got to;
--   * "fold in on itself ... a clone spawns that is like half and then the jaws shut ... and its quick": the real
--     plate is not touched. A copy of its top, cut in two under your feet, swings up and slams shut (the model Jaws
--     under this script; drawn by ReplicatedStorage > EventClients > mimic).
-- Mimics are only ever plates that NOBODY is standing on when the event starts: you have to jump onto one.
-- It uses Systems > EventUtil now (it was one of the last events on the old EventKit).
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local MIMIC_MIN = 1
local MIMIC_MAX = 4        -- how many plates are mimics: one for every two players, between these two
local DAMAGE = 40
local SNAP = 0.22          -- seconds from touching it to the jaws shutting (that is when it hurts)
local HOLD = 0.7           -- seconds the jaws stay shut
local OPEN = 0.5           -- seconds they take to fold back down and vanish
local LAUNCH = 0           -- the old upward spit when it bites (it was 32). 0 = none
local MIN_JAW = 1.5        -- the smaller jaw is never narrower than this (studs)

local BLOOD = Color3.fromRGB(190, 30, 45)

type Mimic = { Plate: BasePart, Spent: boolean }

-- Has this player set foot on the plate? (over it, feet at its top: landed, or a moment from landing)
local function touching(plate: BasePart, root: BasePart, feetY: number): boolean
	local top = K.Top(plate)
	return K.Inside(plate, root.Position, 0) and feetY >= top - 0.5 and feetY <= top + 1.2
end

return {
	Name = "Mimic Plate",
	Id = "mimic",
	Weight = 0.8,
	Duration = 30,
	Target = "Arena",
	Run = function(context: any)
		K.Start(context)
		local alive = K.Alive()
		if #alive == 0 then
			return
		end
		-- plates with nobody on (or jumping over) them, in a random order
		local plates = K.Shuffle(K.Plates())
		local taken = K.Occupied(plates)
		local mimics: { Mimic } = {}
		local count = math.clamp(math.ceil(#alive / 2), MIMIC_MIN, MIMIC_MAX)
		for _, plate in plates do
			if #mimics < count and not taken[plate] then
				table.insert(mimics, { Plate = plate, Spent = false })
			end
		end
		if #mimics == 0 then
			return
		end

		-- the plate folds shut on whoever is on it
		local function bite(mimic: Mimic, victims: { Player }, first: BasePart)
			local plate = mimic.Plate
			-- the fold runs under the first one to touch it, along whichever way cuts the plate more evenly
			local at = plate.CFrame:PointToObjectSpace(first.Position)
			local along: string, offset: number, half: number
			if math.abs(at.X) <= math.abs(at.Z) then
				along, offset, half = "Z", at.X, plate.Size.X / 2
			else
				along, offset, half = "X", at.Z, plate.Size.Z / 2
			end
			local limit = math.max(half - MIN_JAW, 0)
			offset = math.clamp(offset, -limit, limit)
			local now = K.Now()
			local jaws = K.Show(context, "Jaws", plate.CFrame * CFrame.new(0, plate.Size.Y / 2, 0), {
				T0 = now, Snap = SNAP, Hold = HOLD, Open = OPEN,
				Size = plate.Size, Along = along, At = offset, Color = plate.Color, Material = plate.Material,
			})
			if not K.WaitUntil(context, now + SNAP) then
				return
			end
			-- everybody who touched it, wherever they are now, and anybody else who is on it as it shuts
			local bitten: { [Player]: boolean } = {}
			for _, player in victims do
				bitten[player] = true
			end
			if plate.Parent then
				K.Each(function(player, root, _, feetY)
					if K.StandingOn(plate, root, feetY, 0) then
						bitten[player] = true
					end
				end)
			end
			for player in bitten do
				if K.IsAlive(player) then
					K.Strike(context, jaws, player, DAMAGE, if LAUNCH > 0 then Vector3.new(0, LAUNCH, 0) else nil, 0.3)
				end
			end
			K.Hide(context, jaws, HOLD + OPEN + 0.1)
		end

		K.TellAll("Mimic Plate", "Not every plate is what it seems...", BLOOD)

		while context.IsRunning() do
			for _, mimic in mimics do
				local plate = mimic.Plate
				if not mimic.Spent then
					if not plate.Parent then
						mimic.Spent = true
					else
						local victims: { Player } = {}
						local first: BasePart? = nil
						K.Each(function(player, root, _, feetY)
							if touching(plate, root, feetY) then
								table.insert(victims, player)
								first = first or root
							end
						end)
						if first then
							mimic.Spent = true
							task.spawn(bite, mimic, victims, first)
						end
					end
				end
			end
			task.wait(0.05)
		end
	end,
}
