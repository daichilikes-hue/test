-- ModuleScript: ServerScriptService > Events > BatNet     (NEW: Oct 12 Update 23, /setevent batnet)
-- BAT NET (your backlog, protection event 7): a swarm of bats (the model Bats under this script) gathers under 1 to 3
-- random plates. Fall off near one and the bats catch you and toss you back up onto that plate, ONCE; then that
-- swarm flies away. Swarms nobody needed leave when the event ends.
-- This script watches for falling players and bounces them. The bats are drawn in ReplicatedStorage > EventClients > batnet.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local DURATION = 20
local MIN_NETS = 1
local MAX_NETS = 3
local REACH = 9             -- studs out from a net plate's edge that still counts as "near" (seen from above)
local CATCH_BELOW = 2.5     -- you are caught once your feet are this far below the plate's top ...
local CATCH_DEPTH = 13      -- ... and not deeper than this (the void is about 17 down)
local APEX = 7              -- studs over the plate's top the toss carries you
local LAND_INSET = 4        -- you land this far in from the plate's edge

-- the velocity that throws something from `from` over a peak APEX above `top` onto `to` (plain gravity)
local function toss(from: Vector3, to: Vector3, top: number): Vector3
	local g = workspace.Gravity
	local peak = math.max(top + APEX, from.Y + 2, to.Y + 2)
	local up = math.sqrt(2 * g * (peak - from.Y))
	local timeUp = up / g
	local timeDown = math.sqrt(2 * math.max(peak - to.Y, 0.1) / g)
	local flat = Vector3.new(to.X - from.X, 0, to.Z - from.Z) / (timeUp + timeDown)
	return Vector3.new(flat.X, up, flat.Z)
end

return {
	Name = "Bat Net",
	Id = "batnet",
	Weight = 1,
	Duration = DURATION,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local plates = K.Shuffle(K.Plates())
		local nets: { { Plate: BasePart, Id: number?, Used: boolean } } = {}
		for i = 1, math.min(#plates, math.random(MIN_NETS, math.max(MIN_NETS, MAX_NETS))) do
			local plate = plates[i]
			local id = K.Show(context, "Bats", CFrame.new(K.TopCentre(plate)), {
				T0 = t0, Duration = DURATION, Tag = K.Tag(context, plate), Seed = i,
			})
			table.insert(nets, { Plate = plate, Id = id, Used = false })
		end
		K.TellAll("Bat Net", "Bats are gathering under some plates. Fall near one and they'll toss you back up!", K.Colors.Purple)

		local bounced: { [Player]: number } = {}
		K.Loop(context, function()
			for _, net in nets do
				local plate = net.Plate
				if not net.Used and plate.Parent then
					local top = K.Top(plate)
					K.Each(function(player, root, _, feetY)
						if net.Used or (bounced[player] and K.Now() - bounced[player] < 1.5) then
							return
						end
						if feetY > top - CATCH_BELOW or feetY < top - CATCH_DEPTH then
							return
						end
						-- how far outside the plate (seen from above)
						local dx = math.max(math.abs(root.Position.X - plate.Position.X) - plate.Size.X / 2, 0)
						local dz = math.max(math.abs(root.Position.Z - plate.Position.Z) - plate.Size.Z / 2, 0)
						if math.sqrt(dx * dx + dz * dz) > REACH then
							return
						end
						net.Used = true
						bounced[player] = K.Now()
						-- land on the plate, at the spot nearest to where they fell, LAND_INSET in from the edge
						local hx = math.max(plate.Size.X / 2 - LAND_INSET, 0)
						local hz = math.max(plate.Size.Z / 2 - LAND_INSET, 0)
						local land = Vector3.new(
							math.clamp(root.Position.X, plate.Position.X - hx, plate.Position.X + hx),
							top + 3,
							math.clamp(root.Position.Z, plate.Position.Z - hz, plate.Position.Z + hz)
						)
						K.Push(player, toss(root.Position, land, top), 0.12)
						K.Call(context, net.Id, "Bounce", player.UserId)
						K.Hide(context, net.Id, 3)
						K.Complete(context, player) -- (the Event Journal: the bats saved you)
					end)
				end
			end
		end)
	end,
}
