-- ModuleScript: ServerScriptService > Events > GraveLilies     (NEW: Oct 12 Update 23, /setevent lilies)
-- GRAVE LILIES (your backlog, healing event 4): 4 to 8 pale lilies bloom on random plates. Pick one (hold E) and it
-- heals you HEAL HP, gives you a buff (Second Wind or Sure Footing, from your buff list) and, now and then, a Grave
-- Lily item. Each player can pick PER_PLAYER lilies. The ones nobody picks wilt when the event ends.
--   Second Wind: the next time a hit drops you below 25% health (and you live), you heal 15 HP at once.
--   Sure Footing: for 30 s, a plate you stand on crumbles 1.5 s later than it should.
-- (Both live in Systems > EventUtil.Buff; Sure Footing works inside Systems > PlateSpawner.DestroyPlate.)
-- The lilies themselves (the model Lily under this script) bloom in ReplicatedStorage > EventClients > lilies.
local ServerStorage = game:GetService("ServerStorage")
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local DURATION = 18
local MIN_LILIES = 4
local MAX_LILIES = 8
local HEAL = 10
local ITEM_CHANCE = 0.12    -- chance a lily also gives you the Grave Lily item
local ITEM = "Grave Lily"   -- (the Tool in ServerStorage > Items)
local BUFFS = { "SecondWind", "SureFooting" }  -- one of these at random (one you do not have yet when it can)
local PER_PLAYER = 1        -- lilies one player may pick (so everybody gets a chance)
local HOLD = 0.35           -- seconds to hold E
local BLOOM = 2             -- the lilies bloom one after another over this many seconds

local function giveLily(player: Player): boolean
	local items = ServerStorage:FindFirstChild("Items")
	local template = items and items:FindFirstChild(ITEM, true)
	local backpack = player:FindFirstChildOfClass("Backpack")
	if template and template:IsA("Tool") and backpack then
		template:Clone().Parent = backpack
		return true
	end
	return false
end

return {
	Name = "Grave Lilies",
	Id = "lilies",
	Weight = 1,
	Duration = DURATION,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local Damage = K.Sys("Damage")
		local plates = K.Shuffle(K.Plates())
		if #plates == 0 then
			return
		end
		local count = math.random(MIN_LILIES, math.max(MIN_LILIES, MAX_LILIES))
		local picks: { [Player]: number } = {}
		K.TellAll("Grave Lilies", "Pale lilies are blooming on the plates. Pick one to heal.", K.Colors.Ghost)
		for i = 1, count do
			local plate = plates[(i - 1) % #plates + 1]
			local spot = K.PointOn(plate, 3)
			local yaw = math.random() * math.pi * 2
			local delay = (i - 1) / math.max(count - 1, 1) * BLOOM
			local id = K.Show(context, "Lily", CFrame.new(spot) * CFrame.Angles(0, yaw, 0), {
				T0 = t0, Duration = DURATION, Delay = delay, Tag = K.Tag(context, plate),
			})
			local anchor, prompt = K.Prompt(spot + Vector3.new(0, 1.6, 0), "Pick", "Grave Lily", HOLD, context.Folder)
			prompt.Enabled = false
			prompt.MaxActivationDistance = 8
			prompt.RequiresLineOfSight = false
			local gone = false
			local function remove()
				if not gone then
					gone = true
					anchor:Destroy()
				end
			end
			K.Pin(context, anchor, plate, function()
				remove()
				K.Hide(context, id)
			end)
			task.delay(delay + 0.6, function()
				if context.IsRunning() and not gone then
					prompt.Enabled = true
				end
			end)
			prompt.Triggered:Connect(function(player: Player)
				if gone or not context.IsRunning() or not K.IsAlive(player) then
					return
				end
				if (picks[player] or 0) >= PER_PLAYER then
					return
				end
				picks[player] = (picks[player] or 0) + 1
				remove()
				K.Call(context, id, "Picked", player.UserId)
				K.Hide(context, id, 1.5)
				-- what it gives: the heal, a buff, maybe the item
				local got: { string } = {}
				if Damage and Damage.Heal then
					local ok, amount = pcall(Damage.Heal, player, HEAL, { Source = "Grave Lilies" })
					if ok and type(amount) == "number" and amount > 0 then
						table.insert(got, "+" .. math.floor(amount + 0.5) .. " HP")
					end
				end
				local options: { string } = {}
				for _, name in BUFFS do
					if player:GetAttribute("Buff_" .. name) == nil then
						table.insert(options, name)
					end
				end
				local buff = K.Pick(if #options > 0 then options else BUFFS)
				if buff and K.Buff(player, buff) then
					table.insert(got, K.BuffNames[buff] or buff)
				end
				if math.random() < ITEM_CHANCE and giveLily(player) then
					table.insert(got, "a " .. ITEM)
				end
				K.Complete(context, player) -- (the Event Journal: you picked one)
				K.Tell(player, "Grave Lily", if #got > 0 then table.concat(got, ", ") else "It smells of rain.", K.Colors.Ghost)
			end)
		end
		-- the ones nobody picked wilt just before the end
		K.Outro(context, 1.2, function()
			for _, item in context.Folder:GetDescendants() do
				if item:IsA("ProximityPrompt") then
					item.Enabled = false
				end
			end
		end)
	end,
}
