-- ModuleScript: ServerScriptService > Events > HeadlessHorseman     (REPLACE)
-- He picks one player and charges straight at them from the edge of the arena, flattening ANYONE in his
-- path. While he winds up he keeps turning to face his target, so the target can aim him at other players:
-- stand so somebody else is between you and him, then step out of the way.
-- Oct 10 2026 (update 8): no aim line on the ground any more (it made him too easy to dodge: watch which way
-- he faces), your ExclamationWarning over his target's head, half the knockback, twice the damage, and each
-- player is told "He's after YOU!" once per event instead of at every charge.
-- This script decides the hits. What it looks like: ReplicatedStorage > EventClients > horseman.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local CHARGES = 3
local AIM_TIME = 1.8     -- seconds he keeps turning to face his target (was 2.2)
local LOCK_TIME = 0.5    -- seconds he stays locked on that line before he goes
local SPEED = 105        -- (was 85)
local WIDTH = 6          -- how wide his path is
local DAMAGE, PUSH, LIFT = 50, 25, 12   -- (was 25, 50, 24: twice the damage, half the knockback)
local REST = 0.6         -- seconds between charges (was 0.8)

return {
	Name = "Headless Horseman",
	Id = "horseman",
	Weight = 1,
	Duration = 22,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local centre, radius = K.Arena(K.Plates())
		local reach = radius + 22
		local distance = reach * 2 + 20
		local rider = K.Show(context, "Horseman", CFrame.new(centre), { T0 = t0, Reach = reach, Width = WIDTH })
		K.TellAll("Headless Horseman!", "He charges in a straight line and flattens anyone in his path.", K.Colors.Orange)

		local last: Player? = nil
		local told: { [Player]: boolean } = {}
		for _ = 1, CHARGES do
			local alive = K.Alive()
			if #alive == 0 or not context.IsRunning() then
				break
			end
			local target = alive[math.random(1, #alive)]
			if #alive > 1 and target == last then
				target = alive[((table.find(alive, target) or 1) % #alive) + 1]
			end
			last = target
			if not told[target] then
				-- (once per player per event: after that the warning over your head says it)
				told[target] = true
				K.Tell(target, "He's after YOU!", "He turns to face you. Line him up with someone else, then get out of the way!", K.Colors.Orange)
			end

			local angle = math.random() * math.pi * 2
			local from = centre + Vector3.new(math.cos(angle) * reach, 0, math.sin(angle) * reach)
			local dir = K.Dir(centre - from)
			local start = K.Now()
			K.Signal(context, rider, "Aim", from, target.UserId, start, AIM_TIME, LOCK_TIME)
			-- he keeps turning toward his target while he winds up
			while context.IsRunning() and K.Now() < start + AIM_TIME do
				local root = K.Root(target)
				if root then
					dir = K.Dir(root.Position - from, dir)
				end
				task.wait(0.05)
			end
			K.Signal(context, rider, "Lock", dir)
			if not K.WaitUntil(context, start + AIM_TIME + LOCK_TIME) then
				break
			end

			local go = K.Now()
			K.Signal(context, rider, "Charge", from, dir, go, SPEED, distance)
			local perp = Vector3.new(-dir.Z, 0, dir.X)
			local gone = 0
			local hit: { [Player]: boolean } = {}
			while context.IsRunning() and gone < distance do
				local before = gone
				gone = math.min((K.Now() - go) * SPEED, distance)
				K.Each(function(player, root, _, feetY)
					local offset = K.Flat(root.Position - from)
					local along, side = offset:Dot(dir), offset:Dot(perp)
					local inPath = math.abs(side) <= WIDTH / 2 + 0.5 and along >= before - 3 and along <= gone + 3
					if inPath and not hit[player] and feetY <= centre.Y + 6 and feetY >= centre.Y - 3 then
						hit[player] = true
						K.Strike(context, rider, player, DAMAGE, perp * (if side >= 0 then PUSH else -PUSH) + Vector3.new(0, LIFT, 0), 0.4)
					end
				end)
				task.wait(0.03)
			end
			task.wait(REST)
		end
		K.Hold(context)
	end,
}
