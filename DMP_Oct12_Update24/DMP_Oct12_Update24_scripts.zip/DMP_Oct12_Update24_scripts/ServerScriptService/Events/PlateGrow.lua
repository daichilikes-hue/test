-- ModuleScript: ServerScriptService > Events > PlateGrow     (/setevent grow)     (Oct 11 Update 19: RISING TOMB)
--
-- [Update 19] Was "Hallowed Ground" (a random player's plate swelled 20% wider). Now RISING TOMB: a plate somebody
-- is standing on GROWS TALLER, stone layer by stone layer, like a tomb pushing up out of the void, and carries whoever
-- is on it up with it (the plate's velocity is set every frame, the same trick as your Plate Waves). It turns to
-- stone while it is a tomb, stands at its full height for a while, then sinks back to exactly what it was.
-- Plates are physical, so this happens on the server (everyone sees it via replication). The tombstone on its side,
-- the dust and the rumble: ReplicatedStorage > EventClients > grow (and the model Tomb under this script).

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local LAYERS = 5            -- stone layers it grows
local LAYER_HEIGHT = 3      -- studs each (5 x 3 = 15 studs taller)
local LAYER_TIME = 0.45     -- seconds one layer takes to push up
local LAYER_GAP = 0.9       -- seconds from the start of one layer to the next
local WARN = 1.4            -- seconds it rumbles before the first layer
local HOLD = 8              -- seconds it stands at its full height
local SINK_TIME = 2.6       -- seconds it takes to sink back down
local SINK_BACK = true      -- false = it stays tall for the rest of the round (other events then see one tall plate)
local STONE: Enum.Material? = Enum.Material.Cobblestone -- what the plate is made of while it is a tomb (nil = its own)
local WIDEN = 1             -- your old Hallowed Ground: 1.2 = it also swells 20% wider (that stays for the round, as before)
local MAX_SIZE = 30         -- (with WIDEN) plates never get wider than this (studs)

local RISE = WARN + (LAYERS - 1) * LAYER_GAP + LAYER_TIME -- (seconds until it is at its full height)

-- how much taller than its own height the plate is, `t` seconds into the event
local function grownAt(t: number): number
	if t < RISE + HOLD then
		local grown = 0
		for layer = 1, LAYERS do
			local start = WARN + (layer - 1) * LAYER_GAP
			local k = math.clamp((t - start) / LAYER_TIME, 0, 1)
			grown += LAYER_HEIGHT * (k * k * (3 - 2 * k)) -- (each layer eases in and out: no jolt for whoever rides it)
		end
		return grown
	end
	if not SINK_BACK then
		return LAYERS * LAYER_HEIGHT
	end
	local k = math.clamp((t - RISE - HOLD) / SINK_TIME, 0, 1)
	return LAYERS * LAYER_HEIGHT * (1 - k * k * (3 - 2 * k))
end

return {
	Name = "Rising Tomb",
	Id = "grow",
	Weight = 1,
	Duration = math.ceil(RISE + HOLD + SINK_TIME + 0.8),
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local plates = K.Plates()
		-- a plate somebody is standing on (so somebody rides it up); any plate when nobody is on one
		local plate, player = K.PickPlate(plates)
		if not plate then
			return
		end
		if player then
			ReplicatedStorage:SetAttribute("ActiveEventTarget", player.DisplayName)
		end
		local home = plate.CFrame
		local material = plate.Material
		if WIDEN ~= 1 then
			plate.Size = Vector3.new(math.min(plate.Size.X * WIDEN, MAX_SIZE), plate.Size.Y, math.min(plate.Size.Z * WIDEN, MAX_SIZE))
		end
		local size = plate.Size
		local baseTop = K.Top(plate)
		context.Trash.Add(function()
			if plate.Parent then
				if SINK_BACK then
					plate.Size = size
					plate.CFrame = home
					plate.Material = material
				end
				plate.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
			end
		end)

		-- the side that looks at the middle of the arena carries the tombstone
		local centre = K.Arena(plates)
		local toward = home:VectorToObjectSpace(Vector3.new(centre.X - home.Position.X, 0, centre.Z - home.Position.Z))
		local axis = if math.abs(toward.X) > math.abs(toward.Z) then Vector3.new(math.sign(toward.X), 0, 0) else Vector3.new(0, 0, if toward.Z > 0 then 1 else -1)
		local face = home:VectorToWorldSpace(axis)
		K.Show(context, "Tomb", CFrame.new(K.TopCentre(plate)), {
			T0 = t0, Tag = K.Tag(context, plate), BaseTop = baseTop, FaceX = face.X, FaceZ = face.Z,
			Layers = LAYERS, LayerHeight = LAYER_HEIGHT, Warn = WARN, Rise = RISE, Hold = HOLD, Sink = SINK_TIME, SinkBack = SINK_BACK,
		})
		K.TellAll("Rising Tomb!", "A tomb is rising out of the void. Ride it up, or jump off!", K.Colors.Bone)

		-- it grows (and sinks), carrying whoever stands on it
		local was = 0
		local stone = "not yet"
		local rode: { [Player]: boolean } = {}
		K.Loop(context, function(dt: number, t: number)
			if not plate.Parent then
				return
			end
			local grown = grownAt(t)
			if grown ~= was or plate.AssemblyLinearVelocity.Y ~= 0 then
				plate.Size = Vector3.new(size.X, size.Y + grown, size.Z)
				plate.CFrame = home + home.UpVector * (grown / 2)
				-- (the top moves at the full speed: that is what carries the riders)
				plate.AssemblyLinearVelocity = home.UpVector * ((grown - was) / math.max(dt, 1 / 240))
				was = grown
			end
			-- stone while it is a tomb; its own again once it has sunk back
			if STONE and t >= WARN and stone == "not yet" then
				stone = "on"
				plate.Material = STONE
			elseif stone == "on" and SINK_BACK and t >= RISE + HOLD + SINK_TIME then
				stone = "over"
				plate.Material = material
			end
			-- (the Event Journal: rode it all the way up)
			if t >= RISE and t < RISE + HOLD then
				K.Each(function(somebody: Player, root: BasePart, _, feetY: number)
					if not rode[somebody] and K.StandingOn(plate, root, feetY) then
						rode[somebody] = true
						K.Complete(context, somebody)
					end
				end)
			end
		end)
		K.Hold(context)
	end,
}
