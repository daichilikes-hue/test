-- ModuleScript: ServerScriptService > Events > SpiderDrop     (REPLACE)     (/setevent spiderdrop)
-- Oct 10 2026 (update 9), your list: NO dangling spiders any more. Spiders run across the whole arena, from one
-- border to the other, and each leaves a taut line of silk behind it at shin height: a TRIPWIRE. Far fewer of them:
-- every plate is crossed by about WIRES_PER_PLATE wires (it had 6 hanging threads), which is about 15 spiders for a
-- full arena instead of 150.
--   Walk into a wire and it sticks to you: you are slowed (it stacks, and wears off after SLOW_TIME). JUMP over them.
--   Touch THREE different wires and you are wrapped in a cocoon. You cannot move. Unless somebody tears you out
--   (hold the prompt on your cocoon) before WRAP_TIME runs out, the huge spider that has been walking toward you
--   gets there and drags you off: you are out. (No gore: a cocoon, a spider, and off it goes.)
-- The wires are worked out from the same numbers on the server and every client (sent once at the start), so the
-- server knows exactly how far every spider has run.
-- The spiders: the "Spider" in ServerStorage > Items > Spider Jar is used if it is a single part (MeshPart);
-- otherwise a small built one. The wire and the cocoon are the models Thread and Cocoon under this script.
-- What it all looks like: ReplicatedStorage > EventClients > spiderdrop.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local WIRES_PER_PLATE = 3   -- about how many wires cross each plate (the old one hung 6 threads over each: this is half)
local MIN_WIRES, MAX_WIRES = 4, 24
local WIRE_HEIGHT = 1.4     -- studs above the plate tops (shin height: an easy jump)
local SPACING = 6           -- studs two wires that run the same way are at least apart
local SLANT = 22            -- a wire may end up to this many studs to the side of where it started (0 = all dead straight)
local RUN_SPEED = 62        -- studs a second a spider runs (so a wire takes about 3 s to cross the arena)
local SPREAD = 6            -- the spiders set off over this many seconds (not all at once)
local TOUCH = 1.2           -- studs: how close to a wire counts as touching it
local SLOW, SLOW_TIME = 0.72, 8   -- each wire you touch: walk speed x SLOW for SLOW_TIME seconds (they stack)
local COCOON_AT = 3         -- different wires touched = cocooned
local WRAP_TIME = 4         -- seconds somebody has to tear you out
local TEAR_HOLD = 1.2       -- seconds to hold the prompt that tears a cocoon open
local EATEN_TIME = 1.2      -- seconds from the huge spider reaching you to you being out
local IMMUNE = 2.5          -- seconds after being torn out before wires can stick again
local CLIMB = 2             -- seconds at the end for the spiders to run back and take their silk with them

type Wire = { AX: number, AZ: number, BX: number, BZ: number, Start: number, Speed: number, Length: number }

-- How far along wire `w` (studs from its A end) the silk reaches at time `t` (seconds since the event started).
-- KEEP IN SYNC with reached() in EventClients > spiderdrop.
local function reached(w: Wire, t: number): number
	return math.clamp((t - w.Start) * w.Speed, 0, w.Length)
end

-- the jar's spider for the clients to copy (ReplicatedStorage > EventAssets > spiderdrop > Spider)
local function shareSpider()
	local assets = ReplicatedStorage:FindFirstChild("EventAssets")
	local folder = assets and assets:FindFirstChild("spiderdrop")
	if not folder or folder:FindFirstChild("Spider") then
		return
	end
	local items = ServerStorage:FindFirstChild("Items")
	local jar = items and items:FindFirstChild("Spider Jar", true)
	local spider = jar and jar:FindFirstChild("Spider", true)
	if spider and spider:IsA("BasePart") then
		local copy = spider:Clone()
		for _, child in copy:GetDescendants() do
			if child:IsA("LuaSourceContainer") or child:IsA("JointInstance") or child:IsA("WeldConstraint") then
				child:Destroy()
			end
		end
		copy.Parent = folder
	end
end

return {
	Name = "Spider Drop",
	Id = "spiderdrop",
	Weight = 0.8,
	Duration = 30,
	Target = "Arena",
	Run = function(context: any)
		-- (plain words instead of a red error when Systems > EventUtil is an older copy than this script was made for)
		if not (K.Border and K.Box and K.BaseTop) then
			warn("[Spider Drop] ServerScriptService > Systems > EventUtil is an OLDER copy than this event was made for, so the event is skipped. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
			return
		end
		local t0 = K.Start(context)
		local plates = K.Plates()
		if #plates == 0 then
			return
		end
		pcall(shareSpider)

		-- the wires: from one border wall to the opposite one, across the plates
		local middle, halfX, halfZ = K.Border()
		local minX, maxX, minZ, maxZ = K.Box(plates)
		local wireY = K.BaseTop() + WIRE_HEIGHT
		local count = math.clamp(math.floor(#plates * WIRES_PER_PLATE / 5 + 0.5), MIN_WIRES, MAX_WIRES)
		local wires: { Wire } = {}
		local flat: { number } = {}
		local taken: { [boolean]: { number } } = { [true] = {}, [false] = {} } -- where the wires of each direction cross the middle
		local function round(value: number): number
			return math.floor(value * 1000 + 0.5) / 1000
		end
		for index = 1, count do
			local alongX = index % 2 == 1 -- (every other one runs the other way)
			local low, high = if alongX then minZ else minX, if alongX then maxZ else maxX
			local from: number?, to: number? = nil, nil
			for _ = 1, 12 do
				local a = low + 1.5 + math.random() * math.max(high - low - 3, 0)
				local b = math.clamp(a + (math.random() * 2 - 1) * SLANT, low + 1.5, high - 1.5)
				local mid = (a + b) / 2
				local free = true
				for _, other in taken[alongX] do
					if math.abs(other - mid) < SPACING then
						free = false
						break
					end
				end
				if free then
					from, to = a, b
					table.insert(taken[alongX], mid)
					break
				end
			end
			if from and to then
				local flip = math.random() < 0.5 -- (which wall it sets off from)
				local ax: number, az: number, bx: number, bz: number
				if alongX then
					ax, bx = middle.X - halfX, middle.X + halfX
					az, bz = from, to
				else
					az, bz = middle.Z - halfZ, middle.Z + halfZ
					ax, bx = from, to
				end
				if flip then
					ax, az, bx, bz = bx, bz, ax, az
				end
				local wire: Wire = { AX = round(ax), AZ = round(az), BX = round(bx), BZ = round(bz), Start = round(0.6 + math.random() * SPREAD), Speed = round(RUN_SPEED * (0.85 + math.random() * 0.3)), Length = 0 }
				wire.Length = math.sqrt((wire.BX - wire.AX) ^ 2 + (wire.BZ - wire.AZ) ^ 2)
				table.insert(wires, wire)
				for _, value in { wire.AX, wire.AZ, wire.BX, wire.BZ, wire.Start, wire.Speed } do
					table.insert(flat, value)
				end
			end
		end
		local web = K.Show(context, "Web", CFrame.new(middle.X, wireY, middle.Z), {
			T0 = t0, Wires = flat, Climb = CLIMB, Eaten = EATEN_TIME, HalfX = halfX, HalfZ = halfZ, Height = WIRE_HEIGHT,
		})
		K.TellAll("Spider Drop", "Tripwires! Jump over the silk: three wires on you and you're wrapped.", Color3.fromRGB(170, 165, 150))

		local touched: { [Player]: { [number]: boolean } } = {}
		local counts: { [Player]: number } = {}
		local immune: { [Player]: number } = {}
		local cocooned: { [Player]: { Prompt: ProximityPrompt?, Anchor: BasePart?, Freed: boolean } } = {}
		local over = false
		local slowCount = 0

		local function free(player: Player)
			local cocoon = cocooned[player]
			if not cocoon then
				return
			end
			cocooned[player] = nil
			cocoon.Freed = true
			if cocoon.Anchor then
				cocoon.Anchor:Destroy()
			end
			K.Unmod(player, "SpiderCocoonWalk")
			K.Unmod(player, "SpiderCocoonJump")
			touched[player] = {}
			counts[player] = 0
			immune[player] = os.clock() + IMMUNE
			K.Signal(context, web, "Freed", player.UserId)
		end
		context.Trash.Add(function()
			for player in table.clone(cocooned) do
				if player.Parent then
					free(player)
				end
			end
		end)

		local function cocoon(player: Player, root: BasePart)
			local entry = { Prompt = nil :: ProximityPrompt?, Anchor = nil :: BasePart?, Freed = false }
			cocooned[player] = entry
			K.Mod(player, "WalkSpeed", { Mult = 0 }, "SpiderCocoonWalk")
			K.Mod(player, "Jump", { Mult = 0 }, "SpiderCocoonJump")
			K.Signal(context, web, "Cocoon", player.UserId, root.Position, WRAP_TIME)
			K.Tell(player, "Wrapped up!", "You can't move. Somebody has to tear you out before the spider gets to you...", Color3.fromRGB(170, 165, 150))
			-- the others can tear it open
			local anchor, prompt = K.Prompt(root.Position, "Tear the web", player.DisplayName .. "'s cocoon", TEAR_HOLD, context.Folder)
			entry.Anchor, entry.Prompt = anchor, prompt
			prompt.Triggered:Connect(function(helper: Player)
				if helper == player or entry.Freed or not K.IsAlive(helper) then
					return
				end
				K.Tell(helper, "You tore " .. player.DisplayName .. " out!", nil, Color3.fromRGB(170, 165, 150))
				K.Tell(player, helper.DisplayName .. " tore you out!", nil, Color3.fromRGB(170, 165, 150))
				K.Complete(context, helper) -- Event Journal: you have saved somebody from a cocoon
				free(player)
			end)
			task.delay(WRAP_TIME, function()
				if entry.Freed or cocooned[player] ~= entry or not context.IsRunning() then
					return
				end
				-- nobody came: the spider has
				if entry.Prompt then
					entry.Prompt.Enabled = false
				end
				K.Signal(context, web, "Eaten", player.UserId)
				task.delay(EATEN_TIME, function()
					if entry.Freed or cocooned[player] ~= entry then
						return
					end
					local Damage = K.Sys("Damage")
					K.Blame(context, player)
					if Damage and Damage.Kill then
						pcall(Damage.Kill, player, { Source = "Spider Drop" })
					end
					cocooned[player] = nil
					if entry.Anchor then
						entry.Anchor:Destroy()
					end
				end)
			end)
		end

		K.Outro(context, CLIMB, function()
			over = true -- the spiders run back with their silk: no more wires
			K.Signal(context, web, "Outro", CLIMB)
		end)

		local tick = 0
		K.Loop(context, function(dt: number)
			tick -= dt
			if tick > 0 or over then
				return
			end
			tick = 0.05
			local t = K.Now() - t0
			local now = os.clock()
			K.Each(function(player, root, _, feetY)
				if cocooned[player] or (immune[player] or 0) > now then
					return
				end
				-- (the wire has to cross your body: jump and it passes under your feet; on a raised plate you are above it)
				if wireY < feetY + 0.4 or wireY > feetY + 5 then
					return
				end
				local mine = touched[player] or {}
				touched[player] = mine
				local px, pz = root.Position.X, root.Position.Z
				for index, wire in wires do
					if not mine[index] then
						local far = reached(wire, t)
						if far > 0.5 then
							-- how far along the wire we are, and how far to the side of it
							local dx, dz = (wire.BX - wire.AX) / wire.Length, (wire.BZ - wire.AZ) / wire.Length
							local along = (px - wire.AX) * dx + (pz - wire.AZ) * dz
							if along >= 0 and along <= far then
								local side = math.abs((px - wire.AX) * dz - (pz - wire.AZ) * dx)
								if side <= TOUCH then
									mine[index] = true
									local touches = (counts[player] or 0) + 1
									counts[player] = touches
									slowCount += 1
									K.Mod(player, "WalkSpeed", { Mult = SLOW }, "SpiderSilk" .. slowCount, SLOW_TIME)
									K.Signal(context, web, "Touch", player.UserId, index, touches)
									if touches >= COCOON_AT then
										cocoon(player, root)
										return
									end
								end
							end
						end
					end
				end
			end)
		end)
		K.Hold(context)
	end,
}
