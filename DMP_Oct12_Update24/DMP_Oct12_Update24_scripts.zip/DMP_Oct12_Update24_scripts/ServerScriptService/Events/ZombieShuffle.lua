-- ModuleScript: ServerScriptService > Events > ZombieShuffle     (REPLACE)
-- Slow zombies climb out of the plates and shuffle at the nearest player. Up close they wind up and LUNGE
-- in a straight line. Two swings of anything you hold (any Tool) finish one; a hit that does not finish it knocks
-- it back, off the plate if it is near the edge.
-- Oct 10 2026 (update 11), your list:
--   * "they fall into the void on their own if they walk off the ledge": they do not walk off a ledge any more.
--     At an edge they stop. If somebody is across the gap they JUMP it, with their usual wind-up and lunge
--     (LEAP = false: they just stand there). A lunge that catches somebody stops there (it used to fly on, mostly
--     over the edge). Only a lunge that MISSES flies its whole length: sidestepping near an edge still gets rid
--     of one, and so does whacking it off.
--   * "It should take 2 jumps to squish one and it should bite u if u jump on it": STOMPS = 2, and every time you
--     land on its head it bites you (STOMP_BITE).
--   * "less like a kids birthday party": the smile every character starts with is taken off the zombies and a dead
--     face put on (the model Face under this script), their colours are duller, the fedora and the traffic cone
--     are gone. The rest of the look is in ReplicatedStorage > EventClients > zombies.
-- This script moves them and decides the hits. What they look like: ReplicatedStorage > EventClients > zombies.
-- It also builds the zombies' CHARACTERS when the server starts: R6 rigs dressed from the Roblox Marketplace
-- (LOOKS below), kept in ReplicatedStorage > EventClients > zombies > Rigs for every client to copy.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

-- THE ZOMBIES' LOOKS. One R6 character is built for each line; every zombie that rises is a copy of one of them.
--   Wear   = ids from the Roblox Marketplace, as many as you like: hats, hair, face / neck / shoulder / front /
--            back / waist accessories, classic shirts, classic pants, classic faces. Just paste the numbers,
--            the script works out which is which. (3D "layered" clothing does not show on R6 characters.)
--   Skin   = the colour of the head and arms.   Top / Bottom = the colour of the torso / legs (seen where
--            there is no shirt / pants).
-- Add, change or remove lines freely. A look that cannot be built is skipped (Output says why), and if none
-- can be built the old block zombies are shown.
-- YOUR OWN RIGS: any R6 character Model you put in ReplicatedStorage > EventClients > zombies > Rigs yourself (the
-- "Zombie" rig that came with this script, or copies of it that you dressed in Studio) is used as a look too.
-- A rig of yours with the same name as a line below replaces that line.
local LOOKS = {
	{ Name = "Officer", Wear = { 54934826 }, Skin = Color3.fromRGB(106, 120, 100), Top = Color3.fromRGB(38, 44, 60), Bottom = Color3.fromRGB(28, 30, 40) },     -- Officer Zombie
	{ Name = "Doctor", Wear = { 522090615 }, Skin = Color3.fromRGB(118, 126, 106), Top = Color3.fromRGB(146, 146, 136), Bottom = Color3.fromRGB(52, 64, 66) },  -- Dr. Zombie, PhDead
	{ Name = "Knight", Wear = { 22960210 }, Skin = Color3.fromRGB(100, 114, 102), Top = Color3.fromRGB(84, 86, 92), Bottom = Color3.fromRGB(48, 50, 56) },      -- Zombie Knight
	{ Name = "Sinister", Wear = { 133559536 }, Skin = Color3.fromRGB(110, 116, 94), Top = Color3.fromRGB(64, 36, 40), Bottom = Color3.fromRGB(36, 32, 38) },    -- Sinister Zombie
	-- (gone on Oct 10: "Fedora" = 522094442 + 4041573428 and "Cone" = the traffic cone 1082932. Put a line back to have one again.)
}
local RIGS_DEBUG = false                     -- true = Output says what each look was built from
local GRIM_FACES = true                      -- the Roblox smile comes off every zombie and the model Face goes on (false = faces as they are)

local WALK, LUNGE = 6.5, 30                  -- studs per second
local LUNGE_RANGE = 7                        -- how close before it winds up
local RISE_TIME = 1                          -- seconds it takes to climb out
local WIND_UP, LUNGE_TIME, REST = 0.6, 0.5, 0.5
local TOUCH_DAMAGE, LUNGE_DAMAGE = 7, 16
local EDGE = 0.5                             -- how far past a plate's edge it can be (knocked there, or where its lunge ends) before it falls
local LEDGE = 1.2                            -- how close to an edge it walks by itself: it never walks off one any more
local LEAP = true                            -- stuck at an edge, it jumps the gap with a lunge when that lands on a plate (false = it waits there)
local LEAP_WAIT = 0.8                        -- seconds it stands at the edge before it jumps
local LUNGE_STOPS = true                     -- a lunge that catches somebody stops there (false = it always flies its whole length, often over the edge)
local FALL_TIME = 1.4                        -- seconds a falling zombie is still shown
local EXTRA = 6                              -- zombies that can come back after some have fallen or been squished
local HITS = 2                               -- swings it takes to finish a zombie (any Tool in your hand)
local REACH = 7                              -- how close (in front of you) a swing reaches
local KNOCK_SPEED, KNOCK_TIME = 26, 0.35     -- a swing that does not finish it knocks it back this fast, this long
local TALL = 6                               -- how tall a zombie is (for jumping on its head)
local STOMPS = 2                             -- jumps on its head it takes to squish one (was 1)
local STOMP_BITE = 7                         -- it bites you for this much EVERY time you land on its head (0 = it does not)
local STOMP_GAP = 0.4                        -- seconds before the same zombie can be jumped on again
local STOMP_BOUNCE = 46                      -- how high you bounce off a zombie's head
local NEAR_PLAYERS = 0.75                    -- how often a zombie climbs out of a plate somebody is standing on
local REPORT_EVERY = 0.15                    -- seconds between "I am here" messages to the clients

type Zombie = { Id: number?, Position: Vector3, Facing: Vector3, State: string, Clock: number, Report: number, Hits: number, Knock: Vector3, Stomps: number, NoStomp: number, Stuck: number }
type Look = { Name: string, Wear: { number }?, Skin: Color3?, Top: Color3?, Bottom: Color3? }

---------------------------------------------------------------------
-- The characters (built once, when the server starts)
---------------------------------------------------------------------

-- which HumanoidDescription property a marketplace item goes in (by its asset type number)
local LIST_SLOTS: { [number]: string } = {
	[8] = "HatAccessory", [41] = "HairAccessory", [42] = "FaceAccessory", [43] = "NeckAccessory",
	[44] = "ShouldersAccessory", [45] = "FrontAccessory", [46] = "BackAccessory", [47] = "WaistAccessory",
}
local SINGLE_SLOTS: { [number]: string } = { [2] = "GraphicTShirt", [11] = "Shirt", [12] = "Pants", [17] = "Head", [18] = "Face" }

local ready: { string } = {}      -- the looks that have a character waiting in the Rigs folder
local building = true             -- (false once every look has been tried)

-- a Roblox function by its new name, or by its old one on an engine that does not have the new name yet
local function method(service: any, newName: string, oldName: string): (...any) -> ...any
	local ok, fn = pcall(function(): any
		return service[newName]
	end)
	return if ok and type(fn) == "function" then fn else service[oldName]
end

local function assetType(id: number): number?
	local ok, info = pcall(function(): any
		return method(MarketplaceService, "GetProductInfoAsync", "GetProductInfo")(MarketplaceService, id, Enum.InfoType.Asset)
	end)
	if ok and type(info) == "table" and type(info.AssetTypeId) == "number" then
		return info.AssetTypeId
	end
	return nil
end

local function createCharacter(description: HumanoidDescription): Model
	return method(Players, "CreateHumanoidModelFromDescriptionAsync", "CreateHumanoidModelFromDescription")(Players, description, Enum.HumanoidRigType.R6)
end

local function buildLook(look: Look, dressed: boolean): Model
	local description = Instance.new("HumanoidDescription")
	local skin = look.Skin or Color3.fromRGB(122, 164, 112)
	description.HeadColor, description.LeftArmColor, description.RightArmColor = skin, skin, skin
	description.TorsoColor = look.Top or Color3.fromRGB(70, 82, 114)
	local bottom = look.Bottom or Color3.fromRGB(52, 52, 64)
	description.LeftLegColor, description.RightLegColor = bottom, bottom
	if dressed then
		local lists: { [string]: { string } } = {}
		local wear: { number } = look.Wear or {}
		for _, id in wear do
			local kind = assetType(id)
			local single = kind and SINGLE_SLOTS[kind]
			if single then
				(description :: any)[single] = id
			elseif kind and kind >= 64 and kind <= 72 then
				warn(("[ZombieShuffle] look '%s': %d is 3D layered clothing, which does not show on R6 characters (skipped)"):format(look.Name, id))
			else
				-- (an accessory; when Roblox would not say what kind, it is tried as a hat)
				local slot = (kind and LIST_SLOTS[kind]) or "HatAccessory"
				local list = lists[slot] or {}
				lists[slot] = list
				table.insert(list, string.format("%.0f", id))
			end
			if RIGS_DEBUG then
				print(("[ZombieShuffle] look '%s': %d is asset type %s"):format(look.Name, id, tostring(kind)))
			end
		end
		for slot, list in lists do
			(description :: any)[slot] = table.concat(list, ",")
		end
	end
	local model = createCharacter(description)
	description:Destroy()
	-- a quiet copy to be cloned: no scripts, no name over its head, nothing that moves by itself
	for _, item in model:GetDescendants() do
		if item:IsA("LuaSourceContainer") then
			item:Destroy()
		elseif item:IsA("BasePart") then
			item.Anchored = true
			item.CanCollide = false
			item.CanQuery = false
			item.CanTouch = false
		elseif item:IsA("Humanoid") then
			item.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
			item.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff
		end
	end
	model.Name = look.Name
	return model
end

-- "less like a kids birthday party": a rig that still has the smile every Roblox character starts with loses it and
-- gets a copy of the model Face (under this script) welded to its head. A face you gave a rig yourself is left alone.
local function grimFace(rig: Instance)
	local template = script:FindFirstChild("Face")
	local head = rig:FindFirstChild("Head")
	if not (GRIM_FACES and template and head and head:IsA("BasePart")) or head:FindFirstChild("GrimFace") then
		return
	end
	local smile: Decal? = nil
	for _, item in head:GetChildren() do
		if item:IsA("Decal") and item.Name == "face" then
			local texture = string.lower(item.Texture)
			if texture ~= "" and not string.find(texture, "textures/face.png", 1, true) then
				return -- (not the default smile: somebody chose this face)
			end
			smile = item
		end
	end
	if smile then
		smile:Destroy()
	end
	local root = template:FindFirstChild("Root")
	local middle: CFrame = if root and root:IsA("BasePart") then root.CFrame else (template :: any):GetPivot()
	local folder = Instance.new("Folder")
	folder.Name = "GrimFace"
	for _, piece in template:GetChildren() do
		if piece:IsA("BasePart") and piece.Name ~= "Root" then
			local part = piece:Clone()
			local offset = middle:ToObjectSpace(piece.CFrame)
			part.CFrame = head.CFrame * offset
			part.Anchored = true
			part.CanCollide = false
			part.CanQuery = false
			part.CanTouch = false
			part.Massless = true
			local weld = Instance.new("Weld")
			weld.Name = "FaceWeld"
			weld.Part0 = head
			weld.Part1 = part
			weld.C0 = offset
			weld.Parent = part
			part.Parent = folder
		end
	end
	folder.Parent = head
end

local function buildRigs()
	local clients = ReplicatedStorage:WaitForChild("EventClients", 30)
	local module = clients and clients:WaitForChild("zombies", 30)
	if not module then
		warn("[ZombieShuffle] ReplicatedStorage > EventClients > zombies was not found, so the zombies are the old block ones")
		return
	end
	local folder = module:FindFirstChild("Rigs")
	if not folder then
		local made = Instance.new("Folder")
		made.Name = "Rigs"
		made.Parent = module
		folder = made
	end
	-- (a Rigs folder that was put NEXT TO the module instead of inside it counts too: its rigs are copied in)
	local beside = clients:FindFirstChild("Rigs")
	if beside and beside ~= folder then
		for _, item in beside:GetChildren() do
			if item:IsA("Model") and not folder:FindFirstChild(item.Name) then
				item:Clone().Parent = folder
			end
		end
	end
	local taken: { [string]: boolean } = {}
	-- the rigs that are already in the folder (put there by hand in Studio) are looks as they are
	for _, item in folder:GetChildren() do
		if item:IsA("Model") and not taken[item.Name] then
			taken[item.Name] = true
			table.insert(ready, item.Name)
		end
	end
	local notes: { string } = {}
	local firstError: string? = nil
	for index, look in LOOKS :: { Look } do
		if type(look.Name) == "string" and taken[look.Name] then
			continue -- (a rig with that name is already there: yours wins)
		end
		local name = if type(look.Name) == "string" and look.Name ~= "" then look.Name else "Look" .. index
		taken[name] = true
		local ok, result = pcall(buildLook, look, true)
		if not ok then
			-- once more with nothing on: a bad id in Wear should not cost the whole character
			local wearError = tostring(result)
			firstError = firstError or wearError
			ok, result = pcall(buildLook, look, false)
			table.insert(notes, if ok
				then ("look '%s' could not be built with what it wears (%s). It is built without: check the ids in its Wear list."):format(name, wearError)
				else ("look '%s' could not be built: %s"):format(name, tostring(result)))
		end
		if ok and typeof(result) == "Instance" then
			result.Name = name
			result.Parent = folder
			table.insert(ready, name)
		end
	end
	for _, item in folder:GetChildren() do
		if item:IsA("Model") then
			local ok, err = pcall(grimFace, item)
			if not ok then
				warn("[ZombieShuffle] the face of '" .. item.Name .. "' was left as it is: " .. tostring(err))
			end
		end
	end
	if #ready == 0 then
		warn("[ZombieShuffle] no zombie character could be built (" .. tostring(firstError) .. "), so the zombies are the old block ones")
	else
		for _, note in notes do
			warn("[ZombieShuffle] " .. note)
		end
		if RIGS_DEBUG then
			print("[ZombieShuffle] zombie characters ready: " .. table.concat(ready, ", "))
		end
	end
end
task.spawn(function()
	local ok, err = pcall(buildRigs :: any)
	building = false
	if not ok then
		warn("[ZombieShuffle] building the zombie characters stopped: " .. tostring(err))
	end
end)

return {
	Name = "Zombie Shuffle",
	Id = "zombies",
	Weight = 1,
	Duration = 28,
	Target = "Arena",
	Run = function(context: any)
		K.Start(context)
		local plates = K.Plates()
		if #plates == 0 then
			return
		end
		K.TellAll("Zombie Shuffle", "They lunge straight at you: sidestep it. Two hits finish one, or two jumps on its head (it bites).", Color3.fromRGB(96, 122, 88))
		-- (only right after the server has started: give the characters a moment to finish being built)
		while building and K.Elapsed(context) < 4 and context.IsRunning() do
			task.wait(0.1)
		end
		local zombies: { Zombie } = {}
		local canHit = K.Cooldown()
		local over = false
		local nextLook = math.random(1, 1000)

		local function setState(zombie: Zombie, state: string)
			zombie.State, zombie.Clock = state, 0
			K.Signal(context, zombie.Id, "State", state, zombie.Position, zombie.Facing)
		end
		local function rise()
			local _, busy = K.Occupied(plates)
			local plate = (math.random() < NEAR_PLAYERS and K.Pick(busy)) or K.Pick(plates)
			if not (plate and plate.Parent) then
				return
			end
			local position = K.PointOn(plate, 4)
			-- (each one a different character, for as long as there are different ones)
			nextLook += 1
			local look: string? = if #ready > 0 then ready[nextLook % #ready + 1] else nil
			table.insert(zombies, {
				Id = K.Show(context, "Zombie", CFrame.new(position), { T0 = K.Now(), Rise = RISE_TIME, Seed = math.random(1, 100000), Look = look, Lunge = LUNGE_TIME }),
				Position = position, Facing = Vector3.new(0, 0, -1), State = "rise", Clock = 0, Report = 0, Hits = 0, Knock = Vector3.new(0, 0, 0),
				Stomps = 0, NoStomp = 0, Stuck = 0,
			})
		end

		-- squished: a splat, and it is gone
		local function squish(zombie: Zombie, by: Player?, how: string)
			zombie.State = "dead"
			K.Signal(context, zombie.Id, "Die", zombie.Position, how)
			K.Hide(context, zombie.Id, 0.9)
			local index = table.find(zombies, zombie)
			if index then
				table.remove(zombies, index)
			end
			if by then
				K.Complete(context, by) -- Event Journal: you have squished a zombie
			end
		end

		-- any Tool swung near a zombie hits it (the nearest one in front of you)
		K.Swings(context, function(player: Player, _tool: Tool)
			local root = K.Root(player)
			if not root or over then
				return
			end
			local look = K.Dir(root.CFrame.LookVector)
			local best: Zombie? = nil
			local bestGap = REACH
			for _, zombie in zombies do
				if zombie.State ~= "rise" and zombie.State ~= "fall" and zombie.State ~= "dead" then
					local gap = K.Flat(zombie.Position - root.Position)
					local high = math.abs(zombie.Position.Y - (root.Position.Y - 3))
					if gap.Magnitude <= bestGap and high <= 6 and (gap.Magnitude < 2.5 or K.Dir(gap):Dot(look) > 0.2) then
						best, bestGap = zombie, gap.Magnitude
					end
				end
			end
			local zombie = best
			if not zombie then
				return
			end
			zombie.Hits += 1
			if zombie.Hits >= HITS then
				squish(zombie, player, "whack")
			else
				zombie.Knock = K.Dir(zombie.Position - root.Position, look)
				zombie.Facing = -zombie.Knock
				setState(zombie, "stagger")
				K.Signal(context, zombie.Id, "Whacked", player.UserId)
			end
		end)

		K.Outro(context, 1.2, function()
			over = true -- they sink back into the plates: no more hits
			for _, zombie in zombies do
				K.Signal(context, zombie.Id, "Outro", 1.1)
			end
		end)

		local wanted = math.clamp(math.ceil(#K.Alive() / 2) + 1, 2, 6)
		local made, refresh = 0, 0
		K.Loop(context, function(dt)
			if over then
				return
			end
			refresh -= dt
			if refresh <= 0 then
				refresh = 1
				plates = K.Plates()
				if #zombies < wanted and made < wanted + EXTRA and #plates > 0 and K.Elapsed(context) < context.Event.Duration - 4 then
					made += 1
					rise()
				end
			end
			for index = #zombies, 1, -1 do
				local zombie = zombies[index]
				zombie.Clock += dt
				if zombie.State == "rise" then
					if zombie.Clock >= RISE_TIME then
						setState(zombie, "walk")
					end
				elseif zombie.State == "fall" then
					if zombie.Clock > FALL_TIME then
						K.Hide(context, zombie.Id)
						table.remove(zombies, index)
					end
				else
					-- nearest = to whoever is nearest (it goes for them); reach = to the nearest one it could tackle
					-- (not somebody up in the air above its head: it does not lunge at those)
					local nearest: Vector3? = nil
					local reach: Vector3? = nil
					K.Each(function(_, root, _, feetY)
						local gap = K.Flat(root.Position - zombie.Position)
						if not nearest or gap.Magnitude < nearest.Magnitude then
							nearest = gap
						end
						if feetY < zombie.Position.Y + TALL - 2 and (not reach or gap.Magnitude < reach.Magnitude) then
							reach = gap
						end
					end)
					if zombie.State == "walk" or zombie.State == "edge" then
						if nearest then
							local ledge, moved = false, false
							if nearest.Magnitude > 1 then -- (with somebody right above its head it stays where it is)
								zombie.Facing = K.Dir(nearest, zombie.Facing)
								-- it walks on as long as there is plate under its next step (LEDGE studs inside the
								-- edge): it never walks off a ledge by itself
								local step = zombie.Position + zombie.Facing * (WALK * dt)
								local under = K.PlateAt(step, plates, -LEDGE)
								if under then
									zombie.Position = Vector3.new(step.X, K.Top(under), step.Z)
									moved = true
								else
									-- at a ledge: it sidles ALONG it toward them (until it stands opposite them, or in
									-- the corner), which is where a jump across lands
									ledge = true
									local alongX = zombie.Position + Vector3.new(zombie.Facing.X * WALK * dt, 0, 0)
									local alongZ = zombie.Position + Vector3.new(0, 0, zombie.Facing.Z * WALK * dt)
									if math.abs(zombie.Facing.X) > 0.15 and K.PlateAt(alongX, plates, -LEDGE) then
										zombie.Position = alongX
										moved = true
									elseif math.abs(zombie.Facing.Z) > 0.15 and K.PlateAt(alongZ, plates, -LEDGE) then
										zombie.Position = alongZ
										moved = true
									end
								end
							end
							zombie.Stuck = if ledge then zombie.Stuck + dt else 0
							if ledge and not moved then
								if zombie.State == "walk" then
									setState(zombie, "edge") -- (it stands at the ledge)
								end
							elseif zombie.State == "edge" then
								setState(zombie, "walk")
							end
							if reach and reach.Magnitude <= LUNGE_RANGE then
								setState(zombie, "windup")
							elseif ledge and LEAP and zombie.Stuck >= LEAP_WAIT
								and K.PlateAt(zombie.Position + zombie.Facing * (LUNGE * LUNGE_TIME), plates, -1) then
								-- somebody is across the gap and a lunge would land on a plate: it jumps
								setState(zombie, "windup")
							end
						end
					elseif zombie.State == "windup" then
						if zombie.Clock >= WIND_UP then
							setState(zombie, "lunge")
						end
					elseif zombie.State == "lunge" then
						-- (in the air: it only falls where the lunge ENDS, if there is no plate there)
						zombie.Position += zombie.Facing * (LUNGE * dt)
						if zombie.Clock >= LUNGE_TIME then
							local landed = K.PlateAt(zombie.Position, plates, EDGE)
							if landed then
								zombie.Position = Vector3.new(zombie.Position.X, K.Top(landed), zombie.Position.Z)
								zombie.Stuck = 0
								setState(zombie, "rest")
							else
								setState(zombie, "fall")
								continue
							end
						end
					elseif zombie.State == "stagger" then
						-- knocked back by a swing
						zombie.Position += zombie.Knock * (KNOCK_SPEED * dt)
						if zombie.Clock >= KNOCK_TIME then
							setState(zombie, "walk")
						end
					elseif zombie.Clock >= REST then
						setState(zombie, "walk")
					end
					zombie.Report -= dt
					if zombie.Report <= 0 and (zombie.State == "walk" or zombie.State == "lunge" or zombie.State == "stagger") then
						zombie.Report = REPORT_EVERY
						K.Signal(context, zombie.Id, "At", zombie.Position, zombie.Facing)
					end
					-- jumped on its head: it BITES (every time), you bounce off, and the second time it is squished
					local stomped: Player? = nil
					zombie.NoStomp -= dt
					if zombie.NoStomp <= 0 then
						K.Each(function(player, root, _, feetY)
							if not stomped and root.AssemblyLinearVelocity.Y < -2 and K.Flat(root.Position - zombie.Position).Magnitude <= 2.8
								and feetY >= zombie.Position.Y + TALL - 1.8 and feetY <= zombie.Position.Y + TALL + 1.5 then
								stomped = player
							end
						end)
					end
					if stomped then
						zombie.Stomps += 1
						zombie.NoStomp = STOMP_GAP
						K.Push(stomped, Vector3.new(0, STOMP_BOUNCE, 0), 0.15)
						if STOMP_BITE > 0 then
							K.Strike(context, zombie.Id, stomped, STOMP_BITE)
						end
						if zombie.Stomps >= STOMPS then
							squish(zombie, stomped, "stomp")
							continue
						end
						K.Signal(context, zombie.Id, "Stomped", stomped.UserId, zombie.Position)
						-- squashed down: whatever it was doing (winding up, too) is off for a moment
						if zombie.State == "walk" or zombie.State == "edge" or zombie.State == "windup" or zombie.State == "rest" then
							setState(zombie, "rest")
						end
					end
					local caught = false
					K.Each(function(player, root, _, feetY)
						local close = K.Flat(root.Position - zombie.Position).Magnitude <= 2.6 and math.abs(feetY - zombie.Position.Y) <= 5
							and feetY < zombie.Position.Y + TALL - 2 -- (not someone coming down on its head)
						if close then
							caught = true
							if canHit(player, 0.9) then
								if zombie.State == "lunge" then
									K.Strike(context, zombie.Id, player, LUNGE_DAMAGE, zombie.Facing * 30 + Vector3.new(0, 14, 0), 0.3)
								else
									K.Strike(context, zombie.Id, player, TOUCH_DAMAGE)
								end
							end
						end
					end)
					-- a lunge that catches somebody STOPS there. Only one that misses flies its whole length, and over
					-- the edge if that is where it ends (so sidestepping near an edge still gets rid of one)
					if caught and LUNGE_STOPS and zombie.State == "lunge" then
						local landed = K.PlateAt(zombie.Position, plates, EDGE)
						if landed then
							zombie.Position = Vector3.new(zombie.Position.X, K.Top(landed), zombie.Position.Z)
							zombie.Stuck = 0
							setState(zombie, "rest")
						end
					end
					-- knocked off by a swing, or its plate is gone (a lunge is judged where it ends, above)
					if zombie.State ~= "lunge" and not K.PlateAt(zombie.Position, plates, EDGE) then
						setState(zombie, "fall")
					end
				end
			end
		end)
		K.Hold(context)
	end,
}
