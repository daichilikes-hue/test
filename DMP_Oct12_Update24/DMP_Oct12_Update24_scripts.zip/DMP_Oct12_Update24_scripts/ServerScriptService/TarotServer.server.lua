-- Script: ServerScriptService > TarotServer     (Oct 11 Update 13: Auto Draw, readings, the Fortune Teller's day)
-- THE TAROT, server side (what the cards say: ReplicatedStorage > Shared > TarotConfig; what you see:
-- StarterPlayerScripts > TarotClient and ReplicatedStorage > EventClients > tarot).
--   THE DRAW: during the lobby countdown (GameState "Intermission") a player may draw ONE card, free: one click on
--     the little card next to AFK. UPRIGHT_CHANCE (75%) upright, the rest reversed. It works for the round they play
--     next (applied when the round starts: RoundHooks), then it's gone. The attributes TarotCard ("devil") and
--     TarotUpright (true/false) show it to every other script.
--     (Wheel of Fortune works at once, on the modifier vote that's open: Systems > ModifierVote.)
--   AUTO DRAW: the setting "Auto Draw Tarot Card" (Shared > SettingsConfig, key AutoDrawTarot, starts OFF) draws the
--     card for you AUTO_DRAW_DELAY seconds into the countdown (or at once if you switch it on during the countdown).
--   GHOST FLIP: a knocked-out player gets ONE flip (Death upright 2, reversed 0): a random minor thing happens
--     in the arena (TarotConfig.Flips). One flip in the whole server every TarotConfig.FlipCooldown seconds.
--   YOUR READING: when the round ends, everybody who played gets a card for HOW they played (TarotConfig.Readings),
--     added to their deck (the saved string TarotDeck) if it's new. The client is told whether they WON: winners
--     see it at once, everybody who was knocked out sees it only when they click for it (TarotClient).
--   TEST COMMANDS (admins; anyone in Studio), in chat:
--     /tarot death up   /tarot star rev   /tarot sun   (no up / rev = rolled like a draw)   /tarot @Name moon up
--       In a round and alive = it works at once. Otherwise it's held for your next round, like a draw.
--     /tarotclear [@Name]   takes the card away.     /tarotflips [@Name] 3   ghost flips (when you're knocked out).
--     /tarotlist   every card's name.      /fortunereset [@Name]   the Fortune Teller reads for them again today.
--     (/tarot also plays the reveal: in the lobby, /tarot world up shows what a rare card looks like.)
--   THE FORTUNE TELLER: Workspace > Map > NPCS > FortuneTellerNPC (any Model or Part with that name). Once a day:
--     a card, a fortune, TarotConfig.FortuneCandles candles and TarotConfig.FortuneTickets Game Tickets. Her card is
--     the same all day: talking to her again shows it again, with no gift. /fortunereset [@Name] lets her read for
--     you again today (a new card, the gift again). No FortuneTellerNPC in the map? A stand-in booth is built next to
--     the DailyRewardsNPC so you can try it (put your own model in and the booth isn't built).
-- Talks to the client through ReplicatedStorage > Remotes > Tarot (made by this script).

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local ServerScriptService = game:GetService("ServerScriptService")
local ServerStorage = game:GetService("ServerStorage")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local TarotConfig = require(Shared:WaitForChild("TarotConfig"))
local GameConfig = require(Shared:WaitForChild("GameConfig"))
local Systems = ServerScriptService:WaitForChild("Systems")
local EventUtil = require(Systems:WaitForChild("EventUtil"))
local RoundHooks = require(Systems:WaitForChild("RoundHooks"))
local Damage = require(Systems:WaitForChild("Damage"))
local DataManager = require(Systems:WaitForChild("DataManager"))
local EventVisuals = require(Systems:WaitForChild("EventVisuals"))

local remote = EventUtil.GetRemote("Tarot")
local clientEffect = EventUtil.GetRemote("ClientEffect")
local INK = Color3.fromRGB(214, 170, 96)
--[[DMP:KEEP Settings]]
local UPRIGHT_CHANCE = 0.75 -- a drawn card is upright (the good side) this often; 0.75 = 75%, reversed 25%
local AUTO_DRAW_DELAY = 3   -- Auto Draw: seconds into the lobby countdown before the card is drawn for you
--[[DMP:END]]
local AUTO_SETTING = "Setting_AutoDrawTarot" -- (Shared > SettingsConfig, key AutoDrawTarot)
local BASE_MAX_HEALTH = (GameConfig.BaseStats and GameConfig.BaseStats.MaxHealth) or 100

-- other systems this needs only now and then (missing = that part quietly does nothing)
local optionalCache: { [string]: any } = {}
local function optional(name: string): any
	if optionalCache[name] == nil then
		optionalCache[name] = false
		local module = Systems:FindFirstChild(name)
		if module and module:IsA("ModuleScript") then
			local ok, result = pcall(require, module)
			if ok then
				optionalCache[name] = result
			else
				warn("[TarotServer] Systems > " .. name .. " couldn't be loaded: " .. tostring(result))
			end
		end
	end
	return optionalCache[name] or nil
end

local function tell(player: Player, title: string, text: string)
	EventUtil.Notify(player, title, text, INK)
end

local function voidY(): number
	local plates = workspace:FindFirstChild("Map") and (workspace.Map :: any):FindFirstChild("Plates")
	local centre = plates and plates:FindFirstChild("Center")
	local depth = GameConfig.VoidDepth or 60
	return if centre and centre:IsA("BasePart") then centre.Position.Y - depth else -math.huge
end

local function isDark(source: any): boolean
	local text = string.lower(tostring(source or ""))
	for _, word in TarotConfig.DarkWords do
		if string.find(text, string.lower(word), 1, true) then
			return true
		end
	end
	return false
end

-- the round items (ServerStorage > Items): Magician, Justice and the reading count these
local itemNames: { [string]: boolean } = {}
local function refreshItems()
	table.clear(itemNames)
	local folder = ServerStorage:FindFirstChild("Items")
	if folder then
		for _, item in folder:GetDescendants() do
			if item:IsA("Tool") then
				itemNames[item.Name] = true
			end
		end
	end
end
refreshItems()

local function weighted<T>(list: { T }): T
	local total = 0
	for _, entry in list do
		total += (entry :: any).Weight or 1
	end
	local roll = math.random() * total
	for _, entry in list do
		roll -= (entry :: any).Weight or 1
		if roll <= 0 then
			return entry
		end
	end
	return list[#list]
end

local function aliveOthers(player: Player): { BasePart }
	local list = {}
	for _, other in EventUtil.Alive() do
		if other ~= player then
			local root = EventUtil.Root(other)
			if root then
				table.insert(list, root)
			end
		end
	end
	return list
end

local function nearest(player: Player): number
	local root = EventUtil.Root(player)
	if not root then
		return math.huge
	end
	local best = math.huge
	for _, other in aliveOthers(player) do
		best = math.min(best, (other.Position - root.Position).Magnitude)
	end
	return best
end

---------------------------------------------------------------------- round state
type Track = {
	Damage: number, Healed: number, MinFrac: number, FullAt: number, EndFrac: number,
	LastHit: { Amount: number, Source: string, Time: number }?, DarkHurt: boolean, BigHitLived: boolean,
	Samples: number, Still: number, Alone: number, Close: number, Distance: number, LastPos: Vector3?,
	Items: number, Held: number, BelowVoidAt: number, Fell: boolean, Saved: boolean, Revived: boolean,
	OutOrder: number?, Place: number?, OutAt: number?, Seconds: number, MaxHealthLow: boolean, Drew: boolean?,
	Flipped: boolean, FlipHit: boolean, Connections: { RBXScriptConnection },
}
type Active = { Card: string, Upright: boolean, Character: Model?, Cleanup: { () -> () }, FoolCatch: boolean?,
	Magician: boolean?, MagicianUsed: boolean?, Liar: number?, Lovers: boolean?, Star: boolean?, Moon: number? }

local drawn: { [Player]: { Card: string, Upright: boolean } } = {}
local active: { [Player]: Active } = {}
local stats: { [Player]: Track } = {}
local flips: { [Player]: number } = {}
local streaks: { [Player]: { Top: number, Bottom: number } } = {}
local inRound = false
local roundPlayers: { Player } = {}
local roundStart = 0
local outCount = 0
local lastFlip = -100

---------------------------------------------------------------------- the draw
local function applyWheel(player: Player, upright: boolean)
	if upright then
		player:SetAttribute("VoteWeight", 2)
		return
	end
	local ModifierVote = optional("ModifierVote")
	if ModifierVote and ModifierVote.Options and ModifierVote.ForceVote and ModifierVote.IsOpen and ModifierVote.IsOpen() then
		local options = ModifierVote.Options()
		table.insert(options, "Random")
		if ModifierVote.ForceVote(player, options[math.random(1, #options)]) then
			player:SetAttribute("VoteLocked", true)
		end
	end
end

local function onDraw(player: Player, auto: boolean?)
	if not TarotConfig.DrawEnabled then
		return
	end
	if drawn[player] then
		-- (already holds one: the client shows the card it has)
		remote:FireClient(player, "Refused", "")
		return
	end
	if ReplicatedStorage:GetAttribute("GameState") ~= "Intermission" then
		if not auto then
			remote:FireClient(player, "Refused", "You can only draw while the next round is counting down.")
		end
		return
	end
	local card = weighted(TarotConfig.Cards)
	local upright = math.random() < UPRIGHT_CHANCE
	drawn[player] = { Card = card.Id, Upright = upright }
	player:SetAttribute("TarotCard", card.Id)
	player:SetAttribute("TarotUpright", upright)
	if DataManager.IsLoaded(player) then
		local count = player:GetAttribute("TarotDraws")
		player:SetAttribute("TarotDraws", (if type(count) == "number" then count else 0) + 1)
	end
	remote:FireClient(player, "Drawn", card.Id, upright, auto == true)
	if card.Id == "wheel" then
		applyWheel(player, upright)
	end
end

-- AUTO DRAW (the setting): AUTO_DRAW_DELAY seconds into every countdown, for everyone who has it on and no card yet
local autoToken = 0
local function autoDrawFor(player: Player)
	if player.Parent and player:GetAttribute(AUTO_SETTING) == true and not drawn[player] and player:GetAttribute("AFK") ~= true
		and ReplicatedStorage:GetAttribute("GameState") == "Intermission" then
		onDraw(player, true)
	end
end
local function autoDrawAll()
	autoToken += 1
	local token = autoToken
	task.delay(AUTO_DRAW_DELAY, function()
		if token ~= autoToken then
			return
		end
		for _, player in Players:GetPlayers() do
			local ok, err = pcall(autoDrawFor, player)
			if not ok then
				warn("[TarotServer] Auto Draw: " .. tostring(err))
			end
		end
	end)
end
local function watchAutoDraw(player: Player)
	-- (switched on during the countdown, or their saved settings arrive during it: draw now)
	player:GetAttributeChangedSignal(AUTO_SETTING):Connect(function()
		if player:GetAttribute(AUTO_SETTING) == true then
			task.delay(0.5, autoDrawFor, player)
		end
	end)
end
Players.PlayerAdded:Connect(watchAutoDraw)
for _, player in Players:GetPlayers() do
	watchAutoDraw(player)
end

---------------------------------------------------------------------- what each card does in the round
local function applyCard(player: Player, id: string, upright: boolean)
	local root, humanoid = EventUtil.Root(player)
	if not (root and humanoid) then
		return
	end
	local entry: Active = { Card = id, Upright = upright, Character = player.Character, Cleanup = {} }
	active[player] = entry
	local s = if upright then 1 else -1
	local function mod(stat: string, values: { [string]: number })
		EventUtil.Mod(player, stat, values, "Tarot" .. stat)
	end
	local function attr(name: string, value: any)
		local before = player:GetAttribute(name)
		player:SetAttribute(name, value)
		table.insert(entry.Cleanup, function()
			if player:GetAttribute(name) == value then
				player:SetAttribute(name, before)
			end
		end)
	end
	local function handler(priority: number, fn: (any) -> ())
		Damage.AddHandler(player, "Tarot", priority, fn)
	end

	if id == "fool" then
		if upright then
			attr("SpiritCatch", true)
			entry.FoolCatch = true -- (the catch costs half your health: see the void watcher below)
		else
			local tripped = false
			handler(60, function(hit: any)
				if not tripped and not hit.InstantKill and hit.Amount > 0 then
					tripped = true
					task.defer(EventUtil.Topple, player, 1.5)
				end
			end)
		end
	elseif id == "magician" then
		entry.Magician = true
	elseif id == "priestess" then
		if upright then
			attr("SixthSense", true)
		else
			entry.Liar = os.clock() + math.random(18, 30)
		end
	elseif id == "empress" then
		mod("MaxHealth", { Add = 15 * s })
	elseif id == "emperor" then
		local used = false
		handler(15, function(hit: any)
			if used or hit.InstantKill or hit.Amount <= 0 then
				return
			end
			used = true
			if upright then
				hit.Cancelled = true
				tell(player, "The Emperor", "You shrugged that one off.")
			else
				hit.Amount *= 2
			end
		end)
	elseif id == "hierophant" then
		mod("Regen", { Mult = if upright then 1.5 else 0.5 })
	elseif id == "lovers" then
		entry.Lovers = true
	elseif id == "chariot" then
		mod("WalkSpeed", { Mult = 1 + 0.15 * s })
	elseif id == "strength" then
		attr("KnockbackMult", if upright then 0.5 else 1.5)
	elseif id == "hermit" then
		handler(50, function(hit: any)
			if not hit.InstantKill and nearest(player) > 20 then
				hit.Amount *= if upright then 0.75 else 1.25
			end
		end)
	elseif id == "justice" then
		handler(50, function(hit: any)
			if not hit.InstantKill and itemNames[hit.Source] then
				hit.Amount *= if upright then 0.7 else 1.3
			end
		end)
	elseif id == "hanged" then
		mod("Jump", { Mult = 1 + 0.2 * s })
	elseif id == "temperance" then
		handler(50, function(hit: any)
			if not hit.InstantKill and hit.Type then
				hit.Amount *= if upright then 0.75 else 1.25
			end
		end)
	elseif id == "tower" then
		handler(55, function(hit: any)
			if not hit.InstantKill and hit.Amount >= 25 then
				hit.Amount *= if upright then 0.8 else 1.2
			end
		end)
	elseif id == "star" then
		if upright then
			entry.Star = true
		else
			remote:FireClient(player, "Haze", true)
			table.insert(entry.Cleanup, function()
				remote:FireClient(player, "Haze", false)
			end)
		end
	elseif id == "moon" then
		local weight = if upright then 0.75 else 1.25
		entry.Moon = weight
		attr("EventTargetWeight", weight)
		-- (the Doomed feed sets this attribute too and clears it when it ends: put the Moon back after that)
		local connection = player:GetAttributeChangedSignal("EventTargetWeight"):Connect(function()
			if active[player] == entry and player:GetAttribute("EventTargetWeight") == nil then
				task.defer(function()
					if active[player] == entry and player:GetAttribute("EventTargetWeight") == nil then
						player:SetAttribute("EventTargetWeight", weight)
					end
				end)
			end
		end)
		table.insert(entry.Cleanup, function()
			connection:Disconnect()
		end)
	elseif id == "sun" then
		handler(50, function(hit: any)
			if not hit.InstantKill and isDark(hit.Source) then
				hit.Amount *= if upright then 0.5 else 1.5
			end
		end)
	elseif id == "judgement" then
		if upright then
			Damage.AddHandler(player, "TarotJudgement", 100, function(hit: any)
				if hit.Amount >= humanoid.Health and not hit.InstantKill then
					hit.Cancelled = true
					Damage.RemoveHandler(player, "TarotJudgement")
					task.defer(function()
						if humanoid.Parent and humanoid.Health > 0 then
							humanoid.Health = math.min(25, humanoid.MaxHealth)
						end
					end)
					player:SetAttribute("RevivedThisRound", true)
					tell(player, "Judgement", "Not yet. You get back up.")
				end
			end)
		else
			task.defer(function()
				if humanoid.Parent and humanoid.Health > 0 then
					humanoid.Health = humanoid.MaxHealth * 0.75
				end
			end)
		end
	elseif id == "world" then
		mod("WalkSpeed", { Mult = 1 + 0.05 * s })
		mod("MaxHealth", { Mult = 1 + 0.05 * s })
		mod("Jump", { Mult = 1 + 0.05 * s })
	end
	-- (wheel: it acted on the vote when it was drawn. devil: Contracts and the Broker's Table read the attributes.
	--  death: the ghost flips, when they're knocked out.)
end

local function clearCard(player: Player)
	drawn[player] = nil
	local entry = active[player]
	active[player] = nil
	if entry then
		for _, fn in entry.Cleanup do
			pcall(fn)
		end
		if player.Character == entry.Character then
			pcall(Damage.RemoveHandler, player, "Tarot")
			pcall(Damage.RemoveHandler, player, "TarotJudgement")
			for _, stat in { "MaxHealth", "WalkSpeed", "Jump", "Regen" } do
				EventUtil.Unmod(player, "Tarot" .. stat)
			end
			EventUtil.Unmod(player, "TarotLovers")
		end
	end
	if player.Parent then
		player:SetAttribute("TarotCard", nil)
		player:SetAttribute("TarotUpright", nil)
		player:SetAttribute("VoteWeight", nil)
		player:SetAttribute("VoteLocked", nil)
	end
end

---------------------------------------------------------------------- watching how everybody plays
local function newTrack(player: Player): Track
	local t: Track = {
		Damage = 0, Healed = 0, MinFrac = 1, FullAt = os.clock(), EndFrac = 1, LastHit = nil, DarkHurt = false, BigHitLived = false,
		Samples = 0, Still = 0, Alone = 0, Close = 0, Distance = 0, LastPos = nil, Items = 0, Held = 0, BelowVoidAt = -100,
		Fell = false, Saved = false, Revived = false, OutOrder = nil, Place = nil, OutAt = nil, Seconds = 0, MaxHealthLow = false,
		Drew = nil, Flipped = false, FlipHit = false, Connections = {},
	}
	local pick = drawn[player]
	if pick then
		t.Drew = pick.Upright
	end
	-- items picked up this round (and the Magician)
	local function onTool(tool: Instance)
		if not tool:IsA("Tool") or not itemNames[tool.Name] or not inRound or tool:GetAttribute("TarotSeen") then
			return
		end
		tool:SetAttribute("TarotSeen", true)
		t.Items += 1
		local entry = active[player]
		if entry and entry.Magician and not entry.MagicianUsed then
			entry.MagicianUsed = true
			if entry.Upright then
				task.defer(function()
					local given = EventUtil.GiveItem(player)
					if given then
						tell(player, "The Magician", "Your " .. tool.Name .. " brought a friend: " .. given .. ".")
					end
				end)
			else
				task.defer(function()
					if tool.Parent then
						tool:Destroy()
						tell(player, "The Magician", "Your " .. tool.Name .. " crumbled to dust.")
					end
				end)
			end
		end
	end
	local backpack = player:FindFirstChildOfClass("Backpack")
	if backpack then
		for _, tool in backpack:GetChildren() do
			if tool:IsA("Tool") then
				tool:SetAttribute("TarotSeen", true) -- (what they started with doesn't count)
			end
		end
		table.insert(t.Connections, backpack.ChildAdded:Connect(onTool))
	end
	local character = player.Character
	if character then
		table.insert(t.Connections, character.ChildAdded:Connect(onTool))
	end
	return t
end

local function stopTrack(t: Track)
	for _, connection in t.Connections do
		connection:Disconnect()
	end
	table.clear(t.Connections)
end

Damage.Damaged:Connect(function(player: Player, dealt: number, context: any)
	local t = stats[player]
	if not t or not inRound then
		return
	end
	local amount = if type(context) == "table" and type(context.Amount) == "number" then context.Amount else dealt
	local source = if type(context) == "table" then tostring(context.Source) else "Unknown"
	t.Damage += dealt
	t.LastHit = { Amount = amount, Source = source, Time = os.clock() }
	if isDark(source) then
		t.DarkHurt = true
	end
	local _, humanoid = EventUtil.Root(player)
	if humanoid then
		t.MinFrac = math.min(t.MinFrac, humanoid.Health / math.max(humanoid.MaxHealth, 1))
		if amount >= 40 then
			task.delay(0.2, function()
				if humanoid.Parent and humanoid.Health > 0 then
					t.BigHitLived = true
				end
			end)
		end
	end
end)

Damage.Healed:Connect(function(player: Player, amount: number)
	local t = stats[player]
	if t and inRound and type(amount) == "number" then
		t.Healed += amount
	end
end)

-- every half second: movement, company, health; and the cards that work over time
local function sample()
	local now = os.clock()
	for player, t in stats do
		local root, humanoid = EventUtil.Root(player)
		if root and humanoid and player:GetAttribute("Alive") == true then
			t.Samples += 1
			local position = root.Position
			if t.LastPos then
				local moved = (Vector3.new(position.X, 0, position.Z) - Vector3.new(t.LastPos.X, 0, t.LastPos.Z)).Magnitude
				if moved < 0.6 then
					t.Still += 1
				end
				if moved < 60 then -- (not a teleport)
					t.Distance += moved
				end
			end
			t.LastPos = position
			local gap = nearest(player)
			if gap > 20 then
				t.Alone += 1
			elseif gap < 10 then
				t.Close += 1
			end
			local frac = humanoid.Health / math.max(humanoid.MaxHealth, 1)
			t.MinFrac = math.min(t.MinFrac, frac)
			if frac >= 0.99 then
				t.FullAt = now
			end
			-- the cards that work over time
			local entry = active[player]
			if entry and player.Character == entry.Character then
				if entry.Lovers then
					if entry.Upright then
						if gap <= 12 then
							EventUtil.Heal(player, 1)
						end
					else
						if gap <= 8 then
							EventUtil.Mod(player, "Regen", { Mult = 0 }, "TarotLovers")
						else
							EventUtil.Unmod(player, "TarotLovers")
						end
					end
				end
				if entry.Star and humanoid.Health > 0 and humanoid.Health < 25 then
					entry.Star = false
					EventUtil.Heal(player, 20)
					tell(player, "The Star", "A small light finds you in the dark. +20 health.")
					remote:FireClient(player, "Star")
				end
				if entry.Liar and now >= entry.Liar then
					entry.Liar = now + math.random(25, 40)
					local plates = EventUtil.Plates()
					local plate = EventUtil.Pick(plates)
					local name = "Something"
					local EventSystem = optional("EventSystem")
					if EventSystem and EventSystem.GetEventList then
						local ok, list = pcall(EventSystem.GetEventList)
						local pick = ok and type(list) == "table" and EventUtil.Pick(list)
						if pick then
							name = pick.Name
						end
					end
					if plate then
						clientEffect:FireClient(player, "SixthSense", { Plate = plate, EventName = name })
					end
				end
			end
		end
	end
end

-- every frame: who dropped below the void (to tell a fall from a catch)
local voidLine = voidY()
RunService.Heartbeat:Connect(function()
	if not inRound then
		return
	end
	local now = os.clock()
	for player, t in stats do
		local root = EventUtil.Root(player)
		if root then
			if root.Position.Y < voidLine then
				t.BelowVoidAt = now
			elseif now - t.BelowVoidAt < 2 and root.Position.Y > voidLine + 8 and not t.Saved and player:GetAttribute("Alive") == true then
				-- they went under and came back up alive: something caught them
				t.Saved = true
				t.BelowVoidAt = -100
				local entry = active[player]
				if entry and entry.FoolCatch then
					entry.FoolCatch = false
					local _, humanoid = EventUtil.Root(player)
					if humanoid then
						Damage.Deal(player, humanoid.Health * 0.5, { Source = "The Fool" })
					end
					tell(player, "The Fool", "The void spat you back out... and kept half your health.")
				end
			end
		end
	end
end)

task.spawn(function()
	while true do
		task.wait(0.5)
		if inRound then
			local ok, err = pcall(sample)
			if not ok then
				warn("[TarotServer] " .. tostring(err))
			end
		end
	end
end)

---------------------------------------------------------------------- ghost flips
local FLIP_ASSETS = { gale = "Gale", candle = "Candle", rattle = "Rattle", bell = "Bell", tombstone = "Tombstone", web = "Web", crows = "Crows", frost = "Frost" }

local function show(asset: string, cframe: CFrame, props: { [string]: any }, seconds: number)
	local id = EventVisuals.Spawn("tarot", asset, cframe, props)
	task.delay(seconds, EventVisuals.Destroy, id)
	return id
end

local function onPlate(plate: BasePart, root: BasePart): boolean
	return EventUtil.Inside(plate, root.Position, 0.5) and math.abs(root.Position.Y - EventUtil.Top(plate) - 3) < 4
end

-- slows everybody standing in a spot for a while (the web, the frost)
local function slowZone(flipper: Track, test: (BasePart) -> boolean, mult: number, id: string, seconds: number)
	local stop = os.clock() + seconds
	while os.clock() < stop and inRound do
		for _, player in EventUtil.Alive() do
			local root = EventUtil.Root(player)
			if root and test(root) then
				EventUtil.Mod(player, "WalkSpeed", { Mult = mult }, id, 0.4)
				flipper.FlipHit = true
			end
		end
		task.wait(0.25)
	end
end

local function runFlip(player: Player, flipId: string)
	local t = stats[player]
	local plates = EventUtil.Plates()
	if #plates == 0 or not t then
		return
	end
	local _, occupied = EventUtil.Occupied(plates)
	local plate = EventUtil.Pick(if #occupied > 0 then occupied else plates) :: BasePart
	local centre = EventUtil.Arena(plates)
	local top = EventUtil.TopCentre(plate)
	local now = EventUtil.Now()
	local asset = FLIP_ASSETS[flipId] or "Bell"
	if flipId == "gale" then
		local dir = EventUtil.Dir(Vector3.new(math.random() * 2 - 1, 0, math.random() * 2 - 1))
		show(asset, CFrame.lookAt(top, top + dir), { T0 = now, SX = plate.Size.X, SZ = plate.Size.Z }, 3)
		task.wait(0.6)
		for _, other in EventUtil.Alive() do
			local root = EventUtil.Root(other)
			if root and onPlate(plate, root) then
				EventUtil.Push(other, dir * 24 + Vector3.new(0, 6, 0), 0.25)
				t.FlipHit = true
			end
		end
	elseif flipId == "candle" then
		show(asset, CFrame.new(centre), { T0 = now, Seconds = 3 }, 4)
	elseif flipId == "rattle" then
		show(asset, CFrame.new(top), { T0 = now, SX = plate.Size.X, SZ = plate.Size.Z }, 2.5)
	elseif flipId == "bell" then
		show(asset, CFrame.new(centre + Vector3.new(0, 40, 0)), { T0 = now }, 4)
	elseif flipId == "tombstone" then
		local spot = EventUtil.PointOn(plate, 2.5)
		local land = now + 0.9
		show(asset, CFrame.new(spot), { T0 = now, Land = land }, 4)
		task.wait(0.9)
		for _, other in EventUtil.Alive() do
			local root = EventUtil.Root(other)
			if root and EventUtil.Flat(root.Position - spot).Magnitude <= 3 and math.abs(root.Position.Y - spot.Y - 3) < 4 then
				EventUtil.Hurt(other, 8, "Ghost Flip")
				EventUtil.Push(other, EventUtil.Dir(root.Position - spot) * 18 + Vector3.new(0, 10, 0), 0.2)
				t.FlipHit = true
			end
		end
	elseif flipId == "web" then
		local spot = EventUtil.PointOn(plate, 4)
		show(asset, CFrame.new(spot), { T0 = now, Radius = 5, Seconds = 8 }, 9)
		slowZone(t, function(root: BasePart): boolean
			return EventUtil.Flat(root.Position - spot).Magnitude <= 5 and math.abs(root.Position.Y - spot.Y - 3) < 4
		end, 0.75, "TarotWeb", 8)
	elseif flipId == "crows" then
		local dir = EventUtil.Dir(Vector3.new(math.random() * 2 - 1, 0, math.random() * 2 - 1))
		show(asset, CFrame.lookAt(centre, centre + dir), { T0 = now }, 5)
	elseif flipId == "frost" then
		show(asset, CFrame.new(top), { T0 = now, SX = plate.Size.X, SZ = plate.Size.Z, Seconds = 4 }, 5)
		slowZone(t, function(root: BasePart): boolean
			return onPlate(plate, root)
		end, 0.9, "TarotFrost", 4)
	end
end

local function onFlip(player: Player)
	local t = stats[player]
	if not inRound or not t or player:GetAttribute("Alive") == true then
		return
	end
	local left = flips[player] or 0
	if left <= 0 then
		remote:FireClient(player, "Refused", "You have no cards left to flip.")
		return
	end
	if os.clock() - lastFlip < TarotConfig.FlipCooldown then
		remote:FireClient(player, "Refused", "The cards are still settling. Try again in a moment.")
		return
	end
	lastFlip = os.clock()
	flips[player] = left - 1
	t.Flipped = true
	local flip = weighted(TarotConfig.Flips)
	remote:FireClient(player, "Flipped", flip.Id, flips[player])
	task.spawn(function()
		local ok, err = pcall(runFlip, player, flip.Id)
		if not ok then
			warn("[TarotServer] ghost flip " .. flip.Id .. ": " .. tostring(err))
		end
	end)
end

---------------------------------------------------------------------- your reading
local function topHalf(place: number, count: number): boolean
	return place <= math.ceil(count / 2)
end

-- (was that hit what knocked them out? within a moment of going out)
local function recentHit(hit: { Time: number }, t: Track): boolean
	return t.OutAt ~= nil and t.OutAt - hit.Time < 1.5
end

local RULES: { [string]: (t: Track, r: any) -> boolean } = {
	Always = function()
		return true
	end,
	BigWin = function(_, r)
		return r.Count >= 8
	end,
	Untouched = function(t)
		return t.Damage <= 0
	end,
	Barely = function(t)
		return t.EndFrac < 0.2
	end,
	Battered = function(t)
		return t.Damage >= 150
	end,
	Contract = function(_, r)
		return r.Contract
	end,
	Together = function(_, r)
		return r.Winners >= 2
	end,
	Traveller = function(t)
		return t.Distance >= 1500
	end,
	DrewUpright = function(t)
		return t.Drew == true
	end,
	DrewReversed = function(t)
		return t.Drew == false
	end,
	FirstOut = function(t, r)
		return r.Count >= 3 and t.OutOrder == 1
	end,
	SoClose = function(_, r)
		return r.Count >= 8 and r.Place == 2
	end,
	Second = function(_, r)
		return r.Count >= 3 and r.Place == 2
	end,
	Third = function(_, r)
		return r.Count >= 4 and r.Place == 3
	end,
	Fell = function(t)
		return t.Fell
	end,
	BigHitOut = function(t)
		local hit = t.LastHit
		return hit ~= nil and hit.Amount >= 40 and t.Fell == false and recentHit(hit, t)
	end,
	DarkOut = function(t)
		local hit = t.LastHit
		return hit ~= nil and isDark(hit.Source) and t.Fell == false and recentHit(hit, t)
	end,
	Quick = function(t)
		return t.Seconds < 20
	end,
	Sudden = function(t)
		return t.OutAt ~= nil and t.OutAt - t.FullAt < 5
	end,
	Weakened = function(t)
		return t.MaxHealthLow
	end,
	Hoarder = function(t)
		return t.Held >= 2
	end,
	RevivedLow = function(t, r)
		return t.Revived and not r.Top
	end,
	RevivedHigh = function(t, r)
		return t.Revived and r.Top
	end,
	Saved = function(t)
		return t.Saved
	end,
	BigHitLived = function(t, r)
		return t.BigHitLived and r.Top
	end,
	Steady = function(t)
		return t.Seconds >= 180 and t.MinFrac >= 0.5
	end,
	Healed = function(t)
		return t.Healed >= 60
	end,
	Collector = function(t)
		return t.Items >= 3
	end,
	DarkLived = function(t, r)
		return t.DarkHurt and r.Top
	end,
	StillHigh = function(t, r)
		return t.Samples >= 10 and t.Still / t.Samples >= 0.5 and r.Top
	end,
	StillLow = function(t, r)
		return t.Samples >= 10 and t.Still / t.Samples >= 0.5 and not r.Top
	end,
	AloneHigh = function(t, r)
		return t.Samples >= 10 and t.Alone / t.Samples >= 0.6 and r.Top
	end,
	AloneLow = function(t, r)
		return t.Samples >= 10 and t.Alone / t.Samples >= 0.6 and not r.Top
	end,
	CloseHigh = function(t, r)
		return t.Samples >= 10 and t.Close / t.Samples >= 0.5 and r.Top
	end,
	CloseLow = function(t, r)
		return t.Samples >= 10 and t.Close / t.Samples >= 0.5 and not r.Top
	end,
	Stuck = function(t)
		return t.Distance < 80
	end,
	FlipHit = function(t)
		return t.FlipHit
	end,
	FlipMiss = function(t)
		return t.Flipped and not t.FlipHit
	end,
	DrewHigh = function(t, r)
		return t.Drew ~= nil and r.Top
	end,
	DrewLow = function(t, r)
		return t.Drew ~= nil and not r.Top
	end,
	StreakHigh = function(_, r)
		return r.Streak.Top >= 3
	end,
	StreakLow = function(_, r)
		return r.Streak.Bottom >= 3
	end,
	TopHalf = function(_, r)
		return r.Top
	end,
}

local function reading(t: Track, r: any): (string, boolean, string)
	for _, entry in TarotConfig.Readings do
		if (entry.Winner == true) == r.Won then
			local rule = RULES[entry.Rule]
			if rule then
				local ok, yes = pcall(rule, t, r)
				if ok and yes then
					return entry.Card, entry.Upright, entry.How
				end
			end
		end
	end
	return "justice", r.Top, if r.Top then "Finished in the top half." else "Finished in the bottom half."
end

local function deal(player: Player, card: string, upright: boolean, how: string, won: boolean)
	local deck = player:GetAttribute("TarotDeck")
	local updated, isNew = TarotConfig.Add(deck, card, upright)
	if isNew and DataManager.IsLoaded(player) then
		player:SetAttribute("TarotDeck", updated)
	end
	-- (won: the client shows it at once; a player who was knocked out sees it when they click for it)
	remote:FireClient(player, "Reading", card, upright, how, isNew, won)
end

---------------------------------------------------------------------- the round
RoundHooks.OnStart(function(players: { Player })
	inRound = true
	roundPlayers = table.clone(players)
	roundStart = os.clock()
	outCount = 0
	voidLine = voidY()
	refreshItems()
	for _, t in stats do
		stopTrack(t)
	end
	table.clear(stats)
	table.clear(flips)
	local Contracts = optional("Contracts")
	if Contracts and Contracts.NewRound then
		pcall(Contracts.NewRound)
	end
	for _, player in players do
		player:SetAttribute("RevivedThisRound", nil)
		player:SetAttribute("VoteWeight", nil)
		player:SetAttribute("VoteLocked", nil)
		stats[player] = newTrack(player)
		local pick = drawn[player]
		if pick then
			local ok, err = pcall(applyCard, player, pick.Card, pick.Upright)
			if not ok then
				warn("[TarotServer] " .. pick.Card .. " couldn't be applied: " .. tostring(err))
			end
		end
	end
	-- a card drawn by somebody who isn't playing this round is gone
	for player in table.clone(drawn) do
		if not table.find(players, player) then
			clearCard(player)
		end
	end
end)

RoundHooks.OnEliminated(function(player: Player)
	local t = stats[player]
	if not t then
		return
	end
	outCount += 1
	t.OutOrder = outCount
	local alive = 0
	for _, other in roundPlayers do
		if other ~= player and other.Parent and other:GetAttribute("Alive") == true then
			alive += 1
		end
	end
	t.Place = alive + 1
	t.OutAt = os.clock()
	t.Seconds = os.clock() - roundStart
	t.Fell = os.clock() - t.BelowVoidAt < 2
	t.Revived = player:GetAttribute("RevivedThisRound") == true
	local held = 0
	for _, container in { player:FindFirstChildOfClass("Backpack"), player.Character } do
		if container then
			for _, tool in container:GetChildren() do
				if tool:IsA("Tool") and itemNames[tool.Name] then
					held += 1
				end
			end
		end
	end
	t.Held = held
	local humanoid = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
	t.MaxHealthLow = humanoid ~= nil and humanoid.MaxHealth < BASE_MAX_HEALTH - 0.5
	stopTrack(t)
	-- ghost flips
	local count = TarotConfig.FlipsPerGhost
	local entry = active[player]
	if entry and entry.Card == "death" then
		count = if entry.Upright then 2 else 0
	end
	flips[player] = count
	remote:FireClient(player, "Flips", count)
	if entry and entry.Card == "star" and not entry.Upright then
		remote:FireClient(player, "Haze", false)
	end
end)

RoundHooks.OnEnd(function(winners: { Player }, results: { [Player]: any })
	inRound = false
	local count = math.max(#roundPlayers, 1)
	local Contracts = optional("Contracts")
	for player, result in results do
		local t = stats[player]
		if t and player.Parent then
			local won = result.Winner == true
			if won then
				t.Place = 1
				t.Seconds = result.Seconds or (os.clock() - roundStart)
				t.Revived = player:GetAttribute("RevivedThisRound") == true
				local _, humanoid = EventUtil.Root(player)
				if humanoid then
					t.EndFrac = humanoid.Health / math.max(humanoid.MaxHealth, 1)
				end
			end
			local place = t.Place or 1
			local top = won or topHalf(place, count)
			local streak = streaks[player] or { Top = 0, Bottom = 0 }
			streaks[player] = streak
			if top then
				streak.Top += 1
				streak.Bottom = 0
			else
				streak.Bottom += 1
				streak.Top = 0
			end
			local signed = false
			if Contracts and Contracts.Signed then
				local ok, yes = pcall(Contracts.Signed, player)
				signed = ok and yes == true
			end
			local r = { Won = won, Count = count, Winners = #winners, Place = place, Top = top, Contract = signed, Streak = streak }
			local ok, card, upright, how = pcall(reading, t, r)
			if ok then
				deal(player, card, upright, how, won)
			else
				warn("[TarotServer] reading: " .. tostring(card))
			end
		end
	end
	for _, t in stats do
		stopTrack(t)
	end
	table.clear(stats)
	for player in flips do
		if player.Parent then
			remote:FireClient(player, "Flips", 0)
		end
	end
	table.clear(flips)
	for _, player in roundPlayers do
		clearCard(player)
	end
	for player in table.clone(drawn) do
		if table.find(roundPlayers, player) then
			clearCard(player)
		end
	end
	table.clear(roundPlayers)
end)

-- the vote closes when the countdown ends: the Wheel's hold on it goes too. A countdown starting = Auto Draw.
ReplicatedStorage:GetAttributeChangedSignal("GameState"):Connect(function()
	if ReplicatedStorage:GetAttribute("GameState") ~= "Intermission" then
		autoToken += 1
		for _, player in Players:GetPlayers() do
			player:SetAttribute("VoteWeight", nil)
			player:SetAttribute("VoteLocked", nil)
		end
	else
		autoDrawAll()
	end
end)

---------------------------------------------------------------------- the Fortune Teller
-- her card for this player today: always the same one that day (worked out from the day and the player, so it is
-- the same after a rejoin too). /fortunereset gives her another go (turns) so a test can see a new card.
local fortuneTurns: { [Player]: number } = {}
local function todaysFortune(player: Player, day: number): (any, boolean, string)
	local seed = (day * 7919 + player.UserId * 104729 + (fortuneTurns[player] or 0) * 15485863) % 2147483647
	local rng = Random.new(seed)
	local card = TarotConfig.Cards[rng:NextInteger(1, #TarotConfig.Cards)]
	local upright = rng:NextNumber() < 0.5
	local lines = TarotConfig.Fortunes[card.Id]
	local words = if lines then lines[if upright then 1 else 2] else "The cards are quiet today."
	return card, upright, words
end

local function fortune(player: Player)
	if not DataManager.IsLoaded(player) then
		remote:FireClient(player, "Refused", "Your data is still loading. Try again in a moment.")
		return
	end
	local now = os.time()
	local day = math.floor(now / 86400)
	local card, upright, words = todaysFortune(player, day)
	local again = player:GetAttribute("LastFortuneDay") == day
	local candles, tickets = 0, 0
	if not again then
		player:SetAttribute("LastFortuneDay", day)
		candles = TarotConfig.FortuneCandles or 0
		tickets = TarotConfig.FortuneTickets or 5
		if candles > 0 then
			EventUtil.Candles(player, candles)
		end
		if tickets > 0 then
			DataManager.AddTickets(player, tickets)
		end
	end
	-- (again = she already read for you today: the same card and words, no gift; the last number = seconds to a new day)
	remote:FireClient(player, "Fortune", card.Id, upright, words, candles, tickets, again, 86400 - now % 86400)
end

local function promptPart(npc: Instance): BasePart?
	if npc:IsA("BasePart") then
		return npc
	end
	for _, name in { "HumanoidRootPart", "Head" } do
		local part = npc:FindFirstChild(name)
		if part and part:IsA("BasePart") then
			return part
		end
	end
	if npc:IsA("Model") and npc.PrimaryPart then
		return npc.PrimaryPart
	end
	return npc:FindFirstChildWhichIsA("BasePart", true)
end

local hooked: { [Instance]: boolean } = {}
local function hookNpc(npc: Instance)
	if hooked[npc] or not npc:IsDescendantOf(workspace) then
		return
	end
	local part = promptPart(npc)
	if not part then
		return
	end
	hooked[npc] = true
	local prompt = Instance.new("ProximityPrompt")
	prompt.Name = "FortunePrompt"
	prompt.ActionText = "Have your fortune told"
	prompt.ObjectText = TarotConfig.FortuneTellerName
	prompt.HoldDuration = 0.5
	prompt.MaxActivationDistance = 10
	prompt.RequiresLineOfSight = false
	prompt.Parent = part
	prompt.Triggered:Connect(fortune)
end

local function isFortuneTeller(instance: Instance): boolean
	return instance.Name == "FortuneTellerNPC" and (instance:IsA("Model") or instance:IsA("BasePart"))
end

-- a stand-in booth (a hooded figure at a little table with a crystal ball) until you place your own
local function buildBooth(): Model?
	local map = workspace:FindFirstChild("Map")
	local npcs = map and map:FindFirstChild("NPCS")
	local neighbour = npcs and (npcs:FindFirstChild("DailyRewardsNPC") or npcs:FindFirstChild("CodesNPC") or npcs:FindFirstChild("QuestGiverNPC"))
	if not neighbour or not neighbour:IsA("PVInstance") then
		warn("[TarotServer] No FortuneTellerNPC in Workspace > Map > NPCS (and no other NPC to put a stand-in next to).")
		return nil
	end
	local pivot = (neighbour :: PVInstance):GetPivot()
	local ground = pivot.Position.Y - 3
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.FilterDescendantsInstances = { neighbour }
	local base = (pivot * CFrame.new(10, 0, 0)).Position
	local hit = workspace:Raycast(base + Vector3.new(0, 4, 0), Vector3.new(0, -20, 0), params)
	if hit then
		ground = hit.Position.Y
	end
	local frame = CFrame.lookAt(Vector3.new(base.X, ground, base.Z), Vector3.new(base.X, ground, base.Z) + pivot.LookVector)
	local model = Instance.new("Model")
	model.Name = "FortuneTellerNPC"
	local function part(name: string, size: Vector3, offset: CFrame, color: Color3, material: Enum.Material?, shape: Enum.PartType?, solid: boolean?): Part
		local p = Instance.new("Part")
		p.Name = name
		p.Anchored = true
		p.CanCollide = solid == true
		p.Size = size
		p.CFrame = frame * offset
		p.Color = color
		p.Material = material or Enum.Material.SmoothPlastic
		if shape then
			p.Shape = shape
		end
		p.Parent = model
		return p
	end
	local cloth = Color3.fromRGB(46, 16, 22)
	part("Table", Vector3.new(0.4, 5, 5), CFrame.new(0, 2.6, -2.4) * CFrame.Angles(0, 0, math.pi / 2), Color3.fromRGB(48, 34, 26), Enum.Material.Wood, Enum.PartType.Cylinder, true)
	part("Leg", Vector3.new(0.8, 2.5, 0.8), CFrame.new(0, 1.25, -2.4), Color3.fromRGB(40, 28, 22), Enum.Material.Wood, nil, true)
	part("Cloth", Vector3.new(0.12, 5.3, 5.3), CFrame.new(0, 2.82, -2.4) * CFrame.Angles(0, 0, math.pi / 2), cloth, Enum.Material.Fabric, Enum.PartType.Cylinder)
	local ball = part("CrystalBall", Vector3.new(1.4, 1.4, 1.4), CFrame.new(0, 3.6, -2.4), Color3.fromRGB(176, 160, 200), Enum.Material.Glass, Enum.PartType.Ball)
	ball.Transparency = 0.35
	local light = Instance.new("PointLight")
	light.Color = Color3.fromRGB(170, 140, 220)
	light.Range = 10
	light.Brightness = 1.2
	light.Parent = ball
	local robe = Color3.fromRGB(34, 24, 36)
	part("HumanoidRootPart", Vector3.new(2, 2, 1), CFrame.new(0, 3, 0), robe, Enum.Material.Fabric).Transparency = 1
	part("Robe", Vector3.new(2.6, 4.2, 2), CFrame.new(0, 2.1, 0.2), robe, Enum.Material.Fabric, nil, true)
	part("Shawl", Vector3.new(3, 0.8, 2.2), CFrame.new(0, 4.3, 0.2), Color3.fromRGB(90, 30, 40), Enum.Material.Fabric)
	part("Head", Vector3.new(1.5, 1.5, 1.5), CFrame.new(0, 5.35, 0.2), Color3.fromRGB(12, 10, 14), Enum.Material.SmoothPlastic, Enum.PartType.Ball)
	part("Hood", Vector3.new(2, 1.9, 2), CFrame.new(0, 5.5, 0.35), robe, Enum.Material.Fabric)
	for _, x in { -0.25, 0.25 } do
		part("Eye", Vector3.new(0.18, 0.12, 0.1), CFrame.new(x, 5.45, -0.56), Color3.fromRGB(200, 170, 230), Enum.Material.Neon)
	end
	for _, x in { -0.9, 0.9 } do
		part("Hand", Vector3.new(0.4, 0.3, 0.7), CFrame.new(x * 0.7, 3.35, -1.6), Color3.fromRGB(150, 140, 130))
	end
	model.PrimaryPart = model:FindFirstChild("HumanoidRootPart") :: BasePart
	model.Parent = npcs
	return model
end

for _, instance in workspace:GetDescendants() do
	if isFortuneTeller(instance) then
		hookNpc(instance)
	end
end
workspace.DescendantAdded:Connect(function(instance)
	if isFortuneTeller(instance) then
		task.defer(hookNpc, instance)
	end
end)
task.delay(8, function()
	if next(hooked) == nil then
		local ok, err = pcall(buildBooth)
		if not ok then
			warn("[TarotServer] The Fortune Teller's stand-in booth couldn't be built: " .. tostring(err))
		end
	end
end)

---------------------------------------------------------------------- test commands (Systems > Commands: admins only)
local function findCard(words: { string }): any
	local text = string.lower(table.concat(words, " "))
	if text == "" then
		return nil
	end
	for _, card in TarotConfig.Cards do
		if card.Id == text or string.lower(card.Name) == text then
			return card
		end
	end
	for _, card in TarotConfig.Cards do -- ("priestess", "the hanged", "judgment"...)
		local name = string.lower(card.Name)
		if string.find(name, text, 1, true) or string.find(card.Id, text, 1, true) or string.find(text, card.Id, 1, true) then
			return card
		end
	end
	return nil
end

local UP_WORDS = { up = true, upright = true, u = true, good = true }
local REV_WORDS = { rev = true, reversed = true, r = true, down = true, bad = true }

-- gives a card as if it was drawn; in a round (alive) it works at once
local function giveCard(player: Player, card: any, upright: boolean): string
	clearCard(player)
	drawn[player] = { Card = card.Id, Upright = upright }
	player:SetAttribute("TarotCard", card.Id)
	player:SetAttribute("TarotUpright", upright)
	remote:FireClient(player, "Drawn", card.Id, upright)
	local playing = inRound and table.find(roundPlayers, player) ~= nil and player:GetAttribute("Alive") == true
	if card.Id == "wheel" then
		applyWheel(player, upright)
	end
	if playing then
		local t = stats[player]
		if t then
			t.Drew = upright
		end
		applyCard(player, card.Id, upright)
		return "now"
	end
	return "next round"
end

task.spawn(function()
	local Commands = optional("Commands")
	if not (Commands and Commands.Register) then
		return
	end
	local function target(player: Player, args: { string }): Player?
		if Commands.TakeTarget then
			return Commands.TakeTarget(player, args)
		end
		return player
	end
	local ok, err = pcall(function()
		Commands.Register("/tarot", function(player: Player, args: { string })
			local who = target(player, args)
			if not who then
				return
			end
			local upright: boolean? = nil
			local last = args[#args] and string.lower(args[#args])
			if last and UP_WORDS[last] then
				upright = true
				table.remove(args)
			elseif last and REV_WORDS[last] then
				upright = false
				table.remove(args)
			end
			local card = findCard(args)
			if not card then
				Commands.Reply(player, "No card called \"" .. table.concat(args, " ") .. "\". Try /tarotlist.", true)
				return
			end
			local isUp = if upright == nil then math.random() < UPRIGHT_CHANCE else upright
			local when = giveCard(who, card, isUp)
			Commands.Reply(player, ("%s gets %s%s (%s)."):format(who.Name, card.Name, if isUp then "" else ", reversed", if when == "now" then "working now" else "for their next round"))
		end)
		Commands.Register("/tarotclear", function(player: Player, args: { string })
			local who = target(player, args)
			if not who then
				return
			end
			clearCard(who)
			remote:FireClient(who, "Haze", false)
			Commands.Reply(player, who.Name .. "'s tarot card is gone.")
		end)
		Commands.Register("/tarotflips", function(player: Player, args: { string })
			local who = target(player, args)
			if not who then
				return
			end
			local count = math.clamp(math.floor(tonumber(args[1]) or 3), 0, 99)
			flips[who] = count
			remote:FireClient(who, "Flips", count)
			Commands.Reply(player, ("%s has %d ghost flip%s (they work once you're knocked out in a round)."):format(who.Name, count, if count == 1 then "" else "s"))
		end)
		Commands.Register("/fortunereset", function(player: Player, args: { string })
			local who = target(player, args)
			if not who then
				return
			end
			who:SetAttribute("LastFortuneDay", 0)
			fortuneTurns[who] = (fortuneTurns[who] or 0) + 1
			Commands.Reply(player, who.Name .. " can have their fortune told again today (a new card, and her gift again).")
		end)
		Commands.Register("/tarotlist", function(player: Player)
			local names = {}
			for _, card in TarotConfig.Cards do
				table.insert(names, card.Id)
			end
			Commands.Reply(player, "Cards: " .. table.concat(names, ", ") .. ". Add up or rev, e.g. /tarot death up")
		end)
	end)
	if not ok then
		warn("[TarotServer] the test commands couldn't be registered: " .. tostring(err))
	end
end)

---------------------------------------------------------------------- the remote
local lastAsk: { [Player]: number } = {}
remote.OnServerEvent:Connect(function(player: Player, action: any)
	local now = os.clock()
	if lastAsk[player] and now - lastAsk[player] < 0.3 then
		return
	end
	lastAsk[player] = now
	if action == "Draw" then
		onDraw(player)
	elseif action == "Flip" then
		onFlip(player)
	elseif action == "Sync" then
		-- (the client asks when it starts: anything it should already be showing)
		remote:FireClient(player, "Flips", flips[player] or 0)
		local entry = active[player]
		if entry and entry.Card == "star" and not entry.Upright and player:GetAttribute("Alive") == true then
			remote:FireClient(player, "Haze", true)
		end
	end
end)

Players.PlayerRemoving:Connect(function(player)
	local t = stats[player]
	if t then
		stopTrack(t)
	end
	stats[player] = nil
	drawn[player] = nil
	active[player] = nil
	flips[player] = nil
	streaks[player] = nil
	lastAsk[player] = nil
	fortuneTurns[player] = nil
end)
