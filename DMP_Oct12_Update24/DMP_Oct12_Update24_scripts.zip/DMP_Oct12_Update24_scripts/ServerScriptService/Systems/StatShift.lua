-- ModuleScript: ServerScriptService > Systems > StatShift
-- Builds a simple "stat shift" event that hits ONE random living player.
-- Modifiers = { Stat = {Add=, Mult=} }, or a function(player) returning that (nil = can't be picked).
-- Description = text after the player's name (string, or function(player) -> string).
-- Everyone gets a Toast: "<Name> <Description>".
-- The victim also gets server-built visuals (Systems/StatShiftVisuals) that replicate to everyone.
--
-- DURATION: with WHOLE_MATCH = true (below) a shift lasts for the rest of the match instead of
-- config.Duration. It ends when that player dies, is eliminated, leaves, respawns, the round ends,
-- or it is cancelled out by an opposing shift. The EVENT itself still ends after config.Duration
-- (so it can be picked again); only the effect lasts. While a player has a shift, the same shift
-- can't hit them again (no stacking). Set WHOLE_MATCH = false for the old timed behaviour.
--
-- OPPOSING SHIFTS: if the picked player already has a shift that contradicts the new one
-- (e.g. Feather + Weighing of the Heart), the new one is NOT applied and the old one is
-- removed early: they cancel out. Opposites come from:
--   1) config.Opposes = { "keyword", ... } (optional, matched against the other shift's Id/Name), and
--   2) the DEFAULT_OPPOSES table below (keyword -> list of opposite keywords).
-- Keywords are lowercase, no spaces, and match as a substring of the Id or Name.
--
-- (Oct 12 2026, update 23) StatShift.Give(player, config, quiet?) -> true when it took: the SAME shift given to a
-- chosen player by another event (the healing events' small buffs, Systems > EventUtil.Boon). Same rules: it lasts
-- the match, never stacks with itself, cancels against an opposite. Only that player is told (quiet = nobody).
-- StatShift.Has(player, config) -> is it running on them right now.

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerScriptService = game:GetService("ServerScriptService")

local Systems = ServerScriptService:WaitForChild("Systems")
local Stats = require(Systems:WaitForChild("Stats"))
local EventUtil = require(Systems:WaitForChild("EventUtil"))
local Visuals = require(Systems:WaitForChild("StatShiftVisuals"))

local WHOLE_MATCH = true -- true: every stat shift lasts the whole match; false: config.Duration (default 60s)

-- Add pairs here (both directions). Styx needs your real ids: send them or use config.Opposes.
local DEFAULT_OPPOSES = {
	feather = { "heart" },
	maat = { "heart" },
	heart = { "feather", "maat" },
	hermes = { "tartarus" },
	tartarus = { "hermes" },
	veil = { "nighthunt" },
	nighthunt = { "veil" },
}

local StatShift = {}
local counter = 0
local apply: (Player, any, any, number, boolean | Player | nil) -> boolean

-- active[player] = list of { config, key, ids, cleanupVisual, character, finished, connections }
local active: { [Player]: { any } } = {}

local function notifyAll(title: string, text: string?, color: Color3?)
	local remotes = ReplicatedStorage:FindFirstChild("Remotes")
	local remote = remotes and remotes:FindFirstChild("ClientEffect")
	if remote then
		(remote :: RemoteEvent):FireAllClients("Notify", { Title = title, Text = text or "", Color = color })
	end
end

local function resolve(value, player: Player)
	if type(value) == "function" then
		return value(player)
	end
	return value
end

local function keyOf(config): string
	local id = tostring(config.Id or "")
	local name = tostring(config.Name or "")
	local joined = string.lower(id .. name)
	local cleaned = string.gsub(joined, "[%s%p]", "")
	return cleaned
end

-- Does shift A (config) contradict shift B (entry key + config)?
local function opposes(config, otherConfig): boolean
	local myKey = keyOf(config)
	local otherKey = keyOf(otherConfig)

	-- Styx's Blessing vs Styx's Curse: any two DIFFERENT shifts with "styx" in the Id/Name cancel
	if config ~= otherConfig and string.find(myKey, "styx", 1, true) and string.find(otherKey, "styx", 1, true) then
		return true
	end

	-- Explicit lists, checked both ways
	local function listHits(cfg, targetKey: string): boolean
		if type(cfg.Opposes) ~= "table" then
			return false
		end
		for _, word in cfg.Opposes do
			local w = string.lower(tostring(word))
			w = string.gsub(w, "[%s%p]", "")
			if w ~= "" and string.find(targetKey, w, 1, true) then
				return true
			end
		end
		return false
	end
	if listHits(config, otherKey) or listHits(otherConfig, myKey) then
		return true
	end

	-- Default table, checked both ways
	local function defaultHits(aKey: string, bKey: string): boolean
		for keyword, opposites in DEFAULT_OPPOSES do
			if string.find(aKey, keyword, 1, true) then
				for _, opp in opposites do
					if string.find(bKey, opp, 1, true) then
						return true
					end
				end
			end
		end
		return false
	end
	return defaultHits(myKey, otherKey) or defaultHits(otherKey, myKey)
end

local function removeEntry(player: Player, entry)
	local list = active[player]
	if not list then
		return
	end
	local index = table.find(list, entry)
	if index then
		table.remove(list, index)
	end
	if #list == 0 then
		active[player] = nil
	end
end

-- Idempotent: safe to call from the timer AND from a cancel
local function finish(player: Player, entry)
	if entry.finished then
		return
	end
	entry.finished = true
	removeEntry(player, entry)

	if entry.connections then
		for _, connection in entry.connections do
			connection:Disconnect()
		end
		entry.connections = nil
	end

	if player.Parent then
		for _, id in entry.ids do
			Stats.RemoveModifier(player, id)
		end
	end
	if entry.cleanupVisual then
		local ok, err = pcall(entry.cleanupVisual)
		if not ok then
			warn("StatShift visual cleanup failed: " .. tostring(err))
		end
	end
end

-- Active shifts still valid for this player (drops ones from a previous character)
local function getActive(player: Player): { any }
	local result = {}
	local list = active[player]
	if not list then
		return result
	end
	for _, entry in table.clone(list) do
		if entry.finished or entry.character ~= player.Character then
			finish(player, entry)
		else
			table.insert(result, entry)
		end
	end
	return result
end

-- Does this player already have THIS shift running?
local function hasShift(player: Player, config): boolean
	for _, entry in getActive(player) do
		if entry.config == config then
			return true
		end
	end
	return false
end

local function finishEverything()
	for player, list in table.clone(active) do
		for _, entry in table.clone(list) do
			finish(player, entry)
		end
	end
end

game:GetService("Players").PlayerRemoving:Connect(function(player)
	local list = active[player]
	if list then
		for _, entry in table.clone(list) do
			finish(player, entry)
		end
	end
	active[player] = nil
end)

-- Safety net for "the whole match": when the round stops being InRound, every shift ends
ReplicatedStorage:GetAttributeChangedSignal("GameState"):Connect(function()
	if ReplicatedStorage:GetAttribute("GameState") ~= "InRound" then
		finishEverything()
	end
end)

function StatShift.new(config)
	local Event = {
		Name = config.Name,
		Id = config.Id,
		Weight = config.Weight or 1,
		Duration = config.Duration or 60, -- how long the EVENT counts as running (not the effect, see WHOLE_MATCH)
		Target = "Arena",
	}

	function Event.Run(_context)
		-- Random order, first player this event can affect
		local alive = table.clone(EventUtil.GetAlivePlayers())
		for i = #alive, 2, -1 do
			local j = math.random(i)
			alive[i], alive[j] = alive[j], alive[i]
		end
		local target: Player? = nil
		local mods = nil
		for _, player in alive do
			local m = resolve(config.Modifiers, player)
			-- whole-match shifts don't stack: skip anyone who already has this one
			if m and not (WHOLE_MATCH and hasShift(player, config)) then
				target, mods = player, m
				break
			end
		end
		if not target or not mods then
			return
		end

		apply(target, config, mods, Event.Duration, false)
	end

	return Event
end

-- puts a shift on a player (Run and Give). Returns true when it took (false = it cancelled against an opposite one)
apply = function(target: Player, config, mods, duration: number, only: boolean | Player | nil): boolean
	do
		local function tell(title: string, text: string)
			if only == true then
				return
			elseif typeof(only) == "Instance" then
				local remotes = ReplicatedStorage:FindFirstChild("Remotes")
				local remote = remotes and remotes:FindFirstChild("ClientEffect")
				if remote then
					(remote :: RemoteEvent):FireClient(only, "Notify", { Title = title, Text = text, Color = config.Color })
				end
			else
				notifyAll(title, text, config.Color)
			end
		end
		-- Contradicting shift already on them? Both cancel out.
		local clashing = {}
		for _, entry in getActive(target) do
			if opposes(config, entry.config) then
				table.insert(clashing, entry)
			end
		end
		if #clashing > 0 then
			local oldName = Visuals.GetDisplayName(clashing[1].config)
			for _, entry in clashing do
				finish(target, entry)
			end
			tell("Cancelled Out", target.DisplayName .. "'s " .. oldName .. " and " .. Visuals.GetDisplayName(config) .. " cancelled out")
			return false
		end

		local description = resolve(config.Description, target) or ""
		if typeof(only) == "Instance" then
			tell(Visuals.GetDisplayName(config), description)
		else
			tell(Visuals.GetDisplayName(config), target.DisplayName .. " " .. description)
		end

		counter += 1
		local ids = {}
		for stat, mod in mods do
			table.insert(ids, Stats.AddModifier(target, stat, mod))
		end

		-- Visuals must never break the stat change itself (math.huge = no countdown, lasts the match)
		local visualDuration = if WHOLE_MATCH then math.huge else duration
		local okVisual, cleanupVisual = pcall(Visuals.Attach, target, config, visualDuration)
		if not okVisual then
			warn("StatShift visuals failed: " .. tostring(cleanupVisual))
			cleanupVisual = nil
		end

		local character = target.Character
		local entry = {
			config = config,
			ids = ids,
			cleanupVisual = cleanupVisual,
			character = character,
			finished = false,
			connections = {},
		}
		active[target] = active[target] or {}
		table.insert(active[target], entry)

		if WHOLE_MATCH then
			local victim = target
			-- eliminated / round over
			table.insert(entry.connections, victim:GetAttributeChangedSignal("Alive"):Connect(function()
				if victim:GetAttribute("Alive") == false then
					finish(victim, entry)
				end
			end))
			if character then
				local humanoid = character:FindFirstChildOfClass("Humanoid")
				if humanoid then
					table.insert(entry.connections, humanoid.Died:Connect(function()
						finish(victim, entry)
					end))
				end
				-- respawned / removed
				table.insert(entry.connections, character.AncestryChanged:Connect(function(_, parent)
					if not parent then
						finish(victim, entry)
					end
				end))
			end
		else
			task.delay(duration, function()
				finish(target, entry)
			end)
		end
		return true
	end
end

function StatShift.Has(player: Player, config): boolean
	return hasShift(player, config)
end

function StatShift.Give(player: Player, config, quiet: boolean?): boolean
	if player:GetAttribute("Alive") == false or not player.Character then
		return false
	end
	if WHOLE_MATCH and hasShift(player, config) then
		return false
	end
	local mods = resolve(config.Modifiers, player)
	if not mods then
		return false
	end
	return apply(player, config, mods, config.Duration or 60, if quiet then true else player)
end

return StatShift