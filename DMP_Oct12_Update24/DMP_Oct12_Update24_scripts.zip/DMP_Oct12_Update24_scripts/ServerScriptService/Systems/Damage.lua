-- ModuleScript: ServerScriptService > Systems > Damage
-- ALL damage and healing goes through here, so shields, dodges, and
-- cheat-death effects work in one place instead of inside every event.
--
--   Damage.Deal(player, 20, { Source = "Gargoyle Attack" })
--   Damage.Kill(player, { Source = "Guillotine" })
--   Damage.Heal(player, 25, { Source = "Grave Lily" })
--
-- Handlers let effects change or block damage before it lands:
--
--   Damage.AddHandler(player, "TombstoneShield", 10, function(context)
--       context.Cancelled = true
--       Damage.RemoveHandler(player, "TombstoneShield") -- one-time
--   end)
--
-- Handlers run lowest priority first. Suggested order:
--   0   immunity        (Gargoyle Charm)
--   10  shields         (Tombstone Shield, Guardian Wisp)
--   20  chance dodges   (Phantom Form)
--   50  reductions
--   100 cheat death     (Last Breath) - runs last so it sees the final amount
--
-- DAMAGE TYPES AND SIDES (Oct 8). Damage can have a type: "Fire", "Poison" or "Bleed". Pass it as
--   Damage.Deal(player, 10, { Source = "Bed of Nails", Type = "Poison" })
-- or list the Source below in Damage.SourceTypes (every hit from that source then has that type).
-- Ghosts and Vampires (the Soul attribute: above 0 = Ghost, below 0 = Vampire) take more or less of each type:
-- Damage.SideRules. (Oct 10: the toast that told you about it the first time is OFF: Damage.SideToasts.)
--
-- STATUS EFFECTS (Oct 10 2026, update 9). Damage that has a type also SHOWS on the character, for everybody: drops
-- of blood, green fumes, flames. Whoever takes typed damage gets the attribute Status_Bleed / Status_Poison /
-- Status_Fire = the server time until it shows (Damage.StatusTime seconds for one hit; damage over time keeps
-- pushing it back). StarterPlayerScripts > EventClients > StatusEffectsClient draws it, from the emitters in
-- ReplicatedStorage > Assets > StatusEffects. Damage.Mark(player, "Fire", 5) shows one without any damage.

local ServerScriptService = game:GetService("ServerScriptService")
local Players = game:GetService("Players")

local Stats = require(ServerScriptService:WaitForChild("Systems"):WaitForChild("Stats"))

export type DamageContext = {
	Player: Player,
	Humanoid: Humanoid,
	Amount: number,
	Source: string,
	Type: string?,       -- "Fire", "Poison", "Bleed" or nil
	InstantKill: boolean,
	Cancelled: boolean,
}

type Handler = { Id: string, Priority: number, Callback: (DamageContext) -> () }

local Damage = {}

-- How much of each damage type a side takes (1 = normal). Neutral players (Soul 0) always take it normally.
Damage.SideRules = {
	Fire = { Vampire = 2, Ghost = 0.5 },     -- vampires burn, ghosts hardly feel it
	Poison = { Vampire = 0.5, Ghost = 2 },   -- ghosts are hit hard by poison, vampires shrug it off
	Bleed = { Ghost = 0.5 },                 -- ghosts have hardly any blood to lose (an extra Ghost perk)
}

-- Sources whose damage always has a type (the Source names the events and items already pass)
Damage.SourceTypes = {
	["Ghost Fire"] = "Fire",
	Ghostfire = "Fire",              -- Wisp Guide's flames
	["Furnace Pipe"] = "Fire",
	["Infernal Sigil"] = "Fire",
	["Balefire Skull"] = "Fire",
	["Candle Circle"] = "Fire",
	["Meteor Shower"] = "Fire",
	["Witch's Cauldron"] = "Poison",
	["Spider Jar"] = "Poison",
	["Iron Maiden"] = "Bleed",
	["Bear Trap"] = "Bleed",
}

Damage.SideToasts = false   -- true = the first time a side rule changes somebody's damage, a toast tells them
Damage.StatusTime = 1.6     -- seconds one hit of typed damage shows on the character

-- what the first toast about a side rule says (side .. type)
local SIDE_TIPS = {
	VampireFire = { "Vampires burn!", "Fire hurts you twice as much." },
	GhostFire = { "Ghostly!", "Fire only does half to you." },
	GhostPoison = { "Ghosts hate poison!", "Poison hurts you twice as much." },
	VampirePoison = { "Vampire blood!", "Poison only does half to you." },
	GhostBleed = { "Ghostly!", "Bleeding only does half to you." },
}
local tipped: { [Player]: { [string]: boolean } } = {}

local handlersByPlayer: { [Player]: { Handler } } = {}

local damagedEvent = Instance.new("BindableEvent")
local healedEvent = Instance.new("BindableEvent")

-- Damage.Damaged:Connect(function(player, amount, context) end)
-- Used later by Open Wound, Fright, Undying Flame, etc.
Damage.Damaged = damagedEvent.Event
-- Damage.Healed:Connect(function(player, amount, source) end)
Damage.Healed = healedEvent.Event

local function getHumanoid(player: Player): Humanoid?
	local character = player.Character
	return character and character:FindFirstChildOfClass("Humanoid")
end

function Damage.AddHandler(player: Player, id: string, priority: number, callback: (DamageContext) -> ())
	local handlers = handlersByPlayer[player]
	if not handlers then
		handlers = {}
		handlersByPlayer[player] = handlers
	end

	Damage.RemoveHandler(player, id) -- replace if it already exists
	table.insert(handlers, { Id = id, Priority = priority, Callback = callback })
	table.sort(handlers, function(a, b)
		return a.Priority < b.Priority
	end)
end

function Damage.RemoveHandler(player: Player, id: string)
	local handlers = handlersByPlayer[player]
	if not handlers then
		return
	end
	for index, handler in handlers do
		if handler.Id == id then
			table.remove(handlers, index)
			return
		end
	end
end

-- "Ghost", "Vampire" or "Neutral" (from the Soul attribute, like FeedHaunt.GetSide)
function Damage.SideOf(player: Player): string
	local soul = player:GetAttribute("Soul")
	if type(soul) ~= "number" or soul == 0 then
		return "Neutral"
	end
	return if soul > 0 then "Ghost" else "Vampire"
end

-- How much of damage type `kind` this player takes because of their side (1 = normal)
function Damage.SideMultiplier(player: Player, kind: string?): number
	local rules = kind and Damage.SideRules[kind]
	local mult = rules and rules[Damage.SideOf(player)]
	return if type(mult) == "number" then mult else 1
end

local function tellSide(player: Player, kind: string)
	local key = Damage.SideOf(player) .. kind
	local tip = SIDE_TIPS[key]
	local seen = tipped[player] or {}
	tipped[player] = seen
	if not tip or seen[key] then
		return
	end
	seen[key] = true
	pcall(function()
		local remotes = game:GetService("ReplicatedStorage"):FindFirstChild("Remotes")
		local remote = remotes and remotes:FindFirstChild("ClientEffect")
		if remote and remote:IsA("RemoteEvent") then
			remote:FireClient(player, "Notify", { Title = tip[1], Text = tip[2], Color = Color3.fromRGB(255, 200, 60) })
		end
	end)
end

-- Shows a status on the character ("Fire", "Poison" or "Bleed") for `seconds` (default Damage.StatusTime), for
-- everybody. It never shortens one that is already showing for longer.
local STATUS = { Fire = "Status_Fire", Poison = "Status_Poison", Bleed = "Status_Bleed" }
function Damage.Mark(player: Player, kind: string, seconds: number?)
	local name = STATUS[kind]
	if not name or player.Parent ~= Players then
		return
	end
	local ends = workspace:GetServerTimeNow() + (seconds or Damage.StatusTime)
	local current = player:GetAttribute(name)
	if type(current) ~= "number" or current < ends then
		player:SetAttribute(name, ends)
	end
end

-- Takes a status off again (kind = nil: all of them)
function Damage.Unmark(player: Player, kind: string?)
	for key, name in STATUS do
		if (kind == nil or kind == key) and player:GetAttribute(name) ~= nil then
			player:SetAttribute(name, nil)
		end
	end
end

function Damage.HasHandler(player: Player, id: string): boolean
	for _, handler in handlersByPlayer[player] or {} do
		if handler.Id == id then
			return true
		end
	end
	return false
end

-- Returns how much damage was actually dealt.
-- info.Type = "Fire" / "Poison" / "Bleed" (or leave it out: Damage.SourceTypes may give the Source one)
function Damage.Deal(player: Player, amount: number, info: { Source: string?, InstantKill: boolean?, Type: string? }?): number
	local humanoid = getHumanoid(player)
	if not humanoid or humanoid.Health <= 0 or amount <= 0 then
		return 0
	end

	local options = info or {}
	local instantKill = options.InstantKill == true
	local kind: string? = options.Type or Damage.SourceTypes[options.Source or ""]
	local sideMult = if instantKill then 1 else Damage.SideMultiplier(player, kind)

	local context: DamageContext = {
		Player = player,
		Humanoid = humanoid,
		Amount = if instantKill then humanoid.Health else amount * Stats.Get(player, "DamageTaken") * sideMult,
		Source = options.Source or "Unknown",
		Type = kind,
		InstantKill = instantKill,
		Cancelled = false,
	}

	-- Copy the list so handlers can safely remove themselves
	for _, handler in table.clone(handlersByPlayer[player] or {}) do
		handler.Callback(context)
		if context.Cancelled then
			return 0
		end
	end

	if context.Amount <= 0 then
		return 0
	end

	local dealt = math.min(context.Amount, humanoid.Health)
	humanoid.Health -= dealt
	damagedEvent:Fire(player, dealt, context)
	if kind and not instantKill then
		Damage.Mark(player, kind)
	end
	if Damage.SideToasts and sideMult ~= 1 and kind then
		tellSide(player, kind)
	end
	return dealt
end

function Damage.Kill(player: Player, info: { Source: string? }?): number
	return Damage.Deal(player, math.huge, {
		Source = if info then info.Source else nil,
		InstantKill = true,
	})
end

-- Returns how much was actually healed.
function Damage.Heal(player: Player, amount: number, info: { Source: string? }?): number
	local humanoid = getHumanoid(player)
	if not humanoid or humanoid.Health <= 0 or amount <= 0 then
		return 0
	end

	local healed = math.min(amount, humanoid.MaxHealth - humanoid.Health)
	if healed <= 0 then
		return 0
	end

	humanoid.Health += healed
	healedEvent:Fire(player, healed, if info then info.Source else nil)
	return healed
end

-- Handlers belong to the current character, like stat modifiers
local function onPlayerAdded(player: Player)
	player.CharacterAdded:Connect(function()
		handlersByPlayer[player] = {}
		Damage.Unmark(player) -- (a fresh character is not bleeding or on fire)
	end)
end

Players.PlayerAdded:Connect(onPlayerAdded)
Players.PlayerRemoving:Connect(function(player)
	handlersByPlayer[player] = nil
	tipped[player] = nil
end)
for _, player in Players:GetPlayers() do
	onPlayerAdded(player)
end

return Damage