-- ModuleScript: ServerScriptService > Systems > ItemCrates
--   The chest model lives in ReplicatedStorage > Assets > Chest (see EventClients > crates).
--
-- Every few events (GameConfig.CrateEvery), item chests drop on random plates: the more
-- players still alive, the more chests (GameConfig.CratesPerPlayer each). Hold E to open one and get a random item from
-- ServerStorage > Items. Chests vanish when their plate breaks, after a while, or when
-- the round ends.
--
-- SERVER: where chests land, who opens them, giving the item.
-- CLIENT (ReplicatedStorage > EventClients > crates): the chest falling, bobbing, opening animation.
--
-- Oct 10 2026 (update 8): ItemCrates.Spawn(position, options) = the same chest anywhere you want one (an event's
-- prize, the top of the Stairway of Spirits ...). Events reach it through EventUtil.Chest. Dropped chests are
-- unchanged.
-- Oct 11 2026 (update 12): a chest from Spawn can be told to open by itself (chest.Open()): The Bidding's prize.

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerScriptService = game:GetService("ServerScriptService")
local ServerStorage = game:GetService("ServerStorage")

local GameConfig = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("GameConfig"))
local Systems = ServerScriptService:WaitForChild("Systems")
local EventUtil = require(Systems:WaitForChild("EventUtil"))
local EventVisuals = require(Systems:WaitForChild("EventVisuals"))
local PlateSpawner = require(Systems:WaitForChild("PlateSpawner"))

local VISUAL_ID = "crates"
local DROP_HEIGHT = 40
local DROP_TIME = 0.6
local LIFETIME = 40
local OPEN_TIME = 2 -- how long the opened chest stays (opening animation + fade)

local ItemCrates = {}

-- Copy any model under this module to where clients can see it
-- (not needed for the Chest, which is already in ReplicatedStorage > Assets)
do
	local assets = ReplicatedStorage:FindFirstChild("EventAssets")
	if not assets then
		assets = Instance.new("Folder")
		assets.Name = "EventAssets"
		assets.Parent = ReplicatedStorage
	end
	local old = assets:FindFirstChild(VISUAL_ID)
	if old then
		old:Destroy()
	end
	local folder = Instance.new("Folder")
	folder.Name = VISUAL_ID
	for _, child in script:GetChildren() do
		if not child:IsA("LuaSourceContainer") then
			child:Clone().Parent = folder
		end
	end
	folder.Parent = assets
end

local serverFolder = Instance.new("Folder")
serverFolder.Name = "ItemCrates"
serverFolder.Parent = workspace:WaitForChild("Map")

type Crate = { Visual: number, Anchor: BasePart, Plate: BasePart?, Expires: number, Options: { [string]: any }? }
local crates: { Crate } = {}

local function getItemPool(): { Tool }
	local pool = {}
	local folder = ServerStorage:FindFirstChild("Items", true)
	for _, item in if folder then folder:GetDescendants() else {} do
		if item:IsA("Tool") then
			table.insert(pool, item)
		end
	end
	return pool
end

local function removeCrate(crate: Crate, opened: boolean)
	local index = table.find(crates, crate)
	if not index then
		return
	end
	table.remove(crates, index)
	crate.Anchor:Destroy()
	if opened then
		EventVisuals.Call(crate.Visual, "Open")
		task.delay(OPEN_TIME, EventVisuals.Destroy, crate.Visual)
	else
		EventVisuals.Destroy(crate.Visual)
	end
end

-- One chest standing at `landed` (the bottom middle of the chest). plate = the plate it is on (nil = not on one).
local function addCrate(landed: CFrame, plate: BasePart?, pool: { Tool }, options: { [string]: any }?): Crate
	local ground = landed.Position
	local drop = not (options and options.Drop == false)
	local visual: number
	if drop then
		visual = EventVisuals.Spawn(VISUAL_ID, "Chest", landed + Vector3.new(0, DROP_HEIGHT, 0))
		EventVisuals.Tween(visual, landed, DROP_TIME, "Quad", "In")
	else
		visual = EventVisuals.Spawn(VISUAL_ID, "Chest", landed)
	end

	local objectText = if options and type(options.Name) == "string" then options.Name else "Chest"
	local anchor, prompt = EventUtil.MakePrompt(ground + Vector3.new(0, 1.5, 0), "Open", objectText, 0.3, serverFolder)
	prompt.Enabled = false
	task.delay(if drop then DROP_TIME else 0.1, function()
		if prompt.Parent then
			prompt.Enabled = true
		end
	end)

	local lifetime = if options and type(options.Lifetime) == "number" then options.Lifetime else LIFETIME
	local crate: Crate = { Visual = visual, Anchor = anchor, Plate = plate, Expires = os.clock() + lifetime, Options = options }
	table.insert(crates, crate)

	prompt.Triggered:Connect(function(player: Player)
		if not table.find(crates, crate) or player:GetAttribute("Alive") ~= true then
			return
		end
		if options and type(options.CanOpen) == "function" then
			local ok, allowed = pcall(options.CanOpen, player)
			if not ok or not allowed then
				return
			end
		end
		local itemName: string? = nil
		if not (options and options.NoItem) then
			local backpack = player:FindFirstChildOfClass("Backpack")
			if not backpack or #pool == 0 then
				return
			end
			local item = pool[math.random(#pool)]:Clone()
			item.Parent = backpack
			itemName = item.Name
			EventUtil.Notify(player, objectText, "You found a " .. item.Name .. ".", Color3.fromRGB(255, 214, 140))
		end
		removeCrate(crate, true)
		if options and type(options.OnOpened) == "function" then
			task.spawn(options.OnOpened, player, itemName)
		end
	end)
	return crate
end

local function spawnCrate(plate: BasePart, pool: { Tool })
	local halfX, halfZ = plate.Size.X / 2 - 2.5, plate.Size.Z / 2 - 2.5
	local ground = plate.CFrame:PointToWorldSpace(Vector3.new((math.random() * 2 - 1) * halfX, 0, (math.random() * 2 - 1) * halfZ))
	ground = Vector3.new(ground.X, EventUtil.GetPlateTop(plate), ground.Z)
	addCrate(CFrame.new(ground) * CFrame.Angles(0, math.random() * math.pi * 2, 0), plate, pool, nil)
end

-- The same chest, wherever you want one. position = the spot it stands on (its bottom middle).
-- options (all optional):
--   Plate    = a plate: the chest goes when that plate breaks (like a dropped chest)
--   Lifetime = seconds until it disappears if nobody opens it (default 40)
--   Drop     = false: it is simply there (default: it falls out of the sky like the others)
--   Name     = what the prompt and the "You found a ..." toast call it (default "Chest")
--   Yaw      = which way it faces, in radians (default: random)
--   CanOpen  = function(player) -> boolean: who may open it (default: anyone alive)
--   OnOpened = function(player, itemName?): runs after it was opened (the item, if any, is already theirs)
--   NoItem   = true: no item comes out of it (OnOpened decides what they get)
-- Returns the chest: chest.Remove() takes it away, chest.IsOpen() is true once somebody opened it, chest.Open()
-- makes it open by itself (its own opening animation, then it goes; nobody gets anything from that).
-- nil when there are no items in ServerStorage > Items (and NoItem is not set).
function ItemCrates.Spawn(position: Vector3, options: { [string]: any }?): { Remove: () -> (), IsOpen: () -> boolean, Open: () -> () }?
	local pool = getItemPool()
	if #pool == 0 and not (options and options.NoItem) then
		warn("[ItemCrates] No items found. Put the item tools in ServerStorage > Items")
		return nil
	end
	local settings: { [string]: any } = if options then table.clone(options) else {}
	local yaw = if type(settings.Yaw) == "number" then settings.Yaw else math.random() * math.pi * 2
	local plate = if typeof(settings.Plate) == "Instance" and settings.Plate:IsA("BasePart") then settings.Plate else nil
	local opened = false
	local userOpened = settings.OnOpened
	settings.OnOpened = function(player: Player, itemName: string?)
		opened = true
		if type(userOpened) == "function" then
			userOpened(player, itemName)
		end
	end
	local crate = addCrate(CFrame.new(position) * CFrame.Angles(0, yaw, 0), plate, pool, settings)
	return {
		Remove = function()
			removeCrate(crate, false)
		end,
		IsOpen = function(): boolean
			return opened
		end,
		Open = function()
			removeCrate(crate, true)
		end,
	}
end

-- Drops chests on random plates (one per plate at most).
-- With no count, it's CratesPerPlayer for every player still alive.
function ItemCrates.Drop(count: number?)
	local pool = getItemPool()
	if #pool == 0 then
		warn("[ItemCrates] No items found. Put the item tools in ServerStorage > Items")
		return 0
	end

	local alive = 0
	for _, player in game:GetService("Players"):GetPlayers() do
		if player:GetAttribute("Alive") == true then
			alive += 1
		end
	end
	local amount = count or math.ceil(alive * GameConfig.CratesPerPlayer)

	local plates = PlateSpawner.GetAllPlates()
	for i = #plates, 2, -1 do
		local j = math.random(i)
		plates[i], plates[j] = plates[j], plates[i]
	end
	amount = math.min(amount, #plates)
	for index = 1, amount do
		spawnCrate(plates[index], pool)
	end
	return amount
end

-- Removes every chest (end of round)
function ItemCrates.ClearAll()
	for _, crate in table.clone(crates) do
		removeCrate(crate, false)
	end
end

-- Chests on broken plates, or left too long, disappear
task.spawn(function()
	while true do
		task.wait(0.5)
		local now = os.clock()
		for _, crate in table.clone(crates) do
			local plate = crate.Plate
			if (plate and not plate.Parent) or now > crate.Expires then
				removeCrate(crate, false)
			end
		end
	end
end)

return ItemCrates