-- ModuleScript: _Install     (inside every DMP update package: DMP_<update> > _Install)     DMP installer v3
-- v3 (Oct 10 2026): YOUR OWN EDITS ARE SAFE. An update is built from an export of your game. If you have edited
-- one of the scripts it replaces SINCE that export, the update would wipe your edit out, so the installer checks
-- first: when it finds such a script it installs NOTHING and tells you which ones. Then either send a fresh
-- export and get the update rebuilt on your scripts, or install anyway by running it once more (click "Install
-- update" on the Plugins tab): your versions are kept in the backups. Values you filled in inside a
-- --[[DMP:KEEP]] block do not count as an edit (they are carried over, as before).
-- Installs the update it sits in. The package's folders mirror your game (ServerScriptService/Events/...,
-- ReplicatedStorage/EventClients/..., ServerStorage/Items/...), so everything goes where its folders say:
--   * A SCRIPT that already exists there keeps its place, its children (models, sounds, animations under it) and
--     its attributes: only its CODE is replaced. Your old code is copied first to
--     ServerStorage > DMP_Backups > <update name> (scripts there never run). If you had moved that script into a
--     subfolder of the same folder, that one is updated instead of adding a second copy.
--   * YOUR SETTINGS SURVIVE: in a block between the lines --[[DMP:KEEP name]] and --[[DMP:END]] (the SOUNDS /
--     ANIMATIONS tables, TUNE_ID ...), every id you filled in (Id = "...", Name = 123, local X = "...") is copied
--     into the new code. (A script you had from before these markers existed: the same table is found by its first
--     line, e.g. "local SOUNDS = {".)
--   * A script that doesn't exist yet is moved in.
--   * Folders are merged into yours. Anything else (parts, models, tools, values) is only ADDED when it is missing:
--     yours is kept (the package's copy can force a replace with the attribute DMPReplace = true; your old one then
--     goes to the backups).
--   * _Delete (a StringValue in the package, one path per line, e.g. ServerScriptService/Systems/EventKit2) lists
--     things to take out: they are MOVED to the backups, not destroyed.
--   * _Notes (a StringValue in the package) is printed at the end.
--   * _Base (a StringValue in the package) is how it knows what your scripts looked like in the export (and in
--     the updates sent since).
-- Everything it did is printed in Output, and Ctrl+Z undoes it.
-- Run it: the "DMP Installer" plugin runs it by itself when you drag the update into Studio. Without the plugin,
-- paste this into the Command Bar (View > Command Bar) and press Enter:
--     require(workspace.DMP_Oct8_Update3._Install).Install()
-- (use the update's folder name). Never while playing: Studio throws away changes made during Play.

local ChangeHistoryService = game:GetService("ChangeHistoryService")
local RunService = game:GetService("RunService")
local ServerStorage = game:GetService("ServerStorage")

local Installer = {}
Installer.Version = 3

local RESERVED = { _Install = true, _Notes = true, _Delete = true, _Base = true }

local function serviceFor(name: string): Instance?
	if name == "Workspace" then
		return workspace
	end
	local ok, found = pcall(function()
		return game:GetService(name :: any)
	end)
	if ok and found then
		return found
	end
	return game:FindFirstChild(name)
end

local function isScript(item: Instance): boolean
	return item:IsA("LuaSourceContainer")
end

---------------------------------------------------------------------
-- Keeping his settings: the ids he filled in inside --[[DMP:KEEP name]] ... --[[DMP:END]] blocks
---------------------------------------------------------------------

local function linesOf(source: string): { string }
	local list = {}
	for line in (source .. "\n"):gmatch("(.-)\r?\n") do
		table.insert(list, line)
	end
	return list
end

local function keyOf(line: string): string?
	return line:match("^%s*local%s+([%w_]+)%s*=[^=]") or line:match("^%s*([%w_]+)%s*=[^=]")
end

-- name -> { first, last } line numbers of the lines INSIDE each KEEP block
local function keepBlocks(lines: { string }): { [string]: { number } }
	local found: { [string]: { number } } = {}
	local name: string? = nil
	local first = 0
	for index, line in lines do
		local open = line:match("^%s*%-%-%[%[DMP:KEEP%s+([%w_]+)%]%]")
		if open then
			name, first = open, index + 1
		elseif line:match("^%s*%-%-%[%[DMP:END%]%]") and name then
			found[name] = { first, index - 1 }
			name = nil
		end
	end
	return found
end

-- the same table in an OLD source that has no markers: the line "local NAME = {" down to the closing "}"
local function findTable(oldLines: { string }, key: string): { number }?
	for index, line in oldLines do
		if keyOf(line) == key and line:match("{%s*$") then
			for last = index + 1, #oldLines do
				if oldLines[last]:match("^}%s*$") then
					return { index, last }
				end
			end
		end
	end
	return nil
end

local function escape(text: string): string
	return (text:gsub("%%", "%%%%"))
end

-- his value from oldLine put into newLine (nil = nothing of his to keep)
local function carry(newLine: string, oldLine: string): string?
	local quoted = oldLine:match('[^%w_]Id%s*=%s*"([^"]*)"') or oldLine:match('^%s*Id%s*=%s*"([^"]*)"')
	local bare = oldLine:match("[^%w_]Id%s*=%s*(%d+)")
	local id = if quoted and quoted ~= "" then quoted elseif bare and bare ~= "0" then bare else nil
	if id and newLine:match("Id%s*=") then
		local replaced, count = newLine:gsub('([^%w_]Id%s*=%s*)"[^"]*"', "%1\"" .. escape(id) .. "\"", 1)
		if count == 0 then
			replaced, count = newLine:gsub("([^%w_]Id%s*=%s*)%d+", "%1\"" .. escape(id) .. "\"", 1)
		end
		return if count > 0 then replaced else nil
	end
	local number = oldLine:match("^%s*[%w_]+%s*=%s*(%d[%d%.]*)")
	if number and tonumber(number) and tonumber(number) ~= 0 then
		local replaced, count = newLine:gsub("^(%s*[%w_]+%s*=%s*)%d[%d%.]*", "%1" .. escape(number), 1)
		return if count > 0 then replaced else nil
	end
	local text = oldLine:match('^%s*local%s+[%w_]+%s*=%s*"([^"]*)"')
	if text and text ~= "" then
		local replaced, count = newLine:gsub('^(%s*local%s+[%w_]+%s*=%s*)"[^"]*"', "%1\"" .. escape(text) .. "\"", 1)
		return if count > 0 then replaced else nil
	end
	return nil
end

-- new source with his settings carried over; and how many values were kept
local function keepSettings(oldSource: string, newSource: string): (string, number)
	local newLines = linesOf(newSource)
	local blocks = keepBlocks(newLines)
	if next(blocks) == nil then
		return newSource, 0
	end
	local oldLines = linesOf(oldSource)
	local oldBlocks = keepBlocks(oldLines)
	local kept = 0
	for name, range in blocks do
		local mine: { [string]: string } = {}
		local oldRange = oldBlocks[name]
		if not oldRange then
			-- an old copy from before the markers: a table block is found by its first line ("local SOUNDS = {"),
			-- single settings ("local TUNE_ID = ...") by their names, at the top level of the old script
			for index = range[1], range[2] do
				local key = keyOf(newLines[index])
				if key then
					if newLines[index]:match("{%s*$") then
						oldRange = findTable(oldLines, key)
					else
						for _, line in oldLines do
							local top = line:match("^local%s+([%w_]+)%s*=[^=]")
							if top then
								mine[top] = line
							end
						end
					end
					break
				end
			end
		end
		if oldRange then
			for index = oldRange[1], oldRange[2] do
				local key = keyOf(oldLines[index])
				if key then
					mine[key] = oldLines[index]
				end
			end
		end
		if next(mine) ~= nil then
			for index = range[1], range[2] do
				local key = keyOf(newLines[index])
				local old = key and mine[key]
				if old then
					local merged = carry(newLines[index], old)
					if merged and merged ~= newLines[index] then
						newLines[index] = merged
						kept += 1
					end
				end
			end
		end
	end
	local text = table.concat(newLines, "\n")
	if string.sub(newSource, -1) ~= "\n" and string.sub(text, -1) == "\n" then
		text = string.sub(text, 1, -2)
	end
	return text, kept
end
Installer.KeepSettings = keepSettings

---------------------------------------------------------------------
-- Has he edited a script since the export this update was built from?
---------------------------------------------------------------------

-- A short fingerprint of a script's code. What is INSIDE a KEEP block does not count (his ids live there), nor do
-- spaces at the end of a line or empty lines at the end of the script. KEEP IN SYNC with fingerprint() in the
-- packing tool (pack_update.py): both must give the same answer for the same code.
local function fingerprint(source: string): string
	local lines = linesOf(source)
	local keeping = false
	local out: { string } = {}
	for _, line in lines do
		local text = (line:gsub("[ \t\r]+$", ""))
		if text:match("^%s*%-%-%[%[DMP:END%]%]") then
			keeping = false
		end
		if not keeping then
			table.insert(out, text)
		end
		if text:match("^%s*%-%-%[%[DMP:KEEP%s+[%w_]+%]%]") then
			keeping = true
		end
	end
	while #out > 0 and out[#out] == "" do
		table.remove(out)
	end
	local joined = table.concat(out, "\n")
	local a, b = 1, 0
	for index = 1, #joined do
		a = (a + string.byte(joined, index)) % 65521
		b = (b + a) % 65521
	end
	return string.format("%d:%d:%d", #joined, a, b)
end
Installer.Fingerprint = fingerprint

local function setSource(target: Instance, source: string): (boolean, string?)
	local ok, err = pcall(function()
		local editor = game:GetService("ScriptEditorService")
		editor:UpdateSourceAsync(target :: any, function()
			return source
		end)
	end)
	if ok and (target :: any).Source == source then
		return true, nil
	end
	local ok2, err2 = pcall(function()
		(target :: any).Source = source
	end)
	if ok2 then
		return true, nil
	end
	return false, tostring(err2 or err)
end

-- force = true installs even when you have edited scripts it replaces (running it a second time does the same)
function Installer.Install(package: Instance?, force: boolean?): { [string]: { string } }?
	local pkg = package or script.Parent
	if not pkg or pkg == game then
		warn("[DMP] _Install has to sit inside an update folder")
		return nil
	end
	if RunService:IsRunning() then
		warn("[DMP] Stop Play first: Studio throws away changes made while playing.")
		return nil
	end
	if pkg:GetAttribute("DMPInstalling") then
		warn("[DMP] " .. pkg.Name .. " is already being installed")
		return nil
	end
	pkg:SetAttribute("DMPInstalling", true)

	local report = { Updated = {}, Added = {}, Kept = {}, Same = {}, Removed = {}, Failed = {}, Settings = {}, Edited = {} }
	local backupRoot: Folder? = nil
	local function backups(): Folder
		if backupRoot and backupRoot.Parent then
			return backupRoot
		end
		local all = ServerStorage:FindFirstChild("DMP_Backups")
		if not all then
			all = Instance.new("Folder")
			all.Name = "DMP_Backups"
			all.Parent = ServerStorage
		end
		local mine = all:FindFirstChild(pkg.Name)
		if not mine then
			mine = Instance.new("Folder")
			mine.Name = pkg.Name
			mine.Parent = all
		end
		backupRoot = mine :: Folder
		return mine :: Folder
	end
	-- a copy of the old script (without its children) in the backups, named by where it lived
	local function backupSource(target: Instance)
		local ok, copy = pcall(function()
			return target:Clone()
		end)
		if ok and copy then
			copy:ClearAllChildren()
			copy.Name = target:GetFullName()
			copy.Parent = backups()
		end
	end
	-- moves something out of the game into the backups (it stops running there)
	local function retire(target: Instance)
		target.Name = target:GetFullName()
		target.Parent = backups()
	end

	local function findScriptBelow(container: Instance, name: string, className: string): Instance?
		for _, item in container:GetDescendants() do
			if item.Name == name and item.ClassName == className then
				return item
			end
		end
		return nil
	end

	local merge: (item: Instance, destination: Instance) -> ()
	merge = function(item: Instance, destination: Instance)
		local existing = destination:FindFirstChild(item.Name)
		if isScript(item) then
			local target = if existing and isScript(existing) then existing else nil
			if not target and not existing then
				target = findScriptBelow(destination, item.Name, item.ClassName)
			end
			if target and target.ClassName ~= item.ClassName then
				-- same name, different kind of script: the package's one takes its place, its children come along
				for _, child in target:GetChildren() do
					child.Parent = item
				end
				local where = target.Parent
				retire(target)
				item.Parent = where
				table.insert(report.Updated, item:GetFullName() .. "  (was a " .. target.ClassName .. ")")
				return
			end
			if target then
				local new, kept = keepSettings((target :: any).Source, (item :: any).Source)
				if kept > 0 then
					table.insert(report.Settings, target:GetFullName() .. "  (" .. kept .. " of your values)")
				end
				if (target :: any).Source ~= new then
					backupSource(target)
					local ok, err = setSource(target, new)
					if ok then
						table.insert(report.Updated, target:GetFullName())
					else
						table.insert(report.Failed, target:GetFullName() .. ": " .. tostring(err))
					end
				else
					table.insert(report.Same, target:GetFullName())
				end
				for _, child in item:GetChildren() do
					merge(child, target)
				end
				return
			end
			item.Parent = destination
			table.insert(report.Added, item:GetFullName())
			return
		end
		if existing then
			if item:GetAttribute("DMPReplace") and not item:IsA("Folder") then
				local where = existing.Parent
				retire(existing)
				item.Parent = where
				table.insert(report.Updated, item:GetFullName() .. "  (replaced; yours is in the backups)")
				return
			end
			local children = item:GetChildren()
			if #children == 0 then
				if not item:IsA("Folder") then
					table.insert(report.Kept, existing:GetFullName())
				end
				return
			end
			for _, child in children do
				merge(child, existing)
			end
			return
		end
		item.Parent = destination
		local scripts = 0
		for _, child in item:GetDescendants() do
			if isScript(child) then
				scripts += 1
			end
		end
		table.insert(report.Added, item:GetFullName() .. (if scripts > 0 and not isScript(item) then "  (" .. scripts .. " script" .. (if scripts == 1 then "" else "s") .. " inside)" else ""))
	end

	-- BEFORE anything is changed: has he edited a script this update replaces since the export it was built from?
	-- _Base: "# export: <when it was made>" and one line per script: path <tab> fingerprint[,fingerprint ...]
	-- (the export's copy first, then every version an earlier update shipped: all of those are "not his edit")
	local bases: { [string]: { [string]: boolean } } = {}
	local builtFrom = "your last export"
	local baseValue = pkg:FindFirstChild("_Base")
	if baseValue and baseValue:IsA("StringValue") then
		for line in string.gmatch(baseValue.Value, "[^\r\n]+") do
			local from = line:match("^#%s*export:%s*(.+)$")
			local path, prints = line:match("^([^\t]+)\t([%d:,]+)$")
			if from then
				builtFrom = "the export made " .. from
			elseif path and prints then
				local known: { [string]: boolean } = {}
				for print_ in string.gmatch(prints, "[^,]+") do
					known[print_] = true
				end
				bases[path] = known
			end
		end
	end
	local scan: (item: Instance, destination: Instance, path: string) -> ()
	scan = function(item: Instance, destination: Instance, path: string)
		local existing = destination:FindFirstChild(item.Name)
		if isScript(item) then
			local target = if existing and isScript(existing) then existing else nil
			if not target and not existing then
				target = findScriptBelow(destination, item.Name, item.ClassName)
			end
			if target and target.ClassName == item.ClassName then
				local known = bases[path]
				if known then
					local current = fingerprint((target :: any).Source)
					if not known[current] and current ~= fingerprint((item :: any).Source) then
						table.insert(report.Edited, target:GetFullName())
					end
				end
				for _, child in item:GetChildren() do
					scan(child, target, path .. "/" .. child.Name)
				end
			end
		elseif existing then
			for _, child in item:GetChildren() do
				scan(child, existing, path .. "/" .. child.Name)
			end
		end
	end
	if next(bases) ~= nil then
		pcall(function()
			for _, top in pkg:GetChildren() do
				if not RESERVED[top.Name] then
					local service = serviceFor(top.Name)
					if service then
						for _, item in top:GetChildren() do
							scan(item, service, top.Name .. "/" .. item.Name)
						end
					end
				end
			end
		end)
	end
	if #report.Edited > 0 and not force and not pkg:GetAttribute("DMPEditedShown") then
		warn("[DMP] " .. pkg.Name .. " was NOT installed. Nothing was changed.")
		warn("[DMP] You have edited " .. (if #report.Edited == 1 then "this script" else "these scripts") .. " since " .. builtFrom .. ", which is what this update was built from:")
		for _, name in report.Edited do
			warn("[DMP]     " .. name)
		end
		warn("[DMP] Installing would replace " .. (if #report.Edited == 1 then "it with a version" else "them with versions") .. " that do not have your edits.")
		warn("[DMP]   BEST: send a fresh export (drag DMP_ExportTool into Studio) so the update can be rebuilt on your scripts.")
		warn("[DMP]   OR install it anyway: click \"Install update\" on the Plugins tab (DMP Updates). Your versions are then kept in ServerStorage > DMP_Backups > " .. pkg.Name .. ".")
		pkg:SetAttribute("DMPEditedShown", true)
		pkg:SetAttribute("DMPInstalling", nil)
		return report
	end
	if #report.Edited > 0 then
		for _, name in report.Edited do
			print("[DMP] YOUR EDITED VERSION IS IN THE BACKUPS  " .. name)
		end
	end

	local recording: string? = nil
	pcall(function()
		recording = ChangeHistoryService:TryBeginRecording("Install " .. pkg.Name, "Install " .. pkg.Name)
	end)
	if not recording then
		pcall(function()
			ChangeHistoryService:SetWaypoint("Before " .. pkg.Name)
		end)
	end

	print("[DMP] Installing " .. pkg.Name .. " (installer v" .. Installer.Version .. ")...")
	local ok, err = pcall(function()
		local deletions = pkg:FindFirstChild("_Delete")
		if deletions and deletions:IsA("StringValue") then
			for line in string.gmatch(deletions.Value, "[^\r\n]+") do
				local trimmed = line:match("^%s*(.-)%s*$") or ""
				if trimmed ~= "" then
					local parts = string.split(trimmed, "/")
					local current: Instance? = serviceFor(parts[1])
					for index = 2, #parts do
						current = current and current:FindFirstChild(parts[index])
					end
					if current and current ~= game and #parts >= 2 then
						local name = current:GetFullName()
						retire(current)
						table.insert(report.Removed, name)
					end
				end
			end
		end
		for _, top in pkg:GetChildren() do
			if not RESERVED[top.Name] then
				local service = serviceFor(top.Name)
				if service then
					for _, item in top:GetChildren() do
						merge(item, service)
					end
				else
					table.insert(report.Failed, top.Name .. ": there is no service called that")
				end
			end
		end
	end)

	if recording then
		ChangeHistoryService:FinishRecording(recording, Enum.FinishRecordingOperation.Commit)
	else
		pcall(function()
			ChangeHistoryService:SetWaypoint("Installed " .. pkg.Name)
		end)
	end

	for _, line in report.Removed do
		print("[DMP] REMOVED  " .. line .. "  (moved to the backups)")
	end
	for _, line in report.Updated do
		print("[DMP] UPDATED  " .. line)
	end
	for _, line in report.Added do
		print("[DMP] ADDED    " .. line)
	end
	for _, line in report.Kept do
		print("[DMP] KEPT YOURS  " .. line)
	end
	for _, line in report.Settings do
		print("[DMP] KEPT YOUR SETTINGS  " .. line)
	end
	for _, line in report.Failed do
		warn("[DMP] FAILED   " .. line)
	end
	if not ok then
		warn("[DMP] The install stopped with an error: " .. tostring(err) .. "  (press Ctrl+Z to undo what it did)")
	end
	print(string.format("[DMP] Done: %d updated, %d added, %d unchanged, %d kept yours, %d removed, %d failed.%s",
		#report.Updated, #report.Added, #report.Same, #report.Kept, #report.Removed, #report.Failed,
		if backupRoot then " Your old code: ServerStorage > DMP_Backups > " .. pkg.Name .. "." else ""))
	local notes = pkg:FindFirstChild("_Notes")
	if notes and notes:IsA("StringValue") and notes.Value ~= "" then
		for line in string.gmatch(notes.Value, "[^\r\n]+") do
			print("[DMP] NOTE: " .. line)
		end
	end
	print("[DMP] Stop and start Play to load the new code.")

	if ok then
		pkg:Destroy()
	else
		pkg:SetAttribute("DMPInstalling", nil)
	end
	return report
end

return Installer
