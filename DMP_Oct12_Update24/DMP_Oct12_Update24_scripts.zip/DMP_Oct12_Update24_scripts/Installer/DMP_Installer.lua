-- DMP Installer: a Roblox Studio PLUGIN (set it up once, it works in every place you open).
-- SET UP (once): Studio > Plugins tab > Plugins Folder. Put this file (DMP_Installer.lua) in the folder that opens,
-- then close and reopen Studio. You get a "DMP Updates" toolbar on the Plugins tab with two buttons.
-- EVERY UPDATE: drag the update's .rbxmx (e.g. DMP_Oct8_Update3.rbxmx) into Studio. That's it: with "Auto install"
-- on (it is, at first) the update installs itself the moment it lands. With it off, click "Install update".
-- The first time it changes a script, Studio may ask whether this plugin may modify scripts: click Allow.
-- What the install does (and the backups it keeps) is written at the top of the update's own _Install module.
-- Everything it did is printed in Output; Ctrl+Z undoes it.

local RunService = game:GetService("RunService")
local ServerScriptService = game:GetService("ServerScriptService")
local ServerStorage = game:GetService("ServerStorage")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local SETTING = "DMPAutoInstall"

local toolbar = plugin:CreateToolbar("DMP Updates")
local installButton = toolbar:CreateButton("DMPInstall", "Install the DMP update you dragged into Studio", "", "Install update")
local autoButton = toolbar:CreateButton("DMPAuto", "Install DMP updates the moment you drag them in", "", "Auto install")
installButton.ClickableWhenViewportHidden = true
autoButton.ClickableWhenViewportHidden = true

local auto = plugin:GetSetting(SETTING)
if auto == nil then
	auto = true
end
autoButton:SetActive(auto == true)

local function isPackage(item: Instance): boolean
	if not item:IsA("Folder") or string.sub(item.Name, 1, 4) ~= "DMP_" then
		return false
	end
	local module = item:FindFirstChild("_Install")
	return module ~= nil and module:IsA("ModuleScript")
end

local WATCHED = { workspace, ServerStorage, ReplicatedStorage, ServerScriptService }

local function findPackages(): { Instance }
	local list = {}
	for _, container in WATCHED do
		for _, child in container:GetChildren() do
			if isPackage(child) then
				table.insert(list, child)
			end
		end
	end
	for _, selected in game:GetService("Selection"):Get() do
		if isPackage(selected) and not table.find(list, selected) then
			table.insert(list, selected)
		end
	end
	return list
end

local busy = false
local function install(package: Instance)
	if RunService:IsRunning() then
		warn("[DMP] Stop Play first, then click Install update.")
		return
	end
	if busy or package:GetAttribute("DMPInstalling") then
		return
	end
	busy = true
	local module = package:FindFirstChild("_Install")
	local ok, installer = pcall(require, module :: ModuleScript)
	if not ok or type(installer) ~= "table" or type(installer.Install) ~= "function" then
		warn("[DMP] " .. package.Name .. " has no working _Install: " .. tostring(installer))
	else
		local done, err = pcall(installer.Install, package)
		if not done then
			warn("[DMP] Installing " .. package.Name .. " failed: " .. tostring(err))
		end
	end
	busy = false
end

installButton.Click:Connect(function()
	installButton:SetActive(false)
	local packages = findPackages()
	if #packages == 0 then
		warn("[DMP] No update found. Drag the update's .rbxmx into Studio first (or select its DMP_ folder).")
		return
	end
	for _, package in packages do
		install(package)
	end
end)

autoButton.Click:Connect(function()
	auto = not auto
	plugin:SetSetting(SETTING, auto)
	autoButton:SetActive(auto)
	print("[DMP] Auto install is " .. (if auto then "ON: updates install when you drag them in." else "OFF: click Install update."))
end)

for _, container in WATCHED do
	container.ChildAdded:Connect(function(child: Instance)
		if not auto or RunService:IsRunning() then
			return
		end
		task.delay(0.5, function() -- (let the whole folder arrive first)
			if child.Parent and isPackage(child) then
				install(child)
			end
		end)
	end)
end
