-- LocalScript: StarterPlayer > StarterPlayerScripts > StatusEffectsClient
-- Client-side parts of feeds and haunts (blindness, shoves, jump cooldown, etc.)
-- Oct 10 2026 (update 9), at the bottom: STATUSES EVERYBODY CAN SEE. Whoever is bleeding, poisoned or burning shows
-- it on their character (drops of blood, green fumes, flames). The emitters are yours to restyle:
-- ReplicatedStorage > Assets > StatusEffects > Bleed / Poison / Fire.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local Debris = game:GetService("Debris")

local clientEffectRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("ClientEffect") :: RemoteEvent
local Toast = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Toast"))

local player = Players.LocalPlayer

local function getCharacterParts(): (Model?, Humanoid?, BasePart?)
	local character = player.Character
	if not character then
		return nil, nil, nil
	end
	return character, character:FindFirstChildOfClass("Humanoid"), character:FindFirstChild("HumanoidRootPart") :: BasePart?
end

local function notify(title: string, text: string)
	Toast.Show(title, text)
end

-- Blindness overlay
-- Remove any copy left over from an earlier run (e.g. if this script ran again after a respawn)
local playerGui = player:WaitForChild("PlayerGui")
for _, old in playerGui:GetChildren() do
	if old.Name == "StatusEffectsOverlay" then
		old:Destroy()
	end
end

local overlayGui = Instance.new("ScreenGui")
overlayGui.Name = "StatusEffectsOverlay"
overlayGui.IgnoreGuiInset = true
overlayGui.ResetOnSpawn = false
overlayGui.DisplayOrder = 100
overlayGui.Parent = player:WaitForChild("PlayerGui")

local blindFrame = Instance.new("Frame")
blindFrame.Size = UDim2.fromScale(1, 1)
blindFrame.BackgroundColor3 = Color3.new(0, 0, 0)
blindFrame.BackgroundTransparency = 1
blindFrame.BorderSizePixel = 0
blindFrame.Parent = overlayGui

local handlers = {}

function handlers.Blind(data)
	local duration = data.Duration or 2
	TweenService:Create(blindFrame, TweenInfo.new(0.2), { BackgroundTransparency = 0 }):Play()
	task.delay(duration, function()
		TweenService:Create(blindFrame, TweenInfo.new(0.6), { BackgroundTransparency = 1 }):Play()
	end)
end

function handlers.BatShove()
	local _, _, root = getCharacterParts()
	if not root then
		return
	end
	local angle = math.random() * math.pi * 2
	local direction = Vector3.new(math.cos(angle), 0, math.sin(angle))
	root.AssemblyLinearVelocity += direction * 45 + Vector3.new(0, 25, 0)

	-- Quick bat visual
	for _ = 1, 10 do
		local bat = Instance.new("Part")
		bat.Anchored = true
		bat.CanCollide = false
		bat.CanQuery = false
		bat.Size = Vector3.new(1.2, 0.2, 0.6)
		bat.Color = Color3.new(0.05, 0.05, 0.07)
		local start = root.Position - direction * 8 + Vector3.new(math.random(-3, 3), math.random(-1, 3), math.random(-3, 3))
		bat.CFrame = CFrame.lookAt(start, start + direction)
		bat.Parent = workspace
		TweenService:Create(bat, TweenInfo.new(0.6), { CFrame = bat.CFrame + direction * 20, Transparency = 1 }):Play()
		Debris:AddItem(bat, 0.7)
	end
end

function handlers.ShadowGrasp(data)
	local _, humanoid, root = getCharacterParts()
	if not root or not humanoid then
		return
	end
	local legLength = if humanoid.RigType == Enum.HumanoidRigType.R6 then 2 else humanoid.HipHeight
	local feetY = root.Position.Y - (legLength + root.Size.Y / 2)
	local ring = Instance.new("Part")
	ring.Shape = Enum.PartType.Cylinder
	ring.Anchored = true
	ring.CanCollide = false
	ring.CanQuery = false
	ring.Size = Vector3.new(0.3, 5, 5)
	ring.Color = Color3.new(0, 0, 0)
	ring.Material = Enum.Material.Neon
	ring.Transparency = 0.3
	ring.CFrame = CFrame.new(root.Position.X, feetY + 0.15, root.Position.Z) * CFrame.Angles(0, 0, math.rad(90))
	ring.Parent = workspace
	Debris:AddItem(ring, data.Duration or 1)
end

function handlers.SixthSense(data)
	local plate = data.Plate
	if not plate then
		return
	end
	local highlight = Instance.new("Highlight")
	highlight.FillColor = Color3.fromRGB(170, 120, 255)
	highlight.FillTransparency = 0.4
	highlight.OutlineColor = Color3.fromRGB(220, 200, 255)
	highlight.Adornee = plate
	highlight.Parent = workspace
	Debris:AddItem(highlight, 4)
	notify("Sixth Sense", (data.EventName or "Something") .. " is coming for the glowing plate.")
end

function handlers.Notify(data)
	Toast.Show(data.Title or "", data.Text or "", data.Color)
end

clientEffectRemote.OnClientEvent:Connect(function(name, data)
	local handler = handlers[name]
	if handler then
		handler(data or {})
	end
end)

-- Gargoyle's Weight: jump cooldown while the JumpCooldown attribute is set
local function onCharacterAdded(character: Model)
	local humanoid = character:WaitForChild("Humanoid") :: Humanoid
	humanoid.StateChanged:Connect(function(_, newState)
		if newState ~= Enum.HumanoidStateType.Jumping then
			return
		end
		local cooldown = player:GetAttribute("JumpCooldown")
		if not cooldown then
			return
		end
		humanoid:SetStateEnabled(Enum.HumanoidStateType.Jumping, false)
		task.delay(cooldown, function()
			if humanoid.Parent then
				humanoid:SetStateEnabled(Enum.HumanoidStateType.Jumping, true)
			end
		end)
	end)
end

player.CharacterAdded:Connect(onCharacterAdded)
if player.Character then
	task.spawn(onCharacterAdded, player.Character)
end

---------------------------------------------------------------------
-- Statuses everybody can see: bleeding, poisoned, burning (Oct 10 2026)
---------------------------------------------------------------------
-- Systems > Damage gives a player the attribute Status_Bleed / Status_Poison / Status_Fire (= the server time until
-- it shows) whenever they take damage of that type. While it runs, the Attachment of that name in ReplicatedStorage >
-- Assets > StatusEffects is copied onto their Torso and its emitters (and lights) are switched on. Everybody sees
-- it, on everybody. The player it is on also gets ONE soft flash of its colour when it starts (no text).

local STATUS_KINDS = { "Bleed", "Poison", "Fire" }
local STATUS_FLASH = { Bleed = Color3.fromRGB(150, 10, 14), Poison = Color3.fromRGB(70, 150, 50), Fire = Color3.fromRGB(230, 110, 30) }
local STATUS_FADE = 1.6 -- seconds the last particles get to die away before the copy is removed

type StatusShown = { Mark: Attachment, Ends: number }
local statusShown: { [Player]: { [string]: StatusShown } } = {}
local statusWarned = false

local function statusTemplate(kind: string): Attachment?
	local assets = ReplicatedStorage:FindFirstChild("Assets")
	local folder = assets and assets:FindFirstChild("StatusEffects")
	local template = folder and folder:FindFirstChild(kind)
	if template and template:IsA("Attachment") then
		return template
	end
	if not statusWarned then
		statusWarned = true
		warn("[StatusEffectsClient] ReplicatedStorage > Assets > StatusEffects > " .. kind .. " (an Attachment with emitters) was not found: bleeding / poison / fire will not show on characters. Install the update again.")
	end
	return nil
end

local function setStatusEmitters(mark: Instance, on: boolean)
	local particles = on and player:GetAttribute("Setting_DisableParticles") ~= true
	for _, item in mark:GetDescendants() do
		if item:IsA("ParticleEmitter") then
			item.Enabled = particles
		elseif item:IsA("Light") then
			item.Enabled = on
		end
	end
end

local function stopStatus(who: Player, kind: string)
	local mine = statusShown[who]
	local entry = mine and mine[kind]
	if not (mine and entry) then
		return
	end
	mine[kind] = nil
	setStatusEmitters(entry.Mark, false)
	Debris:AddItem(entry.Mark, STATUS_FADE)
end

local function refreshStatus(who: Player, kind: string)
	local ends = who:GetAttribute("Status_" .. kind)
	local now = workspace:GetServerTimeNow()
	if type(ends) ~= "number" or ends <= now then
		stopStatus(who, kind)
		return
	end
	local character = who.Character
	local torso = character and (character:FindFirstChild("Torso") or character:FindFirstChild("UpperTorso") or character:FindFirstChild("HumanoidRootPart"))
	if not (torso and torso:IsA("BasePart")) then
		stopStatus(who, kind)
		return
	end
	local mine = statusShown[who]
	if not mine then
		mine = {}
		statusShown[who] = mine
	end
	local entry = mine[kind]
	if entry and entry.Mark.Parent == torso then
		entry.Ends = ends -- (still on them: it just lasts longer)
		return
	end
	if entry then
		stopStatus(who, kind) -- (they respawned: the old copy went with the old character)
	end
	local template = statusTemplate(kind)
	if not template then
		return
	end
	local mark = template:Clone()
	mark.Name = "Status" .. kind
	mark.Parent = torso
	setStatusEmitters(mark, true)
	mine[kind] = { Mark = mark, Ends = ends }
	if who == player and player:GetAttribute("Setting_DisableFlashing") ~= true then
		-- one soft flash of its colour on your own screen: you know what you have got
		local flash = Instance.new("Frame")
		flash.Name = "StatusFlash"
		flash.Size = UDim2.fromScale(1, 1)
		flash.BackgroundColor3 = STATUS_FLASH[kind] or Color3.new(1, 1, 1)
		flash.BackgroundTransparency = 0.72
		flash.BorderSizePixel = 0
		flash.Parent = overlayGui
		TweenService:Create(flash, TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { BackgroundTransparency = 1 }):Play()
		Debris:AddItem(flash, 0.5)
	end
end

local function watchStatuses(who: Player)
	for _, kind in STATUS_KINDS do
		who:GetAttributeChangedSignal("Status_" .. kind):Connect(function()
			refreshStatus(who, kind)
		end)
		refreshStatus(who, kind)
	end
	who.CharacterAdded:Connect(function()
		task.defer(function()
			for _, kind in STATUS_KINDS do
				refreshStatus(who, kind)
			end
		end)
	end)
end

Players.PlayerAdded:Connect(watchStatuses)
Players.PlayerRemoving:Connect(function(who)
	statusShown[who] = nil
end)
for _, who in Players:GetPlayers() do
	task.spawn(watchStatuses, who)
end
-- statuses run out by the clock (nothing tells us): look twice a second
task.spawn(function()
	while true do
		task.wait(0.25)
		local now = workspace:GetServerTimeNow()
		for who, mine in statusShown do
			for kind, entry in mine do
				if now >= entry.Ends or entry.Mark.Parent == nil then
					stopStatus(who, kind)
				end
			end
		end
	end
end)
