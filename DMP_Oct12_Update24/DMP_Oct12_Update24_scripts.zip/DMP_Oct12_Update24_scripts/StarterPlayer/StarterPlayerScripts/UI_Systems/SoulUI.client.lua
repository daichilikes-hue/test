-- LocalScript: StarterPlayer > StarterPlayerScripts > SoulMenuClient
-- Replaces SoulCandleUI and FeedHauntClient (delete both).
--
--   * Soul moon + Candle counter + Game Tickets counter, bottom left
--   * Click the moon: Soul menu with your standing (white = Ghost, black = neutral, red = Vampire)
--   * Pick Haunt or Feed, then click a player in the world OR in the list on the right
--   * Whoever you're targeting glows white (Haunt) or red (Feed), even when hovering the list
--   * Uses your Vignette (StarterGui > Vignette > Vignette > ImageLabel) while choosing
--   * Click empty space (not a player, not the UI) to close it. Esc also cancels.

local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")

local GameConfig = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("GameConfig"))
local Toast = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Toast"))
local remotes = ReplicatedStorage:WaitForChild("Remotes")
local requestRemote = remotes:WaitForChild("FeedHauntRequest") :: RemoteEvent
local resultRemote = remotes:WaitForChild("FeedHauntResult") :: RemoteEvent
local exposedRemote = remotes:WaitForChild("Exposed") :: RemoteEvent

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

---------------------------------------------------------------------
-- Settings
---------------------------------------------------------------------

local FULL_MOON_AT = 100
local MOON_SIZE = 72
local PANEL_SIZE = Vector2.new(190, MOON_SIZE + 46) -- (one row taller since the Game Tickets row)
local MARGIN = 16

local WHITE = Color3.fromRGB(240, 238, 245)
local BLACK = Color3.fromRGB(8, 6, 10)
local RED = Color3.fromRGB(190, 20, 35)
local PANEL = Color3.fromRGB(14, 12, 20)
local STROKE = Color3.fromRGB(70, 58, 85)
local TEXT = Color3.fromRGB(230, 225, 240)
local MUTED = Color3.fromRGB(160, 150, 175)
local CANDLE_TEXT = Color3.fromRGB(255, 214, 140)
local TICKET_TEXT = Color3.fromRGB(255, 130, 200) -- (the Game Tickets pink of the end-of-round rewards)

local COLORS = {
	Vampire = { Lit = Color3.fromRGB(179, 32, 42), Dark = Color3.fromRGB(28, 18, 24), Text = Color3.fromRGB(230, 150, 155) },
	Ghost = { Lit = Color3.fromRGB(228, 234, 243), Dark = Color3.fromRGB(20, 25, 37), Text = Color3.fromRGB(200, 214, 234) },
	Neutral = { Lit = Color3.fromRGB(120, 120, 130), Dark = Color3.fromRGB(26, 26, 32), Text = Color3.fromRGB(170, 170, 180) },
}

local MODE_COLORS = { Haunt = WHITE, Feed = RED }

-- The dial's needle (ornate key). Put your image id here, e.g. "rbxassetid://123456".
-- Draw the key pointing straight UP, with the bow (handle) at the bottom.
-- Leave it "" to show a plain gold placeholder needle.
--[[DMP:KEEP Images]]
local KEY_IMAGE = ""
local TICKET_IMAGE = "" -- your uploaded Game Ticket icon (TicketIcon.png); "" = a little ticket drawn with frames
--[[DMP:END]]
local KEY_SIZE = Vector2.new(30, 96) -- width, length (the length should reach the arc)

---------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------

local function corner(parent: Instance, radius: UDim)
	local uiCorner = Instance.new("UICorner")
	uiCorner.CornerRadius = radius
	uiCorner.Parent = parent
end

local function stroke(parent: Instance, color: Color3, thickness: number?)
	local uiStroke = Instance.new("UIStroke")
	uiStroke.Color = color
	uiStroke.Thickness = thickness or 1
	uiStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	uiStroke.Parent = parent
	return uiStroke
end

local function label(parent: Instance, props: { [string]: any }): TextLabel
	local textLabel = Instance.new("TextLabel")
	textLabel.BackgroundTransparency = 1
	textLabel.Font = Enum.Font.Gotham
	textLabel.TextColor3 = TEXT
	textLabel.TextSize = 14
	for key, value in props do
		(textLabel :: any)[key] = value
	end
	textLabel.Parent = parent
	return textLabel
end

local function closeButton(parent: Instance, position: UDim2): TextButton
	local button = Instance.new("TextButton")
	button.Name = "Close"
	button.AnchorPoint = Vector2.new(1, 0)
	button.Position = position
	button.Size = UDim2.fromOffset(28, 28)
	button.BackgroundColor3 = Color3.fromRGB(60, 48, 75)
	button.Font = Enum.Font.GothamBold
	button.TextSize = 16
	button.TextColor3 = MUTED
	button.Text = "X"
	button.ZIndex = 5
	button.Parent = parent
	corner(button, UDim.new(0.5, 0))
	button.MouseEnter:Connect(function()
		button.TextColor3 = TEXT
	end)
	button.MouseLeave:Connect(function()
		button.TextColor3 = MUTED
	end)
	return button
end

local function notify(title: string, text: string, color: Color3?, options: { FadeTitle: boolean? }?)
	Toast.Show(title, text, color, options)
end

local function getSoul(target: Player?): number
	return (target or player):GetAttribute("Soul") or 0
end

local function getSide(soul: number): string
	if soul > 0 then
		return "Ghost"
	elseif soul < 0 then
		return "Vampire"
	end
	return "Neutral"
end

local function canAct(): (boolean, string?)
	if ReplicatedStorage:GetAttribute("GameState") ~= "InRound" then
		return false, "Only during a round"
	end
	if player:GetAttribute("Alive") ~= true then
		return false, "You must be alive"
	end
	if player:GetAttribute("ActionUsed") == true then
		return false, "Already used this match"
	end
	return true, nil
end

---------------------------------------------------------------------
-- Build: ScreenGui
---------------------------------------------------------------------

for _, name in { "SoulCandleUI", "SoulMenuUI" } do
	local old = playerGui:FindFirstChild(name)
	if old then
		old:Destroy()
	end
end

local gui = Instance.new("ScreenGui")
gui.Name = "SoulMenuUI"
gui.ResetOnSpawn = false
gui.DisplayOrder = 10
gui.Parent = playerGui

---------------------------------------------------------------------
-- Build: moon + candle panel (bottom left)
---------------------------------------------------------------------

local panel = Instance.new("Frame")
panel.Name = "Panel"
panel.AnchorPoint = Vector2.new(0, 1)
panel.Position = UDim2.new(0, MARGIN, 1, -MARGIN)
panel.Size = UDim2.fromOffset(PANEL_SIZE.X, PANEL_SIZE.Y)
panel.BackgroundColor3 = PANEL
panel.BackgroundTransparency = 0.25
panel.Parent = gui
corner(panel, UDim.new(0, 12))
stroke(panel, STROKE).Transparency = 0.4

-- The moon is a button
local moonButton = Instance.new("TextButton")
moonButton.Name = "MoonButton"
moonButton.Text = ""
moonButton.AutoButtonColor = false
moonButton.BackgroundTransparency = 1
moonButton.Position = UDim2.fromOffset(12, math.floor((PANEL_SIZE.Y - MOON_SIZE) / 2))
moonButton.Size = UDim2.fromOffset(MOON_SIZE, MOON_SIZE)
moonButton.Parent = panel

local moonScale = Instance.new("UIScale")
moonScale.Parent = moonButton

local moon = Instance.new("Frame")
moon.Name = "Moon"
moon.Size = UDim2.fromScale(1, 1)
moon.BorderSizePixel = 0
moon.Parent = moonButton
corner(moon, UDim.new(0.5, 0))

local glow = stroke(moon, WHITE, 3)
glow.Transparency = 1

local rows = {}
local radius = MOON_SIZE / 2
for index = 1, MOON_SIZE do
	local row = Instance.new("Frame")
	row.Name = "Row"
	row.BorderSizePixel = 0
	row.Size = UDim2.fromOffset(0, 1)
	row.Position = UDim2.fromOffset(0, index - 1)
	row.Parent = moon
	local y = (index - 0.5) - radius
	rows[index] = { Frame = row, HalfWidth = math.sqrt(math.max(0, radius * radius - y * y)) }
end

for _, crater in { { 0.3, 0.32, 0.2 }, { 0.62, 0.62, 0.14 }, { 0.64, 0.26, 0.09 } } do
	local dot = Instance.new("Frame")
	dot.Name = "Crater"
	dot.AnchorPoint = Vector2.new(0.5, 0.5)
	dot.Position = UDim2.fromScale(crater[1], crater[2])
	dot.Size = UDim2.fromScale(crater[3], crater[3])
	dot.BackgroundColor3 = Color3.new(0, 0, 0)
	dot.BackgroundTransparency = 0.85
	dot.BorderSizePixel = 0
	dot.ZIndex = 2
	dot.Parent = moon
	corner(dot, UDim.new(0.5, 0))
end

local flash = Instance.new("Frame")
flash.Name = "Flash"
flash.Size = UDim2.fromScale(1, 1)
flash.BackgroundColor3 = Color3.fromRGB(255, 30, 40)
flash.BackgroundTransparency = 1
flash.BorderSizePixel = 0
flash.ZIndex = 3
flash.Parent = moon
corner(flash, UDim.new(0.5, 0))

-- Little dot on the moon when your feed/haunt is ready to use
local readyDot = Instance.new("Frame")
readyDot.Name = "ReadyDot"
readyDot.AnchorPoint = Vector2.new(0.5, 0.5)
readyDot.Position = UDim2.fromScale(0.88, 0.12)
readyDot.Size = UDim2.fromOffset(12, 12)
readyDot.BackgroundColor3 = CANDLE_TEXT
readyDot.ZIndex = 4
readyDot.Visible = false
readyDot.Parent = moonButton
corner(readyDot, UDim.new(0.5, 0))
stroke(readyDot, BLACK, 2)

local textX = MOON_SIZE + 24
local sideLabel = label(panel, {
	Name = "Side",
	Position = UDim2.fromOffset(textX, 12),
	Size = UDim2.new(1, -textX - 10, 0, 18),
	Font = Enum.Font.Fantasy,
	TextSize = 16,
	TextXAlignment = Enum.TextXAlignment.Left,
})
local soulLabel = label(panel, {
	Name = "Soul",
	Position = UDim2.fromOffset(textX, 30),
	Size = UDim2.new(1, -textX - 10, 0, 22),
	Font = Enum.Font.GothamBold,
	TextSize = 18,
	TextXAlignment = Enum.TextXAlignment.Left,
})

local candleRow = Instance.new("Frame")
candleRow.Name = "Candles"
candleRow.BackgroundTransparency = 1
candleRow.Position = UDim2.fromOffset(textX, 56)
candleRow.Size = UDim2.new(1, -textX - 10, 0, 24)
candleRow.Parent = panel

local wax = Instance.new("Frame")
wax.Name = "Wax"
wax.BackgroundColor3 = Color3.fromRGB(236, 226, 204)
wax.BorderSizePixel = 0
wax.Position = UDim2.fromOffset(3, 9)
wax.Size = UDim2.fromOffset(8, 14)
wax.Parent = candleRow
corner(wax, UDim.new(0, 2))

local flame = Instance.new("Frame")
flame.Name = "Flame"
flame.BackgroundColor3 = Color3.fromRGB(255, 170, 60)
flame.BorderSizePixel = 0
flame.Position = UDim2.fromOffset(4, 1)
flame.Size = UDim2.fromOffset(6, 8)
flame.Parent = candleRow
corner(flame, UDim.new(0.5, 0))

local candleLabel = label(candleRow, {
	Name = "Count",
	Position = UDim2.fromOffset(20, 0),
	Size = UDim2.new(1, -20, 1, 0),
	Font = Enum.Font.GothamBold,
	TextSize = 18,
	TextColor3 = CANDLE_TEXT,
	TextXAlignment = Enum.TextXAlignment.Left,
})

-- Game Tickets (the arcade's money: the player attribute "Tickets", saved by DataManager)
local ticketRow = Instance.new("Frame")
ticketRow.Name = "Tickets"
ticketRow.BackgroundTransparency = 1
ticketRow.Position = UDim2.fromOffset(textX, 82)
ticketRow.Size = UDim2.new(1, -textX - 10, 0, 24)
ticketRow.Parent = panel

local ticketIcon: GuiObject
if TICKET_IMAGE ~= "" then
	local image = Instance.new("ImageLabel")
	image.Name = "Icon"
	image.BackgroundTransparency = 1
	image.Image = if tonumber(TICKET_IMAGE) then "rbxassetid://" .. TICKET_IMAGE else TICKET_IMAGE
	image.ScaleType = Enum.ScaleType.Fit
	image.Position = UDim2.fromOffset(-2, 2)
	image.Size = UDim2.fromOffset(20, 20)
	image.Parent = ticketRow
	ticketIcon = image
else
	-- a little ticket: pink, tilted, a dark notch on each end
	local ticket = Instance.new("Frame")
	ticket.Name = "Icon"
	ticket.AnchorPoint = Vector2.new(0.5, 0.5)
	ticket.Position = UDim2.fromOffset(8, 13)
	ticket.Size = UDim2.fromOffset(16, 11)
	ticket.Rotation = -14
	ticket.BackgroundColor3 = TICKET_TEXT
	ticket.BorderSizePixel = 0
	ticket.Parent = ticketRow
	corner(ticket, UDim.new(0, 2))
	for _, x in { 0, 1 } do
		local notch = Instance.new("Frame")
		notch.Name = "Notch"
		notch.AnchorPoint = Vector2.new(0.5, 0.5)
		notch.Position = UDim2.fromScale(x, 0.5)
		notch.Size = UDim2.fromOffset(5, 5)
		notch.BackgroundColor3 = PANEL
		notch.BorderSizePixel = 0
		notch.Parent = ticket
		corner(notch, UDim.new(0.5, 0))
	end
	local line = Instance.new("Frame")
	line.Name = "Line"
	line.AnchorPoint = Vector2.new(0.5, 0.5)
	line.Position = UDim2.fromScale(0.68, 0.5)
	line.Size = UDim2.new(0, 1, 1, -3)
	line.BackgroundColor3 = Color3.fromRGB(120, 30, 80)
	line.BorderSizePixel = 0
	line.Parent = ticket
	ticketIcon = ticket
end

local ticketLabel = label(ticketRow, {
	Name = "Count",
	Position = UDim2.fromOffset(20, 0),
	Size = UDim2.new(1, -20, 1, 0),
	Font = Enum.Font.GothamBold,
	TextSize = 18,
	TextColor3 = TICKET_TEXT,
	TextXAlignment = Enum.TextXAlignment.Left,
})

---------------------------------------------------------------------
-- Build: Soul menu (opens to the right of the moon panel)
---------------------------------------------------------------------

local MENU_SIZE = Vector2.new(340, 302)
local DIAL_CENTER = Vector2.new(MENU_SIZE.X / 2, 178)
local DIAL_RADIUS = 112
local DIAL_THICKNESS = 14
local DIAL_SEGMENTS = 56

local menu = Instance.new("Frame")
menu.Name = "SoulMenu"
menu.AnchorPoint = Vector2.new(0, 1)
menu.Position = UDim2.new(0, MARGIN + PANEL_SIZE.X + 10, 1, -MARGIN) -- right of the moon panel
menu.Size = UDim2.fromOffset(MENU_SIZE.X, MENU_SIZE.Y)
menu.BackgroundColor3 = PANEL
menu.BackgroundTransparency = 0.05
menu.Visible = false
menu.Parent = gui
corner(menu, UDim.new(0, 12))
stroke(menu, STROKE)

local menuScale = Instance.new("UIScale")
menuScale.Parent = menu

label(menu, {
	Name = "Title",
	Position = UDim2.fromOffset(16, 12),
	Size = UDim2.fromOffset(140, 26),
	Font = Enum.Font.Fantasy,
	TextSize = 24,
	TextXAlignment = Enum.TextXAlignment.Left,
	Text = "Your Soul",
})
local menuClose = closeButton(menu, UDim2.new(1, -10, 0, 10))

-- Half-moon dial: white (Ghost) on the left, black (neutral) at the top, red (Vampire) on the right.
-- Drawn as short rotated segments along the arc, so no images or clipping are needed.
local dial = Instance.new("Frame")
dial.Name = "Dial"
dial.BackgroundTransparency = 1
dial.Size = UDim2.fromScale(1, 1)
dial.Parent = menu

local function lerpColor(t: number): Color3
	if t < 0.5 then
		return WHITE:Lerp(BLACK, t * 2)
	end
	return BLACK:Lerp(RED, (t - 0.5) * 2)
end

local function drawArc(radius: number, thickness: number, colorAt: (number) -> Color3, zIndex: number)
	local segmentLength = math.pi * radius / DIAL_SEGMENTS + 1.5
	for index = 1, DIAL_SEGMENTS do
		local t = (index - 0.5) / DIAL_SEGMENTS
		local angle = math.pi * (1 - t) -- 180 degrees (left) to 0 (right), over the top
		local segment = Instance.new("Frame")
		segment.Name = "Arc"
		segment.AnchorPoint = Vector2.new(0.5, 0.5)
		segment.Position = UDim2.fromOffset(
			DIAL_CENTER.X + math.cos(angle) * radius,
			DIAL_CENTER.Y - math.sin(angle) * radius
		)
		segment.Size = UDim2.fromOffset(segmentLength, thickness)
		segment.Rotation = 90 - math.deg(angle)
		segment.BackgroundColor3 = colorAt(t)
		segment.BorderSizePixel = 0
		segment.ZIndex = zIndex
		segment.Parent = dial
	end
end

-- Rim behind the arc so the black middle still shows on the dark panel
drawArc(DIAL_RADIUS, DIAL_THICKNESS + 4, function()
	return Color3.fromRGB(95, 85, 110)
end, 1)
drawArc(DIAL_RADIUS, DIAL_THICKNESS, lerpColor, 2)

-- Tick marks all along the inside of the arc, with small gaps between them.
-- Long ticks at Ghost / Neutral / Vampire, medium every quarter, short everywhere else.
local TICK_COUNT = 60 -- one tick every 3 degrees
for index = 0, TICK_COUNT do
	local angle = math.pi * index / TICK_COUNT
	local length, tickColor
	if index % (TICK_COUNT / 2) == 0 then
		length, tickColor = 12, Color3.fromRGB(150, 138, 165)
	elseif index % (TICK_COUNT / 6) == 0 then
		length, tickColor = 8, Color3.fromRGB(125, 114, 140)
	else
		length, tickColor = 5, Color3.fromRGB(90, 80, 104)
	end

	local tickRadius = DIAL_RADIUS - DIAL_THICKNESS / 2 - 4 - length / 2
	local tick = Instance.new("Frame")
	tick.Name = "Tick"
	tick.AnchorPoint = Vector2.new(0.5, 0.5)
	tick.Position = UDim2.fromOffset(DIAL_CENTER.X + math.cos(angle) * tickRadius, DIAL_CENTER.Y - math.sin(angle) * tickRadius)
	tick.Size = UDim2.fromOffset(length, 2)
	tick.Rotation = -math.deg(angle)
	tick.BackgroundColor3 = tickColor
	tick.BorderSizePixel = 0
	tick.ZIndex = 2
	tick.Parent = dial
end

-- Your current side, over the top of the dial
local sideTitle = label(dial, {
	Name = "SideTitle",
	AnchorPoint = Vector2.new(0.5, 1),
	Position = UDim2.fromOffset(DIAL_CENTER.X, DIAL_CENTER.Y - DIAL_RADIUS - DIAL_THICKNESS / 2 - 4),
	Size = UDim2.fromOffset(120, 14),
	Font = Enum.Font.GothamBold,
	TextSize = 12,
	TextColor3 = MUTED,
	Text = "UNALIGNED",
})

-- The key (needle)
local key = Instance.new("ImageLabel")
key.Name = "Key"
key.AnchorPoint = Vector2.new(0.5, 0.5)
key.Size = UDim2.fromOffset(KEY_SIZE.X, KEY_SIZE.Y)
key.ZIndex = 4
key.Parent = dial
if KEY_IMAGE ~= "" then
	key.Image = KEY_IMAGE
	key.BackgroundTransparency = 1
	key.ScaleType = Enum.ScaleType.Fit
else
	-- Placeholder: a thin gold needle
	key.Size = UDim2.fromOffset(6, KEY_SIZE.Y)
	key.BackgroundColor3 = CANDLE_TEXT
	key.ImageTransparency = 1
	corner(key, UDim.new(0.5, 0))
end

-- Ornamental hub over the pivot
local hub = Instance.new("Frame")
hub.Name = "Hub"
hub.AnchorPoint = Vector2.new(0.5, 0.5)
hub.Position = UDim2.fromOffset(DIAL_CENTER.X, DIAL_CENTER.Y)
hub.Size = UDim2.fromOffset(18, 18)
hub.BackgroundColor3 = CANDLE_TEXT
hub.ZIndex = 5
hub.Parent = dial
corner(hub, UDim.new(0.5, 0))
stroke(hub, BLACK, 3)

-- Your Soul number, just under the pivot (out of the key's way)
local dialReadout = label(dial, {
	Name = "Readout",
	AnchorPoint = Vector2.new(0.5, 0),
	Position = UDim2.fromOffset(DIAL_CENTER.X, DIAL_CENTER.Y + 14),
	Size = UDim2.fromOffset(100, 20),
	Font = Enum.Font.GothamBold,
	TextSize = 16,
	ZIndex = 3,
})

-- Points the key at an angle (radians): 0 = straight up (neutral), negative = Ghost (left), positive = Vampire (right)
local keyAngle = Instance.new("NumberValue")
local function placeKey(angle: number)
	local length = KEY_SIZE.Y
	key.Rotation = math.deg(angle)
	key.Position = UDim2.fromOffset(
		DIAL_CENTER.X + math.sin(angle) * length / 2,
		DIAL_CENTER.Y - math.cos(angle) * length / 2
	)
end
keyAngle.Changed:Connect(placeKey)
placeKey(0)

-- Buttons under each end of the arc, with the side name and Soul change under each button
local BUTTON_WIDTH = 90
local BUTTON_HEIGHT = 30
local BUTTON_TOP = DIAL_CENTER.Y + 14

local function addSideName(sideName: string, sideColor: Color3, centerX: number)
	label(menu, {
		AnchorPoint = Vector2.new(0.5, 0),
		Position = UDim2.fromOffset(centerX, BUTTON_TOP + BUTTON_HEIGHT + 6),
		Size = UDim2.fromOffset(BUTTON_WIDTH + 30, 18),
		Font = Enum.Font.GothamBlack,
		TextSize = 16,
		TextColor3 = sideColor,
		TextStrokeColor3 = BLACK,
		TextStrokeTransparency = 0.2,
		Text = sideName,
	})
end

-- "+5 Soul" / "-10 Soul" under each side name
local function addCostLabel(centerX: number, color: Color3): TextLabel
	return label(menu, {
		AnchorPoint = Vector2.new(0.5, 0),
		Position = UDim2.fromOffset(centerX, BUTTON_TOP + BUTTON_HEIGHT + 26),
		Size = UDim2.fromOffset(BUTTON_WIDTH + 30, 16),
		Font = Enum.Font.GothamBold,
		TextSize = 13,
		TextColor3 = color,
	})
end

local function actionButton(name: string, centerX: number, background: Color3, textColor: Color3): TextButton
	local button = Instance.new("TextButton")
	button.Name = name
	button.AnchorPoint = Vector2.new(0.5, 0)
	button.Position = UDim2.fromOffset(centerX, BUTTON_TOP)
	button.Size = UDim2.fromOffset(BUTTON_WIDTH, BUTTON_HEIGHT)
	button.BackgroundColor3 = background
	button.AutoButtonColor = false
	button.Text = ""
	button.Parent = menu
	corner(button, UDim.new(0, 8))
	local buttonStroke = stroke(button, textColor, 2)
	buttonStroke.Transparency = 1

	label(button, {
		Size = UDim2.fromScale(1, 1),
		Font = Enum.Font.Fantasy,
		TextSize = 18,
		TextColor3 = textColor,
		Text = name,
	})

	button.MouseEnter:Connect(function()
		buttonStroke.Transparency = 0
	end)
	button.MouseLeave:Connect(function()
		buttonStroke.Transparency = 1
	end)
	return button
end

-- Under each end of the arc (kept inside the menu)
local leftX = math.max(DIAL_CENTER.X - DIAL_RADIUS, 16 + BUTTON_WIDTH / 2)
local rightX = math.min(DIAL_CENTER.X + DIAL_RADIUS, MENU_SIZE.X - 16 - BUTTON_WIDTH / 2)
local VAMPIRE_TEXT = Color3.fromRGB(235, 70, 80)
local hauntButton = actionButton("Haunt", leftX, WHITE, BLACK)
local feedButton = actionButton("Feed", rightX, Color3.fromRGB(120, 12, 24), WHITE)
addSideName("GHOST", WHITE, leftX)
addSideName("VAMPIRE", VAMPIRE_TEXT, rightX)
local hauntCost = addCostLabel(leftX, Color3.fromRGB(205, 210, 225))
local feedCost = addCostLabel(rightX, Color3.fromRGB(240, 120, 128))

local statusLabel = label(menu, {
	Name = "Status",
	AnchorPoint = Vector2.new(0.5, 1),
	Position = UDim2.new(0.5, 0, 1, -10),
	Size = UDim2.new(1, -32, 0, 24),
	TextSize = 13,
	TextColor3 = MUTED,
	TextWrapped = true,
})

---------------------------------------------------------------------
-- Build: target list (right side)
---------------------------------------------------------------------

local listPanel = Instance.new("Frame")
listPanel.Name = "TargetList"
listPanel.AnchorPoint = Vector2.new(1, 0.5)
listPanel.Position = UDim2.new(1, -20, 0.5, 0)
listPanel.Size = UDim2.fromOffset(280, 340)
listPanel.BackgroundColor3 = PANEL
listPanel.BackgroundTransparency = 0.05
listPanel.Visible = false
listPanel.Parent = gui
corner(listPanel, UDim.new(0, 12))
local listStroke = stroke(listPanel, STROKE, 2)

local listTitle = label(listPanel, {
	Position = UDim2.fromOffset(14, 12),
	Size = UDim2.new(1, -60, 0, 26),
	Font = Enum.Font.Fantasy,
	TextSize = 22,
	TextXAlignment = Enum.TextXAlignment.Left,
})
label(listPanel, {
	Position = UDim2.fromOffset(14, 38),
	Size = UDim2.new(1, -28, 0, 16),
	TextSize = 12,
	TextColor3 = MUTED,
	TextXAlignment = Enum.TextXAlignment.Left,
	Text = "Click someone here or in the world",
})
local listClose = closeButton(listPanel, UDim2.new(1, -10, 0, 10))

local list = Instance.new("ScrollingFrame")
list.BackgroundTransparency = 1
list.BorderSizePixel = 0
list.Position = UDim2.fromOffset(10, 64)
list.Size = UDim2.new(1, -20, 1, -74)
list.CanvasSize = UDim2.new()
list.AutomaticCanvasSize = Enum.AutomaticSize.Y
list.ScrollBarThickness = 4
list.Parent = listPanel

local listLayout = Instance.new("UIListLayout")
listLayout.Padding = UDim.new(0, 6)
listLayout.SortOrder = Enum.SortOrder.Name
listLayout.Parent = list

---------------------------------------------------------------------
-- Targeting
---------------------------------------------------------------------

local exitMode: () -> () -- defined below
local mode: string? = nil          -- "Haunt", "Feed", or nil
local listHovered: Player? = nil   -- hovered in the list
local worldHovered: Player? = nil  -- hovered in the world

local targetHighlight = Instance.new("Highlight")
targetHighlight.Name = "SoulTargetHighlight"
targetHighlight.FillTransparency = 0.45
targetHighlight.OutlineTransparency = 0
targetHighlight.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop

local raycastParams = RaycastParams.new()
raycastParams.FilterType = Enum.RaycastFilterType.Exclude

local function isTargetable(other: Player?): boolean
	return other ~= nil and other ~= player and other.Parent == Players and other:GetAttribute("Alive") == true
end

-- Which player is at this point on the screen
local function getPlayerAtRay(ray: Ray): Player?
	raycastParams.FilterDescendantsInstances = { player.Character }
	local result = workspace:Raycast(ray.Origin, ray.Direction * 1000, raycastParams)
	local model = result and result.Instance:FindFirstAncestorWhichIsA("Model")
	while model do
		local found = Players:GetPlayerFromCharacter(model)
		if found then
			return if isTargetable(found) then found else nil
		end
		model = model:FindFirstAncestorWhichIsA("Model")
	end
	return nil
end

local function getVignetteImage(): ImageLabel?
	local vignetteGui = playerGui:FindFirstChild("Vignette")
	local frame = vignetteGui and vignetteGui:FindFirstChild("Vignette")
	local image = frame and frame:FindFirstChildWhichIsA("ImageLabel")
	if vignetteGui and vignetteGui:IsA("ScreenGui") then
		vignetteGui.Enabled = true
	end
	if frame and frame:IsA("GuiObject") then
		frame.Visible = true
	end
	return image
end

local function setVignette(color: Color3?)
	local image = getVignetteImage()
	if not image then
		return
	end
	if color then
		image.ImageColor3 = color
		TweenService:Create(image, TweenInfo.new(0.35), { ImageTransparency = 0.25 }):Play()
	else
		TweenService:Create(image, TweenInfo.new(0.35), { ImageTransparency = 1 }):Play()
	end
end

-- Round headshots, cached per player
local thumbnails: { [number]: string } = {}
local function setThumbnail(image: ImageLabel, userId: number)
	if thumbnails[userId] then
		image.Image = thumbnails[userId]
		return
	end
	task.spawn(function()
		local ok, content = pcall(
			Players.GetUserThumbnailAsync,
			Players,
			math.max(userId, 1), -- Studio test players have negative ids
			Enum.ThumbnailType.HeadShot,
			Enum.ThumbnailSize.Size100x100
		)
		if ok and content then
			thumbnails[userId] = content
			if image.Parent then
				image.Image = content
			end
		end
	end)
end

local function rebuildList()
	for _, child in list:GetChildren() do
		if child:IsA("GuiObject") then
			child:Destroy()
		end
	end
	if not mode then
		return
	end

	local accent = MODE_COLORS[mode]
	for _, other in Players:GetPlayers() do
		if isTargetable(other) then
			local row = Instance.new("TextButton")
			row.Name = other.DisplayName
			row.Size = UDim2.new(1, -6, 0, 48)
			row.BackgroundColor3 = Color3.fromRGB(32, 26, 38)
			row.AutoButtonColor = false
			row.Text = ""
			row.Parent = list
			corner(row, UDim.new(0, 8))
			local rowStroke = stroke(row, accent, 2)
			rowStroke.Transparency = 1

			-- Circle avatar
			local avatar = Instance.new("ImageLabel")
			avatar.Name = "Avatar"
			avatar.AnchorPoint = Vector2.new(0, 0.5)
			avatar.Position = UDim2.new(0, 6, 0.5, 0)
			avatar.Size = UDim2.fromOffset(38, 38)
			avatar.BackgroundColor3 = Color3.fromRGB(50, 42, 60)
			avatar.ScaleType = Enum.ScaleType.Crop
			avatar.Parent = row
			corner(avatar, UDim.new(0.5, 0))
			stroke(avatar, accent, 2)
			setThumbnail(avatar, other.UserId)

			label(row, {
				Position = UDim2.fromOffset(52, 8),
				Size = UDim2.new(1, -60, 0, 18),
				Font = Enum.Font.GothamBold,
				TextSize = 15,
				TextXAlignment = Enum.TextXAlignment.Left,
				TextTruncate = Enum.TextTruncate.AtEnd,
				Text = other.DisplayName,
			})
			label(row, {
				Position = UDim2.fromOffset(52, 26),
				Size = UDim2.new(1, -60, 0, 14),
				TextSize = 11,
				TextColor3 = MUTED,
				TextXAlignment = Enum.TextXAlignment.Left,
				TextTruncate = Enum.TextTruncate.AtEnd,
				Text = "@" .. other.Name,
			})

			row.MouseEnter:Connect(function()
				listHovered = other
				rowStroke.Transparency = 0
			end)
			row.MouseLeave:Connect(function()
				if listHovered == other then
					listHovered = nil
				end
				rowStroke.Transparency = 1
			end)
			row.Activated:Connect(function()
				if mode and isTargetable(other) then
					requestRemote:FireServer(mode, other)
					exitMode()
				end
			end)
		end
	end
end

exitMode = function()
	mode = nil
	listHovered = nil
	worldHovered = nil
	listPanel.Visible = false
	targetHighlight.Adornee = nil
	targetHighlight.Parent = nil
	setVignette(nil)
	rebuildList()
end

local function enterMode(newMode: string)
	local ok, reason = canAct()
	if not ok then
		statusLabel.Text = reason or ""
		menu.Visible = true
		return
	end
	mode = newMode
	menu.Visible = false

	local accent = MODE_COLORS[newMode]
	listTitle.Text = if newMode == "Haunt" then "Who will you Haunt?" else "Who will you Feed on?"
	listTitle.TextColor3 = if newMode == "Haunt" then WHITE else Color3.fromRGB(235, 70, 80)
	listStroke.Color = accent
	targetHighlight.FillColor = accent
	targetHighlight.OutlineColor = accent
	listPanel.Visible = true
	setVignette(accent)
	rebuildList()
end

---------------------------------------------------------------------
-- Menu
---------------------------------------------------------------------

local function soulChangeText(action: string): string
	local soul = getSoul()
	local change
	if action == "Feed" then
		change = if soul > 0 then -GameConfig.Soul.OppositeCost else -GameConfig.Soul.PerAction
	else
		change = if soul < 0 then GameConfig.Soul.OppositeCost else GameConfig.Soul.PerAction
	end
	return (if change > 0 then "+" else "") .. change
end

local function updateMenu()
	local soul = getSoul()
	local side = getSide(soul)
	local lean = math.clamp(soul / FULL_MOON_AT, -1, 1) -- +1 = full Ghost, -1 = full Vampire
	TweenService:Create(keyAngle, TweenInfo.new(0.6, Enum.EasingStyle.Back), { Value = -lean * math.pi / 2 }):Play()

	local colors = COLORS[side]
	dialReadout.Text = ("%d Soul"):format(math.abs(soul))
	dialReadout.TextColor3 = colors.Text
	sideTitle.Text = if side == "Neutral" then "UNALIGNED" else side:upper()
	sideTitle.TextColor3 = if side == "Neutral" then MUTED else colors.Text

	local ok, reason = canAct()
	hauntButton.BackgroundTransparency = if ok then 0 else 0.6
	feedButton.BackgroundTransparency = if ok then 0 else 0.6
	hauntCost.Text = soulChangeText("Haunt") .. " Soul"
	feedCost.Text = soulChangeText("Feed") .. " Soul"
	statusLabel.Text = if ok then "Pick one, then choose a player" else (reason or "")
end

local function toggleMenu()
	if mode then
		exitMode()
		return
	end
	menu.Visible = not menu.Visible
	if menu.Visible then
		updateMenu()
		menuScale.Scale = 0.9
		TweenService:Create(menuScale, TweenInfo.new(0.2, Enum.EasingStyle.Back), { Scale = 1 }):Play()
	end
end

moonButton.Activated:Connect(toggleMenu)
moonButton.MouseEnter:Connect(function()
	TweenService:Create(moonScale, TweenInfo.new(0.15), { Scale = 1.06 }):Play()
end)
moonButton.MouseLeave:Connect(function()
	TweenService:Create(moonScale, TweenInfo.new(0.15), { Scale = 1 }):Play()
end)
menuClose.Activated:Connect(function()
	menu.Visible = false
end)
listClose.Activated:Connect(exitMode)
hauntButton.Activated:Connect(function()
	enterMode("Haunt")
end)
feedButton.Activated:Connect(function()
	enterMode("Feed")
end)

---------------------------------------------------------------------
-- Input
---------------------------------------------------------------------

-- Is a screen point (GUI coordinates) over one of our panels?
local function isOverOurUI(point: Vector2): boolean
	for _, frame in { panel, menu, listPanel } do
		if frame.Visible then
			local topLeft, size = frame.AbsolutePosition, frame.AbsoluteSize
			if point.X >= topLeft.X and point.X <= topLeft.X + size.X and point.Y >= topLeft.Y and point.Y <= topLeft.Y + size.Y then
				return true
			end
		end
	end
	return false
end

UserInputService.InputBegan:Connect(function(input, gameProcessed)
	if mode and input.KeyCode == Enum.KeyCode.Escape then
		exitMode()
		return
	end

	local isClick = input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch
	if isClick then
		-- Where the click landed, in GUI coordinates and as a ray into the world
		local camera = workspace.CurrentCamera
		local guiPoint: Vector2
		local ray: Ray
		if input.UserInputType == Enum.UserInputType.Touch then
			guiPoint = Vector2.new(input.Position.X, input.Position.Y)
			ray = camera:ScreenPointToRay(guiPoint.X, guiPoint.Y)
		else
			local mouse = UserInputService:GetMouseLocation()
			guiPoint = mouse - GuiService:GetGuiInset()
			ray = camera:ViewportPointToRay(mouse.X, mouse.Y)
		end

		if gameProcessed or isOverOurUI(guiPoint) then
			return -- the UI's own buttons handle it
		end

		if mode then
			local target = getPlayerAtRay(ray)
			if target then
				requestRemote:FireServer(mode, target)
			end
			-- Clicked a player: used. Clicked nothing: cancelled. Either way, close.
			exitMode()
		elseif menu.Visible then
			menu.Visible = false
		end
		return
	end

end)

RunService.RenderStepped:Connect(function()
	-- Ready dot on the moon
	local ok = canAct()
	readyDot.Visible = ok and mode == nil

	if not mode then
		return
	end
	if not ok then
		exitMode()
		return
	end

	-- Hovered player in the world
	local mouseLocation = UserInputService:GetMouseLocation()
	worldHovered = getPlayerAtRay(workspace.CurrentCamera:ViewportPointToRay(mouseLocation.X, mouseLocation.Y))

	-- The list takes priority, so hovering a name lights up that player
	local target = if isTargetable(listHovered) then listHovered else worldHovered
	local character = target and target.Character
	targetHighlight.Adornee = character
	targetHighlight.Parent = if character then workspace else nil
end)

-- Keep the list current as players die, join, or leave
local function watchPlayer(other: Player)
	other:GetAttributeChangedSignal("Alive"):Connect(function()
		if mode then
			rebuildList()
		end
	end)
end
Players.PlayerAdded:Connect(watchPlayer)
Players.PlayerRemoving:Connect(function()
	if mode then
		task.defer(rebuildList)
	end
end)
for _, other in Players:GetPlayers() do
	watchPlayer(other)
end

---------------------------------------------------------------------
-- Moon + candles
---------------------------------------------------------------------

local fillValue = Instance.new("NumberValue")
local currentFromRight = true
local currentLit = COLORS.Neutral.Lit

local function drawMoon(fill: number)
	for _, row in rows do
		local halfWidth = row.HalfWidth
		local terminator = (1 - 2 * fill) * halfWidth
		local width = halfWidth - terminator
		local frame = row.Frame
		frame.BackgroundColor3 = currentLit
		frame.Visible = width > 0.05
		frame.Size = UDim2.fromOffset(width, 1)
		local left = if currentFromRight then radius + terminator else radius - halfWidth
		frame.Position = UDim2.fromOffset(left, frame.Position.Y.Offset)
	end
end
fillValue.Changed:Connect(drawMoon)

local function popUp(text: string, color: Color3, anchor: GuiObject)
	local popLabel = label(panel, {
		Position = UDim2.fromOffset(
			anchor.AbsolutePosition.X - panel.AbsolutePosition.X + 60,
			anchor.AbsolutePosition.Y - panel.AbsolutePosition.Y
		),
		Size = UDim2.fromOffset(80, 22),
		Font = Enum.Font.GothamBold,
		TextSize = 16,
		TextColor3 = color,
		TextStrokeTransparency = 0.5,
		TextXAlignment = Enum.TextXAlignment.Left,
		Text = text,
	})
	TweenService:Create(popLabel, TweenInfo.new(1, Enum.EasingStyle.Quad), {
		Position = popLabel.Position - UDim2.fromOffset(0, 20),
		TextTransparency = 1,
		TextStrokeTransparency = 1,
	}):Play()
	task.delay(1, function()
		popLabel:Destroy()
	end)
end

local lastSoul: number? = nil
local function updateSoul(animate: boolean)
	local soul = getSoul()
	local side = getSide(soul)
	local colors = COLORS[side]
	local fill = math.clamp(math.abs(soul) / FULL_MOON_AT, 0, 1)
	local isFull = fill >= 1

	moon.BackgroundColor3 = colors.Dark
	glow.Color = colors.Lit
	currentFromRight = side ~= "Ghost"
	currentLit = colors.Lit

	if animate then
		drawMoon(fillValue.Value)
		TweenService:Create(fillValue, TweenInfo.new(0.5, Enum.EasingStyle.Quad), { Value = fill }):Play()
		TweenService:Create(glow, TweenInfo.new(0.5), { Transparency = if isFull then 0.2 else 1 }):Play()
	else
		fillValue.Value = fill
		drawMoon(fill)
		glow.Transparency = if isFull then 0.2 else 1
	end

	sideLabel.Text = if side == "Neutral" then "Unaligned" else side
	sideLabel.TextColor3 = colors.Text
	soulLabel.Text = ("%d Soul"):format(math.abs(soul))
	soulLabel.TextColor3 = colors.Text

	if animate and lastSoul and soul ~= lastSoul then
		moonScale.Scale = if math.abs(soul) > math.abs(lastSoul) then 1.15 else 0.9
		TweenService:Create(moonScale, TweenInfo.new(0.35, Enum.EasingStyle.Back), { Scale = 1 }):Play()
		local change = soul - lastSoul
		popUp((if change > 0 then "+" else "") .. change, colors.Text, soulLabel)
	end
	lastSoul = soul

	if menu.Visible then
		updateMenu()
	end
end

local lastCandles: number? = nil
local function updateCandles(animate: boolean)
	local candles = player:GetAttribute("Candles") or 0
	candleLabel.Text = tostring(candles)
	if animate and lastCandles and candles ~= lastCandles then
		local change = candles - lastCandles
		popUp((if change > 0 then "+" else "") .. change, CANDLE_TEXT, candleRow)
		flame.Size = UDim2.fromOffset(8, 11)
		TweenService:Create(flame, TweenInfo.new(0.4, Enum.EasingStyle.Back), { Size = UDim2.fromOffset(6, 8) }):Play()
	end
	lastCandles = candles
end

local lastTickets: number? = nil
local function updateTickets(animate: boolean)
	local tickets = player:GetAttribute("Tickets")
	tickets = if type(tickets) == "number" then tickets else 0
	ticketLabel.Text = tostring(tickets)
	if animate and lastTickets and tickets ~= lastTickets then
		local change = tickets - lastTickets
		popUp((if change > 0 then "+" else "") .. change, TICKET_TEXT, ticketRow)
		local home = ticketIcon.Size
		ticketIcon.Size = UDim2.fromOffset(home.X.Offset * 1.35, home.Y.Offset * 1.35)
		TweenService:Create(ticketIcon, TweenInfo.new(0.4, Enum.EasingStyle.Back), { Size = home }):Play()
	end
	lastTickets = tickets
end

player:GetAttributeChangedSignal("Soul"):Connect(function()
	updateSoul(true)
end)
player:GetAttributeChangedSignal("Tickets"):Connect(function()
	updateTickets(true)
end)
player:GetAttributeChangedSignal("Candles"):Connect(function()
	updateCandles(true)
end)
for _, attribute in { "ActionUsed", "Alive" } do
	player:GetAttributeChangedSignal(attribute):Connect(function()
		if menu.Visible then
			updateMenu()
		end
	end)
end
ReplicatedStorage:GetAttributeChangedSignal("GameState"):Connect(function()
	if menu.Visible then
		updateMenu()
	end
end)

-- Exposed: flash and shake the moon
player:GetAttributeChangedSignal("Exposed"):Connect(function()
	if player:GetAttribute("Exposed") ~= true then
		return
	end
	flash.BackgroundTransparency = 0.2
	TweenService:Create(flash, TweenInfo.new(1.2), { BackgroundTransparency = 1 }):Play()
	local home = moonButton.Position
	for _ = 1, 6 do
		moonButton.Position = home + UDim2.fromOffset(math.random(-4, 4), math.random(-4, 4))
		task.wait(0.04)
	end
	moonButton.Position = home
end)

-- Candle flicker
task.spawn(function()
	while gui.Parent do
		flame.BackgroundColor3 = Color3.fromRGB(255, math.random(150, 190), math.random(40, 80))
		task.wait(0.12 + math.random() * 0.15)
	end
end)

---------------------------------------------------------------------
-- Results (from FeedHauntClient)
---------------------------------------------------------------------

resultRemote.OnClientEvent:Connect(function(kind, action, effectName, description, targetName)
	local verb = if action == "Feed" then "fed on" else "haunted"
	local color = if action == "Feed" then Color3.fromRGB(235, 70, 80) else WHITE
	if kind == "Used" then
		notify(("You %s %s"):format(verb, targetName), ("%s: %s"):format(effectName, description), color, { FadeTitle = true })
	elseif kind == "Received" then
		notify(("You were %s"):format(verb), ("%s: %s"):format(effectName, description), color, { FadeTitle = true })
	elseif kind == "Failed" then
		notify("Can't do that", tostring(effectName), MUTED) -- effectName holds the reason here
	end
end)

-- Placeholder: swap for your aura + bats reveal
exposedRemote.OnClientEvent:Connect(function(exposedPlayer: Player)
	notify("EXPOSED", exposedPlayer.DisplayName .. " was caught feeding on a powerful Ghost!", Color3.fromRGB(255, 60, 60))
end)

updateSoul(false)
updateCandles(false)
updateTickets(false)
setVignette(nil)