-- LocalScript inside the "Cloud in a Bottle" tool. (Oct 11 Update 20, new item.)
-- Click while you are in the air: you jump again at once, here on your own screen (so it feels instant), and the
-- server is told, which counts the charge, plays the "fwup" and puts the puff of cloud under your feet.
-- It does nothing on the ground, with no charges left, within 1.5 s of the last one, or while something has taken
-- your jump away (a "no jumping" trick: the cloud does not get round that).

local Players = game:GetService("Players")

local tool = script.Parent
local remote = tool:WaitForChild("ItemRemote") :: RemoteEvent
local player = Players.LocalPlayer

local COOLDOWN = 1.5

-- how fast a jump of yours goes up right now (your Humanoid's own jump, so speed / jump changes count)
local function jumpSpeed(humanoid: Humanoid): number
	if humanoid.UseJumpPower then
		return humanoid.JumpPower
	end
	return math.sqrt(2 * workspace.Gravity * math.max(humanoid.JumpHeight, 0))
end

local last = -math.huge
tool.Activated:Connect(function()
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local root = character and character:FindFirstChild("HumanoidRootPart") :: BasePart?
	if not humanoid or not root or humanoid.Health <= 0 then
		return
	end
	if (tool:GetAttribute("Charges") or 0) <= 0 or os.clock() - last < COOLDOWN then
		return
	end
	if humanoid.FloorMaterial ~= Enum.Material.Air then
		return -- (only in the air)
	end
	local speed = jumpSpeed(humanoid)
	if speed <= 0.5 then
		return -- (your jump has been taken away: no cloud gets round that)
	end
	last = os.clock()
	local velocity = root.AssemblyLinearVelocity
	root.AssemblyLinearVelocity = Vector3.new(velocity.X, speed, velocity.Z)
	humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
	remote:FireServer("Puff")
end)
