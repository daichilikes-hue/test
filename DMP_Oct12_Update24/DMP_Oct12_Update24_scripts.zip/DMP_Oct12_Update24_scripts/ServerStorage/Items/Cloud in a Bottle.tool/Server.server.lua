-- Script inside the "Cloud in a Bottle" tool. Self-contained: drop the tool into a Backpack and it works.
-- (Oct 11 Update 20, new item.) Click while you are in the AIR to pop the cork: a little cloud puffs out under your
-- feet and you get one extra jump. 3 charges, 1.5 s between them, only in the air; the charges never come back, and
-- when they are used up the bottle is gone. The jump itself happens on YOUR screen (the LocalScript Client, so it is
-- instant); this script keeps the charges, plays the "fwup" and puts the puff of cloud where everybody sees it.

local Debris = game:GetService("Debris")
local Players = game:GetService("Players")
local TweenService = game:GetService("TweenService")

local tool = script.Parent

local CHARGES = 3
local COOLDOWN = 1.5
local PUFF_TIME = 0.8      -- seconds the puff of cloud swells and fades under your feet

-- The player holding or carrying this tool
local function getOwner(): Player?
	local parent = tool.Parent
	if parent and parent:IsA("Backpack") then
		return parent.Parent :: Player
	end
	return Players:GetPlayerFromCharacter(parent)
end

-- Returns character, humanoid, root if the player is alive
local function getAlive(player: Player?): (Model?, Humanoid?, BasePart?)
	local character = player and player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	local root = character and character:FindFirstChild("HumanoidRootPart") :: BasePart?
	if character and humanoid and root and humanoid.Health > 0 then
		return character, humanoid, root
	end
	return nil, nil, nil
end

-- This tool's own RemoteEvent (created here, so nothing needs to be set up elsewhere)
local remote = tool:FindFirstChild("ItemRemote") :: RemoteEvent?
if not remote then
	local newRemote = Instance.new("RemoteEvent")
	newRemote.Name = "ItemRemote"
	newRemote.Parent = tool
	remote = newRemote
end

if tool:GetAttribute("Charges") == nil then
	tool:SetAttribute("Charges", CHARGES)
end
tool.ToolTip = ("Click in mid-air to pop the cork: a little cloud gives you one extra jump. %d charges."):format(tool:GetAttribute("Charges"))

-- the cloud inside the bottle shrinks with every charge used
local handle = tool:FindFirstChild("Handle")
local inside: { [BasePart]: Vector3 } = {}
for _, name in { "Cloud1", "Cloud2", "Cloud3" } do
	local part = handle and handle:FindFirstChild(name)
	if part and part:IsA("BasePart") then
		inside[part] = part.Size
	end
end
local function showCharges(charges: number)
	local left = math.clamp(charges / CHARGES, 0, 1)
	for part, size in inside do
		part.Size = size * (0.25 + 0.75 * left)
		part.Transparency = if charges <= 0 then 1 else 0.15
	end
end
showCharges(tool:GetAttribute("Charges"))

-- the puff of cloud under the feet (a copy of the model Puff in the bottle; five plain balls if it is missing)
local function puffAt(feet: Vector3)
	local template = handle and handle:FindFirstChild("Puff")
	local puff: Instance
	if template then
		puff = template:Clone()
	else
		puff = Instance.new("Model")
		for index = 1, 5 do
			local ball = Instance.new("Part")
			ball.Shape = Enum.PartType.Ball
			ball.Size = Vector3.one * (if index == 1 then 2.2 else 1.6)
			ball.Color = Color3.fromRGB(226, 228, 232)
			ball.Material = Enum.Material.SmoothPlastic
			ball.Parent = puff
		end
	end
	local centre: Vector3? = nil
	local parts: { BasePart } = {}
	for _, item in puff:GetDescendants() do
		if item:IsA("JointInstance") or item:IsA("WeldConstraint") then
			item:Destroy()
		elseif item:IsA("BasePart") then
			table.insert(parts, item)
		end
	end
	for index, part in parts do
		centre = centre or part.Position
		-- (where each ball sits in the cloud, as it was made: the bottle is tilted in your hand, the cloud is not)
		local offset = if template and handle then handle.CFrame:VectorToObjectSpace(part.Position - (centre :: Vector3)) else Vector3.new(math.cos(index * 1.3) * 1.1, 0, math.sin(index * 1.3) * 1.1)
		part.Anchored = true
		part.CanCollide = false
		part.CanQuery = false
		part.CanTouch = false
		part.CastShadow = false
		part.Massless = true
		part.Transparency = 0.3
		local size = part.Size
		part.Size = size * 0.4
		part.CFrame = CFrame.new(feet + offset * 0.5)
		TweenService:Create(part, TweenInfo.new(PUFF_TIME, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			Size = size * 1.15, Transparency = 1, CFrame = CFrame.new(feet + offset * 1.2 + Vector3.new(0, -0.8, 0)),
		}):Play()
	end
	puff.Name = "CloudPuff"
	puff.Parent = workspace
	Debris:AddItem(puff, PUFF_TIME + 0.2)
end

local lastPuff = -math.huge
remote.OnServerEvent:Connect(function(player, request)
	if request ~= "Puff" or player ~= getOwner() or tool.Parent ~= player.Character then
		return
	end
	local _, _, root = getAlive(player)
	if not root then
		return
	end
	local charges = tool:GetAttribute("Charges") or 0
	local now = os.clock()
	if charges <= 0 or now - lastPuff < COOLDOWN - 0.25 then -- (a little slack: the click left your screen a moment ago)
		return
	end
	lastPuff = now
	charges -= 1
	tool:SetAttribute("Charges", charges)
	showCharges(charges)
	local fwup = handle and handle:FindFirstChild("Fwup")
	if fwup and fwup:IsA("Sound") then
		fwup:Play()
	end
	puffAt(root.Position - Vector3.new(0, 3.2, 0))
	if charges <= 0 then
		-- (the last of the cloud: the bottle is gone)
		tool.Enabled = false
		task.delay(0.5, function()
			tool:Destroy()
		end)
	end
end)
