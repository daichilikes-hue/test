These are the scripts of Update 24 as plain files, for reading.
TO INSTALL THE UPDATE, DRAG DMP_Oct12_Update24.rbxmx INTO STUDIO (the solid Bearer model is only in the .rbxmx).
Updates are cumulative: Updates 8 to 23 are in it too, except StarterPlayerScripts > TarotClient (yours, left as it is).
Changed in Update 24: ReplicatedStorage/EventClients/procession, baker, guardian, ward, and the model Bearer.
