-- ModuleScript: ReplicatedStorage > EventClients > circles     (REWORKED: Oct 12 Update 28; first made Oct 8 update 3)
-- Draws The Circles (server: ServerScriptService > Events > TheCircles):
--   Glow   one per plate that has a rule: a Highlight on the plate in the rule's colour (OutlineTransparency 0, a soft
--          pulsing fill), the sign RuleSign over it with the rule's name, and its haze (embers, drops ...).
--   Board  the rules panel RulesGui on every screen (left side): the rules in play, one line each, "◄ YOU" on the
--          one you are under, and when the rules change.
-- Restyle the sign and the panel under ServerScriptService > Events > TheCircles; the colours and words are below.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local FX = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("EventFX"))
if not (FX.Gui and FX.Clone and FX.UseSounds) then
	warn("[circles] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for. Install the WHOLE update (drag its .rbxmx in).")
end

--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	CirclesShift = { Id = "", Stand = "", Speed = 1, Volume = 1 },                                       -- the rules change (one low tone)
	Sizzle = { Id = "", Stand = "rbxasset://sounds/swordslash.wav", Speed = 0.35, Volume = 0.45 },      -- HOT FLOOR burns your feet
	Skid = { Id = "", Stand = "rbxasset://sounds/action_get_up.mp3", Speed = 1.6, Volume = 0.6 },        -- SLIPPERY
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

-- each rule: its colour, its name on the sign and the panel, and what it does in a few words
local RULES: { [string]: { Color: Color3, Name: string, Hint: string, Text: string, Haze: string } } = {
	Slow = { Color = Color3.fromRGB(110, 200, 70), Name = "SLOW", Hint = "you walk slower", Text = "You walk slower while you're on it.", Haze = "Mist" },
	Slick = { Color = Color3.fromRGB(90, 180, 255), Name = "SLIPPERY", Hint = "you skid!", Text = "Running makes you skid. Careful near the edge!", Haze = "Drop" },
	Heavy = { Color = Color3.fromRGB(170, 90, 255), Name = "HEAVY", Hint = "knocked back x2", Text = "Hits knock you back twice as far.", Haze = "Dust" },
	Leaden = { Color = Color3.fromRGB(200, 196, 180), Name = "NO JUMPING", Hint = "you can't jump", Text = "You can't jump while you're on it.", Haze = "Smoke" },
	Scorch = { Color = Color3.fromRGB(255, 120, 30), Name = "HOT FLOOR", Hint = "keep moving!", Text = "Standing still burns you. Keep moving!", Haze = "Ember" },
}
local FILL_MIN, FILL_MAX = 0.55, 0.8   -- the Highlight's fill pulses between these (its outline is always solid)

return FX.Module({
	Glow = {
		Init = function(self: any, props: any)
			self.Rule = RULES[tostring(props.Rule)] or RULES.Slow
			self.Tag = props.Tag
			local rule = self.Rule
			local highlight = Instance.new("Highlight")
			highlight.Name = "CircleRule"
			highlight.OutlineTransparency = 0
			highlight.OutlineColor = rule.Color
			highlight.FillColor = rule.Color
			highlight.FillTransparency = FILL_MAX
			highlight.DepthMode = Enum.HighlightDepthMode.Occluded
			highlight.Parent = self.Inst
			self.Highlight = highlight
			local model = FX.Clone("circles", "RuleSign")
			local sign = model and model:FindFirstChild("Sign")
			if sign and sign:IsA("BillboardGui") then
				sign.Parent = self.Inst
				local name = sign:FindFirstChild("Name")
				local hint = sign:FindFirstChild("Hint")
				local back = sign:FindFirstChild("Back")
				local edge = back and back:FindFirstChild("Edge")
				if name and name:IsA("TextLabel") then
					name.Text = rule.Name
					name.TextColor3 = rule.Color
				end
				if hint and hint:IsA("TextLabel") then
					hint.Text = rule.Hint
				end
				if edge and edge:IsA("UIStroke") then
					edge.Color = rule.Color
				end
				self.Sign = sign
			end
			if model then
				model:Destroy()
			end
			-- the haze just over the plate
			local cloud = FX.Block(self.Inst, Vector3.new(1, 0.2, 1), self.Origin, rule.Color, nil, 1)
			self.Cloud = cloud
			if not FX.Off("DisableParticles") then
				FX.Emitter(cloud, rule.Haze, { Color = rule.Color, Rate = if rule.Haze == "Ember" then 10 else 4, Scale = if rule.Haze == "Ember" then 0.8 else 1 })
			end
			FX.Sound("CirclesShift", self.Origin.Position, 0.5)
		end,

		Step = function(self: any, _dt: number, t: number)
			local plate = FX.Tagged(self.Tag)
			if plate and plate:IsA("BasePart") then
				if self.Highlight.Adornee ~= plate then
					self.Highlight.Adornee = plate
					if self.Sign then
						self.Sign.Adornee = plate
					end
				end
				self.Cloud.Size = Vector3.new(math.max(plate.Size.X - 2, 1), 0.2, math.max(plate.Size.Z - 2, 1))
				self.Cloud.CFrame = CFrame.new(plate.Position + Vector3.new(0, plate.Size.Y / 2 + 0.6, 0))
			elseif self.Highlight.Adornee then
				-- the plate is gone
				self.Highlight.Adornee = nil
				if self.Sign then
					self.Sign.Enabled = false
				end
			end
			local pulse = 0.5 + 0.5 * math.sin(t * 2.6)
			self.Highlight.FillTransparency = FILL_MAX - (FILL_MAX - FILL_MIN) * pulse
		end,

		Sizzle = function(_self: any, userId: number)
			local feet = FX.Feet(tonumber(userId) or 0)
			if feet then
				FX.Burst(feet + Vector3.new(0, 0.3, 0), "Smoke", 4, { Color = Color3.fromRGB(60, 50, 46), Scale = 0.6 })
				FX.Burst(feet + Vector3.new(0, 0.2, 0), "Ember", 4, { Color = RULES.Scorch.Color, Scale = 0.6 })
				FX.Sound("Sizzle", feet, 1, 0.9 + math.random() * 0.2)
			end
		end,

		Skid = function(_self: any, userId: number)
			local feet = FX.Feet(tonumber(userId) or 0)
			if feet then
				FX.Burst(feet + Vector3.new(0, 0.3, 0), "Drop", 6, { Color = RULES.Slick.Color, Scale = 0.6 })
				FX.Sound("Skid", feet)
			end
		end,
	},

	Board = {
		Init = function(self: any)
			self.InPlay = {}
			self.Mine = ""
			self.ChangeAt = (tonumber(self.Props.T0) or FX.Now()) + 2.5
			self.Phase = 0
			local gui = FX.Gui("circles", "RulesGui")
			self.Gui = gui
			if gui then
				self:Keep(gui)
				local panel = gui:FindFirstChild("Panel")
				local scale = panel and panel:FindFirstChild("Scale")
				local camera = workspace.CurrentCamera
				if scale and scale:IsA("UIScale") and camera and camera.ViewportSize.Y < 500 then
					scale.Scale = 0.72 -- (a phone held sideways)
				end
				self.Panel = panel
			end
		end,

		Step = function(self: any)
			local panel = self.Panel
			if not panel then
				return
			end
			for k = 1, 3 do
				local row = panel:FindFirstChild("Row" .. k)
				local id = self.InPlay[k]
				local rule = id and RULES[id]
				if row then
					row.Visible = rule ~= nil
					if rule then
						local swatch = row:FindFirstChild("Swatch")
						local name = row:FindFirstChild("Name")
						local text = row:FindFirstChild("Text")
						local you = row:FindFirstChild("You")
						local edge = row:FindFirstChild("Edge")
						if swatch then
							swatch.BackgroundColor3 = rule.Color
						end
						if name then
							name.Text = rule.Name
							name.TextColor3 = rule.Color
						end
						if text then
							text.Text = rule.Text
						end
						local mine = self.Mine == id
						if you then
							you.Visible = mine
						end
						if edge and edge:IsA("UIStroke") then
							edge.Color = if mine then rule.Color else Color3.fromRGB(150, 20, 30)
							edge.Thickness = if mine then 4 else 2
						end
					end
				end
			end
			local timer = panel:FindFirstChild("Timer")
			if timer and timer:IsA("TextLabel") then
				local left = math.max(math.ceil(self.ChangeAt - FX.Now()), 0)
				timer.Text = if #self.InPlay == 0 then (if self.Phase == 0 then "The plates start glowing in " .. left else "All plates are safe... for " .. left) else "These rules end in " .. left
			end
		end,

		-- the rules in play now (none = a gap), and when that changes
		Rules = function(self: any, phase: number, changeAt: number, ...: string)
			self.Phase = phase
			self.ChangeAt = changeAt
			self.InPlay = { ... }
			self.Mine = ""
		end,

		-- the rule a player is under now ("" = none); the panel marks it for that player only
		Yours = function(self: any, userId: number, rule: string)
			if userId == Players.LocalPlayer.UserId then
				self.Mine = rule
			end
		end,
	},
})
