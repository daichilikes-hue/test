-- ModuleScript: ReplicatedStorage > EventClients > ledger     (REWORKED: Oct 12 Update 28, Death Ledger)
-- Everything the Death Ledger looks like (the server, Events > DeathLedger, decides everything; the models and GUIs
-- are under that script):
--   Tome    the cursed book wandering over the arena (the SAME path sums as the server: tomeAt), pages riffling and
--           loose pages circling it; caught = it flies to whoever has it and hovers over their head, open.
--           On THAT player's screen: the seal puzzle (LedgerGui): the order of runes plays, then they press them.
--   Curse   the reaper (the R6 model Reaper: ReaperHover, ReaperReap) floating behind the cursed player, the clock
--           (Clock) over their head for everyone, "THE CURSER" (Mark) over the one who sealed it, and on the cursed
--           player's own screen: the slim strip at the top (RiddleGui) with a quick riddle every 10 s, and the curser
--           outlined in red (a Highlight) so they can find them.
-- HIS ANIMATIONS: ReaperHover and ReaperReap (this module's Animations folder). In Studio they play from there; for the
-- real game upload them and paste the ids into ANIMATIONS. (Not uploaded = the reaper holds his scythe still.)
local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
if not (FX.Actor and FX.HoldPose and FX.Gui and FX.Clone and FX.UseSounds) then
	warn("[ledger] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for. Install the WHOLE update (drag its .rbxmx in).")
end

--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	LedgerWhisper = { Id = "", Stand = "", Speed = 1, Volume = 0.5 },                                       -- the tome drifts by
	LedgerCatch = { Id = "", Stand = "rbxasset://sounds/electronicpingshort.wav", Speed = 0.4, Volume = 0.6 }, -- caught
	RuneTone = { Id = "", Stand = "rbxasset://sounds/electronicpingshort.wav", Speed = 0.8, Volume = 0.4 },    -- a rune lights
	RuneWrong = { Id = "", Stand = "rbxasset://sounds/swordslash.wav", Speed = 0.5, Volume = 0.5 },           -- a wrong rune
	SealBreak = { Id = "", Stand = "rbxasset://sounds/action_falling.mp3", Speed = 0.6, Volume = 0.6 },       -- solved
	ClockTick = { Id = "", Stand = "", Speed = 1, Volume = 0.4 },                                            -- the clock (last 10 s)
	ClockDrain = { Id = "", Stand = "rbxasset://sounds/swordslash.wav", Speed = 0.35, Volume = 0.6 },        -- 20 s lost
	ReaperReap = { Id = "", Stand = "rbxasset://sounds/swordslash.wav", Speed = 0.6, Volume = 0.8 },         -- the scythe
	SealBroken = { Id = "", Stand = "rbxasset://sounds/electronicpingshort.wav", Speed = 1.2, Volume = 0.6 }, -- saved
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

--[[DMP:KEEP Animations]]
local ANIMATIONS = {
	ReaperHover = 0, -- floating behind his victim (looped)
	ReaperReap = 0,  -- the swing (the scythe lands at REAP_AT)
}
--[[DMP:END]]

local REST_POSE = { -- (GENERATED: `python3 animgen/npcs.py rest reaper`)
	["RootJoint"] = CFrame.new(0, 0, 0),
	["Neck"] = CFrame.new(0, 0, 0),
	["Right Shoulder"] = CFrame.new(0, 0, 0, 0.951057, -0.30601, 0.043007, 0.309017, 0.941801, -0.132361, 0, 0.139173, 0.990268),
	["Left Shoulder"] = CFrame.new(0, 0, 0, 0.573576, 0.801252, -0.170311, -0.819152, 0.561042, -0.119253, 0, 0.207912, 0.978148),
	["Right Hip"] = CFrame.new(0, 0, 0),
	["Left Hip"] = CFrame.new(0, 0, 0),
}

local FLASH = 0.6           -- KEEP IN SYNC with FLASH / GAP in Events > DeathLedger
local GAP = 0.15
local REAP_AT = 0.9         -- KEEP IN SYNC with npcs.py REAP_AT
local BEHIND = CFrame.new(0.8, 1.2, 3.4) -- where the reaper floats, from the cursed player's root
local BLOOD = Color3.fromRGB(200, 30, 40)
local KEYS = { Enum.KeyCode.One, Enum.KeyCode.Two, Enum.KeyCode.Three, Enum.KeyCode.Four, Enum.KeyCode.Five, Enum.KeyCode.Six }

-- WHERE THE TOME IS t seconds in (KEEP THE SAME as tomeAt in Events > DeathLedger)
local function tomeAt(t: number, p: any): Vector3
	local x = p.Cx + p.Hx * 0.8 * math.sin(0.31 * t + p.P1)
	local z = p.Cz + p.Hz * 0.8 * math.sin(0.43 * t + p.P2)
	local y = p.Top + p.Height + 0.8 * math.sin(1.7 * t)
	return Vector3.new(x, y, z)
end

local function find(parent: Instance?, path: { string }): any
	local at: any = parent
	for _, name in path do
		at = at and at:FindFirstChild(name)
	end
	return at
end

-- the puzzle panel: one rune lit (or none)
local function lightRune(self: any, index: number?, wrong: boolean?)
	local panel = self.Panel
	if not panel then
		return
	end
	for k = 1, 6 do
		local rune = panel:FindFirstChild("Rune" .. k)
		if rune then
			local lit = rune:GetAttribute("Lit")
			local color = if typeof(lit) == "Color3" then lit else BLOOD
			rune.BackgroundColor3 = if k == index then (if wrong then Color3.fromRGB(120, 10, 14) else color) else Color3.fromRGB(24, 10, 12)
			local glyph = rune:FindFirstChild("Glyph")
			if glyph and glyph:IsA("TextLabel") then
				glyph.TextColor3 = if k == index then Color3.new(1, 1, 1) else color
			end
		end
	end
end

local function status(self: any, text: string)
	local label = self.Panel and self.Panel:FindFirstChild("Status")
	if label and label:IsA("TextLabel") then
		label.Text = text
	end
end

-- the cursed player's strip: the riddle's answers on / off
local function showAnswers(self: any, on: boolean)
	local panel = self.Strip
	if not panel then
		return
	end
	for k = 1, 3 do
		local option = panel:FindFirstChild("Opt" .. k)
		if option then
			option.Visible = on
		end
	end
	local hint = panel:FindFirstChild("Hint")
	if hint then
		hint.Visible = not on
	end
	local bar = panel:FindFirstChild("Bar")
	if bar then
		bar.Visible = on
	end
end

-- a BillboardGui from one of the models (Clock / Mark) put on a player's head
local function overHead(self: any, modelName: string, guiName: string, userId: number): BillboardGui?
	local model = FX.Clone("ledger", modelName)
	local gui = model and model:FindFirstChild(guiName)
	if gui and gui:IsA("BillboardGui") then
		gui.Parent = self.Inst
		local root = FX.Root(userId)
		local head = root and root.Parent and root.Parent:FindFirstChild("Head")
		gui.Adornee = head or root
	else
		gui = nil
	end
	if model then
		model:Destroy()
	end
	return gui
end

return FX.Module({
	Tome = {
		Init = function(self: any, props: any)
			self.Path = {
				Cx = tonumber(props.Cx) or self.Origin.X, Cz = tonumber(props.Cz) or self.Origin.Z,
				Hx = tonumber(props.Hx) or 20, Hz = tonumber(props.Hz) or 20, Top = tonumber(props.Top) or self.Origin.Y,
				Height = tonumber(props.Height) or 7.5, P1 = tonumber(props.P1) or 0, P2 = tonumber(props.P2) or 0,
			}
			local inverse = self.Origin:Inverse()
			self.Parts = {}
			self.Pages = {}
			for _, part in self.Inst:GetChildren() do
				if part:IsA("BasePart") and part.Name ~= "Root" then
					local entry = { Part = part, Offset = inverse * part.CFrame }
					if string.sub(part.Name, 1, 4) == "Page" and tonumber(string.sub(part.Name, 5)) then
						table.insert(self.Pages, entry)
					else
						table.insert(self.Parts, entry)
					end
				end
			end
			self.Seal = self.Inst:FindFirstChild("Seal")
			self.Pos = tomeAt(0, self.Path)
		end,

		Step = function(self: any, dt: number, t: number)
			-- where it is: wandering, flying to its holder, hovering over them, or sinking away
			local want: Vector3
			local holderRoot = self.Holder and FX.Root(self.Holder)
			if self.ClosedAt then
				want = self.Pos + Vector3.new(0, -dt * 4, 0)
			elseif holderRoot then
				want = holderRoot.Position + Vector3.new(0, 4.2 + 0.2 * math.sin(t * 2), 0)
			else
				want = tomeAt(t, self.Path)
			end
			if self.Holder then
				self.Pos = self.Pos:Lerp(want, math.min(dt * 6, 1))
			else
				self.Pos = want
			end
			local spin = if self.Holder then t * 0.4 else t * 0.6
			local base = CFrame.new(self.Pos) * CFrame.Angles(0, spin, 0) * CFrame.Angles(math.rad(8) * math.sin(t * 1.3), 0, math.rad(6) * math.sin(t * 1.1))
			local shown = not (self.ClosedAt and t - self.ClosedAt > 1.2)
			for _, entry in self.Parts do
				entry.Part.CFrame = base * entry.Offset
				entry.Part.Transparency = if shown then entry.Part.Transparency else 1
			end
			for index, entry in self.Pages do
				local a = t * 1.6 + index * 2.1
				entry.Part.CFrame = base * CFrame.new(math.cos(a) * 3, 0.8 + 0.4 * math.sin(t * 2 + index), math.sin(a) * 3) * CFrame.Angles(math.sin(a) * 0.6, a, 0.4)
				if not shown then
					entry.Part.Transparency = 1
				end
			end
			if self.Seal and self.Seal:IsA("BasePart") then
				local beat = 0.5 + 0.5 * math.sin(t * (if self.Holder then 6 else 2.5))
				self.Seal.Color = BLOOD:Lerp(Color3.fromRGB(255, 120, 120), beat * 0.5)
			end
			-- the puzzle: the order plays, rune by rune
			if self.Panel and self.ShowAt then
				local k = (FX.Now() - self.ShowAt) / (FLASH + GAP)
				local index = math.floor(k) + 1
				if k >= 0 and index <= #self.Order then
					local lit = if (k % 1) * (FLASH + GAP) <= FLASH then self.Order[index] else nil
					if lit ~= self.Showing then
						self.Showing = lit
						lightRune(self, lit)
						if lit then
							FX.Sound("RuneTone", nil, 0.6, 0.8 + lit * 0.08)
						end
					end
					status(self, "Watch the runes...")
				elseif k >= 0 and not self.YourTurn then
					self.YourTurn = true
					self.Showing = nil
					lightRune(self, nil)
					status(self, "Your turn! Press them in the same order.")
				elseif k < 0 then
					status(self, "Watch the runes light up...")
				end
				if self.FlashUntil and FX.Now() < self.FlashUntil then
					lightRune(self, self.Flashed, self.FlashWrong)
				elseif self.FlashUntil then
					self.FlashUntil = nil
					lightRune(self, nil)
				end
				local fill = find(self.Panel, { "Bar", "Fill" })
				if fill and self.Ends then
					fill.Size = UDim2.fromScale(math.clamp((self.Ends - FX.Now()) / 25, 0, 1), 1)
				end
			end
		end,

		-- somebody caught it (or it chose them): it flies to them
		Caught = function(self: any, userId: number, _caught: boolean)
			self.Holder = userId
			FX.Sound("LedgerCatch", self.Pos)
			FX.Burst(self.Pos, "Glow", 14, { Color = BLOOD, Scale = 0.8 })
		end,

		-- the seal puzzle on the holder's screen
		Puzzle = function(self: any, userId: number, showAt: number, ends: number, ...: number)
			if not FX.IsMe(userId) then
				return
			end
			self.Order = { ... }
			self.ShowAt = showAt
			self.Ends = ends
			self.YourTurn = false
			local gui = FX.Gui("ledger", "LedgerGui")
			if not gui then
				return
			end
			self:Keep(gui)
			self.Gui = gui
			local panel = gui:FindFirstChild("Panel")
			self.Panel = panel
			local scale = panel and panel:FindFirstChild("Scale")
			local camera = workspace.CurrentCamera
			if scale and scale:IsA("UIScale") and camera then
				scale.Scale = math.clamp((camera.ViewportSize.Y - 40) / 404, 0.55, 1)
			end
			local function press(k: number)
				if self.YourTurn and not self.Solved then
					self:Send("Rune", k)
				end
			end
			for k = 1, 6 do
				local rune = panel and panel:FindFirstChild("Rune" .. k)
				if rune and rune:IsA("GuiButton") then
					self:Keep(rune.Activated:Connect(function()
						press(k)
					end))
				end
			end
			self:Keep(UserInputService.InputBegan:Connect(function(input, processed)
				if processed then
					return
				end
				local k = table.find(KEYS, input.KeyCode)
				if k then
					press(k)
				end
			end))
		end,

		Pressed = function(self: any, rune: number, ok: boolean, count: number)
			if not self.Panel then
				return
			end
			self.Flashed, self.FlashWrong, self.FlashUntil = rune, not ok, FX.Now() + 0.25
			FX.Sound(if ok then "RuneTone" else "RuneWrong", nil, 0.6, 0.8 + rune * 0.08)
			local count_ = find(self.Panel, { "Seal", "Count" })
			if count_ then
				count_.Text = count .. " / " .. #self.Order
			end
			if not ok then
				status(self, "Wrong! Watch again...")
			end
		end,

		Again = function(self: any, showAt: number)
			self.ShowAt = showAt
			self.YourTurn = false
		end,

		Solved = function(self: any)
			self.Solved = true
			FX.Sound("SealBreak", self.Pos)
			FX.Burst(self.Pos, "Spark", 20, { Color = BLOOD, Scale = 1 })
			if self.Panel then
				status(self, "THE SEAL BREAKS. Choose a name...")
				local ring = find(self.Panel, { "Seal", "Ring" })
				if ring then
					ring.Color = Color3.fromRGB(255, 220, 220)
				end
			end
			if self.Gui then
				local gui = self.Gui
				self:After(1.2, function()
					gui:Destroy()
				end)
				self.Gui, self.Panel = nil, nil
			end
		end,

		Refused = function(self: any)
			self.ClosedAt = self:Time()
			FX.Burst(self.Pos, "Smoke", 14, { Color = Color3.fromRGB(40, 20, 24), Scale = 1.2 })
			if self.Gui then
				self.Gui:Destroy()
				self.Gui, self.Panel = nil, nil
			end
		end,

		Sealed = function(self: any, _victim: number)
			self.ClosedAt = self:Time()
			FX.Burst(self.Pos, "Glow", 20, { Color = BLOOD, Scale = 1.1 })
		end,
	},

	Curse = {
		Init = function(self: any, props: any)
			self.Victim = tonumber(props.Victim) or 0
			self.Curser = tonumber(props.Curser) or 0
			self.EndsAt = tonumber(props.EndsAt) or (FX.Now() + 60)
			self.Mine = FX.IsMe(self.Victim)
			-- the reaper
			local model = FX.Clone("ledger", "Reaper")
			if model then
				self.Actor = FX.Actor(model :: Model, ANIMATIONS, script)
				model.Parent = self.Inst
				self.Model = model
				local root = FX.Root(self.Victim)
				if root then
					FX.Burst((root.CFrame * BEHIND).Position, "Smoke", 16, { Color = Color3.fromRGB(30, 26, 36), Scale = 1.5 })
				end
			end
			-- the clock over the cursed one, the mark over the curser
			self.Clock = overHead(self, "Clock", "Face", self.Victim)
			self.Mark = overHead(self, "Mark", "Tag", self.Curser)
			-- on the cursed player's own screen: the curser outlined, the strip at the top
			if self.Mine then
				local curserRoot = FX.Root(self.Curser)
				if curserRoot and curserRoot.Parent then
					local highlight = Instance.new("Highlight")
					highlight.Name = "LedgerCurser"
					highlight.FillTransparency = 0.8
					highlight.FillColor = BLOOD
					highlight.OutlineColor = BLOOD
					highlight.OutlineTransparency = 0
					highlight.Adornee = curserRoot.Parent
					highlight.Parent = self.Inst
				end
				local gui = FX.Gui("ledger", "RiddleGui")
				if gui then
					self:Keep(gui)
					local panel = gui:FindFirstChild("Panel")
					self.Strip = panel
					local hint = panel and panel:FindFirstChild("Hint")
					if hint and hint:IsA("TextLabel") then
						hint.Text = "Knock out " .. tostring(props.CurserName or "the curser") .. " to break the seal!"
					end
					local camera = workspace.CurrentCamera
					local scale = panel and panel:FindFirstChild("Scale")
					if scale and scale:IsA("UIScale") and camera and camera.ViewportSize.X < 700 then
						scale.Scale = 0.75
					end
					local function answer(k: number)
						if self.Riddle and not self.Answered then
							self.Answered = true
							self:Send("Answer", self.Riddle, k)
						end
					end
					for k = 1, 3 do
						local option = panel and panel:FindFirstChild("Opt" .. k)
						if option and option:IsA("GuiButton") then
							self:Keep(option.Activated:Connect(function()
								answer(k)
							end))
						end
					end
					self:Keep(UserInputService.InputBegan:Connect(function(input, processed)
						if processed then
							return
						end
						local k = table.find(KEYS, input.KeyCode)
						if k and k <= 3 then
							answer(k)
						end
					end))
					showAnswers(self, false)
				end
			end
		end,

		Step = function(self: any, _dt: number, t: number)
			local root = FX.Root(self.Victim)
			local actor = self.Actor
			if actor and root and not self.Gone then
				actor.Place(root.CFrame * BEHIND * CFrame.new(0, 0.3 * math.sin(t * 1.4), 0))
				if actor.Animated then
					if not self.Hovering and not self.Reaping then
						self.Hovering = actor.Play("ReaperHover", 0.3) ~= nil
					end
				else
					FX.HoldPose(self.Model, REST_POSE)
				end
			end
			-- the clock
			local left = math.max(self.EndsAt - FX.Now(), 0)
			local face = self.Clock
			if face then
				local time = find(face, { "Dial", "Time" })
				local ring = find(face, { "Dial", "Ring" })
				if time then
					time.Text = tostring(math.ceil(left))
					time.TextColor3 = if left <= 10 then Color3.fromRGB(255, 80, 80) else Color3.fromRGB(255, 220, 220)
				end
				if ring then
					local flash = self.DrainAt and FX.Now() - self.DrainAt < 0.8
					ring.Color = if flash then Color3.new(1, 1, 1) else BLOOD
					ring.Thickness = if flash then 7 else 4
				end
				if left <= 10 and left > 0 and math.ceil(left) ~= self.Tick then
					self.Tick = math.ceil(left)
					FX.Sound("ClockTick", root and root.Position, 0.5)
				end
			end
			-- the riddle's time bar
			if self.Strip and self.RiddleEnds then
				local fill = find(self.Strip, { "Bar", "Fill" })
				if fill then
					fill.Size = UDim2.fromScale(math.clamp((self.RiddleEnds - FX.Now()) / 3, 0, 1), 1)
				end
				if FX.Now() > self.RiddleEnds + 0.6 then
					self.RiddleEnds = nil
					showAnswers(self, false)
					local line = self.Strip:FindFirstChild("Line")
					if line and line:IsA("TextLabel") then
						line.RichText = false
						line.Text = "THE REAPER IS BEHIND YOU"
					end
				end
			end
		end,

		-- a riddle (only the cursed player sees it)
		Riddle = function(self: any, n: number, line: string, a: string, b: string, c: string, ends: number)
			if not self.Strip then
				return
			end
			self.Riddle, self.Answered, self.RiddleEnds = n, false, ends
			local label = self.Strip:FindFirstChild("Line")
			if label and label:IsA("TextLabel") then
				label.RichText = true
				label.Text = line
			end
			for k, text in { a, b, c } do
				local answer = find(self.Strip, { "Opt" .. k, "Answer" })
				if answer then
					answer.Text = text
				end
			end
			showAnswers(self, true)
			FX.Sound("RuneTone", nil, 0.5, 1.2)
		end,

		Right = function(self: any)
			if self.Strip then
				local label = self.Strip:FindFirstChild("Line")
				if label and label:IsA("TextLabel") then
					label.RichText = false
					label.Text = "RIGHT! The reaper waits..."
				end
				self.RiddleEnds = math.min(self.RiddleEnds or FX.Now(), FX.Now())
			end
		end,

		-- 20 s off the clock: the reaper lurches closer
		Drain = function(self: any, _n: number, endsAt: number)
			self.EndsAt = endsAt
			self.DrainAt = FX.Now()
			local root = FX.Root(self.Victim)
			if root then
				FX.Sound("ClockDrain", root.Position)
				FX.Burst(root.Position + Vector3.new(0, 4, 0), "Smoke", 10, { Color = Color3.fromRGB(40, 10, 14), Scale = 0.9 })
			end
			if self.Strip then
				local label = self.Strip:FindFirstChild("Line")
				if label and label:IsA("TextLabel") then
					label.RichText = false
					label.Text = "WRONG! -20 seconds"
				end
				self.RiddleEnds = math.min(self.RiddleEnds or FX.Now(), FX.Now())
			end
			if self.Mine then
				FX.Shake(0.4, 8, 0.05, 0.4)
			end
		end,

		-- the clock ran out: the scythe comes down
		Reap = function(self: any)
			self.Reaping = true
			local actor = self.Actor
			if actor and actor.Animated then
				if self.Hovering then
					actor.Stop("ReaperHover", 0.1)
				end
				actor.Play("ReaperReap", 0.1)
			end
			self:After(REAP_AT, function()
				local root = FX.Root(self.Victim)
				if root then
					FX.Sound("ReaperReap", root.Position)
					FX.Burst(root.Position, "Smoke", 24, { Color = Color3.fromRGB(20, 16, 24), Scale = 1.6 })
				end
				if self.Mine then
					FX.Flash(0.5)
				end
			end)
		end,

		-- the curser is down: the reaper turns to smoke
		Broken = function(self: any)
			self.Gone = true
			local root = FX.Root(self.Victim)
			if self.Model then
				FX.Burst(self.Model:GetPivot().Position, "Smoke", 24, { Color = Color3.fromRGB(30, 26, 36), Scale = 1.6 })
				self.Model:Destroy()
				self.Model, self.Actor = nil, nil
			end
			if root then
				FX.Burst(root.Position, "Glow", 16, { Color = Color3.fromRGB(150, 220, 255), Scale = 1 })
				FX.Sound("SealBroken", root.Position)
			end
			if self.Clock then
				self.Clock.Enabled = false
			end
			if self.Mark then
				self.Mark.Enabled = false
			end
		end,

		Over = function(self: any)
			self.Gone = true
			if self.Model then
				self.Model:Destroy()
				self.Model, self.Actor = nil, nil
			end
		end,
	},
})
