-- ModuleScript: ReplicatedStorage > EventClients > horseshoe     (NEW: Oct 12 Update 26, Lucky Horseshoe)
-- What the Lucky Horseshoe looks like on each client: the horseshoe (the model Horseshoe under ServerScriptService >
-- Events > LuckyHorseshoe) nailed to its plate, glinting now and then; when somebody pries it loose it spins up to them
-- in a shower of gold sparks.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
if not (FX.OnPlate and FX.UseSounds) then
	warn("[horseshoe] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for. Install the WHOLE update (drag its .rbxmx in).")
end

--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	HorseshoeTake = { Id = "", Stand = "rbxasset://sounds/electronicpingshort.wav", Speed = 1.2, Volume = 0.5 }, -- pried loose
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

local GOLD = Color3.fromRGB(255, 220, 140)

return FX.Module({
	Horseshoe = {
		Init = function(self: any, props: any)
			self.Follow = FX.OnPlate(props.Tag, self.Origin)
			local glint = self.Inst:FindFirstChild("Glint")
			self.Light = glint and glint:FindFirstChildOfClass("PointLight")
			self.Pieces = {}
			local inverse = self.Inst:GetPivot():Inverse()
			for _, part in self.Inst:GetDescendants() do
				if part:IsA("BasePart") and part.Name ~= "Root" then
					table.insert(self.Pieces, { Part = part, Offset = inverse * part.CFrame, Transparency = part.Transparency })
				end
			end
		end,

		Step = function(self: any, _dt: number, t: number)
			local base = self.Follow()
			local frame = base
			local shown = true
			if self.TakenAt then
				local k = FX.Clamp01((t - self.TakenAt) / 0.6)
				local root = FX.Root(self.TakenBy or 0)
				local to = if root then root.Position else base.Position + Vector3.new(0, 5, 0)
				frame = CFrame.new(base.Position:Lerp(to, k) + Vector3.new(0, math.sin(k * math.pi) * 3, 0)) * CFrame.Angles(t * 9, t * 7, 0)
				shown = k < 1
			end
			for _, piece in self.Pieces do
				piece.Part.CFrame = frame * piece.Offset
				piece.Part.Transparency = if shown then piece.Transparency else 1
			end
			if self.Light then
				self.Light.Brightness = 0.5 + 1.5 * math.max(math.sin(t * 2.3), 0) ^ 8
			end
		end,

		Taken = function(self: any, userId: number)
			self.TakenAt = self:Time()
			self.TakenBy = userId
			FX.Burst((self.Follow()).Position + Vector3.new(0, 0.5, 0), "Star", 16, { Color = GOLD, Scale = 0.8 })
			FX.Sound("HorseshoeTake", self.Origin.Position)
		end,
	},
})
