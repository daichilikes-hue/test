-- ModuleScript: ReplicatedStorage > EventClients > smores     (NEW: Oct 12 Update 27, Smores)
-- What Smores looks like on each client (models under ServerScriptService > Events > Smores):
--   Campfire  catches light at the start, flickers and crackles, a warm glow round it; dies down at the end.
--   Stick     a marshmallow on a stick, stuck in the plate leaning over the fire. Roasted = it turns golden brown,
--             then it is eaten (gone, with a little puff). It slowly toasts a little just from standing there.
-- Both ride on their plate.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
if not (FX.OnPlate and FX.UseSounds) then
	warn("[smores] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in).")
end

--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	FireLight = { Id = "", Stand = "rbxasset://sounds/action_falling.mp3", Speed = 2, Volume = 0.3 },  -- the fire catches
	MallowRoast = { Id = "", Stand = "", Speed = 1, Volume = 0.5 },                                     -- a marshmallow is roasted
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

local LIGHT_UP = 1.2        -- seconds the fire takes to catch
local DIE = 1.5             -- seconds it takes to die down at the end
local ROAST = 0.8           -- seconds a roasted marshmallow takes to go golden before it is eaten
local RAW = Color3.fromRGB(242, 236, 222)
local TOASTY = Color3.fromRGB(232, 206, 160)  -- what standing by the fire does to it over the whole event
local GOLDEN = Color3.fromRGB(196, 132, 62)
local WARM = Color3.fromRGB(255, 170, 90)

return FX.Module({
	Campfire = {
		Init = function(self: any, props: any)
			self.Follow = FX.OnPlate(props.Tag, self.Origin)
			self.Flames = {}
			local inverse = self.Origin:Inverse()
			for _, part in self.Inst:GetChildren() do
				if part:IsA("BasePart") and string.sub(part.Name, 1, 5) == "Flame" then
					table.insert(self.Flames, { Part = part, Size = part.Size, Offset = inverse * part.CFrame, Transparency = part.Transparency, Seed = #self.Flames * 1.9 })
				end
			end
			local core = self.Inst:FindFirstChild("FireCore")
			self.Light = core and core:FindFirstChildOfClass("PointLight")
			self.Brightness = self.Light and self.Light.Brightness or 2
			self.Emitters = {}
			for _, item in core and core:GetChildren() or {} do
				if item:IsA("ParticleEmitter") then
					table.insert(self.Emitters, item)
				end
			end
		end,

		Step = function(self: any, _dt: number, t: number)
			local base = self.Follow()
			if self.LastBase ~= base then
				self.LastBase = base
				self.Inst:PivotTo(base)
			end
			if not self.Lit and t > 0.2 then
				self.Lit = true
				FX.Sound("FireLight", base.Position)
				FX.Burst(base.Position + Vector3.new(0, 1, 0), "Ember", 16, { Color = WARM, Scale = 0.6 })
			end
			local duration = tonumber(self.Props.Duration) or 25
			local fire = FX.Ease.Out(FX.Clamp01((t - 0.2) / LIGHT_UP))
			if self.OutAt then
				fire *= 1 - FX.Clamp01((t - self.OutAt) / DIE)
			else
				fire *= 1 - FX.Clamp01((t - (duration - DIE)) / DIE)
			end
			for _, flame in self.Flames do
				local flick = 1 + 0.22 * FX.Noise(flame.Seed, t * 4.5)
				local h = flame.Size.Y * flick * fire
				flame.Part.Size = Vector3.new(flame.Size.X * (0.5 + 0.5 * fire), math.max(h, 0.05), flame.Size.Z * (0.5 + 0.5 * fire))
				flame.Part.CFrame = base * flame.Offset * CFrame.new(0, (h - flame.Size.Y) / 2, 0)
				flame.Part.Transparency = if fire <= 0.02 then 1 else flame.Transparency
			end
			if self.Light then
				self.Light.Brightness = self.Brightness * fire * (1 + 0.18 * FX.Noise(5, t * 6))
			end
			local on = fire > 0.3 and not FX.Off("DisableParticles")
			for _, emitter in self.Emitters do
				if emitter.Enabled ~= on then
					emitter.Enabled = on
				end
			end
		end,

		-- a roaster got a buff: a little warm swirl round them
		Buff = function(_self: any, userId: number, _buff: string)
			local root = FX.Root(userId)
			if root then
				FX.Burst(root.Position, "Ember", 8, { Color = WARM, Scale = 0.5 })
			end
		end,

		-- the end: it dies down
		Out = function(self: any)
			self.OutAt = self.OutAt or self:Time()
		end,
	},

	Stick = {
		Init = function(self: any, props: any)
			self.Follow = FX.OnPlate(props.Tag, self.Origin)
			self.Delay = tonumber(props.Delay) or 0
			local inverse = self.Origin:Inverse()
			self.Parts = {}
			for _, part in self.Inst:GetChildren() do
				if part:IsA("BasePart") and part.Name ~= "Root" then
					table.insert(self.Parts, { Part = part, Offset = inverse * part.CFrame, Size = part.Size, Transparency = part.Transparency, Mallow = part.Name == "Mallow" })
					part.Transparency = 1
				end
			end
		end,

		Step = function(self: any, _dt: number, t: number)
			local base = self.Follow()
			local duration = tonumber(self.Props.Duration) or 25
			local since = t - self.Delay
			-- it is pushed into the plate from above
			local push = 1 - FX.Ease.Out(FX.Clamp01(since / 0.4))
			local roast = if self.RoastAt then FX.Clamp01((t - self.RoastAt) / ROAST) else 0
			local eaten = self.RoastAt ~= nil and t - self.RoastAt > ROAST
			local toast = FX.Clamp01(t / duration)
			for _, entry in self.Parts do
				local part: BasePart = entry.Part
				part.CFrame = base * CFrame.new(0, push * 3, 0) * entry.Offset
				if entry.Mallow then
					part.Color = RAW:Lerp(TOASTY, toast):Lerp(GOLDEN, roast)
					part.Transparency = if since <= 0 or eaten then 1 else entry.Transparency
				else
					part.Transparency = if since <= 0 then 1 else entry.Transparency
				end
			end
			if eaten and not self.Puffed then
				self.Puffed = true
				FX.Burst((base * CFrame.new(0, 2.4, -2.1)).Position, "Smoke", 4, { Color = Color3.fromRGB(220, 210, 190), Scale = 0.4 })
			end
		end,

		Roast = function(self: any, userId: number)
			self.RoastAt = self:Time()
			local at = ((self.Follow()) * CFrame.new(0, 2.4, -2.1)).Position
			FX.Sound("MallowRoast", at)
			FX.Burst(at, "Ember", 6, { Color = WARM, Scale = 0.4 })
			if FX.IsMe(userId) then
				FX.Popup(at + Vector3.new(0, 1.5, 0), "YUM!", Color3.fromRGB(255, 200, 120), 1.8)
			end
		end,
	},
})
