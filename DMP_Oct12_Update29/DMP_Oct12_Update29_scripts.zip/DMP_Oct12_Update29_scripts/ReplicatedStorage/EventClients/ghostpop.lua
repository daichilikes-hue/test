-- ModuleScript: ReplicatedStorage > EventClients > ghostpop     (NEW: Oct 12 Update 27, Ghost Pop)
-- What Ghost Pop looks like on each client. The server (Events > GhostPop) makes the prompts, the Tool "Old Bone" and
-- gives the items / soul; this draws (models under ServerScriptService > Events > GhostPop):
--   Dog      the ghost dog: appears in a puff of mist, wags, turns its head to whoever is holding a bone, bounces
--            happily when given one, and goes in a puff of mist at the end. It is SOLID (never see-through).
--   Bone     the old bones on the plates: they pop up, and shrink away when picked up.
--   BoneGui  (on the screen of whoever holds a bone) the TOSS button (or T) and a line with the three choices.
-- A crushed bone bursts into bone dust; a tossed one flies off the arena.
local UserInputService = game:GetService("UserInputService")
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
if not (FX.OnPlate and FX.UseSounds and FX.Gui and FX.Clone) then
	warn("[ghostpop] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in).")
end

--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	DogBark = { Id = "", Stand = "", Speed = 1, Volume = 0.6 },                                         -- given a bone
	DogAppear = { Id = "", Stand = "", Speed = 1, Volume = 0.4 },                                       -- the puff of mist
	BoneCrunch = { Id = "", Stand = "rbxasset://sounds/collide.wav", Speed = 1.4, Volume = 0.6 },       -- crushed
	BoneToss = { Id = "", Stand = "rbxasset://sounds/swordslash.wav", Speed = 0.7, Volume = 0.4 },      -- tossed
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

local TOSS_KEY = Enum.KeyCode.T
local MIST = Color3.fromRGB(176, 192, 204)
local BONE = Color3.fromRGB(206, 196, 168)
local WAG = 0.5             -- radians the tail swings each way
local BOUNCE = 0.7          -- seconds of the happy bounce

-- the parts of a model and where they sit in it
local function partsOf(self: any): { any }
	local inverse = self.Origin:Inverse()
	local list = {}
	for _, part in self.Inst:GetChildren() do
		if part:IsA("BasePart") and part.Name ~= "Root" then
			table.insert(list, { Part = part, Offset = inverse * part.CFrame, Transparency = part.Transparency, Name = part.Name })
		end
	end
	return list
end

-- the TOSS button goes (the bone is used up)
local function dropGui(self: any)
	if self.BoneGui then
		self.BoneGui:Destroy()
		self.BoneGui = nil
	end
end

-- the bone flying off: a copy of the model Bone thrown in an arc away from the arena
local function throwBone(self: any, from: Vector3)
	local model = FX.Clone("ghostpop", "Bone")
	if not model then
		return
	end
	model.Parent = self.Inst
	local out = FX.Flat(from - (self.LastBase or self.Origin).Position)
	out = if out.Magnitude > 0.1 then out.Unit else Vector3.new(1, 0, 0)
	local start = FX.Now()
	local conn
	conn = game:GetService("RunService").RenderStepped:Connect(function()
		local k = (FX.Now() - start) / 1.4
		if k >= 1 or not model.Parent then
			conn:Disconnect()
			model:Destroy()
			return
		end
		local at = from + out * 30 * k + Vector3.new(0, 10 * k - 18 * k * k, 0)
		model:PivotTo(CFrame.new(at) * CFrame.Angles(k * 12, k * 7, 0))
	end)
	self:Keep(conn)
end

return FX.Module({
	Dog = {
		Init = function(self: any, props: any)
			self.Follow = FX.OnPlate(props.Tag, self.Origin)
			self.Parts = partsOf(self)
			self.Holders = {}
			for _, entry in self.Parts do
				entry.Tail = string.sub(entry.Name, 1, 4) == "Tail"
				entry.Head = entry.Name == "Head" or entry.Name == "Snout" or entry.Name == "Nose" or entry.Name == "Jaw"
					or string.sub(entry.Name, 1, 3) == "Ear" or string.sub(entry.Name, 1, 3) == "Eye"
				entry.Part.Transparency = 1
			end
			self.TailRoot = Vector3.new(0, 1.9, 1.6)
			self.Neck = Vector3.new(0, 2.2, -1.0)
			self.Turn = 0
		end,

		Step = function(self: any, dt: number, t: number)
			local base, there = self.Follow()
			self.LastBase = base
			local duration = tonumber(self.Props.Duration) or 30
			local shown = t > 0.3 and t < duration - 0.6 and (there or not self.WasThere)
			self.WasThere = self.WasThere or there
			if shown and not self.Appeared then
				self.Appeared = true
				FX.Burst(base.Position + Vector3.new(0, 1.5, 0), "Mist", 12, { Color = MIST, Scale = 1.4 })
				FX.Sound("DogAppear", base.Position)
			elseif not shown and self.Appeared and not self.Vanished then
				self.Vanished = true
				FX.Burst(base.Position + Vector3.new(0, 1.5, 0), "Mist", 12, { Color = MIST, Scale = 1.4 })
			end
			-- look at the nearest player holding a bone (else straight ahead)
			local want = 0
			local nearest = math.huge
			for userId in self.Holders do
				local root = FX.Root(userId)
				if root then
					local local3 = base:PointToObjectSpace(root.Position)
					local d = local3.Magnitude
					if d < nearest and d < 40 then
						nearest = d
						want = math.clamp(math.atan2(-local3.X, -local3.Z), -0.8, 0.8)
					end
				end
			end
			self.Turn += (want - self.Turn) * math.min(dt * 5, 1)
			-- the happy bounce
			local hop = 0
			if self.FedAt then
				local k = (t - self.FedAt) / BOUNCE
				if k < 2 then
					hop = math.max(math.sin(math.pi * (k % 1)), 0) * 1.4
				end
			end
			local excited = if next(self.Holders) or (self.FedAt and t - self.FedAt < 3) then 2.2 else 1
			local wag = math.sin(t * 9 * excited) * WAG * math.min(excited, 1.6)
			local breathe = CFrame.new(0, 0.05 * math.sin(t * 2.4) + hop, 0)
			local tail = CFrame.new(self.TailRoot) * CFrame.Angles(0, wag, 0) * CFrame.new(-self.TailRoot)
			local head = CFrame.new(self.Neck) * CFrame.Angles(0, self.Turn, 0) * CFrame.Angles(math.rad(8) * math.sin(t * 1.3), 0, 0) * CFrame.new(-self.Neck)
			for _, entry in self.Parts do
				local cf = base * breathe
				if entry.Tail then
					cf *= tail
				elseif entry.Head then
					cf *= head
				end
				entry.Part.CFrame = cf * entry.Offset
				entry.Part.Transparency = if shown then entry.Transparency else 1
			end
		end,

		-- somebody picked up a bone: the dog watches them; on their own screen, the TOSS button
		Holding = function(self: any, userId: number)
			self.Holders[userId] = true
			if not FX.IsMe(userId) then
				return
			end
			local gui = FX.Gui("ghostpop", "BoneGui")
			self.BoneGui = gui
			if not gui then
				return
			end
			self:Keep(gui)
			local function toss()
				if self.BoneGui then
					self:Send("Toss")
				end
			end
			local button = gui:FindFirstChild("Toss")
			if button and button:IsA("GuiButton") then
				self:Keep(button.Activated:Connect(toss))
				local key = button:FindFirstChild("Key")
				if key and key:IsA("TextLabel") and UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled then
					key.Text = "TAP"
				end
			end
			self:Keep(UserInputService.InputBegan:Connect(function(input, processed)
				if not processed and input.KeyCode == TOSS_KEY then
					toss()
				end
			end))
		end,

		Crushed = function(self: any, userId: number, where: Vector3?)
			self.Holders[userId] = nil
			local at = where or (FX.Root(userId) and (FX.Root(userId) :: BasePart).Position) or self.Origin.Position
			FX.Burst(at, "Dust", 14, { Color = BONE, Scale = 0.8 })
			FX.Sound("BoneCrunch", at)
			if FX.IsMe(userId) then
				FX.Popup(at + Vector3.new(0, 2, 0), "CRUNCH!", Color3.fromRGB(190, 120, 220), 2)
				dropGui(self)
			end
		end,

		Tossed = function(self: any, userId: number, where: Vector3?)
			self.Holders[userId] = nil
			local root = FX.Root(userId)
			local at = where or (root and root.Position) or self.Origin.Position
			throwBone(self, at)
			FX.Sound("BoneToss", at)
			if FX.IsMe(userId) then
				dropGui(self)
			end
		end,

		Fed = function(self: any, userId: number)
			self.Holders[userId] = nil
			self.FedAt = self:Time()
			local at = (self.LastBase or self.Origin).Position + Vector3.new(0, 2.5, 0)
			FX.Burst(at, "Star", 10, { Color = Color3.fromRGB(190, 230, 255), Scale = 0.7 })
			FX.Sound("DogBark", at)
			if FX.IsMe(userId) then
				FX.Popup(at + Vector3.new(0, 1.5, 0), "GOOD DOG!", Color3.fromRGB(170, 230, 255), 2)
				dropGui(self)
			end
		end,

	},

	Bone = {
		Init = function(self: any, props: any)
			self.Follow = FX.OnPlate(props.Tag, self.Origin)
			self.Delay = tonumber(props.Delay) or 0
			self.Parts = partsOf(self)
			for _, entry in self.Parts do
				entry.Size = entry.Part.Size
				entry.Part.Transparency = 1
			end
		end,

		Step = function(self: any, _dt: number, t: number)
			local base = self.Follow()
			local since = t - self.Delay
			local pop = FX.Ease.Back(FX.Clamp01(since / 0.5))
			local taken = if self.TakenAt then FX.Clamp01((t - self.TakenAt) / 0.3) else 0
			local scale = math.max(pop * (1 - taken), 0.02)
			local gone = since <= 0 or taken >= 1
			for _, entry in self.Parts do
				local o: CFrame = entry.Offset
				entry.Part.Size = entry.Size * scale
				entry.Part.CFrame = base * CFrame.new(o.Position * scale) * (o - o.Position)
				entry.Part.Transparency = if gone then 1 else entry.Transparency
			end
		end,

		Taken = function(self: any, _userId: number)
			self.TakenAt = self:Time()
		end,
	},
})
