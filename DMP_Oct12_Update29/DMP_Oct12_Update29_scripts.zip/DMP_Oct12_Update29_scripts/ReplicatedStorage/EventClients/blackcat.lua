-- ModuleScript: ReplicatedStorage > EventClients > blackcat     (NEW: Oct 12 Update 26, Black Cat's Favour)
-- What the black cat looks like on each client: the model Cat under ServerScriptService > Events > BlackCatsFavour pads
-- from plate to plate along the server's route (the same sums: catAt), legs stepping and tail swaying, hopping the gaps,
-- and sits down at every stop. Petting it = a happy flick of the tail and a swirl of little purple sparks.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
if not (FX.Root and FX.UseSounds) then
	warn("[blackcat] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for. Install the WHOLE update (drag its .rbxmx in).")
end

--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	CatPurr = { Id = "", Stand = "", Speed = 1, Volume = 0.6 },  -- somebody pets it
	CatMeow = { Id = "", Stand = "", Speed = 1, Volume = 0.6 },  -- it arrives
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

local CAT_SCALE = 1.1
local HOP = 2
local STEP = 5              -- leg swings a second while walking
local SPARK = Color3.fromRGB(190, 140, 255)

-- KEEP THE SAME as catAt in ServerScriptService > Events > BlackCatsFavour
local function catAt(route: { number }, speed: number, sit: number, t: number): (number, number, number, number, boolean)
	local clock = 0
	local n = math.floor(#route / 2)
	for i = 1, n do
		local x, z = route[2 * i - 1], route[2 * i]
		local nx, nz = route[2 * i + 1], route[2 * i + 2]
		if t < clock + sit or not nx then
			local fx, fz = 0, -1
			if i > 1 then
				fx, fz = x - route[2 * i - 3], z - route[2 * i - 2]
			end
			return x, z, fx, fz, true
		end
		clock += sit
		local length = math.sqrt((nx - x) ^ 2 + (nz - z) ^ 2)
		local walk = length / speed
		if t < clock + walk then
			local u = (t - clock) / math.max(walk, 1e-3)
			return x + (nx - x) * u, z + (nz - z) * u, nx - x, nz - z, false
		end
		clock += walk
	end
	return route[#route - 1], route[#route], 0, -1, true
end

return FX.Module({
	Cat = {
		Init = function(self: any, props: any)
			local model = self.Inst
			if model:IsA("Model") and CAT_SCALE ~= 1 then
				model:ScaleTo(model:GetScale() * CAT_SCALE)
			end
			local pivot = model:GetPivot()
			local inverse = pivot:Inverse()
			self.Scale = if model:IsA("Model") then model:GetScale() else 1
			self.Parts = {}
			for _, part in model:GetChildren() do
				if part:IsA("BasePart") and part.Name ~= "Root" then
					local hip = part:GetAttribute("Hip")
					table.insert(self.Parts, {
						Part = part, Offset = inverse * part.CFrame, Name = part.Name,
						Hip = if typeof(hip) == "Vector3" then hip * self.Scale else nil,
						Tail = tonumber(string.match(part.Name, "^Tail(%d+)$")),
					})
				end
			end
			local map = workspace:FindFirstChild("Map")
			local plates = map and map:FindFirstChild("Plates")
			if plates then
				local params = RaycastParams.new()
				params.FilterType = Enum.RaycastFilterType.Include
				params.FilterDescendantsInstances = { plates }
				self.Ray = params
			end
			self.Ground = tonumber(props.Top) or self.Origin.Position.Y
			self.Yaw = 0
			FX.Sound("CatMeow", self.Origin.Position)
		end,

		Step = function(self: any, dt: number, t: number)
			local props = self.Props
			local x, z, fx, fz, sitting = catAt(props.Route or {}, tonumber(props.Speed) or 9, tonumber(props.Sit) or 2.5, t)
			local top = tonumber(props.Top) or self.Origin.Position.Y
			local over = false
			if self.Ray then
				local hit = workspace:Raycast(Vector3.new(x, top + 60, z), Vector3.new(0, -120, 0), self.Ray)
				if hit and hit.Normal.Y > 0.7 then
					self.Ground += (hit.Position.Y - self.Ground) * math.min(dt * 10, 1)
					over = true
				end
			end
			-- over a gap: a springy leap (the height follows the gap: highest in its middle)
			local hop = 0
			if not over and not sitting then
				self.GapT = (self.GapT or 0) + dt
				hop = HOP * math.sin(math.min(self.GapT / 0.6, 1) * math.pi)
			else
				self.GapT = 0
			end
			local want = math.atan2(-fx, -fz)
			local delta = (want - self.Yaw + math.pi) % (2 * math.pi) - math.pi
			self.Yaw += delta * math.min(dt * 8, 1)
			local sit = if sitting then 1 else 0
			self.SitK = (self.SitK or 0) + (sit - (self.SitK or 0)) * math.min(dt * 6, 1)
			local body = CFrame.new(x, self.Ground + hop, z) * CFrame.Angles(0, self.Yaw, 0) * CFrame.new(0, -0.3 * self.SitK, 0.3 * self.SitK) * CFrame.Angles(math.rad(25) * self.SitK, 0, 0)
			local swing = if sitting then 0 else math.sin(t * STEP * math.pi) * math.rad(35)
			local flick = if self.PetAt and t - self.PetAt < 1 then math.sin((t - self.PetAt) * 20) * 0.5 else 0
			for _, piece in self.Parts do
				local cf = body * piece.Offset
				if piece.Hip then
					local front = string.sub(piece.Name, 4, 4) == "F"
					local left = string.sub(piece.Name, 5, 5) == "L"
					local a = swing * (if front == left then 1 else -1)
					if sitting and not front then
						a = math.rad(-60) * self.SitK
					end
					local hip = CFrame.new(piece.Hip)
					cf = body * hip * CFrame.Angles(a, 0, 0) * hip:Inverse() * piece.Offset
				elseif piece.Tail then
					cf = body * CFrame.new(0, 0, 1.4 * self.Scale) * CFrame.Angles(0, math.sin(t * 2 + piece.Tail * 0.5) * 0.25 * piece.Tail / 5 + flick, 0) * CFrame.new(0, 0, -1.4 * self.Scale) * piece.Offset
				end
				piece.Part.CFrame = cf
			end
		end,

		-- somebody petted it
		Pet = function(self: any, userId: number, _luck: string)
			self.PetAt = self:Time()
			local root = FX.Root(userId)
			FX.Burst((root and root.Position) or self.Origin.Position, "Star", 12, { Color = SPARK, Scale = 0.6 })
			FX.Sound("CatPurr", self.Origin.Position)
		end,
	},
})
