-- ModuleScript: ReplicatedStorage > EventClients > confession     (NEW: Oct 12 Update 27, Midnight Confession)
-- What Midnight Confession looks like on each client: the booth (the model Booth under ServerScriptService > Events >
-- MidnightConfession) grinds up out of its plate in a cloud of dust, its lantern glowing; each confession tolls the
-- bell on its roof (it swings on its Hinge); a lifted curse rises off the player as dark wisps and a pale glow. At the
-- end it sinks back into the plate. It rides on its plate. It is SOLID (never see-through).
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
if not (FX.OnPlate and FX.UseSounds) then
	warn("[confession] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in).")
end

--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	BoothRise = { Id = "", Stand = "rbxasset://sounds/action_falling.mp3", Speed = 0.5, Volume = 0.4 }, -- it grinds up / down
	BellToll = { Id = "", Stand = "rbxasset://sounds/electronicpingshort.wav", Speed = 0.35, Volume = 0.6 }, -- the bell
	CurseLift = { Id = "", Stand = "", Speed = 1, Volume = 0.5 },                                       -- a curse lifted
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

local RISE = 2              -- seconds it takes to rise and to sink (KEEP about the server's RISE)
local DEPTH = 10.5          -- studs under the plate it starts from
local SWING = 2.4           -- seconds the bell swings after a toll
local SWING_ANGLE = 35      -- degrees, at first
local DUST = Color3.fromRGB(110, 100, 90)
local PALE = Color3.fromRGB(220, 210, 255)
local DARK = Color3.fromRGB(40, 30, 50)

return FX.Module({
	Booth = {
		Init = function(self: any, props: any)
			self.Follow = FX.OnPlate(props.Tag, self.Origin)
			self.Rise = tonumber(props.Rise) or RISE
			local inverse = self.Origin:Inverse()
			self.Parts = {}
			for _, part in self.Inst:GetChildren() do
				if part:IsA("BasePart") and part.Name ~= "Root" then
					local hinge = part:GetAttribute("Hinge")
					table.insert(self.Parts, { Part = part, Offset = inverse * part.CFrame, Hinge = if typeof(hinge) == "Vector3" then hinge else nil })
				end
			end
			local lamp = self.Inst:FindFirstChild("Lamp")
			self.Light = lamp and lamp:FindFirstChildOfClass("PointLight")
			self.Brightness = self.Light and self.Light.Brightness or 0.8
			self.Tolls = {}
		end,

		Step = function(self: any, _dt: number, t: number)
			local base = self.Follow()
			local duration = tonumber(self.Props.Duration) or 20
			local up = FX.Ease.Out(FX.Clamp01(t / self.Rise)) * (1 - FX.Ease.In(FX.Clamp01((t - (duration - self.Rise)) / self.Rise)))
			local moving = up > 0.01 and up < 0.99
			if moving and (not self.DustAt or t - self.DustAt > 0.25) then
				self.DustAt = t
				FX.Burst(base.Position + Vector3.new(0, 0.5, 0), "Dust", 6, { Color = DUST, Scale = 1.2 })
				if not self.Ground or t - self.Ground > 2.5 then
					self.Ground = t
					FX.Sound("BoothRise", base.Position)
				end
			end
			-- the bell: every toll adds a swing that dies away
			local angle = 0
			for index = #self.Tolls, 1, -1 do
				local k = (t - self.Tolls[index]) / SWING
				if k >= 1 then
					table.remove(self.Tolls, index)
				elseif k >= 0 then
					angle += math.rad(SWING_ANGLE) * math.sin(k * math.pi * 5) * (1 - k)
				end
			end
			local lift = CFrame.new(0, -DEPTH * (1 - up), 0)
			for _, entry in self.Parts do
				local cf = base * lift
				if entry.Hinge then
					cf *= CFrame.new(entry.Hinge) * CFrame.Angles(angle, 0, 0) * CFrame.new(-entry.Hinge)
				end
				entry.Part.CFrame = cf * entry.Offset
			end
			if self.Light then
				local flare = if self.FlareAt then 3 * math.max(1 - (t - self.FlareAt) / 1.2, 0) else 0
				self.Light.Brightness = self.Brightness * (up + flare) * (1 + 0.1 * FX.Noise(2, t * 3))
			end
		end,

		-- somebody confessed: the bell tolls; lifted = a curse came off them
		Toll = function(self: any, userId: number, lifted: boolean)
			local now = self:Time()
			table.insert(self.Tolls, now)
			self.FlareAt = now
			local bell = (self.Follow() * CFrame.new(0, 9.3, 0)).Position
			FX.Sound("BellToll", bell)
			self:After(0.48, function()
				FX.Sound("BellToll", bell)
			end)
			local root = FX.Root(userId)
			if root and lifted then
				FX.Burst(root.Position, "Smoke", 14, { Color = DARK, Scale = 1 })
				FX.Burst(root.Position + Vector3.new(0, 1.5, 0), "Glow", 10, { Color = PALE, Scale = 0.9 })
				FX.Sound("CurseLift", root.Position)
			elseif root then
				FX.Burst(root.Position + Vector3.new(0, 1.5, 0), "Glow", 5, { Color = PALE, Scale = 0.6 })
			end
		end,
	},
})
