-- ModuleScript: ReplicatedStorage > EventClients > werewolf     (NEW AGAIN: Oct 12 Update 28, Werewolf Moon)
-- "The gun doesn't work. fix it.": THIS MODULE WAS MISSING from your game (it came with Oct 8 Update 1 and did not
-- get in). Events > WerewolfMoon gives the hunter the Silver Pistol and checks every shot, but it only hears a shot
-- when this module tells it one. Rebuilt here from Events > WerewolfMoon (unchanged):
--   THE HUNTER (only on their client): while the Silver Pistol is in their hand, a crosshair, and a click / tap
--     sends "Shoot" with the point aimed at (the server decides what the silver bullet hit; FIRE_RATE apart).
--   EVERYONE: each shot is a silver streak from the pistol, sparks where it hit, "-8" over the werewolf when it is
--     hit, and "OOPS!" over the hunter when they hit somebody else.
local Players = game:GetService("Players")
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
if not (FX.UseSounds and FX.Popup and FX.Lightning) then
	warn("[werewolf] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for. Install the WHOLE update (drag its .rbxmx in).")
end

--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	SilverShot = { Id = "", Stand = "rbxasset://sounds/swordslash.wav", Speed = 1.6, Volume = 0.6 }, -- a shot
	SilverHit = { Id = "", Stand = "rbxasset://sounds/electronicpingshort.wav", Speed = 1.2, Volume = 0.5 }, -- it hit the werewolf
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

local FIRE_RATE = 0.4       -- KEEP the same as FIRE_RATE in Events > WerewolfMoon
local CROSSHAIR = "rbxasset://textures/GunCursor.png"
local SILVER = Color3.fromRGB(215, 222, 235)
local RED = Color3.fromRGB(230, 60, 60)

-- the Silver Pistol in my hand right now (nil = not holding it)
local function myGun(name: string): Tool?
	local character = Players.LocalPlayer.Character
	local tool = character and character:FindFirstChildOfClass("Tool")
	if tool and (tool.Name == name or tool:GetAttribute("WerewolfGun") == true) then
		return tool
	end
	return nil
end

return FX.Module({
	Hunt = {
		Init = function(self: any, props: any)
			self.Hunter = tonumber(props.Hunter) or 0
			self.Wolf = tonumber(props.Wolf) or 0
			self.GunName = tostring(props.Gun or "Silver Pistol")
			self.Mine = FX.IsMe(self.Hunter)
			self.LastShot = -math.huge
			if self.Mine then
				self.Mouse = Players.LocalPlayer:GetMouse()
				self.OldIcon = self.Mouse.Icon
			end
		end,

		Step = function(self: any)
			if not self.Mine or self.Over then
				return
			end
			-- hook the pistol up as soon as it is in my hand (and again if it is put away and taken out)
			local gun = myGun(self.GunName)
			if gun ~= self.Gun then
				self.Gun = gun
				if self.GunConnection then
					self.GunConnection:Disconnect()
					self.GunConnection = nil
				end
				if gun then
					self.GunConnection = self:Keep(gun.Activated:Connect(function()
						if self.Over or FX.Now() - self.LastShot < FIRE_RATE then
							return
						end
						local mouse = self.Mouse
						local character = Players.LocalPlayer.Character
						if character then
							mouse.TargetFilter = character
						end
						self.LastShot = FX.Now()
						self:Send("Shoot", mouse.Hit.Position)
					end))
				end
			end
			local icon = if gun then CROSSHAIR else (self.OldIcon or "")
			if self.Mouse.Icon ~= icon then
				self.Mouse.Icon = icon
			end
		end,

		-- every shot: kind = "wolf" (hit the werewolf), "oops" (hit someone else), "miss"
		Shot = function(_self: any, _hunter: number, from: Vector3, to: Vector3, kind: string, victim: number)
			FX.Lightning(from, to, SILVER, 0.12, 0.15, 0)
			FX.Sound("SilverShot", from)
			if kind == "wolf" then
				FX.Burst(to, "Spark", 10, { Color = SILVER, Scale = 0.8 })
				FX.Sound("SilverHit", to)
				local root = FX.Root(victim)
				if root then
					FX.Popup(root.Position + Vector3.new(0, 3, 0), "-8", RED, 2)
				end
			elseif kind == "oops" then
				FX.Burst(to, "Spark", 6, { Color = SILVER, Scale = 0.6 })
				local root = FX.Root(_hunter)
				if root then
					FX.Popup(root.Position + Vector3.new(0, 3, 0), "OOPS!", RED, 2)
				end
			else
				FX.Burst(to, "Dust", 4, { Color = Color3.fromRGB(150, 150, 150), Scale = 0.5 })
			end
		end,

		-- the moon sets: the crosshair goes
		Over = function(self: any)
			self.Over = true
			if self.Mouse then
				self.Mouse.Icon = self.OldIcon or ""
			end
		end,

		Done = function(self: any)
			if self.Mouse then
				self.Mouse.Icon = self.OldIcon or ""
			end
		end,
	},
})
