-- ModuleScript: ReplicatedStorage > EventClients > patch     (NEW: Oct 12 Update 27, Pumpkin Patch)
-- What the Pumpkin Patch looks like on each client. The server (Events > PumpkinPatch) makes the prompts and gives
-- what is inside; this draws each pumpkin (the model Pumpkin under ServerScriptService > Events > PumpkinPatch): it
-- sprouts out of the plate one after another, sits there with a little wobble, and when somebody smashes it the ribs
-- burst apart and tumble away with a splash of pulp; what came out floats over it on the smasher's screen. The ones
-- nobody smashed sink back into the plate at the end. It rides on its plate.
-- Restyle the model there; keep the names Rib1..6 (they fly apart), the rest just shrinks.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
if not (FX.OnPlate and FX.UseSounds and FX.Popup) then
	warn("[patch] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in).")
end

-- Sounds: paste your own ids into Id (Stand = a Roblox stand-in; "" = silence)
--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	PumpkinSprout = { Id = "", Stand = "", Speed = 1, Volume = 0.4 },                                   -- one pops up
	PumpkinSmash = { Id = "", Stand = "rbxasset://sounds/collide.wav", Speed = 0.6, Volume = 0.7 },     -- smashed
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

local GROW = 0.8            -- seconds it takes to sprout
local SINK = 1.0            -- seconds it takes to sink back at the end
local BURST = 1.2           -- seconds the ribs fly when it is smashed
local PULP = Color3.fromRGB(214, 128, 48)
local WHAT = {              -- what floats over it on the smasher's screen
	Heal = { "+HP", Color3.fromRGB(120, 220, 120) },
	Speed = { "SPEED!", Color3.fromRGB(150, 210, 255) },
	Item = { "ITEM!", Color3.fromRGB(255, 205, 80) },
	HopStone = { "HOP STONE!", Color3.fromRGB(220, 220, 210) },
}

return FX.Module({
	Pumpkin = {
		Init = function(self: any, props: any)
			self.Follow = FX.OnPlate(props.Tag, self.Origin)
			self.Delay = tonumber(props.Delay) or 0
			self.Scale = tonumber(props.Size) or 1
			local inverse = self.Origin:Inverse()
			self.Parts = {}
			for _, part in self.Inst:GetChildren() do
				if part:IsA("BasePart") and part.Name ~= "Root" then
					local offset = inverse * part.CFrame
					table.insert(self.Parts, {
						Part = part, Offset = offset, Size = part.Size, Transparency = part.Transparency,
						Rib = string.sub(part.Name, 1, 3) == "Rib",
						Out = FX.Flat(offset.Position).Unit, Spin = Vector3.new(math.random() - 0.5, math.random() - 0.5, math.random() - 0.5) * 10,
					})
					part.Transparency = 1
				end
			end
		end,

		Step = function(self: any, _dt: number, t: number)
			local base, there = self.Follow()
			local duration = tonumber(self.Props.Duration) or 20
			local since = t - self.Delay
			if since > 0 and not self.Sprouted then
				self.Sprouted = true
				FX.Sound("PumpkinSprout", base.Position)
				FX.Burst(base.Position, "Dust", 5, { Color = Color3.fromRGB(90, 80, 70), Scale = 0.6 })
			end
			local grown = FX.Ease.Back(FX.Clamp01(since / GROW))
			local sink = FX.Ease.In(FX.Clamp01((t - (duration - SINK)) / SINK))
			if not there and self.WasThere then
				sink = 1 -- (its plate is gone)
			end
			self.WasThere = self.WasThere or there
			local smashed = if self.SmashedAt then FX.Clamp01((t - self.SmashedAt) / BURST) else 0
			local scale = math.max(grown * (1 - sink), 0.02) * self.Scale
			-- a lazy wobble while it sits there
			local wobble = CFrame.Angles(math.rad(3) * math.sin(t * 2.1 + self.Delay * 5), 0, math.rad(3) * math.sin(t * 1.7 + self.Delay * 3))
			local gone = since <= 0 or sink >= 1 or smashed >= 1
			for _, entry in self.Parts do
				local o: CFrame = entry.Offset
				local part: BasePart = entry.Part
				local cf = base * wobble * CFrame.new(o.Position * scale) * (o - o.Position)
				if smashed > 0 then
					if entry.Rib then
						-- the ribs fly out and down, tumbling
						cf = CFrame.new(cf.Position + entry.Out * 5 * smashed + Vector3.new(0, 4 * smashed - 6 * smashed * smashed, 0))
							* CFrame.fromEulerAnglesXYZ(entry.Spin.X * smashed, entry.Spin.Y * smashed, entry.Spin.Z * smashed)
					end
					part.Size = entry.Size * scale * (if entry.Rib then 1 else math.max(1 - smashed * 2, 0.02))
				else
					part.Size = entry.Size * scale
				end
				part.CFrame = cf
				part.Transparency = if gone then 1 else entry.Transparency
			end
		end,

		-- somebody smashed it: what = "Heal" / "Speed" / "Item" / "HopStone"
		Smash = function(self: any, userId: number, what: string)
			self.SmashedAt = self:Time()
			local at = (self.Follow()).Position + Vector3.new(0, 1, 0)
			FX.Sound("PumpkinSmash", at)
			FX.Burst(at, "Drop", 14, { Color = PULP, Scale = 0.7 })
			FX.Burst(at, "Dust", 6, { Color = Color3.fromRGB(150, 90, 40), Scale = 0.8 })
			if FX.IsMe(userId) then
				local show = WHAT[what]
				if show then
					FX.Popup(at + Vector3.new(0, 1.5, 0), show[1], show[2], 2.2)
				end
			end
		end,
	},
})
