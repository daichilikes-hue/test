-- ModuleScript: ReplicatedStorage > EventClients > owl     (NEW: Oct 12 Update 26, Owl's Feather)
-- What Owl's Feather looks like on each client: the owl (the model Owl under ServerScriptService > Events > OwlsFeather)
-- glides across the arena flapping slowly; each feather (the model Feather) drifts down from it, swaying, onto its plate
-- and lies there until somebody takes it (it whirls up to them) or the wind takes it at the end.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
if not (FX.OnPlate and FX.UseSounds) then
	warn("[owl] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for. Install the WHOLE update (drag its .rbxmx in).")
end

--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	OwlHoot = { Id = "", Stand = "", Speed = 1, Volume = 0.7 },                                         -- the owl calls as it comes in
	FeatherTake = { Id = "", Stand = "rbxasset://sounds/electronicpingshort.wav", Speed = 0.6, Volume = 0.3 }, -- somebody takes a feather
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

local OWL_SCALE = 1.4
local FLAP = 1.6            -- wing beats a second
local FLAP_ANGLE = 30
local SWAY = 1.6            -- studs a falling feather sways from side to side

-- a model's parts as offsets from its pivot (for posing them by hand)
local function offsets(model: Instance, origin: CFrame): { { Part: BasePart, Offset: CFrame, Transparency: number } }
	local out = {}
	local inverse = origin:Inverse()
	for _, part in model:GetDescendants() do
		if part:IsA("BasePart") and part.Name ~= "Root" then
			table.insert(out, { Part = part, Offset = inverse * part.CFrame, Transparency = part.Transparency })
		end
	end
	return out
end

return FX.Module({
	Owl = {
		Init = function(self: any, props: any)
			local model = self.Inst
			if model:IsA("Model") and OWL_SCALE ~= 1 then
				model:ScaleTo(model:GetScale() * OWL_SCALE)
			end
			local pivot = model:GetPivot()
			self.Body = {}
			self.Wings = {}
			local inverse = pivot:Inverse()
			for _, side in { "L", "R" } do
				local wing = model:FindFirstChild("Wing" .. side)
				local root = wing and wing:FindFirstChild("Root")
				if wing and root and root:IsA("BasePart") then
					local hinge = inverse * root.CFrame
					local parts = {}
					for _, part in wing:GetChildren() do
						if part:IsA("BasePart") and part.Name ~= "Root" then
							table.insert(parts, { Part = part, Offset = root.CFrame:Inverse() * part.CFrame })
						end
					end
					table.insert(self.Wings, { Hinge = hinge, Parts = parts, Side = if side == "L" then 1 else -1 })
				end
			end
			for _, part in model:GetChildren() do
				if part:IsA("BasePart") and part.Name ~= "Root" then
					table.insert(self.Body, { Part = part, Offset = inverse * part.CFrame })
				end
			end
			self.A = Vector3.new(props.Ax, props.Y, props.Az)
			self.B = Vector3.new(props.Bx, props.Y, props.Bz)
			FX.Sound("OwlHoot", self.A)
		end,

		Step = function(self: any, _dt: number, t: number)
			local fly = tonumber(self.Props.Fly) or 9
			local u = t / fly
			local at = self.A:Lerp(self.B, u) + Vector3.new(0, math.sin(t * FLAP * math.pi * 2) * 0.4, 0)
			local frame = CFrame.lookAt(at, at + (self.B - self.A))
			for _, piece in self.Body do
				piece.Part.CFrame = frame * piece.Offset
			end
			local flap = math.rad(FLAP_ANGLE) * math.sin(t * FLAP * math.pi * 2)
			for _, wing in self.Wings do
				local hinge = frame * wing.Hinge * CFrame.Angles(0, 0, wing.Side * flap)
				for _, piece in wing.Parts do
					piece.Part.CFrame = hinge * piece.Offset
				end
			end
			local hidden = u > 1.05
			if hidden ~= self.Hidden then
				self.Hidden = hidden
				for _, piece in self.Body do
					piece.Part.Transparency = if hidden then 1 else 0
				end
				for _, wing in self.Wings do
					for _, piece in wing.Parts do
						piece.Part.Transparency = if hidden then 1 else 0
					end
				end
			end
		end,
	},

	Feather = {
		Init = function(self: any, props: any)
			self.Pieces = offsets(self.Inst, self.Inst:GetPivot())
			self.Follow = FX.OnPlate(props.Tag, self.Origin)
			self.Spin = math.random() * math.pi * 2
			for _, piece in self.Pieces do
				piece.Part.Transparency = 1
			end
		end,

		Step = function(self: any, _dt: number, t: number)
			local props = self.Props
			local drop = tonumber(props.DropAt) or 0
			local fall = tonumber(props.Fall) or 2.6
			local duration = tonumber(props.Duration) or 20
			local since = t - drop
			local frame: CFrame
			local shown = since > 0
			local landed = self.Follow() * CFrame.new(0, 0.15, 0) * CFrame.Angles(0, self.Spin, 0) * CFrame.Angles(0, 0, math.rad(84))
			if self.TakenAt then
				local root = FX.Root(self.TakenBy or 0)
				local k = FX.Clamp01((t - self.TakenAt) / 0.5)
				local to = if root then root.Position else landed.Position + Vector3.new(0, 4, 0)
				frame = CFrame.new(landed.Position:Lerp(to, k)) * CFrame.Angles(0, t * 12, 0)
				shown = k < 1
			elseif since < fall then
				local from: Vector3 = props.From
				local k = FX.Clamp01(since / fall)
				local sway = math.sin(since * 3.2) * SWAY * (1 - k)
				local p = from:Lerp(landed.Position, FX.Ease.Smooth(k)) + Vector3.new(sway, 0, sway * 0.5)
				frame = CFrame.new(p) * CFrame.Angles(0, self.Spin + since * 1.5, math.sin(since * 3.2) * 0.6)
			else
				-- lying on its plate; blown away at the end
				local away = FX.Clamp01((t - (duration - 1.2)) / 1.2)
				frame = landed + Vector3.new(away * 12, away * 6, 0)
				shown = away < 1
			end
			for _, piece in self.Pieces do
				piece.Part.CFrame = frame * piece.Offset
				piece.Part.Transparency = if shown then piece.Transparency else 1
			end
		end,

		Taken = function(self: any, userId: number)
			self.TakenAt = self:Time()
			self.TakenBy = userId
			local root = FX.Root(userId)
			if root then
				FX.Burst(root.Position, "Star", 8, { Color = Color3.fromRGB(230, 220, 200), Scale = 0.6 })
				FX.Sound("FeatherTake", root.Position)
			end
		end,
	},
})
