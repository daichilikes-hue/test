-- ModuleScript: ReplicatedStorage > EventClients > dig     (NEW: Oct 12 Update 26, Digging Site)
-- What the Digging Site looks like on each client: the dig spot (the model DigSpot under ServerScriptService > Events >
-- DiggingSite) on its plate; the shovel bites in with a spray of dirt at every good stroke and the mound sinks; dug up =
-- the hole opens and the find flies out. On the DIGGER's screen only: the ScreenGui DigGui (same script): a marker
-- swings along the bar; press (SPACE, E, click or tap the bar) when it is in the lit zone. Judged by the server.
local UserInputService = game:GetService("UserInputService")
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
if not (FX.OnPlate and FX.Gui and FX.UseSounds) then
	warn("[dig] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for. Install the WHOLE update (drag its .rbxmx in).")
end

--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	DigStroke = { Id = "", Stand = "rbxasset://sounds/clickfast.wav", Speed = 0.45, Volume = 0.7 },          -- a good stroke
	DigMiss = { Id = "", Stand = "rbxasset://sounds/clickfast.wav", Speed = 1.6, Volume = 0.4 },            -- the shovel jams
	DigFound = { Id = "", Stand = "rbxasset://sounds/electronicpingshort.wav", Speed = 0.8, Volume = 0.6 }, -- dug it up
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

local GOLD = Color3.fromRGB(255, 200, 110)
local DIRT = Color3.fromRGB(90, 66, 48)

-- KEEP THE SAME as markerAt in ServerScriptService > Events > DiggingSite
local function markerAt(start: number, period: number, t: number): number
	local u = ((t - start) / period) % 1
	return if u < 0.5 then u * 2 else 2 - u * 2
end

local function panelOf(gui: ScreenGui?): Instance?
	return gui and gui:FindFirstChild("Panel")
end

local function setPips(self: any, hits: number)
	local panel = panelOf(self.Gui)
	for k = 1, 3 do
		local pip = panel and panel:FindFirstChild("Pip" .. k)
		if pip and pip:IsA("GuiObject") then
			pip.BackgroundColor3 = if k <= hits then GOLD else Color3.fromRGB(50, 36, 30)
		end
	end
end

local function status(self: any, text: string)
	local panel = panelOf(self.Gui)
	local label = panel and panel:FindFirstChild("Status")
	if label and label:IsA("TextLabel") then
		label.Text = text
	end
end

return FX.Module({
	DigSpot = {
		Init = function(self: any, props: any)
			self.Follow = FX.OnPlate(props.Tag, self.Origin)
			local inverse = self.Inst:GetPivot():Inverse()
			self.Pieces = {}
			for _, part in self.Inst:GetDescendants() do
				if part:IsA("BasePart") and part.Name ~= "Root" then
					table.insert(self.Pieces, {
						Part = part, Offset = inverse * part.CFrame, Size = part.Size, Transparency = part.Transparency,
						Mound = string.sub(part.Name, 1, 5) == "Mound", Shovel = part.Parent and part.Parent.Name == "Shovel", Hole = part.Name == "Hole",
					})
				end
			end
			local glint = self.Inst:FindFirstChild("Glint")
			self.Dirt = glint and glint:FindFirstChild("Dirt")
			self.Hits = 0
			self.Total = tonumber(props.Hits) or 3
			self.Bite = -10
		end,

		Step = function(self: any, _dt: number, t: number)
			local base = self.Follow()
			local dug = self.Hits / self.Total
			local bite = math.max(1 - (t - self.Bite) / 0.35, 0)
			for _, piece in self.Pieces do
				local cf = base * piece.Offset
				if piece.Mound then
					local k = 1 - 0.75 * dug
					piece.Part.Size = piece.Size * math.max(k, 0.05)
					cf = base * CFrame.new(piece.Offset.Position * Vector3.new(1, k, 1) - Vector3.new(0, 0.3 * dug, 0))
					piece.Part.Transparency = if self.Found then 1 else piece.Transparency
				elseif piece.Shovel then
					cf = base * CFrame.new(0, -0.6 * bite, 0) * piece.Offset
					piece.Part.Transparency = if self.Found then 1 else piece.Transparency
				elseif piece.Hole then
					piece.Part.Transparency = if self.Found then 0 elseif dug > 0 then 0.6 else 1
				end
				piece.Part.CFrame = cf
			end
			-- the digger's panel
			local gui: ScreenGui? = self.Gui
			local panel = panelOf(gui)
			if panel and self.Cue then
				local cue = self.Cue
				local bar = panel:FindFirstChild("Bar")
				local marker = bar and bar:FindFirstChild("Marker")
				local zone = bar and bar:FindFirstChild("Zone")
				if marker and marker:IsA("GuiObject") then
					local now = FX.Now()
					local x = if now >= cue.Start then markerAt(cue.Start, cue.Period, now) else 0
					marker.Position = UDim2.fromScale(x, 0.5)
				end
				if zone and zone:IsA("GuiObject") then
					zone.Position = UDim2.fromScale(cue.Centre, 0.5)
					zone.Size = UDim2.fromScale(cue.Width, 1)
				end
			end
		end,

		-- somebody started digging (their screen gets the panel)
		Digging = function(self: any, userId: number, hits: number)
			self.Hits = hits
			if not FX.IsMe(userId) then
				return
			end
			local gui = FX.Gui("dig", "DigGui")
			self.Gui = gui
			if not gui then
				return
			end
			self:Keep(gui)
			local panel = panelOf(gui)
			local key = panel and panel:FindFirstChild("Key")
			if key and key:IsA("TextLabel") then
				key.Text = if UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled then "TAP" else "SPACE"
			end
			local function press()
				if self.Gui and self.Cue then
					self:Send("Press", FX.Now())
				end
			end
			local bar = panel and panel:FindFirstChild("Bar")
			if bar and bar:IsA("GuiButton") then
				self:Keep(bar.Activated:Connect(press))
			end
			self:Keep(UserInputService.InputBegan:Connect(function(input, processed)
				if not processed and (input.KeyCode == Enum.KeyCode.Space or input.KeyCode == Enum.KeyCode.E) then
					press()
				end
			end))
			setPips(self, hits)
		end,

		-- the next stroke's marker (only the digger draws it)
		Cue = function(self: any, userId: number, start: number, period: number, centre: number, width: number, hits: number)
			if FX.IsMe(userId) then
				self.Cue = { Start = start, Period = period, Centre = centre, Width = width }
				setPips(self, hits)
				status(self, "Hit it in the light!")
			end
		end,

		-- a stroke: good (the shovel bites in) or a miss (it jams)
		Stroke = function(self: any, userId: number, hits: number, good: boolean)
			self.Hits = hits
			local at = (self.Follow()).Position
			if good then
				self.Bite = self:Time()
				if self.Dirt and self.Dirt:IsA("ParticleEmitter") and not FX.Off("DisableParticles") then
					self.Dirt:Emit(tonumber(self.Dirt:GetAttribute("EmitCount")) or 10)
				end
				FX.Burst(at + Vector3.new(0, 0.5, 0), "Smoke", 8, { Color = DIRT, Scale = 0.8 })
				FX.Sound("DigStroke", at)
			else
				FX.Sound("DigMiss", at)
			end
			if FX.IsMe(userId) then
				self.Cue = nil
				setPips(self, hits)
				status(self, if good then "GOOD!" else "MISSED! The shovel's stuck...")
				if good then
					FX.Shake(0.6, 12, 0.02, 0.2)
				end
			end
		end,

		-- the digger let go (walked off, knocked out)
		Free = function(self: any, userId: number)
			if FX.IsMe(userId) and self.Gui then
				self.Gui:Destroy()
				self.Gui = nil
				self.Cue = nil
			end
		end,

		-- dug up!
		Dug = function(self: any, userId: number, _item: string)
			self.Found = true
			self.Hits = self.Total
			local at = (self.Follow()).Position
			FX.Burst(at + Vector3.new(0, 1, 0), "Star", 20, { Color = GOLD, Scale = 0.9 })
			FX.Burst(at, "Smoke", 14, { Color = DIRT, Scale = 1.2 })
			FX.Sound("DigFound", at)
			if FX.IsMe(userId) and self.Gui then
				status(self, "DUG IT UP!")
				local gui = self.Gui
				task.delay(1.2, function()
					gui:Destroy()
				end)
				self.Gui = nil
			end
		end,

	},
})
