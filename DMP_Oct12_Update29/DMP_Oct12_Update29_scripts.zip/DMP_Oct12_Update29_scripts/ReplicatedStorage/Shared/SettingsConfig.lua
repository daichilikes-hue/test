-- ModuleScript: ReplicatedStorage > Shared > SettingsConfig
-- Every player setting, by category. The server only accepts keys listed here,
-- DataManager saves them, SettingsClient draws the menu from this list.
-- All settings are on/off switches and start OFF.

return {
	{
		Category = "Visual",
		Settings = {
			{ Key = "DisableScreenShake", Name = "Disable screenshake", Description = "No camera shaking." },
			{ Key = "DisableFlashing", Name = "Disable flashing lights", Description = "No bright screen flashes." },
			{ Key = "DisableTinting", Name = "Disable tinting", Description = "No color correction / screen tints." },
			{ Key = "DisableFOV", Name = "Disable FOV effects", Description = "Your field of view never zooms." },
		},
	},
	{
		Category = "Performance",
		Settings = {
			{ Key = "DisableTextures", Name = "Disable textures", Description = "The map uses plain materials." },
			{ Key = "DisableShadows", Name = "No shadows", Description = "Turns off shadows." },
			{ Key = "DisableParticles", Name = "Disable particles", Description = "Hides particles, fire and smoke." },
			{ Key = "DisableDecals", Name = "Disable decals", Description = "Hides decals and textures on parts." },
			{ Key = "DisablePostEffects", Name = "Disable post-processing", Description = "No bloom, sun rays or depth of field." },
			{ Key = "HideCosmetics", Name = "Hide Other Players' Cosmetics", Description = "Don't show other players' Vampire and Ghost looks." },
			{ Key = "DisableCosmetic", Name = "Disable My Cosmetic", Description = "Turn off your Vampire or Ghost look for everyone." },
			{ Key = "HidePetsInRound", Name = "Hide pets in rounds", Description = "Don't show pets of players in the arena." },
			{ Key = "HidePetsInLobby", Name = "Hide pets in the lobby", Description = "Don't show pets of players in the lobby." },
		},
	},
	{
		Category = "Gameplay",
		Settings = {
			{ Key = "AutoDrawTarot", Name = "Auto Draw Tarot Card", Description = "Your tarot card is drawn for you in every countdown." },
			{ Key = "SilentTarotDraw", Name = "Silent Tarot Draw", Description = "Your tarot card is drawn for you with no animation, and nothing pops up." },
		},
	},
}