-- LocalScript: StarterPlayer > StarterPlayerScripts > TarotClient     (Oct 11 Update 13: one-click draw, Your Deck)
-- The tarot on your screen (the server is ServerScriptService > TarotServer; the words are Shared > TarotConfig).
--   LITTLE CARD   bottom right, next to the AFK button. In the lobby countdown ONE CLICK on it draws your card: it
--                 flies up to the middle of the screen, charges up, flips and bursts open (TarotDrawGui), then drops
--                 back into the little card, which shows your card from then on. It glows while a draw waits for you.
--                 At any other time a click opens or closes the tarot panel (your card, the ghost flip).
--   AUTO DRAW     the setting "Auto Draw Tarot Card" (Settings > Gameplay) draws it for you in every countdown.
--   GHOST FLIP    in the panel, once you're knocked out: FLIP turns a card and something small happens in the arena.
--   YOUR READING  the card you earned for how you played. A winner sees it when the round ends. If you were knocked
--                 out it WAITS: a second little card glows next to the first one, and a click on it shows it
--                 (HOLD_READINGS below). It goes when the next round starts (it is in your deck anyway).
--   YOUR DECK     every card, both ways up, and how each is earned (TarotDeckGui). Opens from the side bar button
--                 (SHOW_SIDEBAR below), from the Fortune Teller's window, or from any script with UIBus.Fire("OpenTarot").
--   THE FORTUNE TELLER's window: her card for you today, her words, her gift.
-- Made once and CLONED (they are children of this script): Card (every card on the screen), TarotDrawGui (the draw),
-- TarotDeckGui (Your Deck). Restyle them in Studio; keep their names.
-- Pictures: CARD_BACK / CARD_FACE below (yours, uploaded) and TarotConfig.Cards[...].Art (a card's own picture).
-- The screen effects of the draw (tint, zoom, shake, blur, flash) go through ReplicatedStorage > Utility, so the
-- player's Settings switches count.
local Debris = game:GetService("Debris")
local GuiService = game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")
local TweenService = game:GetService("TweenService")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local TarotConfig = require(Shared:WaitForChild("TarotConfig"))
local UIKit = require(Shared:WaitForChild("UIKit"))

local function optional(name: string): any
	local module = Shared:FindFirstChild(name)
	if module and module:IsA("ModuleScript") then
		local ok, result = pcall(require, module)
		if ok then
			return result
		end
	end
	return nil
end
local SideBar = optional("SideBar")
local Toast = optional("Toast")
local UIBus = optional("UIBus")

-- ReplicatedStorage > Utility: the camera / screen effects of the draw (they follow the player's Settings)
local Utility: any = nil
do
	local module = ReplicatedStorage:FindFirstChild("Utility")
	if module and module:IsA("ModuleScript") then
		local ok, result = pcall(require, module)
		if ok then
			Utility = result
		else
			warn("[TarotClient] ReplicatedStorage > Utility couldn't be loaded, so the draw has no screen effects: " .. tostring(result))
		end
	end
end

--[[DMP:KEEP Settings]]
local SHOW_SIDEBAR = true   -- false = no side bar button (the deck still opens from the Fortune Teller / UIBus)
local SIDEBAR_ORDER = 7
local SIDEBAR_ICON = ""     -- your uploaded icon ("rbxassetid://..."); "" = the letter T
local FLIP_SOUND = ""       -- your uploaded card-flip sound; "" = silent
local CARD_RIGHT = 82       -- the little card: pixels from the right edge of the screen (the AFK button covers 14 to 68)
local CARD_BOTTOM = 14      -- the little card: pixels from the bottom of the screen (the same as the AFK button)
local CARD_BACK = ""        -- your uploaded card back (TarotCardBack.png); "" = the back drawn with frames
local CARD_FACE = ""        -- your uploaded card face (TarotCardFace.png); "" = the face drawn with frames
local DRAW_SOUND = "9045122943"         -- the card charging up (its pitch climbs). Now: the Sigil Scythe's wind-up
local REVEAL_SOUND = "127348322119521"  -- the card turning over. Now: Excalibur's pull
local UPRIGHT_SOUND = ""                -- after an upright card; "" = nothing
local REVERSED_SOUND = "139726388352120" -- after a reversed card. Now: Toll the Dead's bell
local KEEP_SOUND = ""                   -- the card dropping into the little card; "" = nothing
local DECK_SOUND = ""                   -- Your Deck opening; "" = nothing
local DRAW_SECONDS = 4.5    -- how long your card stays up after it turns over (a click puts it away sooner)
local READING_SECONDS = 9   -- how long Your Reading stays up
--[[DMP:END]]
local HOLD_READINGS = true  -- true = if you were knocked out, your reading waits until you click for it (winners see it
                            -- at once); false = everybody sees it at once, as before
local AUTO_REVEAL = true    -- true = Auto Draw plays the whole draw too; false = the card just lands in the little card

local C = UIKit.Colors
local make, corner, stroke, gradient, bigText = UIKit.make, UIKit.corner, UIKit.stroke, UIKit.gradient, UIKit.bigText
local GOLD = Color3.fromRGB(214, 172, 92)
local GOLD_LIGHT = Color3.fromRGB(248, 226, 164)
local CRIMSON = Color3.fromRGB(200, 34, 46)
local BACK_TOP, BACK_BOTTOM = Color3.fromRGB(70, 14, 20), Color3.fromRGB(18, 6, 8)
local BACK_EDGE = GOLD
local UPRIGHT_COLOR = Color3.fromRGB(240, 206, 120) -- upright = gold
local REVERSED_COLOR = Color3.fromRGB(226, 72, 68)  -- reversed = red
local SOFT = Color3.fromRGB(232, 214, 196)
local DIM = Color3.fromRGB(150, 124, 110)
local INK = Color3.fromRGB(214, 170, 96)
local ACTIVE = Color3.fromRGB(255, 60, 60) -- the side bar's red (under the mouse / open)
local GHOST_GREY = Color3.fromRGB(150, 160, 170)

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")
local remote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("Tarot") :: RemoteEvent

local gui = make("ScreenGui", { Name = "TarotGui", ResetOnSpawn = false, DisplayOrder = 54, ZIndexBehavior = Enum.ZIndexBehavior.Sibling, Parent = playerGui })

local warned: { [string]: boolean } = {}
local function warnOnce(key: string, text: string)
	if not warned[key] then
		warned[key] = true
		warn("[TarotClient] " .. text)
	end
end

local function toast(title: string, text: string?)
	if Toast then
		Toast.Show(title, text, INK)
	end
end

local function asset(id: any): string
	local text = tostring(id or "")
	if text == "" or text == "0" then
		return ""
	end
	return if tonumber(text) then "rbxassetid://" .. text else text
end

-- a sound from the settings above (speed / volume optional); returns it so it can be bent while it plays
local SOUND_SECONDS = 1.5 -- every tarot sound starts fading after this many seconds
local SOUND_FADE = 0.4    -- how long the fade-out takes
local function playSound(id: string, volume: number?, speed: number?, looped: boolean?): Sound?
	local soundId = asset(id)
	if soundId == "" then
		return nil
	end
	local sound = Instance.new("Sound")
	sound.SoundId = soundId
	sound.Volume = volume or 0.6
	sound.PlaybackSpeed = speed or 1
	sound.Looped = looped == true
	sound.Parent = SoundService
	sound:Play()
	task.delay(SOUND_SECONDS, function()
		if sound.Parent then
			TweenService:Create(sound, TweenInfo.new(SOUND_FADE), { Volume = 0 }):Play()
			task.delay(SOUND_FADE, function()
				sound:Destroy()
			end)
		end
	end)
	return sound
end

local function flipSound()
	playSound(FLIP_SOUND, 0.6)
end

local function label(parent: Instance, props: { [string]: any }): TextLabel
	local textLabel = make("TextLabel", {
		BackgroundTransparency = 1, Font = UIKit.Font, TextColor3 = SOFT, TextSize = 15, TextWrapped = true,
		TextXAlignment = Enum.TextXAlignment.Center, TextYAlignment = Enum.TextYAlignment.Top, Parent = parent,
	})
	for key, value in props do
		(textLabel :: any)[key] = value
	end
	return textLabel
end

local function tween(object: Instance, time: number, props: { [string]: any }, style: Enum.EasingStyle?, direction: Enum.EasingDirection?): Tween
	local t = TweenService:Create(object, TweenInfo.new(time, style or Enum.EasingStyle.Quad, direction or Enum.EasingDirection.Out), props)
	t:Play()
	return t
end

-- may this player see bright flashes? (Settings > Disable flashing lights)
local function canFlash(): boolean
	if Utility and Utility.CanFlash then
		return Utility.CanFlash()
	end
	return player:GetAttribute("Setting_DisableFlashing") ~= true
end

---------------------------------------------------------------------- a card (a clone of the Card under this script)
type Card = {
	Frame: Frame, Full: UDim2, Back: GuiObject, Face: GuiObject, Numeral: TextLabel?, Art: ImageLabel?, Seal: GuiObject?,
	SealText: TextLabel?, SealRing: UIStroke?, Name: TextLabel?, Glow: GuiObject?, Shine: GuiObject?, Busy: number,
	Shown: string?,
}

local cardTemplate: GuiObject? = nil
do
	local found = script:FindFirstChild("Card")
	if found and found:IsA("GuiObject") then
		cardTemplate = found
	else
		warnOnce("card", "StarterPlayerScripts > TarotClient > Card (the picture of a card) is missing: install the update again, always the WHOLE file. Cards are plain until then.")
	end
end
local BACK_IMAGE, FACE_IMAGE = asset(CARD_BACK), asset(CARD_FACE)

-- (only when the Card is missing: a plain card, so nothing breaks)
local function plainCard(): Frame
	local frame = make("Frame", { Name = "Card", BackgroundTransparency = 1 })
	local back = make("Frame", { Name = "Back", Size = UDim2.fromScale(1, 1), BackgroundColor3 = Color3.new(1, 1, 1), Parent = frame })
	corner(back, UDim.new(0.07, 0))
	gradient(back, BACK_TOP, BACK_BOTTOM)
	stroke(back, BACK_EDGE, 2)
	local face = make("Frame", { Name = "Face", Size = UDim2.fromScale(1, 1), BackgroundColor3 = Color3.fromRGB(26, 16, 18), Visible = false, Parent = frame })
	corner(face, UDim.new(0.07, 0))
	stroke(face, BACK_EDGE, 2)
	bigText({ Name = "Numeral", AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.fromScale(0.5, 0.045), Size = UDim2.fromScale(0.7, 0.1), TextScaled = true, Text = "", Parent = face })
	bigText({ Name = "Name", AnchorPoint = Vector2.new(0.5, 1), Position = UDim2.fromScale(0.5, 0.955), Size = UDim2.fromScale(0.8, 0.09), TextScaled = true, Text = "", Parent = face })
	return frame
end

-- your uploaded picture on one side of a card (else the frames drawn in the Card show)
local function setSideImage(side: Instance?, image: string)
	if not side then
		return
	end
	local picture = side:FindFirstChild("Image")
	local plain = side:FindFirstChild("Plain")
	if picture and picture:IsA("ImageLabel") then
		picture.Image = image
		picture.Visible = image ~= ""
	end
	if plain and plain:IsA("GuiObject") then
		plain.Visible = image == ""
	end
end

local function newCard(parent: Instance, width: number, height: number, position: UDim2?): Card
	local frame = (if cardTemplate then cardTemplate:Clone() else plainCard()) :: Frame
	frame.AnchorPoint = Vector2.new(0.5, 0.5)
	frame.Position = position or UDim2.fromScale(0.5, 0.5)
	frame.Size = UDim2.fromOffset(width, height)
	frame.Visible = true
	-- (the lines are drawn for a 150 px card: thinner on a small one, thicker on a big one)
	local k = width / 150
	for _, item in frame:GetDescendants() do
		if item:IsA("UIStroke") then
			item.Thickness = math.max(1, item.Thickness * k)
		end
	end
	frame.Parent = parent
	local back = frame:FindFirstChild("Back") :: GuiObject
	local face = frame:FindFirstChild("Face") :: GuiObject
	setSideImage(back, BACK_IMAGE)
	setSideImage(face, FACE_IMAGE)
	local seal = face and face:FindFirstChild("Seal")
	return {
		Frame = frame, Full = frame.Size, Back = back, Face = face,
		Numeral = face and face:FindFirstChild("Numeral") :: any, Art = face and face:FindFirstChild("Art") :: any,
		Seal = seal :: any, SealText = seal and seal:FindFirstChild("SealText") :: any, SealRing = seal and seal:FindFirstChild("Ring") :: any,
		Name = face and face:FindFirstChild("Name") :: any, Glow = frame:FindFirstChild("Glow") :: any,
		Shine = face and face:FindFirstChild("Shine") :: any, Busy = 0, Shown = nil,
	}
end

local function showBack(card: Card)
	card.Back.Visible = true
	card.Face.Visible = false
	card.Shown = "back"
end

-- a reversed card isn't turned upside down (it stays readable): its numeral and its name just swap ends, and only the
-- frame picture of the face (your CARD_FACE) is turned over, so the name sits in the wide plaque again
local function layout(card: Card, upright: boolean)
	local frameArt = card.Face and card.Face:FindFirstChild("Image")
	if frameArt and frameArt:IsA("GuiObject") then
		frameArt.Rotation = if upright then 0 else 180
	end
	if card.Numeral then
		card.Numeral.AnchorPoint = Vector2.new(0.5, if upright then 0 else 1)
		card.Numeral.Position = if upright then UDim2.fromScale(0.5, 0.045) else UDim2.fromScale(0.5, 0.955)
	end
	if card.Name then
		card.Name.AnchorPoint = Vector2.new(0.5, if upright then 1 else 0)
		card.Name.Position = if upright then UDim2.fromScale(0.5, 0.955) else UDim2.fromScale(0.5, 0.045)
	end
end

local function showFace(card: Card, id: string, upright: boolean)
	local def = TarotConfig.Get(id)
	if not def then
		return
	end
	card.Back.Visible = false
	card.Face.Visible = true
	if card.Numeral then
		card.Numeral.Text = def.Numeral
	end
	if card.Name then
		card.Name.Text = string.upper(def.Name)
	end
	if card.SealRing then
		card.SealRing.Color = if upright then def.Color:Lerp(GOLD, 0.35) else CRIMSON
	end
	local art = asset(def.Art)
	if card.Art then
		card.Art.Image = art
		card.Art.Visible = art ~= ""
	end
	if card.Seal then
		card.Seal.Visible = art == ""
	end
	if card.SealText then
		card.SealText.Text = def.Numeral
	end
	layout(card, upright)
	card.Shown = id .. (if upright then "+" else "-")
end

-- a ghost flip's card (not one of the 22)
local function showMinor(card: Card, name: string)
	card.Back.Visible = false
	card.Face.Visible = true
	if card.Numeral then
		card.Numeral.Text = ""
	end
	if card.Art then
		card.Art.Visible = false
	end
	if card.Seal then
		card.Seal.Visible = true
	end
	if card.SealRing then
		card.SealRing.Color = GHOST_GREY
	end
	if card.SealText then
		card.SealText.Text = "?"
	end
	if card.Name then
		card.Name.Text = string.upper(name)
	end
	layout(card, true)
	card.Shown = "minor"
end

-- turns the card over: it narrows to nothing, `toOtherSide` swaps what's showing, and it widens again
local function flip(card: Card, toOtherSide: () -> ())
	card.Busy += 1
	local token = card.Busy
	local full = card.Full
	flipSound()
	TweenService:Create(card.Frame, TweenInfo.new(0.16, Enum.EasingStyle.Quad, Enum.EasingDirection.In), { Size = UDim2.new(0, 0, full.Y.Scale, full.Y.Offset) }):Play()
	task.delay(0.16, function()
		if card.Busy ~= token then
			return
		end
		toOtherSide()
		TweenService:Create(card.Frame, TweenInfo.new(0.24, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Size = full }):Play()
	end)
end

-- the light behind a card (colour, or nil = off)
local function glowCard(card: Card, color: Color3?)
	local glow = card.Glow
	if not glow then
		return
	end
	glow.Visible = color ~= nil
	if color then
		for _, halo in glow:GetChildren() do
			if halo:IsA("GuiObject") then
				halo.BackgroundColor3 = color
			end
		end
	end
end

-- a streak of light across the face
local function shine(card: Card, time: number?)
	local streak = card.Shine
	local sweep = streak and streak:FindFirstChildOfClass("UIGradient")
	if not (streak and sweep) then
		return
	end
	streak.Visible = true
	sweep.Offset = Vector2.new(-1, 0)
	local t = tween(sweep, time or 0.55, { Offset = Vector2.new(1, 0) }, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
	t.Completed:Once(function()
		streak.Visible = false
	end)
end

-- an X in the cards' colours (dark red, dull gold edge) for the top right corner of a panel; red under the mouse
local function closeButton(parent: Instance): TextButton
	local x = make("TextButton", {
		Name = "Close", AnchorPoint = Vector2.new(1, 0), Position = UDim2.fromScale(1, 0), Size = UDim2.fromOffset(32, 32),
		BackgroundColor3 = Color3.new(1, 1, 1), AutoButtonColor = false, Text = "", ZIndex = 6, Parent = parent,
	})
	corner(x, UDim.new(0, 8))
	gradient(x, BACK_TOP, BACK_BOTTOM)
	local edge = stroke(x, BACK_EDGE, 2)
	edge.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	local mark = bigText({ Size = UDim2.fromScale(1, 1), TextSize = 20, Text = "X", ZIndex = 7, Parent = x })
	local white = mark.TextColor3
	local function paint(hot: boolean)
		edge.Color = if hot then ACTIVE else BACK_EDGE
		mark.TextColor3 = if hot then ACTIVE else white
	end
	x.MouseEnter:Connect(function()
		paint(true)
	end)
	x.MouseLeave:Connect(function()
		paint(false)
	end)
	x.Activated:Connect(function()
		paint(false)
	end)
	return x
end

-- shrinks a panel on short screens (phones) so it still fits above the little card
local function fit(height: number): number
	local camera = workspace.CurrentCamera
	local screen = if camera then camera.ViewportSize.Y else 720
	return math.clamp((screen - CARD_BOTTOM - 160) / height, 0.45, 1)
end

---------------------------------------------------------------------- the tarot panel (your card / ghost flip), opened by the little card
local widget = make("Frame", {
	Name = "Tarot", AnchorPoint = Vector2.new(1, 1), Position = UDim2.new(1, -16, 1, -(CARD_BOTTOM + 84)), Size = UDim2.fromOffset(220, 420),
	BackgroundTransparency = 1, Visible = false, Parent = gui,
})
local widgetScale = make("UIScale", { Parent = widget })
local widgetTitle = bigText({ Position = UDim2.fromOffset(0, 0), Size = UDim2.new(1, 0, 0, 30), TextSize = 24, Text = "THE DRAW", TextColor3 = GOLD_LIGHT, Parent = widget })
local widgetCard = newCard(widget, 150, 240, UDim2.new(0.5, 0, 0, 160))
local tag = bigText({ Position = UDim2.fromOffset(0, 286), Size = UDim2.new(1, 0, 0, 22), TextSize = 18, Text = "", Parent = widget })
local blurb = label(widget, { Position = UDim2.fromOffset(4, 310), Size = UDim2.new(1, -8, 0, 64), TextSize = 14, Text = "" })
local button, setButton = UIKit.pillButton({ AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.new(0.5, 0, 0, 290), Size = UDim2.fromOffset(170, 44), Parent = widget })
local hint = label(widget, { Position = UDim2.fromOffset(4, 340), Size = UDim2.new(1, -8, 0, 44), TextSize = 13, TextColor3 = DIM, Text = "" })
local widgetX = closeButton(widget)

local mode = "none"         -- "draw", "card", "ghost", "rest", "none"
local drawing = false       -- waiting for the server's card
local flipsLeft = 0
local readingUntil = 0
local ghostShowing = false  -- a flipped ghost card is face up for a moment
local widgetOpen = false    -- the little card next to AFK opens / closes the panel (closed at first, so it takes no room)
local refresh: () -> () = function() end

-- THE LITTLE CARD, in its own ScreenGui set up like the side bar's (IgnoreGuiInset) so it lines up with the AFK button
local cardGui = make("ScreenGui", {
	Name = "TarotCardGui", ResetOnSpawn = false, IgnoreGuiInset = true, DisplayOrder = 53, ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
	Parent = playerGui,
})
local opener = make("Frame", {
	Name = "TarotCard", AnchorPoint = Vector2.new(1, 1), Position = UDim2.new(1, -CARD_RIGHT, 1, -CARD_BOTTOM),
	Size = UDim2.fromOffset(38, 54), BackgroundTransparency = 1, Parent = cardGui,
})
local openerScale = make("UIScale", { Parent = opener })
local openerCard = newCard(opener, 38, 54)
-- the rim: red under the mouse / while the panel is open (like the side bar), gold while a draw waits for you
local rim = make("Frame", {
	Name = "Rim", AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5), Size = UDim2.new(1, 6, 1, 6),
	BackgroundTransparency = 1, ZIndex = 4, Parent = opener,
})
corner(rim, UDim.new(0, 7))
local rimStroke = stroke(rim, ACTIVE, 2, 1)
local pip = make("Frame", {
	Name = "Waiting", AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.new(1, -3, 0, 3), Size = UDim2.fromOffset(13, 13),
	BackgroundColor3 = INK, Visible = false, ZIndex = 6, Parent = opener,
})
corner(pip, UDim.new(0.5, 0))
stroke(pip, Color3.fromRGB(20, 8, 10), 2)
TweenService:Create(pip, TweenInfo.new(0.7, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), { BackgroundTransparency = 0.5 }):Play()
local openerClick = make("TextButton", { Name = "Click", Size = UDim2.fromScale(1, 1), BackgroundTransparency = 1, Text = "", ZIndex = 7, Parent = opener })
local hovering = false
local inviting = false      -- a draw is waiting: the little card glows and wiggles
local function paintOpener()
	if hovering or widgetOpen then
		rimStroke.Color = ACTIVE
		rimStroke.Transparency = 0
	elseif inviting then
		rimStroke.Color = GOLD_LIGHT
		rimStroke.Transparency = 0.15
	else
		rimStroke.Transparency = 1
	end
end
local function hover(on: boolean)
	hovering = on
	paintOpener()
	TweenService:Create(openerScale, TweenInfo.new(0.1), { Scale = if on then 1.12 else 1 }):Play()
end
openerClick.MouseEnter:Connect(function()
	hover(true)
end)
openerClick.MouseLeave:Connect(function()
	hover(false)
end)

-- the invitation: while a draw waits, the little card's light pulses and it gives a little wiggle now and then
local inviteTweens: { Tween } = {}
local function setInviting(on: boolean)
	if on == inviting then
		return
	end
	inviting = on
	for _, t in inviteTweens do
		t:Cancel()
	end
	table.clear(inviteTweens)
	glowCard(openerCard, if on then GOLD else nil)
	if on and openerCard.Glow then
		for _, halo in openerCard.Glow:GetChildren() do
			if halo:IsA("GuiObject") then
				local base = halo.BackgroundTransparency
				local t = TweenService:Create(halo, TweenInfo.new(0.9, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), { BackgroundTransparency = math.min(1, base + 0.08) })
				t:Play()
				table.insert(inviteTweens, t)
			end
		end
	end
	paintOpener()
end
task.spawn(function()
	while opener.Parent do
		task.wait(2.4)
		if inviting and not hovering then
			local frame = openerCard.Frame
			tween(frame, 0.08, { Rotation = -9 })
			task.wait(0.08)
			tween(frame, 0.12, { Rotation = 8 })
			task.wait(0.12)
			tween(frame, 0.22, { Rotation = 0 }, Enum.EasingStyle.Back)
		end
	end
end)

-- YOUR READING WAITS HERE (a player who was knocked out): a second little card, left of the first one
local readingTab = make("Frame", {
	Name = "ReadingWaiting", AnchorPoint = Vector2.new(1, 1), Position = UDim2.new(1, -(CARD_RIGHT + 38 + 12), 1, -CARD_BOTTOM),
	Size = UDim2.fromOffset(32, 46), BackgroundTransparency = 1, Visible = false, Parent = cardGui,
})
local readingTabScale = make("UIScale", { Parent = readingTab })
local readingTabCard = newCard(readingTab, 32, 46)
glowCard(readingTabCard, GOLD)
local readingTabPip = make("Frame", {
	Name = "Waiting", AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.new(1, -3, 0, 3), Size = UDim2.fromOffset(12, 12),
	BackgroundColor3 = INK, ZIndex = 6, Parent = readingTab,
})
corner(readingTabPip, UDim.new(0.5, 0))
stroke(readingTabPip, Color3.fromRGB(20, 8, 10), 2)
TweenService:Create(readingTabPip, TweenInfo.new(0.7, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), { BackgroundTransparency = 0.5 }):Play()
TweenService:Create(readingTabScale, TweenInfo.new(0.9, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), { Scale = 1.08 }):Play()
local readingTabClick = make("TextButton", { Name = "Click", Size = UDim2.fromScale(1, 1), BackgroundTransparency = 1, Text = "", ZIndex = 7, Parent = readingTab })
bigText({
	Name = "Label", AnchorPoint = Vector2.new(0.5, 1), Position = UDim2.new(0.5, 0, 0, -3), Size = UDim2.fromOffset(70, 14), TextSize = 12,
	Text = "READING", TextColor3 = GOLD_LIGHT, ZIndex = 6, Parent = readingTab,
})

local function setMode(newMode: string)
	mode = newMode
	if newMode == "draw" then
		widgetTitle.Text = "THE DRAW"
		if not drawing then
			showBack(widgetCard)
		end
		button.Visible = not drawing
		setButton("DRAW A CARD", true)
		tag.Text = ""
		blurb.Text = ""
		hint.Text = "Free. Upright helps you a little, reversed hurts you a little."
	elseif newMode == "card" then
		local id = player:GetAttribute("TarotCard")
		local upright = player:GetAttribute("TarotUpright") == true
		local def = TarotConfig.Get(id)
		widgetTitle.Text = "YOUR CARD"
		button.Visible = false
		hint.Text = ""
		if def then
			if not drawing then
				showFace(widgetCard, id, upright)
			end
			tag.Text = if upright then "UPRIGHT" else "REVERSED"
			tag.TextColor3 = if upright then UPRIGHT_COLOR else REVERSED_COLOR
			blurb.Text = if upright then def.Upright else def.Reversed
		end
	elseif newMode == "ghost" then
		widgetTitle.Text = "GHOST FLIP"
		if not ghostShowing then
			showBack(widgetCard)
			tag.Text = ""
			blurb.Text = ""
		end
		button.Visible = not ghostShowing
		setButton("FLIP (" .. flipsLeft .. ")", true)
		hint.Text = if ghostShowing then "" else "Turn a card. Something small happens in the arena."
	elseif newMode == "rest" then
		widgetTitle.Text = "THE CARDS"
		showBack(widgetCard)
		button.Visible = false
		tag.Text = ""
		blurb.Text = ""
		hint.Text = if TarotConfig.DrawEnabled then "In the lobby countdown, one click on this little card draws yours." else "The cards are resting."
	end
end

---------------------------------------------------------------------- THE DRAW: the reveal on TarotDrawGui
type Mote = { Frame: GuiObject, Active: boolean, Kind: string, T0: number, Life: number, From: Vector2, To: Vector2, Vel: Vector2, Spin: number }
type StagePieces = {
	Gui: ScreenGui, Dim: Frame, Edges: { Frame }, Stage: Frame, Scale: UIScale, Rays: Frame, RayBars: { Frame }, Halos: { Frame },
	HaloBase: { number }, Rings: { Frame }, Motes: { Mote }, Spot: Frame, Title: TextLabel, Rare: TextLabel, CardName: TextLabel,
	Orientation: TextLabel, Effect: TextLabel, EffectHome: UDim2, Flash: Frame, Hint: TextLabel, Click: GuiButton, Card: Card,
	Pulse: UIScale, NamePop: UIScale, TagPop: UIScale,
}
local stageSource = script:FindFirstChild("TarotDrawGui")
local P: StagePieces? = nil

local reveal = {
	Busy = false,         -- the stage is up
	Token = 0,            -- every new draw / abort bumps it: older steps stop
	Result = nil :: { Id: string, Upright: boolean }?,
	Clicked = false,      -- a click on the stage (skip ahead / put it away)
	Phase = "",           -- "fly", "charge", "turn", "show", "keep"
	Riser = nil :: Sound?,
	Ramp = nil :: any,
	Color = nil :: any,   -- the Utility.ColorCorrection handle
	Step = nil :: RBXScriptConnection?,
	PendingClick = false, -- (the click asked the server: waiting for its card)
}

-- a click anywhere on the stage (or on the little card while it is up): skip ahead / put the card away
local function stageClicked()
	if reveal.Busy then
		reveal.Clicked = true
	end
end

local function stageFit()
	if not P then
		return
	end
	local camera = workspace.CurrentCamera
	local size = if camera then camera.ViewportSize else Vector2.new(1280, 720)
	P.Scale.Scale = math.clamp(math.min(size.Y / 640, size.X / 700), 0.48, 1.15)
end

-- finds the pieces of the stage by name (one plain warning naming what is missing)
local function setupStage(): boolean
	if P then
		return true
	end
	if not (stageSource and stageSource:IsA("ScreenGui")) then
		warnOnce("stage", "StarterPlayerScripts > TarotClient > TarotDrawGui (the draw) is missing: install the update again, always the WHOLE file. The card is drawn in the little panel until then.")
		return false
	end
	local copy = stageSource:Clone()
	copy.Enabled = false
	copy.ResetOnSpawn = false
	local missing = {}
	local function need(parent: Instance?, name: string): any
		local found = parent and parent:FindFirstChild(name)
		if not found then
			table.insert(missing, name)
		end
		return found
	end
	local stageFrame = need(copy, "Stage")
	local rays = need(stageFrame, "Rays")
	local glowFrame = need(stageFrame, "Glow")
	local motesFrame = need(stageFrame, "Motes")
	local spot = need(stageFrame, "CardSpot")
	local pieces = {
		Gui = copy, Dim = need(copy, "Dim"), Stage = stageFrame, Scale = need(stageFrame, "Scale"), Rays = rays, Spot = spot,
		Title = need(stageFrame, "Title"), Rare = need(stageFrame, "Rare"), CardName = need(stageFrame, "CardName"),
		Orientation = need(stageFrame, "Orientation"), Effect = need(stageFrame, "Effect"), Flash = need(copy, "Flash"),
		Hint = need(copy, "Hint"), Click = need(copy, "Click"), Edges = {}, RayBars = {}, Halos = {}, HaloBase = {}, Rings = {}, Motes = {},
	} :: any
	if #missing > 0 then
		warnOnce("stagenames", "TarotDrawGui has no " .. table.concat(missing, ", ") .. " (keep the names when you restyle it). The card is drawn in the little panel until then.")
		copy:Destroy()
		return false
	end
	local edges = copy:FindFirstChild("Edges")
	if edges then
		for _, edge in edges:GetChildren() do
			if edge:IsA("Frame") then
				table.insert(pieces.Edges, edge)
			end
		end
	end
	for _, ray in rays:GetChildren() do
		if ray:IsA("Frame") then
			table.insert(pieces.RayBars, ray)
		end
	end
	for index = 1, 9 do
		local halo = glowFrame and glowFrame:FindFirstChild("Halo" .. index)
		if halo and halo:IsA("Frame") then
			table.insert(pieces.Halos, halo)
			table.insert(pieces.HaloBase, halo.Size.X.Offset)
		end
	end
	for index = 1, 4 do
		local ring = stageFrame:FindFirstChild("Ring" .. index)
		if ring and ring:IsA("Frame") then
			table.insert(pieces.Rings, ring)
		end
	end
	for _, mote in motesFrame:GetChildren() do
		if mote:IsA("GuiObject") then
			table.insert(pieces.Motes, { Frame = mote, Active = false, Kind = "", T0 = 0, Life = 1, From = Vector2.zero, To = Vector2.zero, Vel = Vector2.zero, Spin = 0 })
		end
	end
	pieces.Card = newCard(spot, spot.Size.X.Offset, spot.Size.Y.Offset)
	pieces.Pulse = make("UIScale", { Name = "Pulse", Parent = pieces.Card.Frame })
	pieces.NamePop = make("UIScale", { Name = "Pop", Parent = pieces.CardName })
	pieces.TagPop = make("UIScale", { Name = "Pop", Parent = pieces.Orientation })
	pieces.EffectHome = pieces.Effect.Position
	if pieces.Click:IsA("GuiButton") then
		pieces.Click.Activated:Connect(stageClicked)
	end
	copy.Parent = playerGui
	P = pieces
	stageFit()
	return true
end

-- everything on the stage back to "nothing to see"
local function resetStage(p: StagePieces)
	p.Dim.BackgroundTransparency = 1
	for _, edge in p.Edges do
		edge.BackgroundTransparency = 1
		edge.BackgroundColor3 = Color3.fromRGB(46, 4, 10)
	end
	for _, ray in p.RayBars do
		ray.BackgroundTransparency = 1
		ray.BackgroundColor3 = GOLD_LIGHT
	end
	p.Rays.Rotation = 0
	p.Rays.Size = UDim2.fromOffset(860, 860)
	for index, halo in p.Halos do
		local base = p.HaloBase[index] or 300
		halo.BackgroundTransparency = 1
		halo.BackgroundColor3 = GOLD
		halo.Size = UDim2.fromOffset(base, base)
	end
	for _, ring in p.Rings do
		ring.Visible = false
	end
	for _, mote in p.Motes do
		mote.Active = false
		mote.Frame.Visible = false
	end
	for _, text in { p.Title, p.Rare, p.CardName, p.Orientation, p.Effect, p.Hint } do
		text.TextTransparency = 1
		text.TextStrokeTransparency = 1
	end
	p.Flash.BackgroundTransparency = 1
	p.Pulse.Scale = 1
	p.NamePop.Scale = 1
	p.TagPop.Scale = 1
	p.Orientation.Rotation = 0
	p.Effect.Position = p.EffectHome
	p.Card.Frame.Rotation = 0
	glowCard(p.Card, nil)
	showBack(p.Card)
end

local function showText(text: TextLabel, time: number, outline: number?)
	tween(text, time, { TextTransparency = 0, TextStrokeTransparency = outline or 0.3 })
end
local function hideText(text: TextLabel, time: number)
	tween(text, time, { TextTransparency = 1, TextStrokeTransparency = 1 })
end

-- where the little card is, in the stage's own pixels (offset from the stage's middle) and its size there
local function openerOnStage(p: StagePieces): (UDim2, UDim2)
	local scale = math.max(p.Scale.Scale, 0.01)
	local spotCentre = p.Spot.AbsolutePosition + p.Spot.AbsoluteSize / 2
	local inset = Vector2.zero
	if cardGui.IgnoreGuiInset ~= p.Gui.IgnoreGuiInset then
		-- (one of the two is measured from under the top bar)
		local top = GuiService:GetGuiInset()
		inset = if p.Gui.IgnoreGuiInset then top else -top
	end
	local openerCentre = opener.AbsolutePosition + opener.AbsoluteSize / 2 + inset
	local offset = (openerCentre - spotCentre) / scale
	local size = opener.AbsoluteSize / scale
	return UDim2.new(0.5, offset.X, 0.5, offset.Y), UDim2.fromOffset(math.max(size.X, 8), math.max(size.Y, 12))
end

local function launchMote(mote: Mote, kind: string, now: number, rare: boolean)
	mote.Active = true
	mote.Kind = kind
	mote.T0 = now
	mote.Spin = (math.random() - 0.5) * 720
	if kind == "in" then
		local angle = math.random() * math.pi * 2
		local radius = 230 + math.random() * 120
		mote.From = Vector2.new(math.cos(angle), math.sin(angle)) * radius
		mote.To = Vector2.new(math.cos(angle), math.sin(angle)) * (16 + math.random() * 24)
		mote.Life = 0.38 + math.random() * 0.3
	else
		local angle = math.random() * math.pi * 2
		local speed = (if rare then 520 else 380) + math.random() * 420
		mote.From = Vector2.new(math.cos(angle), math.sin(angle)) * (20 + math.random() * 40)
		mote.Vel = Vector2.new(math.cos(angle), math.sin(angle)) * speed + Vector2.new(0, -120)
		mote.Life = 0.7 + math.random() * 0.6
	end
	mote.Frame.Visible = true
	mote.Frame.BackgroundTransparency = 1
end

local function stepMotes(p: StagePieces, now: number, dt: number)
	for _, mote in p.Motes do
		if mote.Active then
			local a = (now - mote.T0) / mote.Life
			if a >= 1 then
				mote.Active = false
				mote.Frame.Visible = false
			elseif mote.Kind == "in" then
				local at = mote.From:Lerp(mote.To, a * a)
				mote.Frame.Position = UDim2.fromOffset(at.X, at.Y)
				mote.Frame.BackgroundTransparency = if a < 0.25 then 1 - a / 0.25 * 0.85 else 0.15 + (a - 0.25) / 0.75 * 0.6
			else
				local t = now - mote.T0
				local at = mote.From + mote.Vel * t + Vector2.new(0, 300) * t * t
				mote.Frame.Position = UDim2.fromOffset(at.X, at.Y)
				mote.Frame.BackgroundTransparency = math.clamp(a ^ 1.6, 0, 1)
			end
			mote.Frame.Rotation += dt * mote.Spin
		end
	end
end

local function freeMote(p: StagePieces): Mote?
	for _, mote in p.Motes do
		if not mote.Active then
			return mote
		end
	end
	return nil
end

-- the colour the draw turns when the card is known: gold (its own colour in it), red when reversed, white-gold when rare
local function outcomeColor(id: string, upright: boolean): (Color3, boolean)
	local def = TarotConfig.Get(id)
	local rare = def ~= nil and (def.Weight or 1) <= 0.5
	if not upright then
		return CRIMSON, rare
	elseif rare then
		return Color3.fromRGB(255, 240, 200), rare
	end
	return GOLD:Lerp(if def then def.Color else GOLD, 0.35), rare
end

-- the camera / screen part of the draw (all through Utility: nothing happens when a setting switches it off)
local function screenCharge()
	if not Utility then
		return
	end
	pcall(function()
		reveal.Color = Utility.ColorCorrection({ Saturation = -0.45, Contrast = 0.1, Brightness = -0.05 }, 0.5)
		Utility.TweenFOV(Utility.BaseFOV - 7, 1.6, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut)
		reveal.Ramp = Utility.ShakeRamp(0.05, 0.8, 1.5, 12)
	end)
end
local function screenBurst(color: Color3, upright: boolean, rare: boolean)
	if not Utility then
		return
	end
	pcall(function()
		if reveal.Ramp then
			reveal.Ramp.Stop(0.05)
			reveal.Ramp = nil
		end
		Utility.Shake(if upright then 3.2 else 5, 16, 0.02, 0.55)
		Utility.TweenFOV(Utility.BaseFOV + 6, 0.07, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		task.delay(0.08, function()
			pcall(Utility.ResetFOV, 0.7)
		end)
		Utility.Blur(if rare then 22 else 16, 0.7)
		if rare then
			Utility.Flash(0.2)
		end
		local handle = reveal.Color
		if handle then
			handle:Tween({ Saturation = 0.25, Contrast = 0.3, Brightness = 0.08, TintColor = Color3.new(1, 1, 1):Lerp(color, 0.25) }, 0.06)
			task.delay(0.12, function()
				handle:Tween({ Saturation = -0.25, Contrast = 0.12, Brightness = -0.03, TintColor = Color3.new(1, 1, 1):Lerp(color, 0.12) }, 0.9)
			end)
		end
	end)
end
local function screenCalm(time: number)
	if not Utility then
		return
	end
	pcall(function()
		if reveal.Ramp then
			reveal.Ramp.Stop(0.1)
			reveal.Ramp = nil
		end
		Utility.ResetFOV(time)
		local handle = reveal.Color
		reveal.Color = nil
		if handle then
			handle:Reset(time)
			handle:Destroy(time + 0.1)
		end
	end)
end

local function stopStep()
	if reveal.Step then
		reveal.Step:Disconnect()
		reveal.Step = nil
	end
	if reveal.Riser then
		reveal.Riser:Stop()
		reveal.Riser:Destroy()
		reveal.Riser = nil
	end
end

-- the end of a draw: the little card shows what you drew (or the back, when there was nothing)
local function landInOpener(id: string?, upright: boolean)
	openerCard.Frame.Visible = true
	if id and TarotConfig.Get(id) then
		showFace(openerCard, id, upright)
		openerScale.Scale = 1.5
		tween(openerScale, 0.4, { Scale = if hovering then 1.12 else 1 }, Enum.EasingStyle.Back)
		glowCard(openerCard, (outcomeColor(id, upright)))
		task.delay(0.6, function()
			if not inviting then
				glowCard(openerCard, nil)
			end
		end)
	else
		showBack(openerCard)
	end
	refresh()
end

-- puts the card away: it flies back down into the little card (fast = the round is starting)
local function finishReveal(token: number, fast: boolean?)
	local p = P
	if not p or reveal.Token ~= token then
		return
	end
	reveal.Phase = "keep"
	local result = reveal.Result
	local time = if fast then 0.25 else 0.42
	playSound(KEEP_SOUND, 0.5)
	for _, text in { p.Title, p.Rare, p.CardName, p.Orientation, p.Effect, p.Hint } do
		hideText(text, 0.18)
	end
	tween(p.Dim, time, { BackgroundTransparency = 1 })
	for _, edge in p.Edges do
		tween(edge, time, { BackgroundTransparency = 1 })
	end
	for _, ray in p.RayBars do
		tween(ray, time * 0.8, { BackgroundTransparency = 1 })
	end
	for _, halo in p.Halos do
		tween(halo, time * 0.8, { BackgroundTransparency = 1 })
	end
	local to, size = openerOnStage(p)
	tween(p.Card.Frame, time, { Position = to, Size = size, Rotation = 10 }, Enum.EasingStyle.Quint, Enum.EasingDirection.In)
	tween(p.Pulse, time, { Scale = 1 })
	screenCalm(time)
	p.Click.Visible = false
	task.delay(time, function()
		if reveal.Token ~= token then
			return
		end
		p.Gui.Enabled = false
		reveal.Busy = false
		reveal.Phase = ""
		pcall(stopStep)
		p.Card.Frame.Position = UDim2.fromScale(0.5, 0.5)
		p.Card.Frame.Size = p.Card.Full
		p.Card.Frame.Rotation = 0
		local ok, err = pcall(landInOpener, if result then result.Id else nil, if result then result.Upright else true)
		if not ok then
			warn("[TarotClient] " .. tostring(err))
		end
	end)
end

-- the last resort: the stage off at once, no animation (when even putting it away went wrong)
local function hardStop()
	reveal.Token += 1
	reveal.Busy = false
	reveal.Phase = ""
	pcall(stopStep)
	pcall(screenCalm, 0.2)
	if P then
		P.Click.Visible = false
		P.Gui.Enabled = false
	end
	openerCard.Frame.Visible = true
	pcall(refresh)
end

-- puts the card away, and if that fails too, stops the stage at once
local function putAway(token: number)
	local ok, err = pcall(finishReveal, token, true)
	if not ok then
		warn("[TarotClient] " .. tostring(err))
		hardStop()
	end
end

-- the click asked, but there is no card (refused / no answer): the card goes back down
local function abortReveal(text: string?)
	if not reveal.Busy then
		return
	end
	reveal.Token += 1
	local token = reveal.Token
	reveal.Result = nil
	reveal.PendingClick = false
	finishReveal(token, true)
	if text and text ~= "" then
		toast("The cards", text)
	end
end

-- the card is known: the rest of the show (the charge goes on until this has happened)
local function turnCard(token: number)
	local p = P
	local result = reveal.Result
	if not p or not result or reveal.Token ~= token then
		return
	end
	local def = TarotConfig.Get(result.Id)
	if not def then
		abortReveal()
		return
	end
	local upright = result.Upright
	local color, rare = outcomeColor(result.Id, upright)
	reveal.Phase = "turn"
	-- the squash before the turn
	tween(p.Pulse, 0.12, { Scale = 0.86 }, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	for index, halo in p.Halos do
		local base = p.HaloBase[index] or halo.Size.X.Offset
		tween(halo, 0.12, { Size = UDim2.fromOffset(base * 0.8, base * 0.8) }, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	end
	task.wait(0.12)
	if reveal.Token ~= token then
		return
	end
	if reveal.Riser then
		reveal.Riser:Stop()
	end
	-- THE TURN: the card narrows to nothing and comes back face up, bigger than before
	local card = p.Card
	local full = card.Full
	tween(card.Frame, 0.08, { Size = UDim2.new(0, 0, full.Y.Scale, full.Y.Offset), Rotation = 0 }, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	task.wait(0.08)
	if reveal.Token ~= token then
		return
	end
	showFace(card, result.Id, upright)
	glowCard(card, color)
	tween(card.Frame, 0.34, { Size = full }, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
	p.Pulse.Scale = 1.22
	tween(p.Pulse, 0.5, { Scale = 1 }, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
	if asset(REVEAL_SOUND) ~= "" then
		playSound(REVEAL_SOUND, 0.8, if upright then 1.05 else 0.85)
	else
		flipSound()
	end
	screenBurst(color, upright, rare)
	-- the burst: flash, two rings, the rays flare, every spark flies out
	if canFlash() then
		p.Flash.BackgroundColor3 = Color3.new(1, 1, 1):Lerp(color, 0.35)
		p.Flash.BackgroundTransparency = if rare then 0.1 else 0.3
		tween(p.Flash, 0.5, { BackgroundTransparency = 1 })
	end
	for index, ring in p.Rings do
		local line = ring:FindFirstChildOfClass("UIStroke")
		ring.Visible = true
		ring.Size = UDim2.fromOffset(full.X.Offset * 0.9, full.X.Offset * 0.9)
		if line then
			line.Color = color:Lerp(Color3.new(1, 1, 1), 0.3)
			line.Thickness = if index == 1 then 12 else 6
			line.Transparency = 0
		end
		local reach = (if index == 1 then 980 else 720) * (if rare then 1.25 else 1)
		task.delay((index - 1) * 0.07, function()
			if reveal.Token ~= token then
				return
			end
			tween(ring, 0.65, { Size = UDim2.fromOffset(reach, reach) }, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
			if line then
				tween(line, 0.65, { Thickness = 1, Transparency = 1 }, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
			end
		end)
	end
	for _, ray in p.RayBars do
		ray.BackgroundColor3 = Color3.new(1, 1, 1):Lerp(color, 0.5)
		ray.BackgroundTransparency = if rare then 0.05 else 0.2
		tween(ray, 1.3, { BackgroundTransparency = if rare then 0.45 else 0.6 })
	end
	p.Rays.Size = UDim2.fromOffset(1120, 1120)
	tween(p.Rays, 1.1, { Size = UDim2.fromOffset(980, 980) }, Enum.EasingStyle.Quad)
	for index, halo in p.Halos do
		local base = p.HaloBase[index] or 300
		halo.BackgroundColor3 = color
		halo.BackgroundTransparency = ({ 0.62, 0.5, 0.35 })[index] or 0.6
		halo.Size = UDim2.fromOffset(base * 1.15, base * 1.15)
		tween(halo, 0.9, { Size = UDim2.fromOffset(base, base), BackgroundTransparency = ({ 0.86, 0.78, 0.66 })[index] or 0.85 })
	end
	local now = os.clock()
	for _, mote in p.Motes do
		launchMote(mote, "out", now + (math.random() * 0.05), rare)
		mote.Frame.BackgroundColor3 = if math.random() < 0.5 then color else GOLD_LIGHT
	end
	for _, edge in p.Edges do
		edge.BackgroundColor3 = if upright then Color3.fromRGB(46, 4, 10) else Color3.fromRGB(90, 0, 8)
		tween(edge, 0.3, { BackgroundTransparency = if upright then 0.25 else 0.05 })
	end
	if not upright then
		-- a reversed card lands heavy: a shudder
		task.spawn(function()
			for _, angle in { 7, -6, 4, -2, 0 } do
				if reveal.Token ~= token then
					return
				end
				tween(card.Frame, 0.06, { Rotation = angle })
				task.wait(0.06)
			end
		end)
	end
	task.delay(0.2, function()
		if reveal.Token == token then
			shine(card, 0.6)
		end
	end)
	-- the words
	reveal.Phase = "show"
	task.delay(0.15, function()
		if reveal.Token ~= token then
			return
		end
		hideText(p.Title, 0.15)
		p.CardName.Text = def.Name
		p.NamePop.Scale = 1.7
		showText(p.CardName, 0.25, 0.2)
		tween(p.NamePop, 0.4, { Scale = 1 }, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
		if rare then
			p.Rare.Text = "A RARE CARD"
			showText(p.Rare, 0.3)
		end
	end)
	task.delay(0.32, function()
		if reveal.Token ~= token then
			return
		end
		p.Orientation.Text = if upright then "UPRIGHT" else "REVERSED"
		p.Orientation.TextColor3 = if upright then UPRIGHT_COLOR else REVERSED_COLOR
		p.Orientation.Rotation = if upright then 0 else -6
		p.TagPop.Scale = 2.2
		showText(p.Orientation, 0.12, 0.2)
		tween(p.TagPop, 0.2, { Scale = 1 }, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		playSound(if upright then UPRIGHT_SOUND else REVERSED_SOUND, 0.7, if upright then 1 else 0.85)
		if not upright and Utility then
			pcall(Utility.Shake, 2, 18, 0.01, 0.3)
		end
	end)
	task.delay(0.5, function()
		if reveal.Token ~= token then
			return
		end
		p.Effect.Text = if upright then def.Upright else def.Reversed
		p.Effect.Position = p.EffectHome + UDim2.fromOffset(0, 10)
		showText(p.Effect, 0.35)
		tween(p.Effect, 0.35, { Position = p.EffectHome })
	end)
	task.delay(1.3, function()
		if reveal.Token == token and reveal.Phase == "show" then
			showText(p.Hint, 0.4, 0.5)
		end
	end)
	-- it stays up DRAW_SECONDS, or until a click (a click that came before the turn doesn't count)
	reveal.Clicked = false
	local shownAt = os.clock()
	while reveal.Token == token and os.clock() - shownAt < DRAW_SECONDS do
		if reveal.Clicked and os.clock() - shownAt > 0.6 then
			break
		end
		task.wait()
	end
	if reveal.Token == token then
		finishReveal(token)
	end
end

-- STARTS THE DRAW from the little card. clicked = the player clicked (the server has to answer first);
-- otherwise the card is already known (Auto Draw, /tarot)
local function startReveal(clicked: boolean): boolean
	if reveal.Busy or not setupStage() then
		return false
	end
	local p = P :: StagePieces
	reveal.Token += 1
	local token = reveal.Token
	reveal.Busy = true
	reveal.Phase = "fly"
	reveal.Clicked = false
	reveal.PendingClick = clicked
	if clicked then
		reveal.Result = nil
	end
	stageFit()
	resetStage(p)
	p.Gui.Enabled = true
	p.Click.Visible = true
	-- the little card IS the card that flies up
	local from, size = openerOnStage(p)
	openerCard.Frame.Visible = false
	setInviting(false)
	local card = p.Card
	card.Frame.Position = from
	card.Frame.Size = size
	card.Frame.Rotation = -8
	tween(card.Frame, 0.45, { Position = UDim2.fromScale(0.5, 0.5), Size = card.Full, Rotation = 0 }, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)
	tween(p.Dim, 0.45, { BackgroundTransparency = 0.42 })
	for _, edge in p.Edges do
		tween(edge, 0.6, { BackgroundTransparency = 0.35 })
	end
	p.Title.Text = "The Draw"
	showText(p.Title, 0.5, 0.35)
	screenCharge()
	reveal.Riser = playSound(DRAW_SOUND, 0.45, 0.8, false)
	widgetOpen = false
	refresh()
	-- the charge: it trembles, the light grows and pulses faster, sparks are drawn in
	local started = os.clock()
	local chargeTime = 1.55
	local nextMote = 0
	local tinted = false
	local function step(dt: number)
		local now = os.clock()
		local t = now - started
		stepMotes(p, now, dt)
		if reveal.Phase == "fly" or reveal.Phase == "charge" then
			local result = reveal.Result
			local rare = false
			if result then
				local _, isRare = outcomeColor(result.Id, result.Upright)
				rare = isRare
			end
			local length = chargeTime + (if rare then 0.5 else 0)
			local k = math.clamp((t - 0.35) / length, 0, 1)
			if t > 0.45 then
				reveal.Phase = "charge"
				local shake = 1 + 4 * k * k
				card.Frame.Position = UDim2.new(0.5, (math.random() - 0.5) * shake, 0.5, (math.random() - 0.5) * shake)
				card.Frame.Rotation = math.sin(t * 38) * k * 2.5
			end
			p.Pulse.Scale = 1 + 0.035 * math.sin(t * (6 + 22 * k)) * k + 0.04 * k
			for index, halo in p.Halos do
				local base = p.HaloBase[index] or 300
				local wave = 0.5 + 0.5 * math.sin(t * (4 + 18 * k) + index)
				halo.BackgroundTransparency = 1 - k * (({ 0.12, 0.2, 0.32 })[index] or 0.15) - wave * 0.06 * k
				local grow = 0.6 + 0.4 * k
				halo.Size = UDim2.fromOffset(base * grow, base * grow)
			end
			p.Rays.Rotation += dt * (8 + 50 * k)
			for _, ray in p.RayBars do
				ray.BackgroundTransparency = 1 - 0.32 * k
			end
			if reveal.Riser then
				reveal.Riser.PlaybackSpeed = 0.8 + 0.55 * k
			end
			-- once the card is known, the light takes on its colour (a hint of what's coming)
			if result and not tinted and k > 0.5 then
				tinted = true
				local color = outcomeColor(result.Id, result.Upright)
				for _, halo in p.Halos do
					tween(halo, 0.5, { BackgroundColor3 = color })
				end
				for _, ray in p.RayBars do
					tween(ray, 0.5, { BackgroundColor3 = Color3.new(1, 1, 1):Lerp(color, 0.5) })
				end
			end
			if now >= nextMote and t > 0.3 then
				nextMote = now + 0.05 - 0.035 * k
				local mote = freeMote(p)
				if mote then
					launchMote(mote, "in", now, false)
					mote.Frame.BackgroundColor3 = if result and k > 0.5 then outcomeColor(result.Id, result.Upright) else GOLD_LIGHT
				end
			end
		else
			-- shown: it floats, the rays turn slowly
			p.Rays.Rotation += dt * 6
			if reveal.Phase == "show" then
				card.Frame.Position = UDim2.new(0.5, 0, 0.5, math.sin(t * 2.2) * 3)
			end
		end
	end
	reveal.Step = RunService.RenderStepped:Connect(function(dt: number)
		if reveal.Token ~= token then
			return
		end
		local ok, err = pcall(step, dt)
		if not ok then
			warnOnce("step", "the draw: " .. tostring(err))
		end
	end)
	local function timeline()
		-- wait for the card (a click asked the server), then for the charge to be full (a click skips the rest)
		local deadline = os.clock() + 4
		while reveal.Token == token do
			local result = reveal.Result
			local t = os.clock() - started
			if result then
				local _, rare = outcomeColor(result.Id, result.Upright)
				local length = chargeTime + 0.35 + (if rare then 0.5 else 0)
				if t >= length or (reveal.Clicked and t > 0.5) then
					break
				end
			elseif os.clock() > deadline then
				abortReveal("The cards didn't answer. Try again.")
				return
			end
			task.wait()
		end
		if reveal.Token == token then
			reveal.PendingClick = false
			turnCard(token)
		end
	end
	task.spawn(function()
		-- (protected: whatever goes wrong, the card is put away)
		local ok, err = pcall(timeline)
		if not ok then
			warn("[TarotClient] the draw: " .. tostring(err))
			if reveal.Token == token then
				putAway(token)
			end
		end
	end)
	-- (whatever happens, the stage and its screen-wide click never stay up)
	task.delay(12 + DRAW_SECONDS, function()
		if reveal.Token == token and reveal.Busy then
			warn("[TarotClient] the draw took too long: put away")
			putAway(token)
		end
	end)
	return true
end

-- (Oct 12 Update 29) SILENT TAROT DRAW (Settings > Gameplay): the card is drawn for you, no animation, nothing pops
-- up, and the little card stays face down (click it to look at your card in the small panel).
local function silent(): boolean
	return player:GetAttribute("Setting_SilentTarotDraw") == true
end
local heldForNext = false -- (the card was drawn while knocked out: it is for the next round)

-- (Oct 12 Update 29) a draw is allowed at any time except while you are alive in a round (or as it starts)
local function drawTime(): boolean
	local state = ReplicatedStorage:GetAttribute("GameState")
	if state == "Starting" then
		return false
	end
	return not (state == "InRound" and player:GetAttribute("Alive") == true)
end

-- may this player draw right now? (not playing, no card for the next round yet, the cards are on)
local function canDraw(): boolean
	local card = player:GetAttribute("TarotCard")
	local state = ReplicatedStorage:GetAttribute("GameState")
	local knockedOut = state == "InRound" and player:GetAttribute("Alive") ~= true
	local spent = card ~= nil and knockedOut and not heldForNext
	if knockedOut and ghostShowing then
		return false -- (a ghost card is face up right now)
	end
	-- (knocked out: the first click draws your next card; after that the little card opens the ghost flips as before)
	return TarotConfig.DrawEnabled == true and drawTime() and (card == nil or spent) and not reveal.Busy and not drawing
end

refresh = function()
	local state = ReplicatedStorage:GetAttribute("GameState")
	local card = player:GetAttribute("TarotCard")
	local upright = player:GetAttribute("TarotUpright") == true
	local alive = player:GetAttribute("Alive") == true
	local reading = os.clock() < readingUntil
	local want = "none"
	if reading then
		want = "none"
	elseif (flipsLeft > 0 or ghostShowing) and state == "InRound" and not alive then
		want = "ghost"
	elseif card ~= nil and (state == "Intermission" or state == "Starting" or state == "WaitingForPlayers" or (state == "InRound" and alive)) then
		want = "card"
	elseif card == nil and drawTime() and TarotConfig.DrawEnabled and drawing then
		want = "draw"
	end
	local waiting = want == "ghost" and flipsLeft > 0
	if want == "none" and widgetOpen and not reading then
		want = "rest" -- (opened with nothing to show: it says when the cards come)
	end
	if want ~= mode or want ~= "none" then
		setMode(want)
	end
	widget.Visible = widgetOpen and want ~= "none"
	widgetScale.Scale = math.min(if want == "card" and state == "InRound" then 0.72 else 1, fit(420))
	-- the little card: your card face up while you hold one, else face down; it glows while a draw waits for you
	if not reveal.Busy then
		openerCard.Frame.Visible = true
		local def = card and TarotConfig.Get(card)
		local key = if def and not silent() then card .. (if upright then "+" else "-") else "back"
		if openerCard.Shown ~= key then
			if def then
				showFace(openerCard, card, upright)
			else
				showBack(openerCard)
			end
		end
	end
	setInviting(canDraw())
	pip.Visible = (waiting or inviting) and not widgetOpen
	paintOpener()
end

-- (only when the stage can't be shown: the draw happens in the little panel, as before)
local function panelDraw()
	widgetOpen = true
	drawing = true
	setMode("draw")
	widget.Visible = true
	button.Visible = false
	hint.Text = "..."
	remote:FireServer("Draw")
	task.delay(4, function()
		if drawing then
			drawing = false
			refresh()
		end
	end)
end

button.Activated:Connect(function()
	if mode == "draw" and not drawing then
		panelDraw()
	elseif mode == "ghost" and flipsLeft > 0 and not ghostShowing then
		button.Visible = false
		remote:FireServer("Flip")
		task.delay(1.5, function()
			if mode == "ghost" and not ghostShowing then
				button.Visible = flipsLeft > 0
			end
		end)
	end
end)

---------------------------------------------------------------------- your reading
local readingPanel = make("Frame", {
	Name = "Reading", AnchorPoint = Vector2.new(1, 1), Position = UDim2.new(1, -16, 1, -(CARD_BOTTOM + 84)), Size = UDim2.fromOffset(240, 440),
	BackgroundTransparency = 1, Visible = false, Parent = gui,
})
bigText({ Size = UDim2.new(1, -34, 0, 30), TextSize = 24, Text = "YOUR READING", TextColor3 = GOLD_LIGHT, Parent = readingPanel })
local readingCard = newCard(readingPanel, 150, 240, UDim2.new(0.5, 0, 0, 160))
local readingName = bigText({ Position = UDim2.fromOffset(0, 286), Size = UDim2.new(1, 0, 0, 22), TextSize = 18, Text = "", Parent = readingPanel })
local readingHow = label(readingPanel, { Position = UDim2.fromOffset(4, 312), Size = UDim2.new(1, -8, 0, 60), TextSize = 14, Text = "" })
local readingNew = bigText({ Position = UDim2.fromOffset(0, 376), Size = UDim2.new(1, 0, 0, 22), TextSize = 18, TextScaled = true, TextColor3 = INK, Text = "", Parent = readingPanel })
make("UITextSizeConstraint", { MaxTextSize = 18, Parent = readingNew })
local readingDismiss = make("TextButton", { Size = UDim2.fromScale(1, 1), BackgroundTransparency = 1, Text = "", Parent = readingPanel })
local readingScale = make("UIScale", { Parent = readingPanel })
local readingX = closeButton(readingPanel)
local readingToken = 0
local pendingReading: { Id: string, Upright: boolean, How: string, IsNew: boolean }? = nil

local function showReading(id: string, upright: boolean, how: string, isNew: boolean)
	local def = TarotConfig.Get(id)
	if not def then
		return
	end
	readingToken += 1
	local token = readingToken
	readingUntil = os.clock() + READING_SECONDS
	refresh()
	showBack(readingCard)
	glowCard(readingCard, nil)
	readingName.Text = ""
	readingHow.Text = ""
	readingNew.Text = ""
	readingScale.Scale = fit(440)
	readingPanel.Visible = true
	task.delay(0.7, function()
		if readingToken ~= token then
			return
		end
		flip(readingCard, function()
			showFace(readingCard, id, upright)
			glowCard(readingCard, (outcomeColor(id, upright)))
			task.delay(0.1, shine, readingCard, 0.6)
		end)
		task.delay(0.45, function()
			if readingToken ~= token then
				return
			end
			readingName.Text = string.upper(def.Name) .. (if upright then "" else ", REVERSED")
			readingName.TextColor3 = if upright then UPRIGHT_COLOR else REVERSED_COLOR
			readingHow.Text = how
			local have, total = TarotConfig.Count(player:GetAttribute("TarotDeck"))
			readingNew.Text = if isNew then "NEW FOR YOUR DECK!  " .. have .. " / " .. total else have .. " / " .. total .. " in your deck"
		end)
	end)
	task.delay(READING_SECONDS, function()
		if readingToken == token then
			readingPanel.Visible = false
			refresh()
		end
	end)
end
local function dismissReading()
	readingToken += 1
	readingUntil = 0
	readingPanel.Visible = false
	refresh()
end
readingDismiss.Activated:Connect(dismissReading)
readingX.Activated:Connect(dismissReading)

-- the reading that waits for a click (you were knocked out)
local function refreshReadingTab()
	readingTab.Visible = pendingReading ~= nil
end
readingTabClick.Activated:Connect(function()
	local waiting = pendingReading
	if not waiting then
		return
	end
	pendingReading = nil
	refreshReadingTab()
	widgetOpen = false
	showReading(waiting.Id, waiting.Upright, waiting.How, waiting.IsNew)
end)

---------------------------------------------------------------------- opening / closing the panel; the draw
openerClick.Activated:Connect(function()
	if reveal.Busy then
		stageClicked()
		return
	end
	-- ONE CLICK DRAWS: any time you're not playing, with no card yet
	if canDraw() and silent() then
		-- (Silent Tarot Draw: no show at all)
		drawing = true
		remote:FireServer("Draw")
		task.delay(4, function()
			drawing = false
			refresh()
		end)
		return
	elseif canDraw() then
		if os.clock() < readingUntil then
			dismissReading()
		end
		if startReveal(true) then
			remote:FireServer("Draw")
		else
			panelDraw()
		end
		return
	end
	if os.clock() < readingUntil then
		widgetOpen = true -- (clicking the little card during a reading swaps the reading for the panel)
		dismissReading()
	else
		widgetOpen = not widgetOpen
		refresh()
	end
end)
widgetX.Activated:Connect(function()
	widgetOpen = false
	refresh()
end)

---------------------------------------------------------------------- the haze (The Star, reversed)
local haze = make("Frame", { Name = "Haze", Size = UDim2.fromScale(1, 1), BackgroundTransparency = 1, Visible = false, Parent = gui })
do
	local edges = {
		{ AnchorPoint = Vector2.new(0, 0), Position = UDim2.fromScale(0, 0), Size = UDim2.fromScale(1, 0.3), Rotation = 90 },
		{ AnchorPoint = Vector2.new(0, 1), Position = UDim2.fromScale(0, 1), Size = UDim2.fromScale(1, 0.3), Rotation = -90 },
		{ AnchorPoint = Vector2.new(0, 0), Position = UDim2.fromScale(0, 0), Size = UDim2.fromScale(0.25, 1), Rotation = 0 },
		{ AnchorPoint = Vector2.new(1, 0), Position = UDim2.fromScale(1, 0), Size = UDim2.fromScale(0.25, 1), Rotation = 180 },
	}
	for _, edge in edges do
		local frame = make("Frame", {
			AnchorPoint = edge.AnchorPoint, Position = edge.Position, Size = edge.Size, BackgroundColor3 = Color3.fromRGB(6, 4, 8),
			BorderSizePixel = 0, Parent = haze,
		})
		make("UIGradient", {
			Rotation = edge.Rotation,
			Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.15), NumberSequenceKeypoint.new(1, 1) }),
			Parent = frame,
		})
	end
end

---------------------------------------------------------------------- the windows (deck, fortune)
local windows: { Frame } = {}
local function closeWindows(except: Frame?)
	for _, window in windows do
		if window ~= except then
			window.Visible = false
		end
	end
end

local function escape(text: string): string
	return (text:gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"))
end

local function describe(id: string, upright: boolean, have: boolean): string
	local def = TarotConfig.Get(id)
	local hows = TarotConfig.HowToEarn(id, upright)
	local head = if upright then "UPRIGHT" else "REVERSED"
	local color = if upright then "#F0CE78" else "#E24844"
	local status = if have then "  <font color=\"#F8E2A4\">(yours)</font>" else ""
	local drawn = if upright then def.Upright else def.Reversed
	local earn = if #hows > 0 then table.concat(hows, " Or: ") else "Can't be earned yet."
	return ("<font color=\"%s\"><b>%s</b></font>%s\n<font color=\"#C8A47A\">Drawn:</font> %s\n<font color=\"#C8A47A\">Earned:</font> %s"):format(color, head, status, escape(drawn), escape(earn))
end

-- YOUR DECK (TarotDeckGui, cloned once)
type DeckCell = { Index: number, Id: string, Cell: Frame, Card: Card, Up: GuiObject?, Rev: GuiObject?, Pick: GuiObject?, New: GuiObject? }
type DeckPieces = {
	Gui: ScreenGui, Shade: GuiObject, Window: Frame, Scale: UIScale, Count: TextLabel, Fill: Frame?, Close: GuiButton,
	Cells: { DeckCell }, Detail: Card, DetailName: TextLabel, Upright: TextLabel, Reversed: TextLabel,
}
local deckSource = script:FindFirstChild("TarotDeckGui")
local D: DeckPieces? = nil
local deckOpen = false
local selected = TarotConfig.Cards[1].Id
local seenDeck: string? = player:GetAttribute("TarotDeck")   -- the deck when you joined / last opened it (what's NEW since)
local sideHandle: any = nil
local openDeck: () -> () = function() end
local closeDeck: () -> () = function() end
local selectCardHook: (string) -> () = function(_id: string) end

local function deckFit()
	if not D then
		return
	end
	local camera = workspace.CurrentCamera
	local size = if camera then camera.ViewportSize else Vector2.new(1280, 720)
	D.Scale.Scale = math.clamp(math.min((size.X - 24) / 920, (size.Y - 30) / 540), 0.4, 1)
end

local function setupDeck(): boolean
	if D then
		return true
	end
	if not (deckSource and deckSource:IsA("ScreenGui")) then
		warnOnce("deck", "StarterPlayerScripts > TarotClient > TarotDeckGui (Your Deck) is missing: install the update again, always the WHOLE file.")
		return false
	end
	local copy = deckSource:Clone()
	copy.ResetOnSpawn = false
	local missing = {}
	local function need(parent: Instance?, name: string): any
		local found = parent and parent:FindFirstChild(name, true)
		if not found then
			table.insert(missing, name)
		end
		return found
	end
	local window = need(copy, "Window")
	local pieces = {
		Gui = copy, Shade = need(copy, "Shade"), Window = window, Scale = need(window, "Scale"), Count = need(window, "Count"),
		Fill = window and window:FindFirstChild("Fill", true), Close = need(window, "Close"), DetailName = need(window, "DetailName"),
		Upright = need(window, "Upright"), Reversed = need(window, "Reversed"), Cells = {},
	} :: any
	local cards = need(window, "Cards")
	local detailSpot = need(window, "DetailSpot")
	if #missing > 0 then
		warnOnce("decknames", "TarotDeckGui has no " .. table.concat(missing, ", ") .. " (keep the names when you restyle it).")
		copy:Destroy()
		return false
	end
	for index, def in TarotConfig.Cards do
		local cell = cards:FindFirstChild(string.format("Cell%02d", index - 1))
		local spot = cell and cell:FindFirstChild("CardSpot")
		if cell and spot and spot:IsA("GuiObject") then
			spot.BackgroundTransparency = 1
			local entry: DeckCell = {
				Index = index, Id = def.Id, Cell = cell, Card = newCard(spot, spot.Size.X.Offset, spot.Size.Y.Offset),
				Up = cell:FindFirstChild("Up") :: any, Rev = cell:FindFirstChild("Rev") :: any, Pick = cell:FindFirstChild("Pick") :: any,
				New = cell:FindFirstChild("New") :: any,
			}
			table.insert(pieces.Cells, entry)
			local click = cell:FindFirstChild("Click")
			if click and click:IsA("GuiButton") then
				click.Activated:Connect(function()
					selectCardHook(def.Id)
				end)
				click.MouseEnter:Connect(function()
					tween(entry.Card.Frame, 0.12, { Position = UDim2.new(0.5, 0, 0.5, -5) })
				end)
				click.MouseLeave:Connect(function()
					tween(entry.Card.Frame, 0.12, { Position = UDim2.fromScale(0.5, 0.5) })
				end)
			end
		else
			warnOnce("cell" .. index, "TarotDeckGui has no Cell" .. string.format("%02d", index - 1) .. " (with a CardSpot) for " .. def.Name .. ".")
		end
	end
	pieces.Detail = newCard(detailSpot, detailSpot.Size.X.Offset, detailSpot.Size.Y.Offset)
	pieces.Window.Visible = false
	pieces.Shade.Visible = false
	copy.Enabled = true
	copy.Parent = playerGui
	pieces.Close.Activated:Connect(function()
		closeDeck()
	end)
	if pieces.Shade:IsA("GuiButton") then
		pieces.Shade.Activated:Connect(function()
			closeDeck()
		end)
	end
	D = pieces
	deckFit()
	return true
end



local function selectCard(id: string)
	local d = D
	if not d then
		return
	end
	selected = id
	local deck = player:GetAttribute("TarotDeck")
	local up, down = TarotConfig.Has(deck, id, true), TarotConfig.Has(deck, id, false)
	for _, entry in d.Cells do
		if entry.Pick then
			entry.Pick.Visible = entry.Id == id
		end
	end
	if up or down then
		showFace(d.Detail, id, up or not down)
		glowCard(d.Detail, (outcomeColor(id, up or not down)))
	else
		showBack(d.Detail)
		glowCard(d.Detail, nil)
	end
	local def = TarotConfig.Get(id)
	d.DetailName.Text = def.Name
	d.Upright.Text = describe(id, true, up)
	d.Reversed.Text = describe(id, false, down)
end
selectCardHook = function(id: string)
	selectCard(id)
	local d = D
	if d then
		for _, entry in d.Cells do
			if entry.Id == id then
				entry.Card.Frame.Rotation = -4
				tween(entry.Card.Frame, 0.25, { Rotation = 0 }, Enum.EasingStyle.Back)
			end
		end
	end
end

local GEM_OFF = Color3.fromRGB(46, 34, 30)
local function refreshDeck(dealIn: boolean)
	local d = D
	if not d then
		return
	end
	local deck = player:GetAttribute("TarotDeck")
	local have, total = TarotConfig.Count(deck)
	d.Count.Text = ("%d / %d collected"):format(have, total)
	if d.Fill then
		d.Fill.Size = UDim2.fromScale(math.clamp(have / math.max(total, 1), 0, 1), 1)
	end
	local newest: string? = nil
	for _, entry in d.Cells do
		local id = entry.Id
		local up, down = TarotConfig.Has(deck, id, true), TarotConfig.Has(deck, id, false)
		if up or down then
			showFace(entry.Card, id, up or not down)
		else
			showBack(entry.Card)
		end
		if entry.Up then
			entry.Up.BackgroundColor3 = if up then GOLD_LIGHT else GEM_OFF
		end
		if entry.Rev then
			entry.Rev.BackgroundColor3 = if down then CRIMSON else GEM_OFF
		end
		local isNew = seenDeck ~= nil and ((up and not TarotConfig.Has(seenDeck, id, true)) or (down and not TarotConfig.Has(seenDeck, id, false)))
		if entry.New then
			entry.New.Visible = isNew
		end
		if isNew then
			newest = id
		end
		if dealIn then
			-- the cards are dealt in, one after the other
			local frame = entry.Card.Frame
			frame.Position = UDim2.new(0.5, 0, 0.5, 26)
			frame.Rotation = -10
			task.delay(0.05 + entry.Index * 0.022, function()
				tween(frame, 0.3, { Position = UDim2.fromScale(0.5, 0.5), Rotation = 0 }, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
			end)
		end
	end
	selectCard(newest or selected)
end

openDeck = function()
	if not setupDeck() then
		return
	end
	local d = D :: DeckPieces
	closeWindows(nil)
	if seenDeck == nil then
		seenDeck = player:GetAttribute("TarotDeck") or ""
	end
	deckFit()
	refreshDeck(true)
	seenDeck = player:GetAttribute("TarotDeck") or ""
	deckOpen = true
	d.Shade.Visible = true
	d.Shade.BackgroundTransparency = 1
	tween(d.Shade, 0.3, { BackgroundTransparency = 0.45 })
	d.Window.Visible = true
	local target = d.Scale.Scale
	d.Scale.Scale = target * 0.86
	tween(d.Scale, 0.38, { Scale = target }, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
	playSound(DECK_SOUND, 0.6)
	if Utility then
		pcall(Utility.Blur, 14, 0.6)
	end
	if UIBus then
		UIBus.Fire("WindowOpened", "TarotDeck")
	end
	if sideHandle then
		sideHandle.SetActive(true)
	end
end
closeDeck = function()
	local d = D
	deckOpen = false
	if d then
		d.Window.Visible = false
		tween(d.Shade, 0.2, { BackgroundTransparency = 1 }).Completed:Once(function()
			if not deckOpen then
				d.Shade.Visible = false
			end
		end)
	end
	if sideHandle then
		sideHandle.SetActive(false)
	end
end
player:GetAttributeChangedSignal("TarotDeck"):Connect(function()
	if seenDeck == nil then
		seenDeck = player:GetAttribute("TarotDeck") -- (your saved deck arriving is not a NEW card)
		return
	end
	if deckOpen then
		refreshDeck(false)
	end
end)

-- THE FORTUNE TELLER
local fortuneTitle = string.upper(TarotConfig.FortuneTellerName)
local fortunePanel, fortuneClose = UIKit.window(gui, 460, 470, fortuneTitle)
table.insert(windows, fortunePanel)
for _, item in fortunePanel:GetDescendants() do
	if item:IsA("TextLabel") and item.Text == fortuneTitle then
		item.TextScaled = true -- (a long name still fits on the title plate)
		make("UIPadding", { PaddingLeft = UDim.new(0, 10), PaddingRight = UDim.new(0, 10), PaddingTop = UDim.new(0, 8), PaddingBottom = UDim.new(0, 8), Parent = item })
	end
end
local fortuneCard = newCard(fortunePanel, 140, 224, UDim2.new(0.5, 0, 0, 160))
local fortuneName = bigText({ Position = UDim2.fromOffset(20, 278), Size = UDim2.new(1, -40, 0, 24), TextSize = 20, Text = "", Parent = fortunePanel })
local fortuneWords = label(fortunePanel, { Position = UDim2.fromOffset(30, 306), Size = UDim2.new(1, -60, 0, 64), TextSize = 18, Text = "" })
local fortuneGift = bigText({ Position = UDim2.fromOffset(20, 372), Size = UDim2.new(1, -40, 0, 22), TextSize = 17, TextColor3 = INK, Text = "", Parent = fortunePanel })
local fortuneDeck, setFortuneDeck = UIKit.pillButton({ AnchorPoint = Vector2.new(0.5, 1), Position = UDim2.new(0.5, 0, 1, -16), Size = UDim2.fromOffset(170, 44), Parent = fortunePanel })
setFortuneDeck("YOUR DECK", true)
fortuneClose.Activated:Connect(function()
	fortunePanel.Visible = false
end)
fortuneDeck.Activated:Connect(function()
	fortunePanel.Visible = false
	openDeck()
end)

-- again = she already read for you today (the same card, no gift); secondsLeft = until a new day
local function showFortune(id: string, upright: boolean, words: string, candles: number, tickets: number, again: boolean, secondsLeft: number)
	local def = TarotConfig.Get(id)
	if not def then
		return
	end
	closeWindows(fortunePanel)
	if deckOpen then
		closeDeck()
	end
	if UIBus then
		UIBus.Fire("WindowOpened", "Fortune")
	end
	showBack(fortuneCard)
	glowCard(fortuneCard, nil)
	fortuneName.Text = ""
	fortuneWords.Text = ""
	fortuneGift.Text = ""
	fortunePanel.Visible = true
	task.delay(0.5, function()
		flip(fortuneCard, function()
			showFace(fortuneCard, id, upright)
			glowCard(fortuneCard, (outcomeColor(id, upright)))
			task.delay(0.1, shine, fortuneCard, 0.6)
		end)
		task.delay(0.45, function()
			fortuneName.Text = string.upper(def.Name) .. (if upright then "" else ", REVERSED")
			fortuneName.TextColor3 = if upright then UPRIGHT_COLOR else REVERSED_COLOR
			fortuneWords.Text = "\"" .. words .. "\""
			if again then
				local hours = math.max(1, math.ceil(secondsLeft / 3600))
				fortuneGift.Text = ("Your card for today. A new one in about %d hour%s."):format(hours, if hours == 1 then "" else "s")
			else
				local gifts = {}
				if candles > 0 then
					table.insert(gifts, "+" .. candles .. " candles")
				end
				if tickets > 0 then
					table.insert(gifts, "+" .. tickets .. " tickets")
				end
				fortuneGift.Text = (if #gifts > 0 then table.concat(gifts, "  ") .. ". " else "") .. "Come back tomorrow."
			end
		end)
	end)
end

if UIBus then
	UIBus.On("OpenTarot", function()
		if deckOpen then
			closeDeck()
		else
			openDeck()
		end
	end)
	UIBus.On("WindowOpened", function(name: any)
		if name ~= "TarotDeck" and deckOpen then
			closeDeck()
		end
		if name ~= "Fortune" then
			fortunePanel.Visible = false
		end
	end)
end
if SHOW_SIDEBAR and SideBar then
	local ok, handle = pcall(SideBar.Add, "Tarot", {
		Order = SIDEBAR_ORDER,
		Icon = if SIDEBAR_ICON ~= "" then SIDEBAR_ICON else nil,
		OnClick = function()
			if deckOpen then
				closeDeck()
			else
				openDeck()
			end
		end,
	})
	if ok then
		sideHandle = handle
	end
end

---------------------------------------------------------------------- the server
remote.OnClientEvent:Connect(function(action: string, ...: any)
	local args = table.pack(...)
	if action == "Drawn" then
		local id, upright = args[1], args[2] == true
		local def = TarotConfig.Get(id)
		if not def then
			drawing = false
			abortReveal()
			refresh()
			return
		end
		local state = ReplicatedStorage:GetAttribute("GameState")
		local playing = state == "InRound" and player:GetAttribute("Alive") == true
		local auto = args[3] == true
		heldForNext = state == "InRound" and not playing
		if silent() and not (reveal.Busy and reveal.PendingClick) then
			-- (Silent Tarot Draw: it is drawn, nothing shows; the small panel has it if you open it)
			drawing = false
			showFace(widgetCard, id, upright)
			tag.Text = if upright then "UPRIGHT" else "REVERSED"
			tag.TextColor3 = if upright then UPRIGHT_COLOR else REVERSED_COLOR
			blurb.Text = if upright then def.Upright else def.Reversed
			refresh()
			return
		end
		if reveal.Busy and reveal.PendingClick then
			-- the answer to the click: the charge on the stage turns it over
			reveal.Result = { Id = id, Upright = upright }
			drawing = false
			return
		end
		if not playing and state ~= "Starting" and not drawing and (not auto or AUTO_REVEAL) and not reveal.Busy then
			-- Auto Draw (or /tarot): the same show, the card already known
			reveal.Result = { Id = id, Upright = upright }
			if startReveal(false) then
				return
			end
		end
		if not reveal.Busy and not playing and not drawing then
			-- (no show: it lands in the little card)
			landInOpener(id, upright)
			if auto then
				toast("The cards", "You drew " .. def.Name .. (if upright then "" else ", reversed") .. ".")
			end
		end
		-- the little panel (it was drawn there, or you are in a round)
		mode = "card"
		widgetTitle.Text = "YOUR CARD"
		button.Visible = false
		hint.Text = ""
		flip(widgetCard, function()
			showFace(widgetCard, id, upright)
			drawing = false
			tag.Text = if upright then "UPRIGHT" else "REVERSED"
			tag.TextColor3 = if upright then UPRIGHT_COLOR else REVERSED_COLOR
			blurb.Text = if upright then def.Upright else def.Reversed
		end)
		refresh()
	elseif action == "Flips" then
		flipsLeft = tonumber(args[1]) or 0
		refresh()
	elseif action == "Flipped" then
		local flipDef = TarotConfig.GetFlip(args[1])
		flipsLeft = tonumber(args[2]) or 0
		if flipDef then
			ghostShowing = true
			button.Visible = false
			hint.Text = ""
			flip(widgetCard, function()
				showMinor(widgetCard, flipDef.Name)
				tag.Text = string.upper(flipDef.Name)
				tag.TextColor3 = SOFT
				blurb.Text = flipDef.Text
			end)
			task.delay(3.2, function()
				ghostShowing = false
				if mode == "ghost" then
					flip(widgetCard, function()
						showBack(widgetCard)
						tag.Text = ""
						blurb.Text = ""
					end)
				end
				refresh()
			end)
		end
	elseif action == "Reading" then
		local id, upright, how, isNew = args[1], args[2] == true, tostring(args[3] or ""), args[4] == true
		if HOLD_READINGS and args[5] == false then
			-- knocked out: it waits for a click on the little card that glows next to the first one
			pendingReading = { Id = id, Upright = upright, How = how, IsNew = isNew }
			refreshReadingTab()
		else
			showReading(id, upright, how, isNew)
		end
	elseif action == "Fortune" then
		showFortune(args[1], args[2] == true, tostring(args[3] or ""), tonumber(args[4]) or 0, tonumber(args[5]) or 0, args[6] == true, tonumber(args[7]) or 0)
	elseif action == "FortuneUsed" then
		local seconds = tonumber(args[1]) or 0
		local hours = math.max(1, math.ceil(seconds / 3600))
		toast(TarotConfig.FortuneTellerName, ("She has already read for you today. Come back in about %d hour%s."):format(hours, if hours == 1 then "" else "s"))
	elseif action == "Haze" then
		haze.Visible = args[1] == true
	elseif action == "Star" then
		-- (the server's toast says it)
	elseif action == "Refused" then
		local text = tostring(args[1] or "")
		if reveal.Busy and reveal.PendingClick then
			abortReveal(text)
		elseif text ~= "" then
			toast("The cards", text)
		end
		if mode == "ghost" then
			button.Visible = flipsLeft > 0
		end
		drawing = false
		refresh()
	end
end)

-- (the stage is made ready now, so the first draw starts at once)
task.defer(setupStage)

ReplicatedStorage:GetAttributeChangedSignal("GameState"):Connect(function()
	local state = ReplicatedStorage:GetAttribute("GameState")
	if state == "Ending" then
		widgetOpen = false -- (every round starts with the panel closed)
	end
	if state ~= "Intermission" and reveal.Busy then
		-- the round is starting: the card goes away quickly
		local result = reveal.Result
		if result then
			reveal.Token += 1
			finishReveal(reveal.Token, true)
		else
			abortReveal()
		end
	end
	if state == "Starting" then
		heldForNext = false -- (Update 29: the card drawn while knocked out is this round's now)
	end
	if state == "Starting" or state == "InRound" then
		-- a reading nobody clicked for goes when the next round starts (it is in the deck anyway)
		pendingReading = nil
		refreshReadingTab()
	end
	if state ~= "InRound" then
		haze.Visible = false
		if state ~= "Ending" then
			flipsLeft = 0
		end
	end
	refresh()
end)
for _, name in { "TarotCard", "TarotUpright", "Alive" } do
	player:GetAttributeChangedSignal(name):Connect(refresh)
end
local camera = workspace.CurrentCamera
if camera then
	camera:GetPropertyChangedSignal("ViewportSize"):Connect(function()
		readingScale.Scale = fit(440)
		stageFit()
		deckFit()
		refresh()
	end)
end
refresh()
refreshReadingTab()
remote:FireServer("Sync")
