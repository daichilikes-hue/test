-- ModuleScript: ServerScriptService > Systems > PlateSpawner
-- Builds the full plate grid around Workspace.Map.Plates.Center,
-- then gives each player a random plate. Extra plates stay unowned.
-- SpawnPlates(players, layout?): a plate modifier (One Plate / Two Plates) passes a layout
-- { Count, Scale }: instead of the grid, Count plates are built side by side in the middle (a row
-- along X, GameConfig.MaxPlateGap between them), each Scale times bigger in X and Z (thickness
-- stays). Players are dealt onto them (several share a plate: GetSpawnCFrame spreads them in a
-- circle so they don't land on top of each other). The plate attribute OwnerUserId is the FIRST
-- player dealt onto that plate; PlateSpawner.GetPlate(player) is always right for every player.
-- (Oct 12 2026, update 23) PROTECTED PLATES AND SURE FOOTING, both inside DestroyPlate (so they work for every event):
--   (Oct 12 2026, update 29) ONE PLATE / TWO PLATES: a round with a layout protects every plate with the key "Layout"
--     (LAYOUT_SAFE below), so NO EVENT can destroy them. Only DestroyPlate(plate, "SuddenDeath") (Systems > SuddenDeath)
--     gets through that guard, so the round can still end.
--   PlateSpawner.Protect(plate, key, true / false): while any key protects a plate, DestroyPlate leaves it alone
--     (Gargoyle Ward). PlateSpawner.IsProtected(plate).
--   A player whose attribute Buff_SureFooting is a server time still to come (a Grave Lily buff) gets
--     PlateSpawner.SureFootingGrace seconds: a plate they stand on crumbles that much later (once per plate).
--   PlateSpawner.Saved:Connect(function(plate, why, player?) end)   why = "Protected" or "SureFooting"
-- (Oct 12 2026, update 25) PlateSpawner.Destroyed() -> the plates destroyed this round that are still missing (where
--   they were, how big, what they looked like); PlateSpawner.Rebuild(entry, cframe?) puts one back (a new plate in
--   the same grid cell, optionally somewhere else first so it can be moved into place) and returns it (Mason's Hammer).

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local GameConfig = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("GameConfig"))

local platesFolder = workspace:WaitForChild("Map"):WaitForChild("Plates")
local center = platesFolder:WaitForChild("Center") :: BasePart

local PlateSpawner = {}

local activeFolder: Folder? = nil
local allPlates: { BasePart } = {}
local plateByUserId: { [number]: BasePart } = {}
local sharers: { [BasePart]: { number } } = {} -- userIds dealt onto each plate, in order
local grid: { [number]: { [number]: BasePart } } = {}
local gridRows, gridCols = 0, 0

local function hasCenterCell(rows: number, cols: number): boolean
	return rows % 2 == 1 and cols % 2 == 1
end

local function isCenterCell(row: number, col: number, rows: number, cols: number): boolean
	return hasCenterCell(rows, cols)
		and row == (rows + 1) / 2
		and col == (cols + 1) / 2
end

local function getCapacity(rows: number, cols: number): number
	local skipped = if GameConfig.SkipCenterCell and hasCenterCell(rows, cols) then 1 else 0
	return rows * cols - skipped
end

-- Uses the configured grid, and only grows it if there are more players than plates.
local function getGridDimensions(playerCount: number): (number, number)
	local rows, cols = GameConfig.GridRows, GameConfig.GridCols
	while getCapacity(rows, cols) < playerCount do
		if cols <= rows then
			cols += 1
		else
			rows += 1
		end
	end
	return rows, cols
end

-- Distance between plate centers, capped so the grid never leaves the arena.
local function getSpacing(rows: number, cols: number): number
	local plateWidth = math.max(GameConfig.PlateSize.X, GameConfig.PlateSize.Z)
	local maxSpacing = plateWidth + GameConfig.MaxPlateGap
	local largestSide = math.max(rows, cols)
	if largestSide <= 1 then
		return maxSpacing
	end

	local fitSpacing = (GameConfig.ArenaSize - plateWidth) / (largestSide - 1)
	if fitSpacing < plateWidth then
		warn("[PlateSpawner] Too many plates for the arena size; plates will overlap.")
	end
	return math.min(maxSpacing, fitSpacing)
end

local function shuffle(list: { any }): { any }
	for i = #list, 2, -1 do
		local j = math.random(i)
		list[i], list[j] = list[j], list[i]
	end
	return list
end

-- Put a Part named "PlateTemplate" in ServerStorage to use your own gothic plate design.
local function createPlate(cframe: CFrame, index: number, row: number, col: number, size: Vector3?): BasePart
	local template = ServerStorage:FindFirstChild("PlateTemplate")
	local plate: BasePart

	if template and template:IsA("BasePart") then
		plate = template:Clone()
	else
		local part = Instance.new("Part")
		part.Material = Enum.Material.Slate
		part.Color = Color3.fromRGB(58, 52, 64)
		part.TopSurface = Enum.SurfaceType.Smooth
		part.BottomSurface = Enum.SurfaceType.Smooth
		plate = part
	end

	plate.Name = "Plate_" .. index
	plate.Size = size or GameConfig.PlateSize
	plate.CFrame = cframe
	plate.Anchored = true
	plate:SetAttribute("Row", row)
	plate:SetAttribute("Col", col)
	plate.Parent = activeFolder
	return plate
end

-- Builds every plate, assigns one to each player, and returns { [UserId] = plate }.
-- layout (optional): { Count, Scale } = a few big plates in the middle instead of the grid.
local LAYOUT_SAFE = true -- (update 29) One Plate / Two Plates: events cannot destroy the plates (false = they can, as before)

function PlateSpawner.SpawnPlates(playerList: { Player }, layout: { Count: number, Scale: number }?): { [number]: BasePart }
	PlateSpawner.Clear()

	local folder = Instance.new("Folder")
	folder.Name = "ActivePlates"
	folder.Parent = platesFolder
	activeFolder = folder

	local origin = CFrame.new(center.Position)

	if layout then
		-- One Plate / Two Plates: a row of big plates, centred on the arena, small gap between them
		local count = math.max(1, math.floor(layout.Count))
		local scale = layout.Scale or 1
		local size = Vector3.new(GameConfig.PlateSize.X * scale, GameConfig.PlateSize.Y, GameConfig.PlateSize.Z * scale)
		local spacing = size.X + GameConfig.MaxPlateGap
		gridRows, gridCols = 1, count
		grid[1] = {}
		for col = 1, count do
			local x = (col - (count + 1) / 2) * spacing
			local plate = createPlate(origin * CFrame.new(x, 0, 0), #allPlates + 1, 1, col, size)
			grid[1][col] = plate
			table.insert(allPlates, plate)
			if LAYOUT_SAFE then
				PlateSpawner.Protect(plate, "Layout", true)
			end
		end
	else
		local rows, cols = getGridDimensions(#playerList)
		local spacing = getSpacing(rows, cols)
		gridRows, gridCols = rows, cols

		-- Build the full grid
		for row = 1, rows do
			grid[row] = {}
			for col = 1, cols do
				if not (GameConfig.SkipCenterCell and isCenterCell(row, col, rows, cols)) then
					local x = (col - (cols + 1) / 2) * spacing
					local z = (row - (rows + 1) / 2) * spacing
					local plate = createPlate(origin * CFrame.new(x, 0, z), #allPlates + 1, row, col)
					grid[row][col] = plate
					table.insert(allPlates, plate)
				end
			end
		end
	end

	-- Deal the players onto the plates (round-robin, so plates are shared as evenly as possible
	-- when there are more players than plates)
	local shuffled = shuffle(table.clone(allPlates))
	local dealt = playerList
	if #playerList > #shuffled then
		dealt = shuffle(table.clone(playerList))
	end

	for index, player in dealt do
		local plate = shuffled[(index - 1) % #shuffled + 1]
		if not plate:GetAttribute("OwnerUserId") then
			plate:SetAttribute("OwnerUserId", player.UserId)
		end
		plateByUserId[player.UserId] = plate
		local list = sharers[plate]
		if not list then
			list = {}
			sharers[plate] = list
		end
		table.insert(list, player.UserId)
	end

	return plateByUserId
end

function PlateSpawner.GetPlate(player: Player): BasePart?
	return plateByUserId[player.UserId]
end

function PlateSpawner.GetOwner(plate: BasePart): Player?
	local userId = plate:GetAttribute("OwnerUserId")
	return if userId then Players:GetPlayerByUserId(userId) else nil
end

function PlateSpawner.GetSpawnCFrame(player: Player): CFrame?
	local plate = plateByUserId[player.UserId]
	if not plate then
		return nil
	end

	-- Several players on one plate (One Plate / Two Plates): stand in a circle
	local offsetX, offsetZ = 0, 0
	local list = sharers[plate]
	if list and #list > 1 then
		local slot = table.find(list, player.UserId) or 1
		local maxRadius = math.max(0, math.min(plate.Size.X, plate.Size.Z) / 2 - 2.5)
		local radius = math.min(maxRadius, math.max(4, #list * 6 / (2 * math.pi)))
		local angle = (slot - 1) / #list * math.pi * 2
		offsetX, offsetZ = math.cos(angle) * radius, math.sin(angle) * radius
	end

	return plate.CFrame * CFrame.new(offsetX, plate.Size.Y / 2 + GameConfig.SpawnHeight, offsetZ)
end

function PlateSpawner.GetPlateAt(row: number, col: number): BasePart?
	return grid[row] and grid[row][col]
end

-- For events like Guillotine
function PlateSpawner.GetRow(row: number): { BasePart }
	local list = {}
	for col = 1, gridCols do
		local plate = PlateSpawner.GetPlateAt(row, col)
		if plate then
			table.insert(list, plate)
		end
	end
	return list
end

function PlateSpawner.GetColumn(col: number): { BasePart }
	local list = {}
	for row = 1, gridRows do
		local plate = PlateSpawner.GetPlateAt(row, col)
		if plate then
			table.insert(list, plate)
		end
	end
	return list
end

-- Every plate in the arena, owned or not
function PlateSpawner.GetAllPlates(): { BasePart }
	return table.clone(allPlates)
end

-- Only plates that belong to a player (each plate once, even if several players share it)
function PlateSpawner.GetOwnedPlates(): { BasePart }
	local list = {}
	local seen: { [BasePart]: boolean } = {}
	for _, plate in plateByUserId do
		if not seen[plate] then
			seen[plate] = true
			table.insert(list, plate)
		end
	end
	return list
end

-- Protected plates (update 23): plate -> { [key] = true }
local guards: { [BasePart]: { [string]: boolean } } = {}
local graced: { [BasePart]: boolean } = setmetatable({}, { __mode = "k" }) :: any
local savedEvent = Instance.new("BindableEvent")
-- plates destroyed this round (update 25): { CFrame, Size, Color, Material, Row, Col }
local destroyedLog: { { [string]: any } } = {}
local rebuiltCount = 0
PlateSpawner.Saved = savedEvent.Event
PlateSpawner.SureFootingGrace = 1.5 -- seconds a Sure Footing player's plate holds on before it crumbles

function PlateSpawner.Protect(plate: BasePart, key: string, on: boolean?)
	local keys = guards[plate]
	if on == false then
		if keys then
			keys[key] = nil
			if next(keys) == nil then
				guards[plate] = nil
			end
		end
		return
	end
	if not keys then
		keys = {}
		guards[plate] = keys
	end
	keys[key] = true
end

function PlateSpawner.IsProtected(plate: BasePart): boolean
	local keys = guards[plate]
	return keys ~= nil and next(keys) ~= nil
end

-- somebody with Sure Footing standing on this plate (nil = nobody)
local function sureFooted(plate: BasePart): Player?
	local now = workspace:GetServerTimeNow()
	local top = plate.Position.Y + plate.Size.Y / 2
	for _, player in Players:GetPlayers() do
		local ends = player:GetAttribute("Buff_SureFooting")
		local character = player.Character
		local root = character and character:FindFirstChild("HumanoidRootPart")
		local humanoid = character and character:FindFirstChildOfClass("Humanoid")
		if type(ends) == "number" and ends > now and root and root:IsA("BasePart") and humanoid and humanoid.Health > 0 then
			local feet = root.Position.Y - 3
			if math.abs(root.Position.X - plate.Position.X) <= plate.Size.X / 2 + 0.5
				and math.abs(root.Position.Z - plate.Position.Z) <= plate.Size.Z / 2 + 0.5
				and feet >= top - 1.5 and feet <= top + 7 then
				return player
			end
		end
	end
	return nil
end

-- Breaks a plate: it crumbles into falling chunks and is removed from the grid,
-- so events stop targeting it. Whoever stood on it falls into the void.
-- (update 23) Not while it is protected; a little later while somebody with Sure Footing stands on it.
function PlateSpawner.DestroyPlate(plate: BasePart, why: string?)
	local index = table.find(allPlates, plate)
	if not index then
		return
	end
	-- (update 29) Sudden Death gets past the One Plate / Two Plates guard (and only that one)
	local keys = guards[plate]
	if why == "SuddenDeath" and keys and keys.Layout then
		local count = 0
		for _ in keys do
			count += 1
		end
		if count == 1 then
			guards[plate] = nil
		end
	end
	if PlateSpawner.IsProtected(plate) then
		savedEvent:Fire(plate, "Protected")
		return
	end
	if not graced[plate] then
		local who = sureFooted(plate)
		if who then
			graced[plate] = true
			savedEvent:Fire(plate, "SureFooting", who)
			task.delay(PlateSpawner.SureFootingGrace, function()
				if plate.Parent then
					PlateSpawner.DestroyPlate(plate)
				end
			end)
			return
		end
	end
	table.remove(allPlates, index)
	for userId, owned in plateByUserId do
		if owned == plate then
			plateByUserId[userId] = nil
		end
	end
	sharers[plate] = nil
	local row, col = plate:GetAttribute("Row"), plate:GetAttribute("Col")
	if row and col and grid[row] and grid[row][col] == plate then
		grid[row][col] = nil
	end

	table.insert(destroyedLog, { CFrame = plate.CFrame, Size = plate.Size, Color = plate.Color, Material = plate.Material, Row = row, Col = col })

	-- Crumble into 4 falling chunks
	local half = plate.Size / 2
	for _, corner in { Vector3.new(-1, 0, -1), Vector3.new(1, 0, -1), Vector3.new(-1, 0, 1), Vector3.new(1, 0, 1) } do
		local chunk = Instance.new("Part")
		chunk.Size = Vector3.new(plate.Size.X / 2 - 0.2, plate.Size.Y, plate.Size.Z / 2 - 0.2)
		chunk.CFrame = plate.CFrame * CFrame.new(corner.X * half.X / 2, 0, corner.Z * half.Z / 2)
		chunk.Color = plate.Color
		chunk.Material = plate.Material
		chunk.CanCollide = false
		chunk.CanQuery = false
		chunk.Anchored = false
		chunk.AssemblyLinearVelocity = Vector3.new(corner.X * 8, 6, corner.Z * 8)
		chunk.AssemblyAngularVelocity = Vector3.new(math.random(-4, 4), math.random(-4, 4), math.random(-4, 4))
		chunk.Parent = workspace
		game:GetService("Debris"):AddItem(chunk, 4)
	end
	plate:Destroy()
end

-- The plates destroyed this round that are still missing (newest last). Each: { CFrame, Size, Color, Material, Row, Col }
function PlateSpawner.Destroyed(): { { [string]: any } }
	return table.clone(destroyedLog)
end

-- Puts a destroyed plate back (one entry of PlateSpawner.Destroyed()). It is a normal plate again: in the grid, in
-- GetAllPlates, targetable by events. `at` (optional) = where it appears first (move it into entry.CFrame yourself).
function PlateSpawner.Rebuild(entry: { [string]: any }, at: CFrame?): BasePart?
	local index = table.find(destroyedLog, entry)
	if not index or not activeFolder then
		return nil
	end
	table.remove(destroyedLog, index)
	rebuiltCount += 1
	local plate = createPlate(at or entry.CFrame, 1000 + rebuiltCount, entry.Row or 0, entry.Col or 0, entry.Size)
	plate.Name = "Plate_Rebuilt" .. rebuiltCount
	plate.Color = entry.Color
	plate.Material = entry.Material
	table.insert(allPlates, plate)
	if entry.Row and entry.Col then
		grid[entry.Row] = grid[entry.Row] or {}
		grid[entry.Row][entry.Col] = plate
	end
	return plate
end

function PlateSpawner.GetGridSize(): (number, number)
	return gridRows, gridCols
end

function PlateSpawner.GetCenter(): BasePart
	return center
end

function PlateSpawner.Clear()
	if activeFolder then
		activeFolder:Destroy()
		activeFolder = nil
	end
	table.clear(allPlates)
	table.clear(plateByUserId)
	table.clear(sharers)
	table.clear(guards)
	table.clear(destroyedLog)
	table.clear(grid)
	gridRows, gridCols = 0, 0
end

return PlateSpawner