-- ModuleScript: ServerScriptService > Systems > SuddenDeath
-- The Sudden Death modifier: after a grace period, plates start dying one at a time. A dying plate
-- turns dark red for a few seconds, then is destroyed (PlateSpawner.DestroyPlate). The gap between
-- plates shrinks as the round goes on. It never destroys the last MIN_PLATES plates.
--   SuddenDeath.Start()  -- called by RoundModifiers when a round with the modifier starts
--   SuddenDeath.Stop()   -- called when the round ends (restores any plate that was going red)

local TweenService = game:GetService("TweenService")

local EventUtil = require(script.Parent:WaitForChild("EventUtil"))

local SuddenDeath = {}

local START_DELAY = 20      -- seconds before the first plate starts dying
local FIRST_GAP = 7         -- seconds between plates at first
local MIN_GAP = 2           -- fastest it gets
local GAP_SHRINK = 0.9      -- gap is multiplied by this after every plate
local WARN_TIME = 3.5       -- how long a plate stays red before it's destroyed
local MIN_PLATES = 2        -- this many plates are always left alone
local DYING_COLOR = Color3.fromRGB(80, 8, 14)

local running = false
local token = 0
local dying: { [BasePart]: { Color: Color3, Tween: Tween } } = {}
local PlateSpawner: any = nil

local function toast(title: string, text: string)
	EventUtil.GetRemote("ClientEffect"):FireAllClients("Notify", { Title = title, Text = text, Color = DYING_COLOR:Lerp(Color3.new(1, 0.3, 0.3), 0.5) })
end

local function killPlate(plate: BasePart, my: number)
	local tween = TweenService:Create(plate, TweenInfo.new(WARN_TIME, Enum.EasingStyle.Sine), { Color = DYING_COLOR })
	dying[plate] = { Color = plate.Color, Tween = tween }
	tween:Play()
	task.wait(WARN_TIME)
	if token ~= my or not running then
		return -- Stop() already restored it
	end
	dying[plate] = nil
	if plate.Parent then
		pcall(PlateSpawner.DestroyPlate, plate, "SuddenDeath") -- (Oct 12 Update 29: gets past the One / Two Plates guard)
	end
end

local function loop(my: number)
	local untilTime = os.clock() + START_DELAY
	while running and token == my and os.clock() < untilTime do
		task.wait(0.5)
	end
	if not (running and token == my) then
		return
	end
	toast("Sudden Death", "The plates are starting to crumble...")

	local gap = FIRST_GAP
	while running and token == my do
		local candidates = {}
		for _, plate in PlateSpawner.GetAllPlates() do
			if plate.Parent and not dying[plate] then
				table.insert(candidates, plate)
			end
		end
		if #candidates > MIN_PLATES then
			task.spawn(killPlate, candidates[math.random(#candidates)], token)
		end
		local untilNext = os.clock() + gap
		while running and token == my and os.clock() < untilNext do
			task.wait(0.25)
		end
		gap = math.max(MIN_GAP, gap * GAP_SHRINK)
	end
end

function SuddenDeath.Start()
	if running then
		return
	end
	if not PlateSpawner then
		PlateSpawner = require(script.Parent:WaitForChild("PlateSpawner"))
	end
	running = true
	token += 1
	task.spawn(loop, token)
end

function SuddenDeath.Stop()
	running = false
	token += 1
	for plate, info in dying do
		info.Tween:Cancel()
		if plate.Parent then
			plate.Color = info.Color
		end
	end
	table.clear(dying)
end

return SuddenDeath