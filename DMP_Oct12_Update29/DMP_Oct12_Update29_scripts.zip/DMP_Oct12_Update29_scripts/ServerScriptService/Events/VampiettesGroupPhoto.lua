-- ModuleScript: ServerScriptService > Events > VampiettesGroupPhoto     (CHANGED: Oct 12 Update 28)
-- Vampiette sets up her old camera beside the arena and wants a picture of everybody. A gold star appears
-- on STARS_PER_PLAYER x (players alive) random plates (Oct 12, your words: "only spawn enough stars for the amount of
-- people there is"; it was one on every plate), never more than there are plates: be standing on a star when the flash goes off and you are in the picture (candles and a
-- little health). She cannot make up her mind, so half way through the countdown every star jumps somewhere
-- else. If EVERYONE alive is in the picture, everybody gets a bonus. She takes PHOTOS pictures.
-- Anyone who is NOT in a picture loses MISS_DAMAGE health (she does not like being ignored).
-- This script places the stars and decides who is in each picture. What it looks like (and the photo that
-- pops up on your screen): ReplicatedStorage > EventClients > photo.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local PHOTOS = 2
local FIRST = 2.6            -- seconds before the first countdown starts
local COUNTDOWN = 6.5        -- seconds from the stars appearing to the flash
local BETWEEN = 4.4          -- seconds between one flash and the next countdown
local STAR = 3.6             -- studs: how close to the middle of a star you have to stand
local CANDLES = 12           -- for being in a picture
local HEAL = 15
local BONUS = 8              -- extra candles each when everybody is in it (needs at least 2 players)
local MISS_DAMAGE = 15       -- health you lose for missing a picture
local STARS_PER_PLAYER = 1   -- (Oct 12) stars for each player alive when it starts

type Star = { Id: number?, Plate: BasePart, Spot: Vector3 }

return {
	Name = "Vampiette's Group Photo",
	Id = "photo",
	Weight = 0.4,
	Duration = 24,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local plates = K.Plates()
		if #plates == 0 then
			return
		end
		-- she hovers beside the arena, on a random side, camera pointing in
		local minX, maxX, minZ, maxZ = math.huge, -math.huge, math.huge, -math.huge
		for _, plate in plates do
			minX = math.min(minX, plate.Position.X - plate.Size.X / 2)
			maxX = math.max(maxX, plate.Position.X + plate.Size.X / 2)
			minZ = math.min(minZ, plate.Position.Z - plate.Size.Z / 2)
			maxZ = math.max(maxZ, plate.Position.Z + plate.Size.Z / 2)
		end
		local centre = K.Arena(plates)
		local sides = { Vector3.new(1, 0, 0), Vector3.new(-1, 0, 0), Vector3.new(0, 0, 1), Vector3.new(0, 0, -1) }
		local side = sides[math.random(1, #sides)]
		local reach = if side.X ~= 0 then (maxX - minX) / 2 else (maxZ - minZ) / 2
		local her = centre + side * (reach + 15) + Vector3.new(0, 5, 0)
		local look = K.Show(context, "Photographer", CFrame.lookAt(her, Vector3.new(centre.X, her.Y, centre.Z)), { T0 = t0, Photos = PHOTOS })
		local stars: { Star } = {}
		local starPlates = K.Shuffle(table.clone(plates))
		local wanted = math.clamp(math.ceil(#K.Alive() * STARS_PER_PLAYER), 1, #starPlates)
		for index = #starPlates, wanted + 1, -1 do
			table.remove(starPlates, index)
		end
		for _, plate in starPlates do
			local spot = K.TopCentre(plate)
			table.insert(stars, { Id = K.Show(context, "Star", CFrame.new(spot), { T0 = t0, Size = STAR }), Plate = plate, Spot = spot })
		end
		K.TellAll("Vampiette's Group Photo!", "Be standing on a gold star when the flash goes off.", K.Colors.Gold)
		K.Outro(context, 1.2, function()
			K.Signal(context, look, "Outro", 1.1)
		end)

		for photo = 1, PHOTOS do
			local start = t0 + FIRST + (photo - 1) * (COUNTDOWN + BETWEEN)
			if not K.WaitUntil(context, start) then
				return
			end
			local jump, flash = start + COUNTDOWN / 2, start + COUNTDOWN
			-- every star: where it starts, and where it jumps to half way
			for _, star in stars do
				local plate = star.Plate
				if plate.Parent then
					local first = K.PointOn(plate, STAR)
					local second = first
					for _ = 1, 6 do
						second = K.PointOn(plate, STAR)
						if (second - first).Magnitude >= math.min(plate.Size.X, plate.Size.Z) * 0.3 then
							break
						end
					end
					star.Spot = second
					K.Call(context, star.Id, "Pose", photo, first, second, start, jump, flash)
				end
			end
			K.Call(context, look, "Ready", photo, start, flash)
			if not K.WaitUntil(context, flash) then
				return
			end
			-- FLASH: who is on a star?
			local inside: { Player } = {}
			local missed: { Player } = {}
			K.Each(function(player, root, _, feetY)
				local on = false
				for _, star in stars do
					if star.Plate.Parent and K.Flat(root.Position - star.Spot).Magnitude <= STAR and math.abs(feetY - star.Spot.Y) <= 8 then
						on = true
						break
					end
				end
				table.insert(if on then inside else missed, player)
			end)
			local everyone = #missed == 0 and #inside >= 2
			local ids: { number } = {}
			for _, player in inside do
				table.insert(ids, player.UserId)
				local candles = CANDLES + (if everyone then BONUS else 0)
				K.Candles(player, candles)
				K.Heal(player, HEAL)
				K.Complete(context, player) -- Event Journal: you have been in one of her pictures
				K.Tell(player, if everyone then "Picture perfect!" else "You're in the picture!", "+" .. candles .. " candles, +" .. HEAL .. " health", K.Colors.Gold)
			end
			for _, player in missed do
				K.Strike(context, look, player, MISS_DAMAGE)
				K.Tell(player, "You missed the photo!", "-" .. MISS_DAMAGE .. " health. Stand on a gold star when the flash goes off.", K.Colors.Purple)
			end
			-- (who is in it goes along as a list of user ids, so every client can put the same picture together)
			K.Signal(context, look, "Snap", photo, everyone, #inside + #missed, table.unpack(ids))
			for _, star in stars do
				K.Call(context, star.Id, "Taken", photo, flash)
			end
		end
		K.Hold(context)
	end,
}
