-- ModuleScript: ServerScriptService > Events > GhostPop     (NEW: Oct 12 Update 27, /setevent ghostpop)
-- GHOST POP (your backlog, reward event 19): old bones lie about on the plates (the model Bone under this script) and
-- a ghost dog (the model Dog) sits on one plate, waiting. Hold E at a bone to pick it up (ONE each): it goes in your
-- hands as the tool "Old Bone". No QTE: you choose what to do with it, and every choice gives you an item:
--   CRUSH IT    click with it                                 -> an item, and SOUL_CRUSH soul (towards Vampire)
--   TOSS IT     the TOSS button / T on your screen, or drop it -> an item
--   GIVE IT     hold E at the dog while you have it            -> an item, and SOUL_GIVE soul (towards Ghost)
-- (Your backlog: the soul changes are free, not a contract price.) A bone still held at the end crumbles.
-- The held bone (the model HeldBone, its grip part is Handle) is cloned into a Tool here. The TOSS button is the
-- ScreenGui BoneGui. ReplicatedStorage > EventClients > ghostpop draws the dog, the bones and the button.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local DURATION = 30
local MIN_BONES = 5
local MAX_BONES = 8
local SOUL_CRUSH = -5
local SOUL_GIVE = 5
local HOLD = 0.3
local TOOL_NAME = "Old Bone"

-- the Tool: the model HeldBone welded to its Handle
local function makeBone(): Tool?
	local template = script:FindFirstChild("HeldBone")
	local handle = template and template:FindFirstChild("Handle")
	if not (template and handle and handle:IsA("BasePart")) then
		warn("[Ghost Pop] the model HeldBone (with a part Handle) is missing under ServerScriptService > Events > GhostPop: install the WHOLE update (drag its .rbxmx in).")
		return nil
	end
	local model = template:Clone()
	local grip = model:FindFirstChild("Handle") :: BasePart
	local tool = Instance.new("Tool")
	tool.Name = TOOL_NAME
	tool.ToolTip = "Click: crush it. TOSS: throw it away. Or give it to the ghost dog."
	tool.CanBeDropped = true
	tool.RequiresHandle = true
	tool.Grip = CFrame.Angles(0, 0, math.rad(90))
	for _, part in model:GetDescendants() do
		if part:IsA("BasePart") then
			part.Anchored = false
			part.CanCollide = false
			part.CanQuery = false
			part.CanTouch = part == grip
			part.Massless = true
			if part ~= grip then
				local weld = Instance.new("WeldConstraint")
				weld.Part0 = grip
				weld.Part1 = part
				weld.Parent = part
			end
		end
	end
	for _, child in model:GetChildren() do
		child.Parent = tool
	end
	model:Destroy()
	return tool
end

local function addSoul(player: Player, amount: number)
	local FeedHaunt = K.Sys("FeedHaunt")
	if FeedHaunt and FeedHaunt.GetSoul and FeedHaunt.SetSoul then
		FeedHaunt.SetSoul(player, FeedHaunt.GetSoul(player) + amount)
	end
end

return {
	Name = "Ghost Pop",
	Id = "ghostpop",
	Weight = 1,
	Duration = DURATION,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local plates = K.Shuffle(K.Plates())
		if #plates == 0 then
			return
		end
		-- the dog on the first plate, the bones on the others (round again if there are few plates)
		local dogPlate = plates[1]
		local dogSpot = K.PointOn(dogPlate, 4)
		local towards = K.Dir(K.Flat(K.Arena(plates) - dogSpot), Vector3.new(0, 0, -1))
		local dogId = K.Show(context, "Dog", CFrame.lookAt(dogSpot, dogSpot + towards), { T0 = t0, Duration = DURATION, Tag = K.Tag(context, dogPlate) })
		local dogAnchor, dogPrompt = K.Prompt(dogSpot + Vector3.new(0, 2, 0), "Give bone", "Ghost Dog", HOLD, context.Folder)
		dogPrompt.MaxActivationDistance = 9
		dogPrompt.RequiresLineOfSight = false
		K.Pin(context, dogAnchor, dogPlate, function()
			dogAnchor:Destroy()
			K.Hide(context, dogId)
		end)

		local holding: { [Player]: Tool } = {}
		local had: { [Player]: boolean } = {}
		-- a bone is used up one way or the other: the tool goes, the item comes, the soul moves
		local function use(player: Player, how: string)
			local tool = holding[player]
			if not tool then
				return
			end
			holding[player] = nil
			local at = tool:FindFirstChild("Handle")
			local where = if at and at:IsA("BasePart") then at.Position else nil
			tool:Destroy()
			local item = K.GiveItem(player)
			local got = if item then "You got a " .. item .. "." else "Nothing came of it."
			if how == "Crush" then
				addSoul(player, SOUL_CRUSH)
				K.Signal(context, dogId, "Crushed", player.UserId, where)
				K.Tell(player, "Crunch!", got .. " Your soul darkens a little (" .. SOUL_CRUSH .. " soul).", K.Colors.Purple)
			elseif how == "Give" then
				addSoul(player, SOUL_GIVE)
				K.Signal(context, dogId, "Fed", player.UserId)
				K.Tell(player, "Good dog!", got .. " Your soul brightens a little (+" .. SOUL_GIVE .. " soul).", K.Colors.Ghost)
			else
				K.Signal(context, dogId, "Tossed", player.UserId, where)
				K.Tell(player, "Tossed!", got, K.Colors.Bone)
			end
			K.Complete(context, player)
		end

		local count = math.random(MIN_BONES, math.max(MIN_BONES, MAX_BONES))
		for i = 1, count do
			local plate = plates[(i % #plates) + 1]
			local spot = K.PointOn(plate, 3)
			local id = K.Show(context, "Bone", CFrame.new(spot) * CFrame.Angles(0, math.random() * math.pi * 2, 0), {
				T0 = t0, Duration = DURATION, Delay = (i - 1) * 0.15, Tag = K.Tag(context, plate),
			})
			local anchor, prompt = K.Prompt(spot + Vector3.new(0, 1.2, 0), "Pick up", "Old Bone", HOLD, context.Folder)
			prompt.MaxActivationDistance = 8
			prompt.RequiresLineOfSight = false
			local gone = false
			local function remove()
				if not gone then
					gone = true
					anchor:Destroy()
				end
			end
			K.Pin(context, anchor, plate, function()
				remove()
				K.Hide(context, id)
			end)
			prompt.Triggered:Connect(function(player: Player)
				if gone or had[player] or not context.IsRunning() or not K.IsAlive(player) then
					return
				end
				local backpack = player:FindFirstChildOfClass("Backpack")
				local tool = makeBone()
				if not (tool and backpack) then
					return
				end
				had[player] = true
				remove()
				K.Call(context, id, "Taken", player.UserId)
				K.Hide(context, id, 0.4)
				holding[player] = tool
				tool.Activated:Connect(function()
					if holding[player] == tool then
						use(player, "Crush")
					end
				end)
				-- dropped (Backspace): a toss
				tool.AncestryChanged:Connect(function(_, parent)
					local inWorld = parent ~= nil and (parent == workspace or parent:IsDescendantOf(workspace))
					local inHands = player.Character ~= nil and parent ~= nil and (parent == player.Character or parent:IsDescendantOf(player.Character))
					if holding[player] == tool and inWorld and not inHands then
						use(player, "Toss")
					end
				end)
				tool.Parent = backpack
				local humanoid = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
				if humanoid then
					humanoid:EquipTool(tool)
				end
				K.Call(context, dogId, "Holding", player.UserId)
			end)
		end
		K.TellAll("Ghost Pop", "Old bones are lying about, and a ghost dog is waiting. Grab a bone: crush it, toss it, or give it to the dog.", K.Colors.Ghost)

		-- the dog takes a bone
		dogPrompt.Triggered:Connect(function(player: Player)
			if holding[player] and context.IsRunning() and K.IsAlive(player) then
				use(player, "Give")
			end
		end)
		-- the TOSS button
		K.Listen(context, function(player: Player, what: any)
			if what == "Toss" and holding[player] and context.IsRunning() then
				use(player, "Toss")
			end
		end)

		-- the end: bones still in somebody's hands crumble
		K.Outro(context, 1, function()
			dogPrompt.Enabled = false
			for player, tool in holding do
				holding[player] = nil
				tool:Destroy()
				K.Tell(player, "Ghost Pop", "Your old bone crumbled to dust.", K.Colors.Bone)
			end
		end)
	end,
}
