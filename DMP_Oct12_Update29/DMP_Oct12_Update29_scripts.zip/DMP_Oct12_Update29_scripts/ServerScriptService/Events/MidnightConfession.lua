-- ModuleScript: ServerScriptService > Events > MidnightConfession     (NEW: Oct 12 Update 27, /setevent confession)
-- MIDNIGHT CONFESSION (your backlog, together event 21): an old confession booth (the model Booth under this script)
-- rises out of a random plate. Step into it and hold E: the bell on its roof tolls and ONE debuff is lifted from you
-- (Systems > EventUtil.Cure):
--   1. a stat shift that makes you weaker (Weighing of the Heart and the like: Systems > StatShift.Cure), else
--   2. a burn / poison / bleeding on you (and that kind of damage can't hurt you for 6 s).
-- Item, feed / haunt and contract effects are NEVER touched. One confession each.
-- [MY CALL] Nothing to lift = the bell still tolls and you heal PEACE HP, so the walk there is never wasted.
-- ReplicatedStorage > EventClients > confession raises the booth and swings the bell.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local DURATION = 20
local HOLD = 1.5            -- seconds of confessing (hold E inside the booth)
local REACH = 4             -- studs from the middle of the booth the prompt works
local PEACE = 5             -- HP when there was nothing to lift
local RISE = 2              -- seconds the booth takes to rise (KEEP about EventClients > confession RISE)

return {
	Name = "Midnight Confession",
	Id = "confession",
	Weight = 1,
	Duration = DURATION,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local Damage = K.Sys("Damage")
		local plates = K.Plates()
		local plate = K.PickPlate(plates)
		if not plate then
			return
		end
		local centre = K.TopCentre(plate)
		local face = K.Dir(K.Flat(K.Arena(plates) - centre), Vector3.new(0, 0, -1))
		local id = K.Show(context, "Booth", CFrame.lookAt(centre, centre + face), { T0 = t0, Duration = DURATION, Tag = K.Tag(context, plate), Rise = RISE })
		local anchor, prompt = K.Prompt(centre + Vector3.new(0, 2.5, 0), "Confess", "Confession Booth", HOLD, context.Folder)
		prompt.MaxActivationDistance = REACH
		prompt.RequiresLineOfSight = false
		prompt.Enabled = false
		K.Pin(context, anchor, plate, function()
			anchor:Destroy()
			K.Hide(context, id)
		end)
		K.TellAll("Midnight Confession", "A confession booth has risen. Step inside and the bell will lift a curse from you.", K.Colors.Purple)
		task.delay(RISE, function()
			if context.IsRunning() and anchor.Parent then
				prompt.Enabled = true
			end
		end)

		local done: { [Player]: boolean } = {}
		prompt.Triggered:Connect(function(player: Player)
			if done[player] or not context.IsRunning() or not K.IsAlive(player) then
				return
			end
			done[player] = true
			local lifted = if K.Cure then K.Cure(player) else nil
			K.Call(context, id, "Toll", player.UserId, lifted ~= nil)
			K.Complete(context, player)
			if lifted then
				K.Tell(player, "The bell tolls", "Your " .. lifted .. " is lifted.", K.Colors.Purple)
			else
				if Damage and Damage.Heal then
					pcall(Damage.Heal, player, PEACE, { Source = "Midnight Confession" })
				end
				K.Tell(player, "The bell tolls", "Nothing weighs on you. You feel a little lighter anyway (+" .. PEACE .. " HP).", K.Colors.Purple)
			end
		end)
		K.Outro(context, RISE, function()
			prompt.Enabled = false
		end)
	end,
}
