-- ModuleScript: ServerScriptService > Events > Smores     (NEW: Oct 12 Update 27, /setevent smores)
-- SMORES (your backlog, together event 20): a campfire burns on a plate (the model Campfire under this script) with
-- marshmallows on sticks stuck in the ground round it (the model Stick: one more than there are players, at least
-- MIN_STICKS). Hold E at one to roast it (you don't sit down): ONE each. It heals HEAL and gives you one buff from your
-- list (one you do not have yet when it can; they live in Systems > EventUtil.Buff):
--   Shared Warmth  30 s: everybody within 6 studs of you, you too, heals 1 HP a second
--   Thick Skin     30 s: the FIRST hit of each kind (fire, poison, bleed, and plain hits) does half damage
--   Second Wind    the next hit that drops you below 25% health (and leaves you alive) heals you 15 at once
-- ReplicatedStorage > EventClients > smores draws the fire and toasts the marshmallows.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local DURATION = 25
local MIN_STICKS = 4
local MAX_STICKS = 9
local RING = 3.6            -- studs from the fire to the sticks
local HOLD = 1.5            -- seconds of roasting (hold E)
local HEAL = 10
local BUFFS = { "SharedWarmth", "ThickSkin", "SecondWind" }

return {
	Name = "Smores",
	Id = "smores",
	Weight = 1,
	Duration = DURATION,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local Damage = K.Sys("Damage")
		local plates = K.Plates()
		local plate = K.PickPlate(plates)
		if not plate then
			return
		end
		local tag = K.Tag(context, plate)
		local centre = K.TopCentre(plate)
		local fireId = K.Show(context, "Campfire", CFrame.new(centre), { T0 = t0, Duration = DURATION, Tag = tag })
		K.TellAll("Smores", "A campfire is crackling on a plate. Roast a marshmallow!", K.Colors.Orange)

		local roasted: { [Player]: boolean } = {}
		local count = math.clamp(#K.Alive() + 1, MIN_STICKS, MAX_STICKS)
		local turn = math.random() * math.pi * 2
		for i = 1, count do
			local a = turn + (i - 1) / count * math.pi * 2
			local out = Vector3.new(math.cos(a), 0, math.sin(a))
			local spot = centre + out * RING
			local id = K.Show(context, "Stick", CFrame.lookAt(spot, centre), { T0 = t0, Duration = DURATION, Tag = tag, Delay = 0.6 + i * 0.1 })
			local anchor, prompt = K.Prompt(spot + Vector3.new(0, 1.4, 0), "Roast", "Marshmallow", HOLD, context.Folder)
			prompt.MaxActivationDistance = 6
			prompt.RequiresLineOfSight = false
			local gone = false
			local function remove()
				if not gone then
					gone = true
					anchor:Destroy()
				end
			end
			K.Pin(context, anchor, plate, function()
				remove()
				K.Hide(context, id)
			end)
			prompt.Triggered:Connect(function(player: Player)
				if gone or roasted[player] or not context.IsRunning() or not K.IsAlive(player) then
					return
				end
				roasted[player] = true
				remove()
				K.Call(context, id, "Roast", player.UserId)
				K.Hide(context, id, 1.6)
				local got: { string } = {}
				if Damage and Damage.Heal then
					local ok, amount = pcall(Damage.Heal, player, HEAL, { Source = "Smores" })
					if ok and type(amount) == "number" and amount > 0 then
						table.insert(got, "+" .. math.floor(amount + 0.5) .. " HP")
					end
				end
				local options: { string } = {}
				for _, name in BUFFS do
					if player:GetAttribute("Buff_" .. name) == nil then
						table.insert(options, name)
					end
				end
				local buff = K.Pick(if #options > 0 then options else BUFFS)
				if buff and K.Buff(player, buff) then
					table.insert(got, K.BuffNames[buff] or buff)
					K.Signal(context, fireId, "Buff", player.UserId, buff)
				end
				K.Complete(context, player)
				K.Tell(player, "S'more!", if #got > 0 then table.concat(got, ", ") else "Gooey.", K.Colors.Orange)
			end)
		end
		K.Outro(context, 1.5, function()
			for _, item in context.Folder:GetDescendants() do
				if item:IsA("ProximityPrompt") then
					item.Enabled = false
				end
			end
			K.Call(context, fireId, "Out")
		end)
	end,
}
