-- ModuleScript: ServerScriptService > Events > PumpkinPatch     (NEW: Oct 12 Update 27, /setevent patch)
-- PUMPKIN PATCH (your backlog, reward event 18): 6 to 10 small pumpkins sprout on the plates (the model Pumpkin under
-- this script). Hold E to smash one: it gives ONE of these at random (OUTCOMES, change the weights):
--   Heal      +HEAL HP
--   Speed     SPEED times as fast for SPEED_TIME seconds
--   Item      a random item from ServerStorage > Items
--   HopStone  your next 2 jumps go 30% higher (Hop Stone, from your buff list: Systems > EventUtil.Buff)
-- Each player can smash PER_PLAYER pumpkins, so everybody gets some. What came out floats over the pumpkin on the
-- smasher's screen (a toast too for their first one, and for an item). The ones left over sink back into the plates.
-- How they sprout, wobble and burst: ReplicatedStorage > EventClients > patch.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local DURATION = 20
local MIN_PUMPKINS = 6
local MAX_PUMPKINS = 10
local PER_PLAYER = 2        -- pumpkins one player may smash
local HOLD = 0.5            -- seconds to hold E
local SPROUT = 2.5          -- they sprout one after another over this many seconds
local HEAL = 20
local SPEED = 1.2
local SPEED_TIME = 10
local OUTCOMES = {          -- { what, weight }
	{ "Heal", 3 },
	{ "Speed", 3 },
	{ "Item", 2 },
	{ "HopStone", 2 },
}

local function roll(): string
	local total = 0
	for _, outcome in OUTCOMES do
		total += outcome[2]
	end
	local r = math.random() * total
	for _, outcome in OUTCOMES do
		r -= outcome[2]
		if r <= 0 then
			return outcome[1]
		end
	end
	return OUTCOMES[1][1]
end

return {
	Name = "Pumpkin Patch",
	Id = "patch",
	Weight = 1,
	Duration = DURATION,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local Damage = K.Sys("Damage")
		local plates = K.Shuffle(K.Plates())
		if #plates == 0 then
			return
		end
		local count = math.random(MIN_PUMPKINS, math.max(MIN_PUMPKINS, MAX_PUMPKINS))
		local smashed: { [Player]: number } = {}
		K.TellAll("Pumpkin Patch", "Pumpkins are sprouting on the plates. Smash them open!", K.Colors.Orange)
		for i = 1, count do
			local plate = plates[(i - 1) % #plates + 1]
			local spot = K.PointOn(plate, 3)
			local delay = (i - 1) / math.max(count - 1, 1) * SPROUT
			local id = K.Show(context, "Pumpkin", CFrame.new(spot) * CFrame.Angles(0, math.random() * math.pi * 2, 0), {
				T0 = t0, Duration = DURATION, Delay = delay, Tag = K.Tag(context, plate), Size = 0.85 + math.random() * 0.35,
			})
			local anchor, prompt = K.Prompt(spot + Vector3.new(0, 1.5, 0), "Smash", "Pumpkin", HOLD, context.Folder)
			prompt.Enabled = false
			prompt.MaxActivationDistance = 8
			prompt.RequiresLineOfSight = false
			local gone = false
			local function remove()
				if not gone then
					gone = true
					anchor:Destroy()
				end
			end
			K.Pin(context, anchor, plate, function()
				remove()
				K.Hide(context, id)
			end)
			task.delay(delay + 0.8, function()
				if context.IsRunning() and not gone then
					prompt.Enabled = true
				end
			end)
			prompt.Triggered:Connect(function(player: Player)
				if gone or not context.IsRunning() or not K.IsAlive(player) then
					return
				end
				if (smashed[player] or 0) >= PER_PLAYER then
					return
				end
				smashed[player] = (smashed[player] or 0) + 1
				remove()
				local what = roll()
				local text: string
				if what == "Heal" then
					local amount = 0
					if Damage and Damage.Heal then
						local ok, healed = pcall(Damage.Heal, player, HEAL, { Source = "Pumpkin Patch" })
						amount = if ok and type(healed) == "number" then healed else 0
					end
					text = if amount > 0 then "+" .. math.floor(amount + 0.5) .. " HP" else "Sweet and filling (you were already at full health)."
				elseif what == "Speed" then
					K.Mod(player, "WalkSpeed", { Mult = SPEED }, "PumpkinSpeed", SPEED_TIME)
					text = "You feel quick on your feet for " .. SPEED_TIME .. " seconds."
				elseif what == "Item" then
					local name = K.GiveItem(player)
					text = if name then "There was a " .. name .. " inside!" else "Just seeds."
				else
					K.Buff(player, "HopStone")
					text = "Hop Stone: your next 2 jumps go higher."
				end
				K.Call(context, id, "Smash", player.UserId, what)
				K.Hide(context, id, 1.6)
				K.Complete(context, player)
				-- (no toast spam: the smasher sees what came out over the pumpkin; a toast for the first one and items)
				if smashed[player] == 1 or what == "Item" then
					K.Tell(player, "Pumpkin Patch", text, K.Colors.Orange)
				end
			end)
		end
		-- the ones nobody smashed sink back in at the end
		K.Outro(context, 1.2, function()
			for _, item in context.Folder:GetDescendants() do
				if item:IsA("ProximityPrompt") then
					item.Enabled = false
				end
			end
		end)
	end,
}
