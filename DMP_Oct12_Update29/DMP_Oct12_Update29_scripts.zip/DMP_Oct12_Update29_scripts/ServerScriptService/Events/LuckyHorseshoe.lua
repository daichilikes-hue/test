-- ModuleScript: ServerScriptService > Events > LuckyHorseshoe     (NEW: Oct 12 Update 26, /setevent horseshoe)
-- LUCKY HORSESHOE (your backlog, luck event 15): an old horseshoe (the model Horseshoe under this script) is nailed to
-- a random plate, glinting. The first to pry it loose (hold E) gets LUCKY LANDING: the next time they fall off a plate
-- (this round) they are put straight back on the nearest one, once. (Systems > EventUtil.Buff "LuckyLanding".)
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local DURATION = 20
local HOLD = 1.2            -- seconds to pry it loose

return {
	Name = "Lucky Horseshoe",
	Id = "horseshoe",
	Weight = 1,
	Duration = DURATION,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local plate = K.PickPlate(K.Plates())
		if not plate then
			return
		end
		local spot = K.PointOn(plate, 4)
		local id = K.Show(context, "Horseshoe", CFrame.new(spot) * CFrame.Angles(0, math.random() * math.pi * 2, 0), { T0 = t0, Duration = DURATION, Tag = K.Tag(context, plate) })
		local anchor, prompt = K.Prompt(spot + Vector3.new(0, 1.5, 0), "Pry it loose", "Lucky Horseshoe", HOLD, context.Folder)
		prompt.MaxActivationDistance = 8
		prompt.RequiresLineOfSight = false
		K.Pin(context, anchor, plate, function()
			anchor:Destroy()
			K.Hide(context, id)
		end)
		K.TellAll("Lucky Horseshoe", "A lucky horseshoe is nailed to a plate. Pry it loose before anyone else!", K.Colors.Gold)
		prompt.Triggered:Connect(function(player: Player)
			if not anchor.Parent or not K.IsAlive(player) then
				return
			end
			anchor:Destroy()
			K.Buff(player, "LuckyLanding")
			K.Call(context, id, "Taken", player.UserId)
			K.Hide(context, id, 1.2)
			K.Complete(context, player)
			K.Tell(player, "Lucky Landing!", "The next time you fall off a plate, you'll land back on one. Once.", K.Colors.Gold)
			K.TellAll("Lucky Horseshoe", player.DisplayName .. " got the lucky horseshoe!", K.Colors.Gold)
		end)
	end,
}
