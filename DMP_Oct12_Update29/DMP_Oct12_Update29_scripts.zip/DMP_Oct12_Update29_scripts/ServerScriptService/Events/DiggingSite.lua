-- ModuleScript: ServerScriptService > Events > DiggingSite     (NEW: Oct 12 Update 26, /setevent dig)
-- DIGGING SITE (your backlog, reward event 17): a dig spot (the model DigSpot under this script: a mound, a ring of
-- stones, a shovel stuck in it) on a random plate. Hold E to start digging: a timing bar comes up on YOUR screen (the
-- ScreenGui DigGui): press when the swinging marker is inside the lit zone. Three good strokes dig it up = a random
-- item. A miss jams the shovel for JAM seconds. One digger at a time; walk away (or get knocked out) and somebody else
-- can carry on where you left off. Judged here, from the server time your client says you pressed (clamped).
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local DURATION = 25
local HITS = 3              -- good strokes to dig it up
local PERIODS = { 1.5, 1.25, 1.05 } -- seconds one full swing of the marker takes, stroke by stroke
local ZONES = { 0.24, 0.2, 0.16 }   -- width of the lit zone (part of the bar), stroke by stroke
local JAM = 1               -- seconds the shovel jams after a miss
local REACH = 10            -- studs from the spot a digger may stand
local HOLD = 0.5

-- where the marker is (0 .. 1 along the bar) at server time `t`: it swings to and fro from the left
local function markerAt(start: number, period: number, t: number): number
	local u = ((t - start) / period) % 1
	return if u < 0.5 then u * 2 else 2 - u * 2
end

return {
	Name = "Digging Site",
	Id = "dig",
	Weight = 1,
	Duration = DURATION,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local plate = K.PickPlate(K.Plates())
		if not plate then
			return
		end
		local spot = K.PointOn(plate, 5)
		local id = K.Show(context, "DigSpot", CFrame.new(spot) * CFrame.Angles(0, math.random() * math.pi * 2, 0), { T0 = t0, Duration = DURATION, Tag = K.Tag(context, plate), Hits = HITS })
		local anchor, prompt = K.Prompt(spot + Vector3.new(0, 2, 0), "Dig", "Digging Site", HOLD, context.Folder)
		prompt.MaxActivationDistance = 8
		prompt.RequiresLineOfSight = false
		K.Pin(context, anchor, plate, function()
			anchor:Destroy()
			K.Hide(context, id)
		end)
		K.TellAll("Digging Site", "Something is buried on one of the plates. Dig it up!", K.Colors.Bone)

		local hits = 0
		local digger: Player? = nil
		local cue: { Start: number, Period: number, Centre: number, Width: number }? = nil
		local jammedUntil = 0
		local done = false
		local rng = Random.new()
		local function newCue()
			local stroke = math.min(hits + 1, #PERIODS)
			local width = ZONES[stroke]
			cue = {
				Start = K.Now() + 0.25, Period = PERIODS[stroke],
				Centre = rng:NextNumber(0.2 + width / 2, 0.95 - width / 2), Width = width,
			}
			local c = cue :: any
			K.Signal(context, id, "Cue", (digger :: Player).UserId, c.Start, c.Period, c.Centre, c.Width, hits)
		end
		local function release(why: string?)
			if digger then
				K.Call(context, id, "Free", digger.UserId, hits)
				digger = nil
				cue = nil
				prompt.Enabled = not done
			end
		end
		prompt.Triggered:Connect(function(player: Player)
			if done or digger or not K.IsAlive(player) then
				return
			end
			digger = player
			prompt.Enabled = false
			K.Call(context, id, "Digging", player.UserId, hits)
			newCue()
		end)
		K.Listen(context, function(player: Player, what: any, pressed: any)
			if what ~= "Press" or player ~= digger or done or not cue or typeof(pressed) ~= "number" then
				return
			end
			local now = K.Now()
			if now < jammedUntil then
				return
			end
			local t = math.clamp(pressed, now - 1, now + 0.1)
			local c = cue :: any
			if t < c.Start then
				return -- (before this stroke's marker started: ignored)
			end
			local x = markerAt(c.Start, c.Period, t)
			if math.abs(x - c.Centre) <= c.Width / 2 + 0.02 then
				hits += 1
				K.Signal(context, id, "Stroke", player.UserId, hits, true)
				if hits >= HITS then
					done = true
					cue = nil
					local item = K.GiveItem(player)
					K.Call(context, id, "Dug", player.UserId, item or "")
					K.Complete(context, player)
					K.Tell(player, "Dug it up!", if item then "You found a " .. item .. "!" else "Just old bones...", K.Colors.Gold)
					K.TellAll("Digging Site", player.DisplayName .. " dug up a " .. tostring(item or "pile of old bones") .. "!", K.Colors.Gold)
					return
				end
				newCue()
			else
				jammedUntil = now + JAM
				K.Signal(context, id, "Stroke", player.UserId, hits, false)
				cue = nil
				task.delay(JAM, function()
					if digger == player and not done and context.IsRunning() then
						newCue()
					end
				end)
			end
		end)
		-- a digger who walks off or is knocked out lets go
		while context.IsRunning() and not done do
			local current = digger
			if current then
				local root = K.Root(current)
				if not K.IsAlive(current) or not root or K.Flat(root.Position - spot).Magnitude > REACH then
					release()
				end
			end
			task.wait(0.2)
		end
		if digger and not done then
			release()
		end
	end,
}
