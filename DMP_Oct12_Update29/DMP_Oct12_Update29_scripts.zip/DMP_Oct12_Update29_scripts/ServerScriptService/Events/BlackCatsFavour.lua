-- ModuleScript: ServerScriptService > Events > BlackCatsFavour     (NEW: Oct 12 Update 26, /setevent blackcat)
-- BLACK CAT'S FAVOUR (your backlog, luck event 16): a black cat (the model Cat under this script) wanders from plate to
-- plate, stopping to sit and wash a paw. Catch up with it and pet it (hold E, once each) for a random bit of luck
-- (your buff table, Systems > EventUtil.Buff):
--   GRAVE LUCK     an item from the pool that you do not have yet                          (LUCK_WEIGHTS)
--   PLATE MAGNET   for 30 s, falling off near a plate pulls you gently back toward it
--   BORROWED TIME  RARE: the next hit that would knock you out leaves you at 1 HP instead (not the void)
-- The cat's walk is worked out the SAME way here and on the clients (catAt below = catAt in EventClients > blackcat),
-- so the prompt rides on it.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local DURATION = 25
local STOPS = 6             -- plates it visits
local SPEED = 9             -- studs a second it pads along
local SIT = 2.5             -- seconds it sits at each stop
local HOLD = 0.5
local LUCK_WEIGHTS = { GraveLuck = 0.45, PlateMagnet = 0.45, BorrowedTime = 0.1 }

-- where the cat is at time t on its route (flat list x1, z1, x2, z2 ...): x, z, the way it faces, and whether it sits.
-- (KEEP THE SAME as catAt in EventClients > blackcat)
local function catAt(route: { number }, speed: number, sit: number, t: number): (number, number, number, number, boolean)
	local clock = 0
	local n = math.floor(#route / 2)
	for i = 1, n do
		local x, z = route[2 * i - 1], route[2 * i]
		local nx, nz = route[2 * i + 1], route[2 * i + 2]
		if t < clock + sit or not nx then
			local fx, fz = 0, -1
			if i > 1 then
				fx, fz = x - route[2 * i - 3], z - route[2 * i - 2]
			end
			return x, z, fx, fz, true
		end
		clock += sit
		local length = math.sqrt((nx - x) ^ 2 + (nz - z) ^ 2)
		local walk = length / speed
		if t < clock + walk then
			local u = (t - clock) / math.max(walk, 1e-3)
			return x + (nx - x) * u, z + (nz - z) * u, nx - x, nz - z, false
		end
		clock += walk
	end
	return route[#route - 1], route[#route], 0, -1, true
end

local function pickLuck(): string
	local total = 0
	for _, w in LUCK_WEIGHTS do
		total += w
	end
	local roll = math.random() * total
	for name, w in LUCK_WEIGHTS do
		roll -= w
		if roll <= 0 then
			return name
		end
	end
	return "GraveLuck"
end

return {
	Name = "Black Cat's Favour",
	Id = "blackcat",
	Weight = 1,
	Duration = DURATION,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local plates = K.Plates()
		if #plates == 0 then
			return
		end
		-- its wander: plate to neighbouring plate
		local near: { [BasePart]: { BasePart } } = {}
		for _, pair in K.Neighbours(plates) do
			near[pair[1]] = near[pair[1]] or {}
			near[pair[2]] = near[pair[2]] or {}
			table.insert(near[pair[1]], pair[2])
			table.insert(near[pair[2]], pair[1])
		end
		local at = K.Pick(plates) :: BasePart
		local route: { number } = {}
		local last: BasePart? = nil
		for _ = 1, STOPS do
			local spot = K.PointOn(at, 4)
			table.insert(route, spot.X)
			table.insert(route, spot.Z)
			local options: { BasePart } = {}
			local around: { BasePart } = near[at] or {}
			for _, other in around do
				if other ~= last then
					table.insert(options, other)
				end
			end
			last = at
			at = K.Pick(options) or at
		end
		local id = K.Show(context, "Cat", CFrame.new(route[1], K.BaseTop(), route[2]), {
			T0 = t0, Duration = DURATION, Route = route, Speed = SPEED, Sit = SIT, Top = K.BaseTop(),
		})
		K.TellAll("Black Cat's Favour", "A black cat is wandering the plates. Pet it for a bit of luck!", K.Colors.Purple)

		-- the prompt rides on the cat
		local anchor, prompt = K.Prompt(Vector3.new(route[1], K.BaseTop() + 2, route[2]), "Pet", "Black Cat", HOLD, context.Folder)
		prompt.MaxActivationDistance = 7
		prompt.RequiresLineOfSight = false
		K.Loop(context, function(_dt, t)
			local x, z = catAt(route, SPEED, SIT, t)
			local plate = K.PlateAt(Vector3.new(x, 0, z), K.Plates())
			local y = if plate then K.Top(plate) else K.BaseTop()
			anchor.CFrame = CFrame.new(x, y + 2, z)
		end)
		local petted: { [Player]: boolean } = {}
		prompt.Triggered:Connect(function(player: Player)
			if petted[player] or not context.IsRunning() or not K.IsAlive(player) then
				return
			end
			petted[player] = true
			local luck = pickLuck()
			local item: string? = nil
			if luck == "GraveLuck" then
				item = K.GiveNewItem(player)
			else
				K.Buff(player, luck)
			end
			K.Signal(context, id, "Pet", player.UserId, luck)
			K.Complete(context, player)
			if luck == "GraveLuck" then
				K.Tell(player, "Grave Luck", "The cat brought you something: " .. tostring(item) .. ".", K.Colors.Purple)
			elseif luck == "PlateMagnet" then
				K.Tell(player, "Plate Magnet", "For 30 s, if you fall off near a plate it pulls you back.", K.Colors.Purple)
			else
				K.Tell(player, "Borrowed Time!", "Rare luck: the next hit that would knock you out leaves you at 1 HP.", K.Colors.Purple)
			end
		end)
	end,
}
