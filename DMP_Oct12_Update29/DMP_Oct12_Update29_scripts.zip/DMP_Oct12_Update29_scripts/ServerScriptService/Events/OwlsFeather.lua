-- ModuleScript: ServerScriptService > Events > OwlsFeather     (NEW: Oct 12 Update 26, /setevent owl)
-- OWL'S FEATHER (your backlog, movement event 14): a great grey-brown owl (the model Owl under this script) glides
-- across the arena and drops 3 to 5 feathers (the model Feather) that drift down onto random plates. Take one (hold E,
-- one each) and you fall slowly for FEATHER_TIME seconds (your gravity x GRAVITY: jumps go higher and falls are gentle),
-- with the feather tucked in your back for everyone to see. Feathers nobody takes blow away at the end.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local DURATION = 20
local MIN_FEATHERS = 3
local MAX_FEATHERS = 5
local FLY = 9               -- seconds the owl takes to cross the arena
local HEIGHT = 22           -- studs over the plates it flies
local FALL = 2.6            -- seconds a feather takes to drift down
local FEATHER_TIME = 12
local GRAVITY = 0.4         -- x gravity while you hold a feather
local HOLD = 0.3

local function wearFeather(player: Player, seconds: number)
	local template = script:FindFirstChild("Feather")
	local character = player.Character
	local torso = character and character:FindFirstChild("Torso")
	if not (template and template:IsA("Model") and torso and torso:IsA("BasePart")) then
		return
	end
	local feather = template:Clone()
	feather.Name = "OwlFeather"
	feather:PivotTo(torso.CFrame * CFrame.new(0.4, 0.4, 0.65) * CFrame.Angles(0, 0, math.rad(-20)))
	for _, part in feather:GetDescendants() do
		if part:IsA("BasePart") then
			part.Anchored = false
			part.CanCollide, part.CanQuery, part.CanTouch = false, false, false
			part.Massless = true
			local weld = Instance.new("WeldConstraint")
			weld.Part0, weld.Part1 = torso, part
			weld.Parent = part
		end
	end
	feather.Parent = character
	game:GetService("Debris"):AddItem(feather, seconds)
end

return {
	Name = "Owl's Feather",
	Id = "owl",
	Weight = 1,
	Duration = DURATION,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local plates = K.Plates()
		if #plates == 0 then
			return
		end
		-- the flight: in over one wall, out over the opposite one, across the middle of the plates
		local centre = K.Arena(plates)
		local _, halfX, halfZ = K.Border()
		local angle = math.random() * math.pi * 2
		local dir = Vector3.new(math.cos(angle), 0, math.sin(angle))
		local reach = math.min(halfX, halfZ) - 4
		local a = centre - dir * reach
		local b = centre + dir * reach
		local y = K.BaseTop() + HEIGHT
		K.Show(context, "Owl", CFrame.lookAt(Vector3.new(a.X, y, a.Z), Vector3.new(b.X, y, b.Z)), {
			T0 = t0, Duration = DURATION, Ax = a.X, Az = a.Z, Bx = b.X, Bz = b.Z, Y = y, Fly = FLY,
		})
		K.TellAll("Owl's Feather", "An owl is dropping feathers. Grab one to float down gently!", K.Colors.Bone)

		local count = math.random(MIN_FEATHERS, math.max(MIN_FEATHERS, MAX_FEATHERS))
		local taken: { [Player]: boolean } = {}
		for i = 1, count do
			local u = 0.15 + 0.7 * (i - 0.5) / count
			local dropAt = FLY * u
			if not K.WaitUntil(context, t0 + dropAt) then
				return
			end
			local from = Vector3.new(a.X + (b.X - a.X) * u, y - 1.5, a.Z + (b.Z - a.Z) * u)
			-- the plate nearest under where it was dropped
			local best, bestD = nil, math.huge
			for _, plate in K.Plates() do
				local d = K.Flat(plate.Position - from).Magnitude + math.random() * 12
				if d < bestD then
					best, bestD = plate, d
				end
			end
			if not best then
				continue
			end
			local plate = best :: BasePart
			local spot = K.PointOn(plate, 3)
			local id = K.Show(context, "Feather", CFrame.new(spot), {
				T0 = t0, Duration = DURATION, From = from, DropAt = dropAt, Fall = FALL, Tag = K.Tag(context, plate),
			})
			task.delay(FALL, function()
				if not context.IsRunning() or not plate.Parent then
					return
				end
				local anchor, prompt = K.Prompt(Vector3.new(spot.X, K.Top(plate) + 1.5, spot.Z), "Take", "Owl Feather", HOLD, context.Folder)
				prompt.MaxActivationDistance = 8
				prompt.RequiresLineOfSight = false
				K.Pin(context, anchor, plate, function()
					anchor:Destroy()
					K.Hide(context, id)
				end)
				prompt.Triggered:Connect(function(player: Player)
					if taken[player] or not anchor.Parent or not K.IsAlive(player) then
						return
					end
					taken[player] = true
					anchor:Destroy()
					K.Mod(player, "Gravity", { Mult = GRAVITY }, "OwlFeather", FEATHER_TIME)
					wearFeather(player, FEATHER_TIME)
					K.Call(context, id, "Taken", player.UserId)
					K.Hide(context, id, 1)
					K.Complete(context, player)
					K.Tell(player, "Owl Feather", "You fall slowly for " .. FEATHER_TIME .. " seconds.", K.Colors.Bone)
				end)
			end)
		end
	end,
}
