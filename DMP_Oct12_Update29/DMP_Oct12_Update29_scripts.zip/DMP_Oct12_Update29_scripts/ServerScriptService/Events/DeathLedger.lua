-- ModuleScript: ServerScriptService > Events > DeathLedger     (REWORKED: Oct 12 Update 28, /setevent ledger)
-- Your words: "needs a complete overhaul ... you can just dodge it by walking". Your idea, built:
--   1. THE TOME (the model Tome) floats and wanders over the arena, just out of reach: JUMP INTO IT to catch it. Nobody
--      in TOME_TIME seconds = it picks somebody at random and swoops down to them.
--   2. THE SEAL PUZZLE (a new panel, the ScreenGui LedgerGui) on the holder's screen: six runes round a seal; the tome
--      lights SEQ_LEN of them one after another; press them in the same order. Wrong = it shows the order again.
--      Not solved in PUZZLE_TIME = the ledger refuses you (REFUSE_DAMAGE) and closes.
--   3. Solved = choose a name (your EventChoice player panel; nobody chosen in CHOOSE_TIME = the ledger picks).
--   4. THE CURSE: the reaper (the R6 model Reaper) floats behind them, a clock (Clock) over their head counts down
--      CURSE_TIME seconds, and the one who sealed it is marked "THE CURSER" (Mark) for everyone. Every RIDDLE_EVERY s
--      they get a quick riddle in a slim strip at the top of their screen (RiddleGui; it never covers the middle):
--      RIDDLE_TIME seconds, three answers. Wrong or too slow = DRAIN seconds off the clock.
--      THE ONLY WAY OUT: knock out the curser before the clock runs out. The clock runs out = the reaper reaps.
-- The tome's wander is worked out the SAME way here and on the clients (tomeAt below = tomeAt in EventClients >
-- ledger), so the catch happens exactly where everybody sees the book. Everything it looks like: EventClients > ledger.
local Players = game:GetService("Players")
local ServerScriptService = game:GetService("ServerScriptService")
local Systems = ServerScriptService:WaitForChild("Systems")
local K = require(Systems:WaitForChild("EventUtil"))
local EventChoice = require(Systems:WaitForChild("EventChoice"))

local TOME_TIME = 30        -- seconds the tome wanders before it picks somebody
local HEIGHT = 7.5          -- studs over the plates it floats (standing under it is not enough: you have to jump)
local CATCH_REACH = 3.5     -- studs (flat) from its middle your character has to come ...
local CATCH_UP = 3.2        -- ... with your middle no more than this far below / above it
local SEQ_LEN = 5           -- runes in the order to repeat
local FLASH = 0.6           -- seconds each rune lights up when the tome shows the order (KEEP IN SYNC with the client)
local GAP = 0.15            -- seconds between two of them
local LEAD = 0.8            -- seconds before it starts showing
local PUZZLE_TIME = 25      -- seconds to break the seal
local REFUSE_DAMAGE = 15
local CHOOSE_TIME = 10
local CURSE_TIME = 60
local RIDDLE_EVERY = 10
local RIDDLE_TIME = 3       -- seconds to answer (plus GRACE for the trip to the server)
local GRACE = 0.4
local DRAIN = 20            -- seconds a wrong / missed riddle takes off the clock
local REAP_AT = 0.9         -- seconds into the reaper's swing when it lands (KEEP IN SYNC with npcs.py REAP_AT)

local Event = {
	Name = "Death Ledger",
	Id = "ledger",
	Weight = 1,
	Duration = TOME_TIME + PUZZLE_TIME + CHOOSE_TIME + CURSE_TIME + 6,
	Target = "Arena",
}

-- WHERE THE TOME IS t seconds in: a slow figure-of-eight wander over the box of plates (KEEP THE SAME as the client)
local function tomeAt(t: number, p: { [string]: number }): Vector3
	local x = p.Cx + p.Hx * 0.8 * math.sin(0.31 * t + p.P1)
	local z = p.Cz + p.Hz * 0.8 * math.sin(0.43 * t + p.P2)
	local y = p.Top + p.Height + 0.8 * math.sin(1.7 * t)
	return Vector3.new(x, y, z)
end

-- THE RIDDLES: quick ones (2-3 s), all kid-safe. Returns the line, three answers and which one is right.
local COLOURS = { { "RED", "#e04040" }, { "BLUE", "#4a90ff" }, { "GREEN", "#4cc05a" }, { "YELLOW", "#f0d040" } }
local ODD = {
	{ "Ghost", "Bat", "Teapot" }, { "Moon", "Star", "Sock" }, { "Pumpkin", "Candle", "Fish" },
	{ "Skull", "Bone", "Cloud" }, { "Owl", "Crow", "Spoon" }, { "Witch", "Wizard", "Toaster" },
}
local function shuffleAnswers(right: string, wrong1: string, wrong2: string): ({ string }, number)
	local list = K.Shuffle({ right, wrong1, wrong2 })
	return list, table.find(list, right) :: number
end
local function makeRiddle(): (string, { string }, number)
	local kind = math.random(1, 5)
	if kind == 1 then
		local a, b = math.random(2, 9), math.random(2, 9)
		if math.random() < 0.5 and a > b then
			local r = a - b
			local list, i = shuffleAnswers(tostring(r), tostring(r + 1), tostring(r + 2))
			return a .. " - " .. b .. " = ?", list, i
		end
		local r = a + b
		local list, i = shuffleAnswers(tostring(r), tostring(r - 1), tostring(r + 1))
		return a .. " + " .. b .. " = ?", list, i
	elseif kind == 2 then
		local pool = K.Shuffle({ 12, 17, 23, 31, 38, 44, 52, 67, 71, 85, 93 })
		local big = math.max(pool[1], pool[2], pool[3])
		local others = {}
		for k = 1, 3 do
			if pool[k] ~= big then
				table.insert(others, tostring(pool[k]))
			end
		end
		local list, i = shuffleAnswers(tostring(big), others[1], others[2])
		return "Which is BIGGEST?", list, i
	elseif kind == 3 then
		local n = math.random(3, 7)
		local list, i = shuffleAnswers(tostring(n), tostring(n - 1), tostring(n + 1))
		return "How many dots?  " .. string.rep("• ", n), list, i
	elseif kind == 4 then
		local deck = K.Shuffle(table.clone(COLOURS))
		local word, ink = deck[1], deck[2]
		local list, i = shuffleAnswers(ink[1], word[1], deck[3][1])
		return 'What COLOUR is the word?  <font color="' .. ink[2] .. '">' .. word[1] .. "</font>", list, i
	end
	local set = ODD[math.random(1, #ODD)]
	local list, i = shuffleAnswers(set[3], set[1], set[2])
	return "Which one doesn't belong?", list, i
end

function Event.Run(context)
	local t0 = K.Start(context)
	local plates = K.Plates()
	if #plates == 0 or #K.Alive() < 2 then
		return
	end
	local Damage = K.Sys("Damage")

	-------------------------------------------------------------------------- 1. THE TOME
	local minX, maxX, minZ, maxZ = K.Box(plates)
	local path = {
		Cx = (minX + maxX) / 2, Cz = (minZ + maxZ) / 2, Hx = math.max((maxX - minX) / 2, 6), Hz = math.max((maxZ - minZ) / 2, 6),
		Top = K.BaseTop(), Height = HEIGHT, P1 = math.random() * math.pi * 2, P2 = math.random() * math.pi * 2,
	}
	local props = { T0 = t0, Duration = Event.Duration, Wander = TOME_TIME, EventName = Event.Name }
	for key, value in path do
		props[key] = value
	end
	local tome = K.Show(context, "Tome", CFrame.new(tomeAt(0, path)), props)
	K.TellAll("Death Ledger", "A cursed ledger is drifting over the arena. Jump into it to catch it... if you dare.", Color3.fromRGB(200, 40, 50))

	local holder: Player? = nil
	while context.IsRunning() and not holder and K.Now() - t0 < TOME_TIME do
		local at = tomeAt(K.Now() - t0, path)
		K.Each(function(player, root)
			if holder then
				return
			end
			local flat = Vector3.new(root.Position.X - at.X, 0, root.Position.Z - at.Z).Magnitude
			if flat <= CATCH_REACH and math.abs(root.Position.Y - at.Y) <= CATCH_UP then
				holder = player
			end
		end)
		task.wait(0.05)
	end
	if not context.IsRunning() then
		return
	end
	local caught = holder ~= nil
	if not holder then
		holder = K.Pick(K.Alive())
	end
	if not holder then
		return
	end
	local writer: Player = holder
	K.Call(context, tome, "Caught", writer.UserId, caught)
	if caught then
		K.TellAll("Death Ledger", writer.DisplayName .. " caught the ledger...", Color3.fromRGB(200, 40, 50))
	else
		K.TellAll("Death Ledger", "The ledger chose " .. writer.DisplayName .. "...", Color3.fromRGB(200, 40, 50))
	end

	-------------------------------------------------------------------------- 2. THE SEAL PUZZLE
	local order: { number } = {}
	for i = 1, SEQ_LEN do
		local rune
		repeat
			rune = math.random(1, 6)
		until rune ~= order[i - 1]
		order[i] = rune
	end
	local puzzleEnds = K.Now() + PUZZLE_TIME + 1
	local showAt = K.Now() + LEAD
	local pressed = 0
	local solved = false
	local function readyAt(): number
		return showAt + SEQ_LEN * (FLASH + GAP)
	end
	K.Call(context, tome, "Puzzle", writer.UserId, showAt, puzzleEnds, table.unpack(order))
	K.Listen(context, function(player: Player, what: any, rune: any)
		if what ~= "Rune" or player ~= writer or solved or type(rune) ~= "number" then
			return
		end
		if K.Now() < readyAt() - 0.1 or K.Now() > puzzleEnds then
			return -- (still showing the order / too late)
		end
		if rune == order[pressed + 1] then
			pressed += 1
			K.Call(context, tome, "Pressed", rune, true, pressed)
			if pressed >= SEQ_LEN then
				solved = true
				K.Call(context, tome, "Solved")
			end
		else
			pressed = 0
			showAt = K.Now() + 1
			K.Call(context, tome, "Pressed", rune, false, 0)
			K.Call(context, tome, "Again", showAt)
		end
	end)
	while context.IsRunning() and not solved and K.Now() < puzzleEnds and K.IsAlive(writer) do
		task.wait(0.05)
	end
	if not context.IsRunning() then
		return
	end
	if not solved then
		K.Call(context, tome, "Refused")
		if K.IsAlive(writer) and Damage and Damage.Deal then
			pcall(Damage.Deal, writer, REFUSE_DAMAGE, { Source = Event.Name })
			K.Tell(writer, "The ledger refuses you", "You couldn't break its seal. It bites! (-" .. REFUSE_DAMAGE .. ")", Color3.fromRGB(200, 40, 50))
		end
		K.Hide(context, tome, 1.5)
		return
	end

	-------------------------------------------------------------------------- 3. A NAME
	local options = {}
	for _, player in K.Alive() do
		if player ~= writer then
			table.insert(options, player.UserId)
		end
	end
	if #options == 0 then
		K.Hide(context, tome, 1)
		return
	end
	local chosen = EventChoice.Ask(writer, "Player", { Title = "Seal a name in the Death Ledger", UserIds = options }, CHOOSE_TIME)
	local victim = if chosen then Players:GetPlayerByUserId(chosen) else nil
	if not (victim and K.IsAlive(victim)) then
		local alive = {}
		for _, player in K.Alive() do
			if player ~= writer then
				table.insert(alive, player)
			end
		end
		victim = K.Pick(alive)
	end
	if not (victim and context.IsRunning()) then
		K.Hide(context, tome, 1)
		return
	end
	local cursed: Player = victim
	K.Call(context, tome, "Sealed", cursed.UserId)
	K.Hide(context, tome, 1.5)
	K.Complete(context, writer)

	-------------------------------------------------------------------------- 4. THE CURSE
	game:GetService("ReplicatedStorage"):SetAttribute("ActiveEventTarget", cursed.DisplayName)
	local endsAt = K.Now() + CURSE_TIME
	local curse = K.Show(context, "Curse", CFrame.new(), {
		T0 = t0, Victim = cursed.UserId, Curser = writer.UserId, EndsAt = endsAt, CurserName = writer.DisplayName, EventName = Event.Name,
	})
	K.Tell(cursed, "Your name is in the Death Ledger!", writer.DisplayName .. " sealed it. Knock them out before your clock runs out!", Color3.fromRGB(200, 40, 50))
	K.Tell(writer, "The seal is set", cursed.DisplayName .. " is cursed. They have to knock YOU out to break it...", Color3.fromRGB(200, 40, 50))

	local riddle = 0
	local answer: number? = nil
	local deadline = 0
	local answered = true
	local function drain()
		endsAt -= DRAIN
		K.Call(context, curse, "Drain", riddle, endsAt)
	end
	K.Listen(context, function(player: Player, what: any, which: any, choice: any)
		if what ~= "Answer" or player ~= cursed or answered or which ~= riddle or type(choice) ~= "number" then
			return
		end
		answered = true
		if K.Now() <= deadline and choice == answer then
			K.Call(context, curse, "Right", riddle)
		else
			drain()
		end
	end)
	local nextRiddle = K.Now() + RIDDLE_EVERY
	local outcome = "over"
	while context.IsRunning() do
		local now = K.Now()
		if not K.IsAlive(cursed) or not cursed.Parent then
			outcome = "over"
			break
		elseif not K.IsAlive(writer) or not writer.Parent then
			outcome = "broken"
			break
		elseif now >= endsAt then
			outcome = "reap"
			break
		end
		if not answered and now > deadline then
			answered = true
			drain()
		end
		if answered and now >= nextRiddle and endsAt - now > RIDDLE_TIME + 1 then
			riddle += 1
			local line, list, right = makeRiddle()
			answer = right
			answered = false
			deadline = now + RIDDLE_TIME + GRACE
			nextRiddle = now + RIDDLE_EVERY
			K.Call(context, curse, "Riddle", riddle, line, list[1], list[2], list[3], now + RIDDLE_TIME)
		end
		task.wait(0.05)
	end
	if not context.IsRunning() then
		return
	end
	if outcome == "broken" then
		K.Call(context, curse, "Broken")
		K.Tell(cursed, "The seal is broken!", "The curser is down. The reaper lets you go.", Color3.fromRGB(150, 220, 255))
		K.Complete(context, cursed)
	elseif outcome == "reap" then
		K.Call(context, curse, "Reap")
		task.wait(REAP_AT)
		if K.IsAlive(cursed) and Damage and Damage.Kill then
			pcall(Damage.Kill, cursed, { Source = Event.Name })
		end
		K.TellAll("Death Ledger", "The reaper took " .. cursed.DisplayName .. ".", Color3.fromRGB(200, 40, 50))
	else
		K.Call(context, curse, "Over")
	end
	K.Hide(context, curse, 2)
	task.wait(2.2)
end

return Event
