-- ModuleScript: ServerScriptService > Events > TheCircles     (REWORKED: Oct 12 Update 28; first made Oct 8 update 3)
-- The Circles. Your words: "USE A HIGHLIGHT WITH OUTLINE TRANSPARENCY = 0. AND MAKE IT SO THAT IT ONLY EFFECTS *SOME*
-- PLATES ... MAKE THE RULES WAYY CLEARER". So now:
--   * Only SOME plates get a rule (SHARE of them, at most MAX_PLATES): each one is outlined with a Highlight in its
--     rule's colour (OutlineTransparency 0, a soft fill) and has a sign over it with the rule's name. Every other
--     plate is plain and SAFE.
--   * A panel on the left of every screen lists the rules in play, one line each, and marks the one you are under.
--   * A rule is on you while you stand on its plate. Step onto a plain plate and it wears off (in the air it stays).
-- Twice (PHASES), RULES_EACH rules are dealt to new random plates for PHASE seconds:
--   SLOW        (green)   you walk slower (x SLOW)
--   SLIPPERY    (blue)    running makes you skid further the way you are going
--   HEAVY       (violet)  you are knocked back twice as far
--   NO JUMPING  (grey)    you can't jump
--   HOT FLOOR   (orange)  standing still burns you (6 a second): keep moving!
-- Client: ReplicatedStorage > EventClients > circles (the plates, signs and the panel: the BillboardGui RuleSign and
-- the ScreenGui RulesGui under this script).
local ServerScriptService = game:GetService("ServerScriptService")

local K = require(ServerScriptService:WaitForChild("Systems"):WaitForChild("EventUtil"))

local Event = {
	Name = "The Circles",
	Id = "circles",
	Weight = 0.7,
	Duration = 37,
	Target = "Arena",
}

local FIRST = 2.5         -- the panel is up this long before the first rules
local PHASE = 15          -- each set of rules lasts this long
local GAP = 1.5           -- all plates are plain between the two sets
local PHASES = 2
local SHARE = 0.4         -- part of the plates that get a rule ...
local MAX_PLATES = 12     -- ... but never more than this (Roblox shows at most 31 Highlights at once)
local RULES_EACH = 3      -- different rules in play at once
local TICK = 0.25
local SLOW = 0.8
local BURN_PER_TICK = 1.5 -- 6 a second
local STILL_AFTER = 0.5   -- seconds without moving before HOT FLOOR burns
local SKID_SPEED = 30
local SKID_EVERY = 0.7

local RULES = { "Slow", "Slick", "Heavy", "Leaden", "Scorch" }

function Event.Run(context)
	local t0 = K.Start(context)
	local plates = K.Plates()
	if #plates == 0 then
		return
	end
	local board = K.Show(context, "Board", CFrame.new((K.Arena(plates))), { T0 = t0, Duration = Event.Duration })
	K.TellAll("The Circles", "Glowing plates have rules (see the list on the left). Plain plates are safe.", Color3.fromRGB(200, 190, 160))

	local ruleOf: { [BasePart]: string } = {}
	local visualOf: { [BasePart]: number } = {}
	local active = false
	local current: { [Player]: string } = {}
	local savedKnock: { [Player]: any } = {}
	local lastPos: { [Player]: Vector3 } = {}
	local stillFor: { [Player]: number } = {}
	local nextSkid: { [Player]: number } = {}
	local nextSizzle: { [Player]: number } = {}

	local function clear(player: Player)
		local rule = current[player]
		if rule == "Slow" then
			K.Unmod(player, "CirclesSlow")
		elseif rule == "Leaden" then
			K.Unmod(player, "CirclesJump")
		elseif rule == "Heavy" then
			local old = savedKnock[player]
			savedKnock[player] = nil
			if player.Parent then
				player:SetAttribute("KnockbackMult", if old == false then nil else old)
			end
		end
		if rule then
			K.Signal(context, board, "Yours", player.UserId, "")
		end
		current[player] = nil
	end

	local function clearAll()
		local list = {}
		for player in current do
			table.insert(list, player)
		end
		for _, player in list do
			clear(player)
		end
	end
	context.Trash.Add(clearAll)

	local function apply(player: Player, rule: string)
		if current[player] == rule then
			return
		end
		clear(player)
		current[player] = rule
		if rule == "Slow" then
			K.Mod(player, "WalkSpeed", { Mult = SLOW }, "CirclesSlow")
		elseif rule == "Leaden" then
			K.Mod(player, "Jump", { Mult = 0 }, "CirclesJump")
		elseif rule == "Heavy" then
			local old = player:GetAttribute("KnockbackMult")
			savedKnock[player] = if old == nil then false else old
			player:SetAttribute("KnockbackMult", (if type(old) == "number" then old else 1) * 2)
		end
		K.Signal(context, board, "Yours", player.UserId, rule)
	end

	task.spawn(function()
		while context.IsRunning() do
			if active then
				local now = os.clock()
				for _, player in K.Alive() do
					local root, humanoid = K.Root(player)
					if root and humanoid then
						local plate = K.PlateUnder(root, K.FeetY(root, humanoid), plates)
						if plate and plate.Parent then
							-- on a ruled plate = its rule; on a plain plate = no rule (in the air: unchanged)
							local rule = ruleOf[plate]
							if rule then
								apply(player, rule)
							elseif current[player] then
								clear(player)
							end
						end
						local position = root.Position
						local before = lastPos[player]
						lastPos[player] = position
						local moved = if before then K.Flat(position - before).Magnitude else 99
						stillFor[player] = if moved < 0.3 then (stillFor[player] or 0) + TICK else 0
						local rule = current[player]
						if rule == "Scorch" and plate and ruleOf[plate] == "Scorch" and stillFor[player] >= STILL_AFTER then
							K.Hurt(player, BURN_PER_TICK, context, "Fire")
							if (nextSizzle[player] or 0) <= now then
								nextSizzle[player] = now + 0.5
								K.Signal(context, visualOf[plate], "Sizzle", player.UserId)
							end
						elseif rule == "Slick" and plate and ruleOf[plate] == "Slick" then
							local velocity = K.Flat(root.AssemblyLinearVelocity)
							if velocity.Magnitude > 6 and (nextSkid[player] or 0) <= now then
								nextSkid[player] = now + SKID_EVERY
								K.Push(player, velocity.Unit * SKID_SPEED, 0.25, context)
								K.Signal(context, visualOf[plate], "Skid", player.UserId)
							end
						end
					end
				end
			end
			task.wait(TICK)
		end
	end)

	for phase = 1, PHASES do
		local startAt = t0 + FIRST + (phase - 1) * (PHASE + GAP)
		if not K.WaitUntil(context, startAt) then
			return
		end
		-- deal: RULES_EACH rules, round-robin over SOME random plates
		local deck = K.Shuffle(table.clone(RULES))
		local inPlay = {}
		for i = 1, math.min(RULES_EACH, #deck) do
			inPlay[i] = deck[i]
		end
		local alive = K.Plates()
		local count = math.clamp(math.floor(#alive * SHARE + 0.5), math.min(#inPlay, #alive), math.min(MAX_PLATES, #alive))
		table.clear(ruleOf)
		table.clear(visualOf)
		for i, plate in K.Shuffle(alive) do
			if i > count then
				break
			end
			local rule = inPlay[(i - 1) % #inPlay + 1]
			ruleOf[plate] = rule
			local id = K.Show(context, "Glow", CFrame.new(K.TopCentre(plate)), {
				T0 = t0, Rule = rule, Tag = K.Tag(context, plate), Ends = startAt + PHASE,
			})
			if id then
				visualOf[plate] = id
			end
		end
		K.Call(context, board, "Rules", phase, startAt + PHASE, table.unpack(inPlay))
		active = true
		if not K.WaitUntil(context, startAt + PHASE) then
			return
		end
		active = false
		clearAll()
		for plate, id in visualOf do
			K.Hide(context, id)
			visualOf[plate] = nil
		end
		table.clear(ruleOf)
		K.Call(context, board, "Rules", phase, startAt + PHASE + GAP)
	end
	K.Hold(context)
end

return Event
