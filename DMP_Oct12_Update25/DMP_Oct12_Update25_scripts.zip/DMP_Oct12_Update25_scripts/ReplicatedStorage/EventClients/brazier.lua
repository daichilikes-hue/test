-- ModuleScript: ReplicatedStorage > EventClients > brazier     (NEW: Oct 12 Update 25, Soul Fire Brazier)
-- What the Soul Fire Brazier looks like on each client: the brazier (the model Brazier under ServerScriptService >
-- Events > SoulFireBrazier) with its pale soul fire flickering; when somebody claims it, the fire streams into them and
-- the brazier goes dark; nobody in time = it gutters out.
--   DASH CHARGE (on the claimer's screen only): the ScreenGui DashGui under the same script. Q, or a click / tap on the
--     button, asks the server for a dash; the button shades while it cools down. Gone when the gift runs out.
--   QUIET BOOTS: the claimer's footstep sound is muted on every client until the gift runs out.
local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
if not (FX.OnPlate and FX.Gui and FX.UseSounds) then
	warn("[brazier] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for. Install the WHOLE update (drag its .rbxmx in).")
end

--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	BrazierClaim = { Id = "", Stand = "rbxasset://sounds/action_falling.mp3", Speed = 1.6, Volume = 0.5 }, -- the fire streams into the claimer
	BrazierDash = { Id = "", Stand = "rbxasset://sounds/swordslash.wav", Speed = 0.8, Volume = 0.5 },      -- a dash
	BrazierOut = { Id = "", Stand = "", Speed = 1, Volume = 0.5 },                                       -- it gutters out
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

local DASH_KEY = Enum.KeyCode.Q
local DASH_COOLDOWN = 3     -- KEEP about the server's DASH_COOLDOWN (the button's shade)
local SOUL = Color3.fromRGB(150, 255, 200)

-- the footstep sounds of a character (the default character sounds call it "Running")
local function footsteps(character: Model?): { Sound }
	local out: { Sound } = {}
	local root = character and character:FindFirstChild("HumanoidRootPart")
	for _, item in root and root:GetChildren() or {} do
		if item:IsA("Sound") and item.Name == "Running" then
			table.insert(out, item)
		end
	end
	return out
end

return FX.Module({
	Brazier = {
		Init = function(self: any, props: any)
			self.Follow = FX.OnPlate(props.Tag, self.Origin)
			self.Flames = {}
			for _, part in self.Inst:GetChildren() do
				if part:IsA("BasePart") and string.sub(part.Name, 1, 5) == "Flame" then
					table.insert(self.Flames, { Part = part, Size = part.Size, Offset = self.Origin:ToObjectSpace(part.CFrame), Transparency = part.Transparency, Seed = #self.Flames * 1.7 })
				end
			end
			local core = self.Inst:FindFirstChild("FireCore")
			self.Light = core and core:FindFirstChildOfClass("PointLight")
			self.Brightness = self.Light and self.Light.Brightness or 2
			self.Embers = core and core:FindFirstChild("Embers")
			self.Fire = 1
			self.Muted = {}
		end,

		Step = function(self: any, dt: number, t: number)
			local base = self.Follow()
			if self.LastBase ~= base then
				self.LastBase = base
				self.Inst:PivotTo(base)
			end
			-- the fire: flickers while it burns, dies once claimed or guttered
			if self.Out then
				self.Fire = math.max(self.Fire - dt / 0.8, 0)
			end
			for _, flame in self.Flames do
				local flick = 1 + 0.18 * FX.Noise(flame.Seed, t * 4)
				local h = flame.Size.Y * flick * self.Fire
				flame.Part.Size = Vector3.new(flame.Size.X * (0.6 + 0.4 * self.Fire), math.max(h, 0.05), flame.Size.Z * (0.6 + 0.4 * self.Fire))
				flame.Part.CFrame = base * flame.Offset * CFrame.new(0, (h - flame.Size.Y) / 2, 0)
				flame.Part.Transparency = if self.Fire <= 0.01 then 1 else flame.Transparency
			end
			if self.Light then
				self.Light.Brightness = self.Brightness * self.Fire * (1 + 0.15 * FX.Noise(3, t * 5))
			end
			if self.Embers and self.Embers:IsA("ParticleEmitter") then
				local on = self.Fire > 0.3 and not FX.Off("DisableParticles")
				if self.Embers.Enabled ~= on then
					self.Embers.Enabled = on
				end
			end
			-- the gift runs out
			local ends = self.GiftEnds
			if ends and FX.Now() >= ends then
				self.GiftEnds = nil
				if self.DashGui then
					self.DashGui:Destroy()
					self.DashGui = nil
				end
				for sound, volume in self.Muted do
					sound.Volume = volume
				end
				table.clear(self.Muted)
			end
			-- quiet boots: keep the claimer's footsteps muted (the character sounds may be made again)
			if self.Quiet and self.GiftEnds then
				local player = Players:GetPlayerByUserId(self.Quiet)
				for _, sound in footsteps(player and player.Character) do
					if self.Muted[sound] == nil then
						self.Muted[sound] = sound.Volume
					end
					sound.Volume = 0
				end
			end
			-- the dash button's cooldown shade
			if self.DashGui then
				local button = self.DashGui:FindFirstChild("Dash")
				local shade = button and button:FindFirstChild("Shade")
				local key = button and button:FindFirstChild("Key")
				local left = math.max((self.LastDash or -math.huge) + DASH_COOLDOWN - FX.Now(), 0)
				if shade and shade:IsA("GuiObject") then
					shade.Size = UDim2.fromScale(1, left / DASH_COOLDOWN)
				end
				if key and key:IsA("TextLabel") then
					key.Text = if left > 0 then string.format("%.1f", left) elseif UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled then "TAP" else "Q"
				end
			end
		end,

		-- somebody claimed it: the fire streams into them; their gift starts
		Claimed = function(self: any, userId: number, gift: string, ends: number)
			self.Out = true
			self.GiftEnds = ends
			local root = FX.Root(userId)
			local from = (self.LastBase or self.Origin).Position + Vector3.new(0, 3.4, 0)
			if root then
				for k = 0, 6 do
					FX.Burst(from:Lerp(root.Position, k / 6), "Glow", 2, { Color = SOUL, Scale = 0.6 })
				end
				FX.Sound("BrazierClaim", root.Position)
			end
			if gift == "Quiet" then
				self.Quiet = userId
			elseif gift == "Dash" and FX.IsMe(userId) then
				local gui = FX.Gui("brazier", "DashGui")
				self.DashGui = gui
				if gui then
					self:Keep(gui)
				end
				local function dash()
					if not self.GiftEnds or FX.Now() - (self.LastDash or -math.huge) < DASH_COOLDOWN then
						return
					end
					local mine = FX.MyRoot()
					if not mine then
						return
					end
					self.LastDash = FX.Now()
					self:Send("Dash", mine.CFrame.LookVector)
				end
				local button = gui and gui:FindFirstChild("Dash")
				if button and button:IsA("GuiButton") then
					self:Keep(button.Activated:Connect(dash))
				end
				self:Keep(UserInputService.InputBegan:Connect(function(input, processed)
					if not processed and input.KeyCode == DASH_KEY then
						dash()
					end
				end))
			end
		end,

		-- somebody dashed: a streak of soul fire behind them
		Dashed = function(_self: any, userId: number)
			local root = FX.Root(userId)
			if root then
				FX.Burst(root.Position, "Glow", 6, { Color = SOUL, Scale = 0.9 })
				FX.Sound("BrazierDash", root.Position)
			end
		end,

		-- nobody claimed it in time
		Gutter = function(self: any)
			self.Out = true
			FX.Burst((self.LastBase or self.Origin).Position + Vector3.new(0, 3.4, 0), "Smoke", 10, { Color = Color3.fromRGB(80, 90, 86), Scale = 1 })
			FX.Sound("BrazierOut", self.Origin.Position)
		end,

		-- (the visual is going: footsteps back)
		Done = function(self: any)
			for sound, volume in self.Muted or {} do
				sound.Volume = volume
			end
		end,
	},
})
