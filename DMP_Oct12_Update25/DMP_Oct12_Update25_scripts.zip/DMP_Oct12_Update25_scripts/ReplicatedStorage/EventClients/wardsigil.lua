-- ModuleScript: ReplicatedStorage > EventClients > wardsigil     (NEW: Oct 12 Update 25, Warding Sigil)
-- What the Warding Sigil looks like on each client. The server (Events > WardingSigil) protects the plates; this
-- brands the sigil (the model Sigil under ServerScriptService > Events > WardingSigil, stretched to the plate) onto
-- each one: its strokes burn in one after another, it breathes with a faint cold light, it FLARES when it stops a plate
-- from breaking, and it fades when the event ends. Restyle the model there; keep Rune* / Inner* / Glyph* / Light.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
if not (FX.Tagged and FX.UseSounds) then
	warn("[wardsigil] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for. Install the WHOLE update (drag its .rbxmx in).")
end

--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	SigilBrand = { Id = "", Stand = "", Speed = 1, Volume = 0.5 },                                      -- a sigil burns into a plate
	SigilHold = { Id = "", Stand = "rbxasset://sounds/electronicpingshort.wav", Speed = 0.35, Volume = 0.6 }, -- it stops a plate breaking
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

local BRAND = 1.2           -- seconds the strokes take to burn in
local FADE = 1.5            -- seconds it fades at the end
local MADE_FOR = 20

return FX.Module({
	Sigil = {
		Init = function(self: any, props: any)
			local inverse = self.Origin:Inverse()
			self.Pieces = {}
			local n = 0
			for _, part in self.Inst:GetChildren() do
				if part:IsA("BasePart") and part.Name ~= "Root" and part.Name ~= "Light" then
					n += 1
					table.insert(self.Pieces, { Part = part, Offset = inverse * part.CFrame, Size = part.Size, Transparency = part.Transparency, Order = n })
					part.Transparency = 1
				end
			end
			self.Count = n
			local lamp = self.Inst:FindFirstChild("Light")
			self.Lamp = lamp
			self.Glow = lamp and lamp:FindFirstChildOfClass("PointLight")
			self.Brightness = self.Glow and self.Glow.Brightness or 0.8
			self.Flare = 0
			self.Delay = tonumber(props.Delay) or 0
		end,

		Step = function(self: any, dt: number, t: number)
			local plate = self.Plate
			if not plate then
				local found = FX.Tagged(self.Props.Tag)
				if found and found:IsA("BasePart") then
					plate = found
					self.Plate = found
					FX.Sound("SigilBrand", found.Position)
				end
			end
			local duration = tonumber(self.Props.Duration) or 25
			local alive = 1 - FX.Clamp01((t - (duration - FADE)) / FADE)
			if self.Seen and (not plate or not plate.Parent) then
				alive = 0
			end
			local top: CFrame = self.Top or self.Origin
			local sx, sz = 1, 1
			if plate and plate.Parent then
				self.Seen = true
				top = plate.CFrame * CFrame.new(0, plate.Size.Y / 2, 0)
				self.Top = top
				sx, sz = plate.Size.X / MADE_FOR, plate.Size.Z / MADE_FOR
			end
			self.Flare = math.max(self.Flare - dt / 1.2, 0)
			local breathe = 0.12 * math.sin(t * 2.2)
			local since = t - self.Delay
			for _, piece in self.Pieces do
				local part: BasePart = piece.Part
				local burn = FX.Clamp01((since - BRAND * (piece.Order / self.Count)) / 0.25)
				local o: CFrame = piece.Offset
				part.CFrame = top * CFrame.new(o.X * sx, o.Y, o.Z * sz) * (o - o.Position)
				part.Size = Vector3.new(piece.Size.X * (if math.abs(o.X) > 0.1 then 1 else sx), piece.Size.Y, piece.Size.Z)
				local base = math.clamp(piece.Transparency + breathe - 0.5 * self.Flare, 0, 1)
				local shown = burn * alive
				local look = if shown > 0.99 then base elseif shown < 0.01 then 1 else base + (1 - base) * (1 - shown)
				part.Transparency = look
			end
			if self.Lamp then
				self.Lamp.CFrame = top * CFrame.new(0, 3, 0)
			end
			if self.Glow then
				self.Glow.Brightness = self.Brightness * alive * FX.Clamp01(since / BRAND) * (1 + 3 * self.Flare)
			end
		end,

		-- it just stopped its plate from breaking
		Held = function(self: any)
			self.Flare = 1
			local at = if self.Top then self.Top.Position else self.Origin.Position
			FX.Burst(at + Vector3.new(0, 0.5, 0), "Star", 16, { Color = Color3.fromRGB(170, 220, 255), Scale = 0.8 })
			FX.Sound("SigilHold", at)
		end,
	},
})
