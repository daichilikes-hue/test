-- ModuleScript: ReplicatedStorage > EventClients > fireflies     (NEW: Oct 12 Update 25, Firefly Swarm)
-- What the Firefly Swarm looks like on each client: the fireflies (the model Fireflies under ServerScriptService >
-- Events > FireflySwarm) drift in and dance round their player, blinking, lighting them softly; they leave at the end.
-- (The jump buff is on the server.) Restyle the model there; keep Fly1..n and Glow > Light.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
if not (FX.Root and FX.UseSounds) then
	warn("[fireflies] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for. Install the WHOLE update (drag its .rbxmx in).")
end

--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	FirefliesArrive = { Id = "", Stand = "", Speed = 1, Volume = 0.4 }, -- the swarm settles on somebody
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

local ARRIVE = 1.5          -- seconds they take to drift in (and to drift off at the end)
local RADIUS = 2.2          -- studs round the player they dance
local LIGHT = 1.2           -- how bright the soft light on the player is

return FX.Module({
	Fireflies = {
		Init = function(self: any, _props: any)
			self.Flies = {}
			local rng = Random.new()
			for _, part in self.Inst:GetChildren() do
				if part:IsA("BasePart") and string.sub(part.Name, 1, 3) == "Fly" then
					table.insert(self.Flies, {
						Part = part, Transparency = part.Transparency,
						Phase = rng:NextNumber(0, math.pi * 2), Speed = rng:NextNumber(1.2, 2.4) * (if rng:NextNumber() < 0.5 then -1 else 1),
						Height = rng:NextNumber(-1.5, 2.5), Blink = rng:NextNumber(1.5, 3), Away = Vector3.new(rng:NextNumber(-1, 1), rng:NextNumber(0.3, 1), rng:NextNumber(-1, 1)).Unit,
					})
				end
			end
			local glow = self.Inst:FindFirstChild("Glow")
			self.GlowPart = glow
			self.Light = glow and glow:FindFirstChildOfClass("PointLight")
			FX.Sound("FirefliesArrive", self.Origin.Position)
		end,

		Step = function(self: any, _dt: number, t: number)
			local duration = tonumber(self.Props.Duration) or 20
			local root = FX.Root(tonumber(self.Props.UserId) or 0)
			local centre = if root then root.Position else self.Last or self.Origin.Position
			self.Last = centre
			local since = t - (tonumber(self.Props.Delay) or 0)
			local come = FX.Ease.Out(FX.Clamp01(since / ARRIVE))
			local go = FX.Ease.In(FX.Clamp01((t - (duration - ARRIVE)) / ARRIVE))
			for _, fly in self.Flies do
				local a = fly.Phase + fly.Speed * t
				local r = RADIUS * (0.7 + 0.3 * math.sin(t * 1.3 + fly.Phase))
				local at = centre + Vector3.new(math.cos(a) * r, fly.Height + 0.4 * math.sin(t * 2 + fly.Phase), math.sin(a) * r)
				at += fly.Away * 25 * ((1 - come) + go)
				fly.Part.CFrame = CFrame.new(at)
				local blink = 0.5 + 0.5 * math.sin(t * math.pi * 2 / fly.Blink + fly.Phase)
				local shown = math.min(come, 1 - go)
				fly.Part.Transparency = if shown < 0.01 then 1 else fly.Transparency + (1 - fly.Transparency) * (1 - shown * (0.45 + 0.55 * blink))
			end
			if self.GlowPart then
				self.GlowPart.CFrame = CFrame.new(centre + Vector3.new(0, 1, 0))
			end
			if self.Light then
				self.Light.Brightness = LIGHT * math.min(come, 1 - go)
			end
		end,
	},
})
