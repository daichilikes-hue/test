-- ModuleScript: ReplicatedStorage > EventClients > cloak     (NEW: Oct 12 Update 25, Seamstress's Cloak)
-- What the Seamstress looks like on each client: the model Seamstress under ServerScriptService > Events >
-- SeamstressCloak (an R6 character, solid) rises out of her plate and sits sewing (TailorSew), looking up with a nod
-- when somebody talks to her (TailorNod); a right answer = a swirl of silver thread round that player, a wrong one = a
-- little puff of dust. (The riddle is your own EventChoice panel; the cloak is welded on by the server.)
-- HER ANIMATIONS: TailorSew and TailorNod (this module's Animations folder): upload them and paste the ids below.
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
if not (FX.Actor and FX.HoldPose and FX.OnPlate and FX.UseSounds) then
	warn("[cloak] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for. Install the WHOLE update (drag its .rbxmx in).")
end

--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	CloakRight = { Id = "", Stand = "rbxasset://sounds/electronicpingshort.wav", Speed = 0.8, Volume = 0.4 }, -- a right answer
	CloakWrong = { Id = "", Stand = "", Speed = 1, Volume = 0.5 },                                          -- a wrong one
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

--[[DMP:KEEP Animations]]
local ANIMATIONS = {
	TailorSew = 0, -- sewing (looped)
	TailorNod = 0, -- she looks up and nods
}
--[[DMP:END]]

local SCALE = 1.1
local RISE = 1.5            -- seconds she takes to rise out of the plate (and to sink at the end)
local THREAD = Color3.fromRGB(210, 214, 230)
local REST_POSE = { -- (GENERATED: `python3 animgen/npcs.py rest cloak`)
	["RootJoint"] = CFrame.new(0, 0, 0),
	["Neck"] = CFrame.new(0, 0, 0, 1, 0, 0, 0, 0.951057, -0.309017, 0, 0.309017, 0.951057),
	["Right Shoulder"] = CFrame.new(0, 0, 0, 0.707107, -0.696364, 0.122788, 0.707107, 0.696364, -0.122788, 0, 0.173648, 0.984808),
	["Left Shoulder"] = CFrame.new(0, 0, 0, 0.642788, 0.728552, -0.236721, -0.766044, 0.611327, -0.198632, 0, 0.309017, 0.951057),
	["Right Hip"] = CFrame.new(0, 0, 0),
	["Left Hip"] = CFrame.new(0, 0, 0),
}

return FX.Module({
	Seamstress = {
		Init = function(self: any, props: any)
			local model: Instance = self.Inst
			if not (model:IsA("Model") and model:FindFirstChild("HumanoidRootPart")) then
				FX.WarnOnce("cloak-model", "[cloak] ServerScriptService > Events > SeamstressCloak has no model named Seamstress. Install the WHOLE update and press Play again.")
				return
			end
			if SCALE ~= 1 then
				(model :: Model):ScaleTo((model :: Model):GetScale() * SCALE)
			end
			self.Scale = (model :: Model):GetScale()
			self.Follow = FX.OnPlate(props.Tag, self.Origin)
			self.Actor = FX.Actor(model :: Model, ANIMATIONS, script)
		end,

		Step = function(self: any, _dt: number, t: number)
			local actor = self.Actor
			if not actor then
				return
			end
			local duration = tonumber(self.Props.Duration) or 30
			local base = self.Follow()
			local up = FX.Ease.Out(FX.Clamp01(t / RISE))
			local away = FX.Clamp01((t - (duration - RISE)) / RISE)
			actor.Place(base * CFrame.new(0, 3 * self.Scale - 6 * ((1 - up) + away), 0))
			if actor.Animated then
				if not self.Sewing then
					self.Sewing = actor.Play("TailorSew", 0.3) ~= nil
				end
			else
				FX.HoldPose(self.Inst, REST_POSE)
			end
		end,

		-- somebody asked her: she looks up and nods
		Ask = function(self: any, _userId: number)
			if self.Actor then
				self.Actor.Play("TailorNod", 0.1, 1, 0)
			end
		end,

		-- their answer: right = silver thread swirls round them, wrong = a puff of dust
		Answer = function(_self: any, userId: number, right: boolean)
			local root = FX.Root(userId)
			if not root then
				return
			end
			if right then
				FX.Burst(root.Position, "Star", 18, { Color = THREAD, Scale = 0.7 })
				FX.Sound("CloakRight", root.Position)
			else
				FX.Burst(root.Position, "Smoke", 6, { Color = Color3.fromRGB(120, 110, 120), Scale = 0.6 })
				FX.Sound("CloakWrong", root.Position)
			end
		end,
	},
})
