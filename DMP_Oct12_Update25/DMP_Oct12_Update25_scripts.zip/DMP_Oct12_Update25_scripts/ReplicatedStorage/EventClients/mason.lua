-- ModuleScript: ReplicatedStorage > EventClients > mason     (NEW: Oct 12 Update 25, Mason's Hammer)
-- What Mason's Hammer looks like on each client. The server (Events > MasonsHammer) rebuilds the plates; this draws
-- THE MASON (the model Mason under ServerScriptService > Events > MasonsHammer, an R6 character, solid): he climbs out
-- of a plate, walks to the edge next to each gap (hopping gaps on the way) and hammers there while the plate rises out
-- of the void stroke by stroke; sparks and stone dust fly at every strike. He sinks away when he is done.
-- HIS ANIMATIONS: MasonWalk and MasonHammer (this module's Animations folder). In Studio they play from there; for the
-- real game upload them and paste the ids into ANIMATIONS. (Not uploaded = he holds his mallet still.)
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
if not (FX.Actor and FX.HoldPose and FX.UseSounds) then
	warn("[mason] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for. Install the WHOLE update (drag its .rbxmx in).")
end

--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	MasonStrike = { Id = "", Stand = "rbxasset://sounds/clickfast.wav", Speed = 0.5, Volume = 0.7 }, -- the mallet hits stone
	MasonRise = { Id = "", Stand = "", Speed = 1, Volume = 0.6 },                                 -- he climbs out of the plate
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

--[[DMP:KEEP Animations]]
local ANIMATIONS = {
	MasonWalk = 0,   -- walking with his mallet (looped)
	MasonHammer = 0, -- hammering (looped; strikes at STRIKE)
}
--[[DMP:END]]

local MASON_SCALE = 1.1
local STRIKE = 0.5          -- KEEP IN SYNC with STRIKE in DMP_tools animgen/npcs.py and Events > MasonsHammer
local SWING = 0.9           -- MasonHammer's length
local HOP = 2.4
local SINK = 6
local SPARK = Color3.fromRGB(255, 214, 150)
local DUST = Color3.fromRGB(170, 166, 156)
local REST_POSE = { -- (GENERATED: `python3 animgen/npcs.py rest mason`)
	["RootJoint"] = CFrame.new(0, 0, 0),
	["Neck"] = CFrame.new(0, 0, 0),
	["Right Shoulder"] = CFrame.new(0, 0, 0, 0.906308, -0.420303, 0.044176, 0.422618, 0.901343, -0.094735, 0, 0.104528, 0.994522),
	["Left Shoulder"] = CFrame.new(0, 0, 0),
	["Right Hip"] = CFrame.new(0, 0, 0),
	["Left Hip"] = CFrame.new(0, 0, 0),
}

-- the stretches of a line with no plate under it (where he hops), as { from, to } in studs
local function gaps(a: Vector3, b: Vector3, ray: RaycastParams?, top: number): { { number } }
	local out: { { number } } = {}
	if not ray then
		return out
	end
	local length = (b - a).Magnitude
	local open: number? = nil
	local d = 0
	while d <= length do
		local at = a + (b - a) * (if length > 0 then d / length else 0)
		local hit = workspace:Raycast(Vector3.new(at.X, top + 40, at.Z), Vector3.new(0, -80, 0), ray)
		if not hit and not open then
			open = d
		elseif hit and open then
			table.insert(out, { open, d })
			open = nil
		end
		d += 0.5
	end
	if open then
		table.insert(out, { open, length })
	end
	return out
end

return FX.Module({
	Mason = {
		Init = function(self: any, props: any)
			local model: Instance = self.Inst
			if not (model:IsA("Model") and model:FindFirstChild("HumanoidRootPart")) then
				FX.WarnOnce("mason-model", "[mason] ServerScriptService > Events > MasonsHammer has no model named Mason (an R6 character). Install the WHOLE update and press Play again.")
				return
			end
			local problem = FX.R6Problem(model)
			if problem then
				warn("[mason] the mason cannot play his animations: " .. problem .. ". He is shown without them.")
			end
			if MASON_SCALE ~= 1 then
				(model :: Model):ScaleTo((model :: Model):GetScale() * MASON_SCALE)
			end
			self.Scale = (model :: Model):GetScale()
			local head = model:FindFirstChild("HammerHead", true)
			self.Head = if head and head:IsA("BasePart") then head else nil
			local dust = model:FindFirstChild("Dust", true)
			self.Dust = if dust and dust:IsA("ParticleEmitter") then dust else nil
			self.Actor = FX.Actor(model :: Model, ANIMATIONS, script)
			local map = workspace:FindFirstChild("Map")
			local plates = map and map:FindFirstChild("Plates")
			if plates then
				local params = RaycastParams.new()
				params.FilterType = Enum.RaycastFilterType.Include
				params.FilterDescendantsInstances = { plates }
				self.Ray = params
			end
			-- the route (the same sums as the server): where he stands, which way he faces, when he gets there
			local route = props.Route or {}
			local top = tonumber(props.Top) or self.Origin.Position.Y
			local speed = math.max(tonumber(props.Speed) or 13, 1)
			local hammer = tonumber(props.Hammer) or 3
			self.Top = top
			self.Stops = {}
			local clock = tonumber(props.Rise) or 1.2
			for i = 1, #route - 3, 4 do
				local at = Vector3.new(route[i], top, route[i + 1])
				local stop = { At = at, Face = Vector3.new(route[i + 2], 0, route[i + 3]), Gaps = {} }
				local last = self.Stops[#self.Stops]
				if last then
					stop.From = last.At
					stop.Leaves = clock
					stop.Length = Vector3.new(at.X - last.At.X, 0, at.Z - last.At.Z).Magnitude
					stop.Gaps = gaps(last.At, at, self.Ray, top)
					clock += stop.Length / speed
				end
				stop.Arrives = clock
				clock += hammer
				table.insert(self.Stops, stop)
			end
			self.Done = tonumber(props.Done) or clock
			self.Ground = top
			self.Strikes = 0
			FX.Sound("MasonRise", self.Origin.Position)
		end,

		Step = function(self: any, dt: number, t: number)
			local actor = self.Actor
			local stops = self.Stops
			if not actor or not stops or #stops == 0 then
				return
			end
			local props = self.Props
			local rise = tonumber(props.Rise) or 1.2
			local leave = tonumber(props.Leave) or 1.2
			local hammer = tonumber(props.Hammer) or 3
			local position: Vector3 = stops[1].At
			local facing: Vector3 = stops[1].Face
			local hop = 0
			local walking, working = false, false
			for _, stop in stops do
				if stop.From and t >= stop.Leaves and t < stop.Arrives then
					local u = (t - stop.Leaves) / (stop.Arrives - stop.Leaves)
					position = stop.From:Lerp(stop.At, u)
					facing = stop.At - stop.From
					walking = true
					local d = u * stop.Length
					for _, gap in stop.Gaps do
						local a, b = gap[1] - 1, gap[2] + 1
						if d > a and d < b then
							hop = HOP * math.sin(math.pi * (d - a) / (b - a))
						end
					end
					break
				elseif t >= stop.Arrives then
					position = stop.At
					facing = stop.Face
					working = t < stop.Arrives + hammer
				end
			end
			-- the ground under him
			local want = self.Top
			if self.Ray then
				local hit = workspace:Raycast(Vector3.new(position.X, self.Top + 60, position.Z), Vector3.new(0, -120, 0), self.Ray)
				if hit and hit.Normal.Y > 0.7 then
					want = hit.Position.Y
				end
			end
			self.Ground += (want - self.Ground) * math.min(dt * 10, 1)
			local up = FX.Ease.Out(FX.Clamp01(t / rise))
			local away = FX.Clamp01((t - self.Done) / leave)
			local at = Vector3.new(position.X, self.Ground + 3 * self.Scale + hop - SINK * ((1 - up) + away), position.Z)
			local flat = Vector3.new(facing.X, 0, facing.Z)
			actor.Place(if flat.Magnitude > 0.01 then CFrame.lookAt(at, at + flat) else CFrame.new(at))
			if actor.Animated then
				if walking and not self.Walking then
					self.Walking = actor.Play("MasonWalk", 0.15) ~= nil
				elseif not walking and self.Walking then
					self.Walking = false
					actor.Stop("MasonWalk", 0.15)
				end
				if working and not self.Working then
					self.Working = actor.Play("MasonHammer", 0.1, 1, 0) ~= nil
				elseif not working and self.Working then
					self.Working = false
					actor.Stop("MasonHammer", 0.2)
				end
			else
				FX.HoldPose(self.Inst, REST_POSE)
			end
			-- every strike while he works: sparks and dust off the mallet
			if working then
				local job: any = nil
				for _, stop in stops do
					if t >= stop.Arrives and t < stop.Arrives + hammer then
						job = stop
					end
				end
				if job then
					local swings = math.floor((t - job.Arrives - STRIKE) / SWING) + 1
					job.Struck = job.Struck or 0
					if swings > job.Struck and t - job.Arrives >= STRIKE then
						job.Struck = swings
						local where = if self.Head then self.Head.Position else at + flat.Unit * 2
						FX.Burst(where, "Spark", 8, { Color = SPARK, Scale = 0.6 })
						if self.Dust and not FX.Off("DisableParticles") then
							self.Dust:Emit(tonumber(self.Dust:GetAttribute("EmitCount")) or 8)
						end
						FX.Sound("MasonStrike", where, 1, 0.9 + 0.2 * math.random())
						FX.Shake(0.5, 12, 0.02, 0.2, where, 15, 60)
					end
				end
			end
		end,

		-- a destroyed plate is coming back (index of the job, the plate's tag)
		Rebuild = function(self: any, _index: number, tag: string)
			local plate = FX.Tagged(tag)
			if plate and plate:IsA("BasePart") then
				FX.Burst(plate.Position, "Smoke", 14, { Color = DUST, Scale = 1.4 })
			end
		end,

		-- nothing was broken: he shored up this plate
		Shored = function(self: any)
			local at = if self.Head then self.Head.Position else self.Origin.Position
			FX.Burst(at, "Star", 10, { Color = Color3.fromRGB(220, 210, 180), Scale = 0.7 })
		end,
	},
})
