-- ModuleScript: ServerScriptService > Events > FireflySwarm     (NEW: Oct 12 Update 25, /setevent fireflies)
-- FIREFLY SWARM (your backlog, movement event 12): a swarm of fireflies settles on 1 to 3 random players. While they
-- glow round you (DURATION) you jump JUMP times as high, and you light up softly for everyone.
-- (Your buff table's Owl Eyes / Deadeye are NOT in it: see INSTALL.md. They need to know the future or change prompts
--  per player, which this game cannot do reliably.)
-- The fireflies (the model Fireflies under this script) are drawn in ReplicatedStorage > EventClients > fireflies.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local DURATION = 20
local MIN_PLAYERS = 1
local MAX_PLAYERS = 3
local JUMP = 1.3            -- x jump while the fireflies are on you

return {
	Name = "Firefly Swarm",
	Id = "fireflies",
	Weight = 1,
	Duration = DURATION,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local alive = K.Shuffle(K.Alive())
		local count = math.min(#alive, math.random(MIN_PLAYERS, math.max(MIN_PLAYERS, MAX_PLAYERS)))
		if count == 0 then
			return
		end
		local lucky: { Player } = {}
		for i = 1, count do
			local player = alive[i]
			table.insert(lucky, player)
			local root = K.Root(player)
			K.Show(context, "Fireflies", if root then root.CFrame else CFrame.new(), { T0 = t0, Duration = DURATION, UserId = player.UserId, Delay = (i - 1) * 0.4 })
			K.Mod(player, "Jump", { Mult = JUMP }, "FireflyJump", DURATION)
			K.Complete(context, player)
			K.Tell(player, "Fireflies!", "They settled on you: you jump higher while they glow.", K.Colors.Gold)
		end
		context.Trash.Add(function()
			for _, player in lucky do
				K.Unmod(player, "FireflyJump")
			end
		end)
		local names: { string } = {}
		for _, player in lucky do
			table.insert(names, player.DisplayName)
		end
		K.TellAll("Firefly Swarm", "Fireflies settled on " .. table.concat(names, ", ") .. ".", K.Colors.Gold)
	end,
}
