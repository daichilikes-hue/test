-- ModuleScript: ServerScriptService > Events > MasonsHammer     (NEW: Oct 12 Update 25, /setevent mason)
-- MASON'S HAMMER (your backlog, protection event 10): a ghost stonemason (the model Mason under this script, an R6
-- character) climbs out of a plate, walks to the gaps where plates were destroyed earlier this round and hammers up to
-- REBUILDS of them back: each plate rises from the void and locks into its old place, a real plate again.
-- Nothing destroyed yet? [MY CALL] he shores up one plate instead: it cannot be destroyed while the event lasts.
-- (Systems > PlateSpawner remembers the destroyed plates: PlateSpawner.Destroyed / Rebuild.)
-- He is drawn in ReplicatedStorage > EventClients > mason (the route below is sent to the clients).
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local DURATION = 20
local REBUILDS = 3          -- plates he puts back at most
local SPEED = 13            -- studs a second he walks
local RISE = 1.2            -- seconds he takes to climb out of the first plate
local HAMMER = 3            -- seconds he hammers at each gap (the plate rises in that time)
local STRIKE = 0.5          -- seconds into each swing of MasonHammer when it hits (KEEP IN SYNC with EventClients > mason)
local SWING = 0.9           -- seconds one swing takes (MasonHammer's length)
local LEAVE = 1.2
local FROM_BELOW = 10       -- studs under its place a rebuilt plate starts

-- the nearest plate to a spot, and where on it he stands (at its edge, facing the spot)
local function standBy(plates: { BasePart }, spot: Vector3): (Vector3?, Vector3?)
	local best, bestD = nil, math.huge
	for _, plate in plates do
		local d = (Vector3.new(plate.Position.X, 0, plate.Position.Z) - Vector3.new(spot.X, 0, spot.Z)).Magnitude
		if d < bestD then
			best, bestD = plate, d
		end
	end
	if not best then
		return nil, nil
	end
	local toward = K.Dir(K.Flat(spot - best.Position), Vector3.new(1, 0, 0))
	local reach = math.min(best.Size.X, best.Size.Z) / 2 - 2
	local stand = Vector3.new(best.Position.X, K.Top(best), best.Position.Z) + toward * reach
	return stand, toward
end

return {
	Name = "Mason's Hammer",
	Id = "mason",
	Weight = 1,
	Duration = DURATION,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local PlateSpawner = K.Sys("PlateSpawner")
		local plates = K.Plates()
		if #plates == 0 then
			return
		end
		local gone = if PlateSpawner and PlateSpawner.Destroyed then PlateSpawner.Destroyed() else {}
		if PlateSpawner and not PlateSpawner.Destroyed then
			warn("[Mason's Hammer] ServerScriptService > Systems > PlateSpawner is an OLDER copy (no Destroyed / Rebuild): he can only shore up a plate. Install the WHOLE update.")
		end
		-- the jobs: the gaps nearest the middle first (nobody wants a plate back at the far edge first)
		local centre = K.Arena(plates)
		table.sort(gone, function(a, b)
			return (a.CFrame.Position - centre).Magnitude < (b.CFrame.Position - centre).Magnitude
		end)
		local jobs = {}
		local points: { number } = {}
		local clock = RISE
		local last: Vector3? = nil
		for _, entry in gone do
			if #jobs >= REBUILDS then
				break
			end
			local stand, toward = standBy(plates, entry.CFrame.Position)
			if stand and toward then
				local walk = if last then K.Flat(stand - last).Magnitude / SPEED else 0
				if clock + walk + HAMMER > DURATION - LEAVE - 0.5 then
					break
				end
				clock += walk
				table.insert(jobs, { Entry = entry, Stand = stand, Face = toward, Arrive = clock })
				table.insert(points, stand.X)
				table.insert(points, stand.Z)
				table.insert(points, toward.X)
				table.insert(points, toward.Z)
				clock += HAMMER
				last = stand
			end
		end
		local shore: BasePart? = nil
		if #jobs == 0 then
			-- nothing to rebuild: he shores up a plate somebody stands on (else any)
			shore = K.PickPlate(plates)
			local plate = shore :: BasePart
			local toward = Vector3.new(1, 0, 0)
			local stand = Vector3.new(plate.Position.X, K.Top(plate), plate.Position.Z) + toward * (math.min(plate.Size.X, plate.Size.Z) / 2 - 2)
			table.insert(jobs, { Stand = stand, Face = -toward, Arrive = RISE })
			points = { stand.X, stand.Z, -toward.X, -toward.Z }
			clock = RISE + HAMMER * 2 -- (he stays a little longer, tapping it solid)
		end
		local id = K.Show(context, "Mason", CFrame.new(jobs[1].Stand), {
			T0 = t0, Duration = DURATION, Route = points, Speed = SPEED, Rise = RISE, Leave = LEAVE,
			Done = clock, Top = K.BaseTop(), Hammer = if shore then HAMMER * 2 else HAMMER,
		})
		if shore then
			K.TellAll("Mason's Hammer", "A ghostly mason is here, but no plate is broken. He shores one up so it can't break.", K.Colors.Bone)
		else
			K.TellAll("Mason's Hammer", "A ghostly mason is rebuilding the plates that were destroyed!", K.Colors.Bone)
		end

		for index, job in jobs do
			if not K.WaitUntil(context, t0 + job.Arrive + STRIKE) then
				return
			end
			if shore then
				K.Protect(context, shore)
				K.Signal(context, id, "Shored", index)
				continue
			end
			-- the plate comes up from the void, a stroke at a time, and locks into its old place
			local entry = job.Entry
			local target: CFrame = entry.CFrame
			local plate = PlateSpawner.Rebuild(entry, target - Vector3.new(0, FROM_BELOW, 0))
			if not plate then
				continue
			end
			K.Signal(context, id, "Rebuild", index, K.Tag(context, plate))
			local strokes = math.max(1, math.floor((HAMMER - STRIKE) / SWING))
			for stroke = 1, strokes do
				local into = target - Vector3.new(0, FROM_BELOW * (1 - stroke / strokes), 0)
				K.Tween(plate, { CFrame = into }, 0.25, "Back", "Out")
				if stroke < strokes and not K.WaitUntil(context, t0 + job.Arrive + STRIKE + stroke * SWING) then
					break
				end
			end
			task.delay(0.3, function()
				if plate.Parent then
					plate.CFrame = target
				end
			end)
		end
		-- the Event Journal: everybody who saw him at work
		for _, player in K.Alive() do
			K.Complete(context, player)
		end
	end,
}
