-- ModuleScript: ServerScriptService > Events > SoulFireBrazier     (NEW: Oct 12 Update 25, /setevent brazier)
-- SOUL FIRE BRAZIER (your backlog, movement event 13): a brazier of pale soul fire lights on a random plate. The FIRST
-- player to claim it (hold E) takes its fire: SPEED times as fast for BUFF_TIME seconds, plus one gift from your buff
-- table at random:
--   DASH CHARGE   a short dash forward (Q, or the DASH button on your screen), DASH_COOLDOWN seconds apart
--   QUIET BOOTS   your footsteps make no sound, for everyone
-- Nobody claims it within BURN seconds = it gutters out. The brazier (the model Brazier) and the dash button (the
-- ScreenGui DashGui) are under this script; ReplicatedStorage > EventClients > brazier draws them.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local DURATION = 35         -- (the brazier burns BURN seconds; whoever claims it keeps the gift BUFF_TIME seconds)
local BURN = 15
local BUFF_TIME = 20
local SPEED = 1.25
local GIFTS = { "Dash", "Quiet" }
local DASH_SPEED = 70       -- studs a second of the dash ...
local DASH_TIME = 0.16      -- ... for this long
local DASH_COOLDOWN = 3
local HOLD = 1

return {
	Name = "Soul Fire Brazier",
	Id = "brazier",
	Weight = 1,
	Duration = DURATION,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local plates = K.Plates()
		local plate = K.PickPlate(plates)
		if not plate then
			return
		end
		local spot = K.PointOn(plate, 5)
		local id = K.Show(context, "Brazier", CFrame.new(spot), { T0 = t0, Duration = DURATION, Burn = BURN, Tag = K.Tag(context, plate) })
		local anchor, prompt = K.Prompt(spot + Vector3.new(0, 3, 0), "Claim", "Soul Fire", HOLD, context.Folder)
		prompt.MaxActivationDistance = 9
		prompt.RequiresLineOfSight = false
		K.Pin(context, anchor, plate)
		K.TellAll("Soul Fire Brazier", "A brazier of soul fire burns on a plate. The first to claim it gets its speed!", K.Colors.Green)

		local claimer: Player? = nil
		local gift: string? = nil
		local claimedAt = 0
		prompt.Triggered:Connect(function(player: Player)
			if claimer or not context.IsRunning() or not K.IsAlive(player) or K.Elapsed(context) > BURN then
				return
			end
			claimer = player
			claimedAt = K.Now()
			gift = K.Pick(GIFTS)
			prompt.Enabled = false
			K.Mod(player, "WalkSpeed", { Mult = SPEED }, "SoulFireSpeed", BUFF_TIME)
			K.Call(context, id, "Claimed", player.UserId, gift, claimedAt + BUFF_TIME)
			K.Complete(context, player)
			if gift == "Dash" then
				K.Tell(player, "Soul Fire: Dash Charge", "You're faster, and you can DASH (Q or the button) for " .. BUFF_TIME .. " seconds.", K.Colors.Green)
			else
				K.Tell(player, "Soul Fire: Quiet Boots", "You're faster, and your steps make no sound for " .. BUFF_TIME .. " seconds.", K.Colors.Green)
			end
			K.TellAll("Soul Fire Brazier", player.DisplayName .. " claimed the soul fire!", K.Colors.Green)
		end)
		-- the dash: the claimer's client asks, the server checks and pushes
		local lastDash = 0
		K.Listen(context, function(player: Player, what: any, direction: any)
			if what ~= "Dash" or player ~= claimer or gift ~= "Dash" or K.Now() > claimedAt + BUFF_TIME then
				return
			end
			if K.Now() - lastDash < DASH_COOLDOWN - 0.15 or typeof(direction) ~= "Vector3" then
				return
			end
			local root = K.Root(player)
			if not root then
				return
			end
			lastDash = K.Now()
			local flat = K.Dir(K.Flat(direction), K.Flat(root.CFrame.LookVector))
			K.Push(player, flat * DASH_SPEED + Vector3.new(0, 4, 0), DASH_TIME)
			K.Signal(context, id, "Dashed", player.UserId)
		end)
		-- nobody claimed it in time: it gutters out
		if K.WaitUntil(context, t0 + BURN) and not claimer then
			prompt.Enabled = false
			K.Call(context, id, "Gutter")
		end
	end,
}
