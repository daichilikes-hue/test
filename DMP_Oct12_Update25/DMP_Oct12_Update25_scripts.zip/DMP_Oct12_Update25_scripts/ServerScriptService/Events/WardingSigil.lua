-- ModuleScript: ServerScriptService > Events > WardingSigil     (NEW: Oct 12 Update 25, /setevent wardsigil)
-- WARDING SIGIL (your backlog, protection event 9): a cold, glowing sigil is branded onto about a quarter of the plates.
-- While the sigils last (DURATION) no event can destroy those plates (Systems > PlateSpawner.DestroyPlate leaves them
-- alone, the same way as the Gargoyle Ward); a sigil flares when it holds. The sigils (the model Sigil under this
-- script, stretched to each plate) are drawn in ReplicatedStorage > EventClients > wardsigil.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local DURATION = 25
local SHARE = 0.25          -- part of the plates that get a sigil (at least one)

return {
	Name = "Warding Sigil",
	Id = "wardsigil",
	Weight = 1,
	Duration = DURATION,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local PlateSpawner = K.Sys("PlateSpawner")
		local plates = K.Shuffle(K.Plates())
		local count = math.min(#plates, math.max(1, math.floor(#plates * SHARE + 0.5)))
		local ids: { [BasePart]: number? } = {}
		for i = 1, count do
			local plate = plates[i]
			ids[plate] = K.Show(context, "Sigil", CFrame.new(K.TopCentre(plate)), { T0 = t0, Duration = DURATION, Tag = K.Tag(context, plate), Delay = (i - 1) * 0.25 })
			K.Protect(context, plate)
		end
		K.TellAll("Warding Sigil", "Glowing sigils protect some of the plates. Nothing can break them while they shine.", K.Colors.Ghost)
		if PlateSpawner and PlateSpawner.Saved then
			context.Trash.Add(PlateSpawner.Saved:Connect(function(plate, why)
				if why == "Protected" and ids[plate] then
					K.Signal(context, ids[plate], "Held")
				end
			end))
		end
		-- the Event Journal: standing on a warded plate counts
		local done: { [Player]: boolean } = {}
		local warded: { BasePart } = {}
		for plate in ids do
			table.insert(warded, plate)
		end
		while context.IsRunning() do
			K.Each(function(player, root, _, feetY)
				if not done[player] and K.PlateUnder(root, feetY, warded) then
					done[player] = true
					K.Complete(context, player)
				end
			end)
			task.wait(0.5)
		end
	end,
}
