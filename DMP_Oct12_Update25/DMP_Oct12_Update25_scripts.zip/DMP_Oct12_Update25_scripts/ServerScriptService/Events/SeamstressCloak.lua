-- ModuleScript: ServerScriptService > Events > SeamstressCloak     (NEW: Oct 12 Update 25, /setevent cloak)
-- SEAMSTRESS'S CLOAK (your backlog, protection event 11): a ghostly seamstress (the model Seamstress under this script,
-- an R6 character) sits sewing on a plate. Go to her and press E: she asks you ONE riddle with 3 answers (your own
-- EventChoice panel). Right = she sews you a cloak (the model Cloak, welded on your back for everyone to see): 20% less
-- damage and 15% faster for CLOAK_TIME seconds. Wrong = nothing. One try each. 15 riddles, kid-safe.
-- She is drawn in ReplicatedStorage > EventClients > cloak.
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local DURATION = 30
local CLOAK_TIME = 30
local DAMAGE_TAKEN = 0.8    -- 20% less damage
local SPEED = 1.15          -- 15% faster
local ANSWER_TIME = 12      -- seconds to pick an answer
local HOLD = 0.3

-- the riddles: the right answer is ALWAYS first here (the buttons are shuffled)
local RIDDLES = {
	{ "What has hands but cannot clap?", "A clock", "A ghost", "A scarecrow" },
	{ "What gets wetter the more it dries?", "A towel", "A candle", "A cobweb" },
	{ "What has a neck but no head?", "A bottle", "A worm", "A candle" },
	{ "What has many teeth but cannot bite?", "A comb", "A pumpkin", "A skeleton" },
	{ "What can you catch but not throw?", "A cold", "A bat", "A ball" },
	{ "What has an eye but cannot see?", "A needle", "A potato", "A storm" },
	{ "What goes up but never comes down?", "Your age", "A balloon", "Smoke" },
	{ "The more you take, the more you leave behind. What am I?", "Footsteps", "Candles", "Cookies" },
	{ "What has a head and a tail but no body?", "A coin", "A snake", "A comet" },
	{ "What can fill a room but takes up no space?", "Light", "Fog", "Bats" },
	{ "What has keys but cannot open locks?", "A piano", "A jailer", "A ghost" },
	{ "What runs but never walks?", "A river", "A spider", "A clock" },
	{ "What belongs to you, but others use it more?", "Your name", "Your shoes", "Your shadow" },
	{ "What has one eye, but cannot see?", "A needle", "A cyclops", "A pirate" },
	{ "I fly without wings and cry without eyes. What am I?", "A cloud", "A bat", "A ghost" },
}

local function shuffled<T>(list: { T }): { T }
	local out = table.clone(list)
	for i = #out, 2, -1 do
		local j = math.random(i)
		out[i], out[j] = out[j], out[i]
	end
	return out
end

-- the cloak on a character (welded to the Torso, unanchored, no collisions), removed after `seconds`
local function wearCloak(player: Player, seconds: number)
	local template = script:FindFirstChild("Cloak")
	local character = player.Character
	local torso = character and character:FindFirstChild("Torso")
	if not (template and template:IsA("Model") and torso and torso:IsA("BasePart")) then
		return
	end
	local old = character:FindFirstChild("SeamstressCloak")
	if old then
		old:Destroy()
	end
	local cloak = template:Clone()
	cloak.Name = "SeamstressCloak"
	cloak:PivotTo(torso.CFrame)
	for _, part in cloak:GetDescendants() do
		if part:IsA("BasePart") then
			part.Anchored = false
			part.CanCollide = false
			part.CanQuery = false
			part.CanTouch = false
			part.Massless = true
			local weld = Instance.new("WeldConstraint")
			weld.Part0 = torso
			weld.Part1 = part
			weld.Parent = part
		end
	end
	cloak.Parent = character
	game:GetService("Debris"):AddItem(cloak, seconds)
end

return {
	Name = "Seamstress's Cloak",
	Id = "cloak",
	Weight = 1,
	Duration = DURATION,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local EventChoice = K.Sys("EventChoice")
		local plates = K.Plates()
		local plate = K.PickPlate(plates)
		if not plate then
			return
		end
		local centre = K.Arena(plates)
		local spot = K.TopCentre(plate)
		local face = K.Dir(K.Flat(centre - spot), Vector3.new(0, 0, -1))
		local id = K.Show(context, "Seamstress", CFrame.lookAt(spot, spot + face), { T0 = t0, Duration = DURATION, Tag = K.Tag(context, plate) })
		local anchor, prompt = K.Prompt(spot + Vector3.new(0, 3, 0), "Talk", "The Seamstress", HOLD, context.Folder)
		prompt.MaxActivationDistance = 9
		prompt.RequiresLineOfSight = false
		K.Pin(context, anchor, plate)
		K.TellAll("Seamstress's Cloak", "A ghostly seamstress asks a riddle. Answer it right and she'll sew you a cloak!", K.Colors.Purple)

		local asked: { [Player]: boolean } = {}
		local numbers: { number } = {}
		for i = 1, #RIDDLES do
			table.insert(numbers, i)
		end
		local order = shuffled(numbers)
		local nextRiddle = 0
		prompt.Triggered:Connect(function(player: Player)
			if asked[player] or not context.IsRunning() or not K.IsAlive(player) then
				return
			end
			asked[player] = true
			if not (EventChoice and EventChoice.Ask) then
				return
			end
			nextRiddle = nextRiddle % #order + 1
			local riddle = RIDDLES[order[nextRiddle]]
			K.Signal(context, id, "Ask", player.UserId)
			local answer = EventChoice.Ask(player, "Options", {
				Title = "The Seamstress asks...",
				Subtitle = riddle[1],
				Options = shuffled({ riddle[2], riddle[3], riddle[4] }),
			}, ANSWER_TIME)
			if not player.Parent then
				return
			end
			local right = answer == riddle[2]
			K.Signal(context, id, "Answer", player.UserId, right)
			if right and K.IsAlive(player) then
				K.Mod(player, "DamageTaken", { Mult = DAMAGE_TAKEN }, "SeamstressCloakArmor", CLOAK_TIME)
				K.Mod(player, "WalkSpeed", { Mult = SPEED }, "SeamstressCloakSpeed", CLOAK_TIME)
				wearCloak(player, CLOAK_TIME)
				K.Complete(context, player)
				K.Tell(player, "A fine cloak!", "20% less damage and 15% faster for " .. CLOAK_TIME .. " seconds.", K.Colors.Purple)
			else
				K.Tell(player, "Not quite...", "The answer was: " .. riddle[2] .. ".", K.Colors.Dark)
			end
		end)
		-- (nobody can talk to her once she is packing up)
		K.Outro(context, 1.5, function()
			prompt.Enabled = false
		end)
	end,
}
