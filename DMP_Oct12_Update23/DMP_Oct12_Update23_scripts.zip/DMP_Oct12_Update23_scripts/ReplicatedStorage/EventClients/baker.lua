-- ModuleScript: ReplicatedStorage > EventClients > baker     (NEW: Oct 12 Update 23, Bone Baker)
-- What the Bone Baker looks like on each client. The server (Events > BoneBaker) works out his route, puts the trays
-- down and feeds people; this draws HIM: the model Baker under ServerScriptService > Events > BoneBaker (an R6
-- character: a skeleton in a chef's hat and apron, carrying a tray). He climbs out of the first plate, walks from
-- plate to plate along the server's route (hopping the gaps), bends down at each one as its tray appears (BakerSet,
-- with a puff of flour), and sinks away after the last. Crumbs fly when somebody eats.
-- HIS ANIMATIONS: BakerWalk and BakerSet, KeyframeSequences in this module's Animations folder. In Studio they play
-- straight from there; for the real game upload them (right-click > Save to Roblox) and paste the ids into ANIMATIONS
-- below. (Not uploaded = in the game he slides along holding his tray out, without the walk.)
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not (FX.Actor and FX.HoldPose and FX.UseSounds) then
	warn("[baker] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end

-- Sounds: paste your own ids into Id (Stand = a Roblox stand-in; "" = silence)
--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	BakerSet = { Id = "", Stand = "rbxasset://sounds/clickfast.wav", Speed = 0.6, Volume = 0.5 },  -- a tray goes down
	BakerCrunch = { Id = "", Stand = "rbxasset://sounds/clickfast.wav", Speed = 1.4, Volume = 0.4 }, -- somebody eats a treat
	BakerRise = { Id = "", Stand = "", Speed = 1, Volume = 0.6 },                                 -- he climbs out of the plate
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

-- Your uploaded animation ids (0 = not uploaded yet: Studio plays the KeyframeSequences from the Animations folder)
--[[DMP:KEEP Animations]]
local ANIMATIONS = {
	BakerWalk = 0, -- walking with the tray (looped)
	BakerSet = 0,  -- bends down and sets a tray on the plate
}
--[[DMP:END]]

local BAKER_SCALE = 1.1     -- his size (1 = a normal R6 character)
local HOP = 2.4             -- studs he hops up crossing a gap between plates
local SINK = 5              -- studs he climbs up out of the plate at the start (and sinks at the end)
local FLOUR = Color3.fromRGB(236, 230, 214)
local REST_POSE = { -- (GENERATED: `python3 animgen/npcs.py rest baker`)
	["RootJoint"] = CFrame.new(0, 0, 0),
	["Neck"] = CFrame.new(0, 0, 0),
	["Right Shoulder"] = CFrame.new(0, 0, 0, 0.469472, -0.874355, 0.122883, 0.882948, 0.464903, -0.065338, 0, 0.139173, 0.990268),
	["Left Shoulder"] = CFrame.new(0, 0, 0, 0.469472, 0.874355, -0.122883, -0.882948, 0.464903, -0.065338, 0, 0.139173, 0.990268),
	["Right Hip"] = CFrame.new(0, 0, 0),
	["Left Hip"] = CFrame.new(0, 0, 0),
}

-- the plates under a line, sampled: the stretches with NO plate under them (where he hops), as { from, to } in studs
local function gaps(a: Vector3, b: Vector3, ray: RaycastParams?, top: number): { { number } }
	local out: { { number } } = {}
	if not ray then
		return out
	end
	local length = (b - a).Magnitude
	local open: number? = nil
	local step = 0.5
	local d = 0
	while d <= length do
		local at = a + (b - a) * (if length > 0 then d / length else 0)
		local hit = workspace:Raycast(Vector3.new(at.X, top + 40, at.Z), Vector3.new(0, -80, 0), ray)
		if not hit and not open then
			open = d
		elseif hit and open then
			table.insert(out, { open, d })
			open = nil
		end
		d += step
	end
	if open then
		table.insert(out, { open, length })
	end
	return out
end

return FX.Module({
	Baker = {
		Init = function(self: any, props: any)
			local model: Instance = self.Inst
			if not (model:IsA("Model") and model:FindFirstChild("HumanoidRootPart")) then
				FX.WarnOnce("baker-model", "[baker] ServerScriptService > Events > BoneBaker has no model named Baker (an R6 character), so the baker cannot be shown. Install the WHOLE update (drag its .rbxmx in) and press Play again.")
				return
			end
			local problem = FX.R6Problem(model)
			if problem then
				warn("[baker] the baker (ServerScriptService > Events > BoneBaker > Baker) cannot play his animations: " .. problem .. ". He is shown without them.")
			end
			if BAKER_SCALE ~= 1 and BAKER_SCALE > 0 then
				(model :: Model):ScaleTo((model :: Model):GetScale() * BAKER_SCALE)
			end
			self.Scale = (model :: Model):GetScale()
			self.Parts = {}
			for _, item in model:GetDescendants() do
				if item:IsA("BasePart") then
					table.insert(self.Parts, { Part = item, Transparency = item.Transparency })
				end
			end
			local flour = model:FindFirstChild("Flour", true)
			self.Flour = if flour and flour:IsA("ParticleEmitter") then flour else nil
			self.Actor = FX.Actor(model :: Model, ANIMATIONS, script)
			local map = workspace:FindFirstChild("Map")
			local plates = map and map:FindFirstChild("Plates")
			if plates then
				local params = RaycastParams.new()
				params.FilterType = Enum.RaycastFilterType.Include
				params.FilterDescendantsInstances = { plates }
				self.Ray = params
			end
			-- the route (the same sums as the server): where he stops, when he gets there
			local route = props.Route or {}
			local top = tonumber(props.Top) or self.Origin.Position.Y
			local speed = math.max(tonumber(props.Speed) or 14, 1)
			local set = tonumber(props.Set) or 1
			self.Top = top
			self.Stops = {}
			local clock = tonumber(props.Rise) or 1.2
			for i = 1, #route - 1, 2 do
				local at = Vector3.new(route[i], top, route[i + 1])
				local last = self.Stops[#self.Stops]
				local stop = { At = at, Gaps = {} }
				if last then
					local length = Vector3.new(at.X - last.At.X, 0, at.Z - last.At.Z).Magnitude
					stop.From = last.At
					stop.Leaves = clock
					stop.Length = length
					stop.Gaps = gaps(last.At, at, self.Ray, top)
					clock += length / speed
				end
				stop.Arrives = clock
				clock += set
				table.insert(self.Stops, stop)
			end
			self.Done = clock
			self.Ground = top
			self.Faded = -1
			FX.Sound("BakerRise", self.Origin.Position)
		end,

		Step = function(self: any, dt: number, t: number)
			local actor = self.Actor
			local stops = self.Stops
			if not actor or not stops or #stops == 0 then
				return
			end
			local props = self.Props
			local rise = tonumber(props.Rise) or 1.2
			local leave = tonumber(props.Leave) or 1.2
			local set = tonumber(props.Set) or 1
			local setAt = tonumber(props.SetAt) or 0.45
			-- where he is on the route
			local position: Vector3 = stops[1].At
			local facing: Vector3? = nil
			local hop = 0
			local walking = false
			for i, stop in stops do
				if stop.From and t >= stop.Leaves and t < stop.Arrives then
					local u = (t - stop.Leaves) / (stop.Arrives - stop.Leaves)
					position = stop.From:Lerp(stop.At, u)
					facing = stop.At - stop.From
					walking = true
					local d = u * stop.Length
					for _, gap in stop.Gaps do
						local a, b = gap[1] - 1, gap[2] + 1
						if d > a and d < b then
							hop = HOP * math.sin(math.pi * (d - a) / (b - a))
						end
					end
					break
				elseif t >= stop.Arrives then
					position = stop.At
					facing = if stop.From then stop.At - stop.From elseif stops[i + 1] then stops[i + 1].At - stop.At else facing
					-- he bends to set this tray down (once)
					if not stop.Set and t < stop.Arrives + set then
						stop.Set = true
						actor.Play("BakerSet", 0.1, 1, 0)
						self:After(math.max(stop.Arrives + setAt - t, 0), function()
							local flour = self.Flour
							if flour and not FX.Off("DisableParticles") then
								flour:Emit(tonumber(flour:GetAttribute("EmitCount")) or 10)
							end
							FX.Sound("BakerSet", stop.At)
						end)
					end
				end
			end
			if not facing then
				facing = if stops[2] then stops[2].At - stops[1].At else Vector3.new(0, 0, -1)
			end
			-- the ground under him (the plate there; over a gap: the plates' height plus his hop)
			local want = self.Top
			if self.Ray then
				local hit = workspace:Raycast(Vector3.new(position.X, self.Top + 60, position.Z), Vector3.new(0, -120, 0), self.Ray)
				if hit and hit.Normal.Y > 0.7 then
					want = hit.Position.Y
				end
			end
			self.Ground += (want - self.Ground) * math.min(dt * 10, 1)
			-- climbing out at the start, sinking away at the end
			local up = FX.Ease.Out(FX.Clamp01(t / rise))
			local away = FX.Clamp01((t - self.Done) / leave)
			local sink = SINK * ((1 - up) + away)
			local at = Vector3.new(position.X, self.Ground + 3 * self.Scale + hop - sink, position.Z)
			local way: Vector3 = facing or Vector3.new(0, 0, -1)
			local flat = Vector3.new(way.X, 0, way.Z)
			actor.Place(if flat.Magnitude > 0.01 then CFrame.lookAt(at, at + flat) else CFrame.new(at))
			if actor.Animated then
				if walking and not self.Walking then
					self.Walking = actor.Play("BakerWalk", 0.15) ~= nil
				elseif not walking and self.Walking then
					self.Walking = false
					actor.Stop("BakerWalk", 0.15)
				end
			else
				FX.HoldPose(self.Inst, REST_POSE) -- (no animations uploaded: he holds his tray out)
			end
			local shown = math.min(up, 1 - away)
			if math.abs(shown - self.Faded) > 0.01 then
				self.Faded = shown
				for _, entry in self.Parts do
					entry.Part.Transparency = entry.Transparency + (1 - entry.Transparency) * (1 - shown)
				end
			end
		end,

		-- somebody ate a treat from a tray at `at`
		Ate = function(_self: any, userId: number, at: Vector3?)
			local root = FX.Root(userId)
			local where = at or (root and root.Position)
			if where then
				FX.Burst(where + Vector3.new(0, 0.6, 0), "Smoke", 6, { Color = FLOUR, Scale = 0.4 })
				FX.Sound("BakerCrunch", where)
			end
			if root then
				FX.Burst(root.Position, "Star", 3, { Color = Color3.fromRGB(255, 220, 160), Scale = 0.5 })
			end
		end,
	},
})
