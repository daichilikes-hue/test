-- ModuleScript: ReplicatedStorage > EventClients > guardian     (NEW: Oct 12 Update 23, Ghost Guardian)
-- What the Ghost Guardian looks like on each client. The server (Events > GhostGuardian) blocks the hit; this draws
-- the little friendly ghost (the model Guardian under ServerScriptService > Events > GhostGuardian): it floats at its
-- player's shoulder, bobbing and looking where they look. When it takes the hit it darts in front of them, flares up
-- in a burst of pale sparkles, and fades away rising. It also drifts off when the event ends or its player is out.
-- Restyle the model there; keep Glow (with the PointLight Light and the emitter Wisp).
local FX = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("EventFX"))
-- (plain words instead of a red error when Shared > EventFX is an older copy than this script was made for)
if not (FX.Root and FX.UseSounds) then
	warn("[guardian] ReplicatedStorage > Shared > EventFX is an OLDER copy than this script was made for, so it will not draw right. Install the WHOLE update (drag its .rbxmx in): scripts pasted in one by one are not enough.")
end

-- Sounds: paste your own ids into Id (Stand = a Roblox stand-in; "" = silence)
--[[DMP:KEEP SOUNDS]]
local SOUNDS = {
	GuardianAbsorb = { Id = "", Stand = "rbxasset://sounds/electronicpingshort.wav", Speed = 0.45, Volume = 0.6 }, -- it takes the hit
	GuardianAppear = { Id = "", Stand = "", Speed = 1, Volume = 0.5 },                                               -- it arrives
}
--[[DMP:END]]
if FX.UseSounds then
	FX.UseSounds(SOUNDS)
end

local SHOULDER = Vector3.new(2.4, 2.2, 1.4) -- where it floats from its player's root (right, up, behind)
local FOLLOW = 6            -- how quickly it keeps up (bigger = snappier)
local SCALE = 0.85          -- its size
local FADE = 1.5            -- seconds it takes to fade after taking the hit (KEEP about the server's FADE)
local DART = 0.25           -- seconds it darts in front of its player when it takes the hit
local SPARKLE = Color3.fromRGB(214, 232, 255)

return FX.Module({
	Guardian = {
		Init = function(self: any, props: any)
			local model = self.Inst
			if model:IsA("Model") and SCALE ~= 1 then
				model:ScaleTo(model:GetScale() * SCALE)
			end
			self.Parts = {}
			for _, item in model:GetDescendants() do
				if item:IsA("BasePart") then
					table.insert(self.Parts, { Part = item, Transparency = item.Transparency })
				end
			end
			local glow = model:FindFirstChild("Glow", true)
			self.Light = glow and glow:FindFirstChildOfClass("PointLight")
			self.Brightness = self.Light and self.Light.Brightness or 1.2
			self.Wisp = glow and glow:FindFirstChild("Wisp")
			self.Pos = self.Origin.Position + Vector3.new(0, 4, 0)
			self.Yaw = 0
			self.Faded = -1
			FX.Sound("GuardianAppear", self.Origin.Position)
		end,

		Step = function(self: any, dt: number, t: number)
			local duration = tonumber(self.Props.Duration) or 25
			local root = FX.Root(tonumber(self.Props.UserId) or 0)
			local ending = self.EndAt and FX.Clamp01((t - self.EndAt) / FADE) or FX.Clamp01((t - (duration - 1)) / 1)
			local want = self.Pos
			if root then
				local _, yaw = root.CFrame:ToOrientation()
				local delta = (yaw - self.Yaw + math.pi) % (2 * math.pi) - math.pi
				self.Yaw += delta * math.min(dt * 4, 1)
				local bob = math.sin(t * 2.4) * 0.3
				want = (root.CFrame * CFrame.new(SHOULDER.X, SHOULDER.Y + bob, SHOULDER.Z)).Position
				-- (it took the hit: it darts in front of its player first)
				if self.AbsorbAt and t - self.AbsorbAt < DART then
					want = (root.CFrame * CFrame.new(0, 1, -2.4)).Position
				end
			end
			-- it rises as it fades
			want += Vector3.new(0, 4 * ending * ending, 0)
			local snap = if self.AbsorbAt and t - self.AbsorbAt < DART then 18 else FOLLOW
			self.Pos = self.Pos:Lerp(want, math.min(dt * snap, 1))
			local spin = if self.AbsorbAt then (t - self.AbsorbAt) * 6 else 0
			self.Inst:PivotTo(CFrame.new(self.Pos) * CFrame.Angles(0, self.Yaw + spin, 0))
			local shown = math.min(FX.Clamp01(t / 0.8), 1 - ending)
			if math.abs(shown - self.Faded) > 0.01 then
				self.Faded = shown
				for _, entry in self.Parts do
					entry.Part.Transparency = entry.Transparency + (1 - entry.Transparency) * (1 - shown)
				end
				local wisp = self.Wisp
				if wisp and wisp:IsA("ParticleEmitter") then
					wisp.Enabled = shown > 0.4 and not FX.Off("DisableParticles")
				end
			end
			local light: PointLight? = self.Light
			if light then
				local flare = if self.AbsorbAt then 1 + 3 * math.max(1 - (t - self.AbsorbAt) / 0.6, 0) else 1
				light.Brightness = self.Brightness * shown * flare
			end
		end,

		-- it took a hit for its player
		Absorb = function(self: any, _amount: number?)
			local t = self:Time()
			self.AbsorbAt = t
			self.EndAt = t + DART
			local userId = tonumber(self.Props.UserId) or 0
			local root = FX.Root(userId)
			local at = if root then root.Position + root.CFrame.LookVector * 1.5 else self.Pos
			FX.Burst(at, "Star", 14, { Color = SPARKLE, Scale = 0.8 })
			FX.Burst(at, "Glow", 4, { Color = SPARKLE, Scale = 1.2 })
			FX.Sound("GuardianAbsorb", at)
			if FX.IsMe(userId) then
				FX.Pulse(Color3.fromRGB(190, 215, 255), 0.7, 0.35)
			end
		end,

		-- its player is out of the round: it just drifts away
		Leave = function(self: any)
			self.EndAt = self.EndAt or self:Time()
		end,
	},
})
