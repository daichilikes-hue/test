These are the scripts of Update 23 as plain files, for reading.
TO INSTALL THE UPDATE, DRAG DMP_Oct12_Update23.rbxmx INTO STUDIO. Do not paste these in one by one: the six new events
need their models (under their scripts in the .rbxmx) and the baker / gargoyle need their animations, and the events
need the shared scripts. (Updates are cumulative: Updates 8 to 22 are in it too, except StarterPlayerScripts >
TarotClient, which you edited yourself: your copy is left as it is.)
New in Update 23: ServerScriptService/Events/MossBloom, GraveLilies, BoneBaker, GhostGuardian, BatNet, GargoyleWard and
ReplicatedStorage/EventClients/moss, lilies, baker, guardian, batnet, ward.
Changed: ServerScriptService/Systems/PlateSpawner, StatShift (yours, with additions), EventUtil; ReplicatedStorage/Shared/EventFX;
ServerScriptService/Events/LanternProcession (the small stat buff). Gentle Rain is NOT changed.
