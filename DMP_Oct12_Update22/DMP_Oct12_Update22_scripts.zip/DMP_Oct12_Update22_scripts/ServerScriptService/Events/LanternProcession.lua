-- ModuleScript: ServerScriptService > Events > LanternProcession     (NEW: Oct 12 Update 22, /setevent procession)
-- LANTERN PROCESSION (your backlog, healing event 2): two or three ghost bearers walk one slow lap over the plates,
-- each holding out a pale lantern. Anyone alive within RADIUS studs of a lantern heals HEAL HP every TICK seconds.
-- They float, so they cross the gaps between the plates (and rise over a plate that is higher than the rest).
-- This script decides where the bearers are and heals. What they look like (the model Bearer under this script:
-- an R6 character with the lantern welded to his hand, and his walk) is in ReplicatedStorage > EventClients >
-- procession. The lap and the timing are worked out the SAME way on both sides (lapPoint below = lapPoint there).
local K = require(game:GetService("ServerScriptService"):WaitForChild("Systems"):WaitForChild("EventUtil"))

local DURATION = 20
local MIN_BEARERS = 2       -- how many ghosts walk (at random between these two)
local MAX_BEARERS = 3
local RADIUS = 8            -- studs: a lantern heals whoever stands this close to its bearer (seen from above) ...
local REACH_UP = 9          -- ... with their feet no more than this many studs above the ground he floats over
local REACH_DOWN = 3        -- ... or this many below it
local HEAL = 1              -- HP every TICK seconds while you are in a lantern's light (2 lanterns do not stack)
local TICK = 0.5
local LAP = 0.42            -- how far out the lap goes: 0 = the middle of the plates, 1 = their outer edge
                            -- (0.42 on his 5 x 5 grid = right over the middle of the ring of plates round the centre)
local CORNER = 10           -- studs: how round the lap's corners are
local LAPS = 1              -- laps they walk in DURATION seconds (the speed follows from it: about 10 studs a second)

-- THE LAP: a rectangle with round corners round the middle (cx, cz), half sizes hx, hz, corner radius r.
-- s = studs along it from its start (any number: it goes round and round). Returns x, z and the way it runs (dx, dz).
-- (KEEP THE SAME as lapPoint in EventClients > procession)
local function lapLength(hx: number, hz: number, r: number): number
	return 4 * (hx - r) + 4 * (hz - r) + 2 * math.pi * r
end

local function lapPoint(cx: number, cz: number, hx: number, hz: number, r: number, s: number): (number, number, number, number)
	local sideX, sideZ = 2 * (hx - r), 2 * (hz - r)
	local arc = math.pi * r / 2
	s %= lapLength(hx, hz, r)
	-- (a quarter circle round (x0, z0), starting at angle a0, d studs along it)
	local function round(x0: number, z0: number, a0: number, d: number): (number, number, number, number)
		local a = a0 + d / r
		return x0 + r * math.cos(a), z0 + r * math.sin(a), -math.sin(a), math.cos(a)
	end
	-- the four straight sides and the four corners, in order (counter-clockwise seen from above)
	local pieces = {
		{ sideZ, function(d) return cx + hx, cz - (hz - r) + d, 0, 1 end },
		{ arc, function(d) return round(cx + hx - r, cz + hz - r, 0, d) end },
		{ sideX, function(d) return cx + (hx - r) - d, cz + hz, -1, 0 end },
		{ arc, function(d) return round(cx - hx + r, cz + hz - r, math.pi / 2, d) end },
		{ sideZ, function(d) return cx - hx, cz + (hz - r) - d, 0, -1 end },
		{ arc, function(d) return round(cx - hx + r, cz - hz + r, math.pi, d) end },
		{ sideX, function(d) return cx - (hx - r) + d, cz - hz, 1, 0 end },
		{ arc, function(d) return round(cx + hx - r, cz - hz + r, 1.5 * math.pi, d) end },
	}
	for _, piece in pieces do
		if s <= piece[1] or piece == pieces[#pieces] then
			return piece[2](math.min(s, piece[1]))
		end
		s -= piece[1]
	end
	return cx + hx, cz, 0, 1
end

-- the ground a bearer floats over: the top of the plate under that spot, else the height of an untouched plate
local function groundAt(x: number, z: number, plates: { BasePart }, base: number): number
	local plate = K.PlateAt(Vector3.new(x, 0, z), plates)
	return if plate then K.Top(plate) else base
end

return {
	Name = "Lantern Procession",
	Id = "procession",
	Weight = 1,
	Duration = DURATION,
	Target = "Arena",
	Run = function(context: any)
		local t0 = K.Start(context)
		local Damage = K.Sys("Damage")
		local plates = K.Plates()
		local base = K.BaseTop()
		-- the lap, round the plates that are left
		local minX, maxX, minZ, maxZ = K.Box(plates)
		local cx, cz = (minX + maxX) / 2, (minZ + maxZ) / 2
		local hx = math.max((maxX - minX) / 2 * LAP, 6)
		local hz = math.max((maxZ - minZ) / 2 * LAP, 6)
		local r = math.clamp(CORNER, 0.5, math.min(hx, hz))
		local length = lapLength(hx, hz, r)
		local speed = length * LAPS / DURATION
		local dir = if math.random() < 0.5 then 1 else -1
		local start = math.random() * length

		-- the bearers, spread evenly round the lap
		local count = math.random(MIN_BEARERS, math.max(MIN_BEARERS, MAX_BEARERS))
		local bearers: { { Offset: number, Id: number? } } = {}
		for i = 1, count do
			local offset = start + (i - 1) * length / count
			local x, z, dx, dz = lapPoint(cx, cz, hx, hz, r, offset)
			local at = Vector3.new(x, groundAt(x, z, plates, base), z)
			local id = K.Show(context, "Bearer", CFrame.lookAt(at, at + Vector3.new(dx * dir, 0, dz * dir)), {
				T0 = t0, Duration = DURATION, Index = i,
				Cx = cx, Cz = cz, Hx = hx, Hz = hz, Corner = r,
				Start = offset, Speed = speed * dir, Top = base, Radius = RADIUS,
			})
			table.insert(bearers, { Offset = offset, Id = id })
		end
		K.TellAll("Lantern Procession", "Ghosts are carrying their lanterns across the plates. Walk in the light to heal.", K.Colors.Ghost)

		-- where each bearer is right now (the same sums as on the clients)
		local function where(bearer, t: number, list: { BasePart }): Vector3
			local x, z = lapPoint(cx, cz, hx, hz, r, bearer.Offset + speed * dir * t)
			return Vector3.new(x, groundAt(x, z, list, base), z)
		end

		local healed: { [Player]: boolean } = {}
		while context.IsRunning() do
			local t = K.Now() - t0
			local list = K.Plates()
			local spots = {}
			for i, bearer in bearers do
				spots[i] = where(bearer, t, list)
			end
			K.Each(function(player, root, _, feetY)
				-- the nearest lantern that reaches this player (they do not stack)
				local best, bestDistance = nil, math.huge
				for i, spot in spots do
					local flat = Vector3.new(root.Position.X - spot.X, 0, root.Position.Z - spot.Z).Magnitude
					if flat <= RADIUS and feetY <= spot.Y + REACH_UP and feetY >= spot.Y - REACH_DOWN and flat < bestDistance then
						best, bestDistance = bearers[i], flat
					end
				end
				if not best or not (Damage and Damage.Heal) then
					return
				end
				local ok, amount = pcall(Damage.Heal, player, HEAL, { Source = "Lantern Procession" })
				if ok and type(amount) == "number" and amount > 0 then
					K.Signal(context, best.Id, "Healed", player.UserId)
					if not healed[player] then
						healed[player] = true
						K.Complete(context, player) -- (the Event Journal: a lantern healed you)
					end
				end
			end)
			task.wait(TICK)
		end
	end,
}
