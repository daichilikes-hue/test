-- ModuleScript: ServerScriptService > Systems > EventUtil
-- Shared helpers for event modules.
-- Oct 7 2026: everything that was in Systems > EventKit2 now lives in here, under the same function names
-- (the second half of this file). Systems > EventKit2 can be deleted once no event requires it any more.
-- Oct 8 2026: Hurt / Strike take a damage type ("Fire", "Poison", "Bleed": Ghosts and Vampires take more or
-- less of each, see Systems > Damage), and there are three new helpers: Dot (damage over time), Topple
-- (knocks a player over) and Swings (runs your function whenever someone swings the tool in their hand).
-- Oct 8 2026 (update 2): PocketRoom (the hand-built Pocket Dimension, for any event that sends people there),
-- ReturnToPlates (puts somebody back on a plate), and Push now honours the player's "KnockbackMult" attribute
-- (the Strength tarot card: 0 = can't be shoved, 1.5 = shoved 50% harder).
-- Oct 8 2026 (update 3): Detached (an event's helpers and visuals OUTSIDE an event, for an item's effect:
-- The Devil's Fiddle plays "Hellhound's Howl" with the Hellhound's own hunt and visuals).
-- Oct 10 2026 (update 8), at the bottom: BaseTop (the height of an untouched plate's top: the same number whatever
-- events did to the plates), Border / RingSpot (the walls round the arena, and a spot in the empty strip between
-- the outermost plates and those walls) and Chest (a NORMAL item chest anywhere, through Systems > ItemCrates).
-- Oct 10 2026 (update 9): Box (the box round the plates), Beside (a spot beside the arena), RingAlong (how far it
-- is to the edge of the plates and to the wall in a direction) and WaterY (the height of the water under the plates).
-- Oct 11 2026 (update 12): an event's own buttons. Show sends the event's name along with the props, and Listen
-- hears what a visual sends back (self:Send(...) in a client module, see Shared > EventFX).

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

local EventUtil = {}

-- Gets (or creates) ReplicatedStorage > Remotes > <name>
function EventUtil.GetRemote(name: string): RemoteEvent
	local remotes = ReplicatedStorage:FindFirstChild("Remotes")
	if not remotes then
		remotes = Instance.new("Folder")
		remotes.Name = "Remotes"
		remotes.Parent = ReplicatedStorage
	end
	local remote = remotes:FindFirstChild(name)
	if not remote then
		remote = Instance.new("RemoteEvent")
		remote.Name = name
		remote.Parent = remotes
	end
	return remote :: RemoteEvent
end

function EventUtil.IsAlive(player: Player): boolean
	return player.Parent == Players and player:GetAttribute("Alive") == true
end

function EventUtil.GetAlivePlayers(): { Player }
	local list = {}
	for _, player in Players:GetPlayers() do
		if EventUtil.IsAlive(player) then
			table.insert(list, player)
		end
	end
	return list
end

function EventUtil.GetRoot(player: Player): (BasePart?, Humanoid?)
	local character = player.Character
	if not character then
		return nil, nil
	end
	local root = character:FindFirstChild("HumanoidRootPart") :: BasePart?
	local humanoid = character:FindFirstChildOfClass("Humanoid")
	return root, humanoid
end

-- Y of a character's feet. R6 has no HipHeight (its legs hang 2 studs below the torso).
function EventUtil.GetFeetY(root: BasePart, humanoid: Humanoid): number
	if humanoid.RigType == Enum.HumanoidRigType.R6 then
		return root.Position.Y - root.Size.Y / 2 - 2
	end
	return root.Position.Y - (humanoid.HipHeight + root.Size.Y / 2)
end

-- Approximate Y of the player's feet and head
function EventUtil.GetVerticalSpan(player: Player): (number?, number?)
	local root, humanoid = EventUtil.GetRoot(player)
	if not root or not humanoid then
		return nil, nil
	end
	return EventUtil.GetFeetY(root, humanoid), EventUtil.GetFeetY(root, humanoid) + 5
end

-- Alive players within a flat radius of a position (and within `height` studs vertically)
function EventUtil.GetPlayersInRadius(position: Vector3, radius: number, height: number?): { Player }
	local list = {}
	local maxHeight = height or 10
	for _, player in EventUtil.GetAlivePlayers() do
		local root = EventUtil.GetRoot(player)
		if root then
			local offset = root.Position - position
			local flatDistance = Vector3.new(offset.X, 0, offset.Z).Magnitude
			if flatDistance <= radius and math.abs(offset.Y) <= maxHeight then
				table.insert(list, player)
			end
		end
	end
	return list
end

function EventUtil.GetPlateTop(plate: BasePart): number
	return plate.Position.Y + plate.Size.Y / 2
end

-- Creates an anchored, non-colliding part. Pass any properties to override.
function EventUtil.MakePart(properties: { [string]: any }): Part
	local part = Instance.new("Part")
	part.Anchored = true
	part.CanCollide = false
	part.CanQuery = false
	part.CanTouch = false
	part.TopSurface = Enum.SurfaceType.Smooth
	part.BottomSurface = Enum.SurfaceType.Smooth
	local parent = properties.Parent
	for key, value in properties do
		if key ~= "Parent" then
			(part :: any)[key] = value
		end
	end
	part.Parent = parent
	return part
end

-- Flat red circle that warns players where something is about to hit
function EventUtil.CreateWarningCircle(position: Vector3, radius: number, parent: Instance): Part
	return EventUtil.MakePart({
		Name = "WarningCircle",
		Shape = Enum.PartType.Cylinder,
		Size = Vector3.new(0.2, radius * 2, radius * 2),
		CFrame = CFrame.new(position) * CFrame.Angles(0, 0, math.rad(90)),
		Color = Color3.fromRGB(200, 30, 40),
		Material = Enum.Material.Neon,
		Transparency = 0.55,
		Parent = parent,
	})
end

-- Smoothly moves a model to a CFrame. Yields until done.
function EventUtil.TweenModel(model: Model, target: CFrame, duration: number, trash: any, style: Enum.EasingStyle?, direction: Enum.EasingDirection?)
	local value = Instance.new("CFrameValue")
	value.Value = model:GetPivot()
	trash.Add(value)

	local connection = value.Changed:Connect(function(cframe)
		model:PivotTo(cframe)
	end)
	trash.Add(connection)

	local tween = TweenService:Create(
		value,
		TweenInfo.new(duration, style or Enum.EasingStyle.Quad, direction or Enum.EasingDirection.Out),
		{ Value = target }
	)
	tween:Play()
	tween.Completed:Wait()

	connection:Disconnect()
	value:Destroy()
end

-- Anchors a model's parts and makes them non-colliding (optionally raycastable)
function EventUtil.PrepareModel(model: Model, canQuery: boolean?): Model
	for _, descendant in model:GetDescendants() do
		if descendant:IsA("BasePart") then
			descendant.Anchored = true
			descendant.CanCollide = false
			descendant.CanQuery = canQuery == true
			descendant.CanTouch = false
		end
	end
	return model
end

-- Clones a Model (or single Part) named `name` from under `container` (usually the event's script),
-- or builds a placeholder with `build` if there isn't one. Leftover attributes are cleared.
function EventUtil.GetTemplate(container: Instance, name: string, build: () -> Model, canQuery: boolean?): Model
	local template = container:FindFirstChild(name)
	local model: Model
	if template and template:IsA("Model") then
		model = template:Clone()
	elseif template and template:IsA("BasePart") then
		model = Instance.new("Model")
		model.Name = name
		local part = template:Clone()
		part.Parent = model
		model.PrimaryPart = part
	else
		model = build()
	end
	for attribute in model:GetAttributes() do
		model:SetAttribute(attribute, nil)
	end
	return EventUtil.PrepareModel(model, canQuery)
end

-- Builds a Model from a list of part property tables. The first part becomes the PrimaryPart.
function EventUtil.BuildModel(name: string, parts: { { [string]: any } }): Model
	local model = Instance.new("Model")
	model.Name = name
	for index, properties in parts do
		properties.Parent = model
		local part = EventUtil.MakePart(properties)
		if index == 1 then
			model.PrimaryPart = part
		end
	end
	return model
end

-- Pushes a player with a velocity for a short time (works on client-owned characters).
-- duration is optional (0.3 seconds). context is optional: the event that shoved them, for the Event Journal.
function EventUtil.Push(player: Player, velocity: Vector3, duration: number?, context: any?)
	if context then
		EventUtil.Blame(context, player)
	end
	local root = EventUtil.GetRoot(player)
	if not root then
		return
	end
	local seconds = duration or 0.3
	local mult = player:GetAttribute("KnockbackMult")
	if type(mult) == "number" then
		velocity *= math.max(mult, 0)
		if velocity.Magnitude < 0.5 then
			return
		end
	end
	local attachment = Instance.new("Attachment")
	attachment.Parent = root
	local push = Instance.new("LinearVelocity")
	push.Attachment0 = attachment
	push.MaxForce = math.huge
	push.VelocityConstraintMode = Enum.VelocityConstraintMode.Vector
	push.RelativeTo = Enum.ActuatorRelativeTo.World
	push.VectorVelocity = velocity
	push.Parent = root
	game:GetService("Debris"):AddItem(push, seconds)
	game:GetService("Debris"):AddItem(attachment, seconds)
end

-- Players whose feet are within `height` of a surface Y and within `radius` (flat) of a point
function EventUtil.GetPlayersOnSpot(position: Vector3, radius: number, surfaceY: number, height: number?): { Player }
	local list = {}
	for _, player in EventUtil.GetAlivePlayers() do
		local root = EventUtil.GetRoot(player)
		local feetY = EventUtil.GetVerticalSpan(player)
		if root and feetY and feetY > surfaceY - 3 and feetY < surfaceY + (height or 4) then
			local offset = root.Position - position
			if Vector3.new(offset.X, 0, offset.Z).Magnitude <= radius then
				table.insert(list, player)
			end
		end
	end
	return list
end

-- Arc position from a to b at progress t (0..1)
function EventUtil.Arc(a: Vector3, b: Vector3, t: number, height: number): Vector3
	return a:Lerp(b, t) + Vector3.new(0, 4 * height * t * (1 - t), 0)
end

-- An invisible part with a ProximityPrompt, for things players interact with.
-- (The object itself is drawn on clients; this is just the server's "button".)
function EventUtil.MakePrompt(position: Vector3, actionText: string, objectText: string, holdDuration: number?, parent: Instance): (Part, ProximityPrompt)
	local anchor = EventUtil.MakePart({
		Name = "Interact",
		Size = Vector3.new(1, 1, 1),
		CFrame = CFrame.new(position),
		Transparency = 1,
		Parent = parent,
	})
	local prompt = Instance.new("ProximityPrompt")
	prompt.ActionText = actionText
	prompt.ObjectText = objectText
	prompt.HoldDuration = holdDuration or 0
	prompt.MaxActivationDistance = 10
	prompt.RequiresLineOfSight = false
	prompt.Parent = anchor
	return anchor, prompt
end

-- The plate a player is standing over (nil if none)
function EventUtil.GetPlateUnder(player: Player, plates: { BasePart }): BasePart?
	local root = EventUtil.GetRoot(player)
	if not root then
		return nil
	end
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Include
	params.FilterDescendantsInstances = plates
	local hit = workspace:Raycast(root.Position, Vector3.new(0, -25, 0), params)
	return if hit then hit.Instance :: BasePart else nil
end

-- A plate for a plate event: under a random alive player if possible, otherwise any plate.
-- Returns the plate and the player on it (if any).
function EventUtil.PickPlate(plates: { BasePart }): (BasePart?, Player?)
	if #plates == 0 then
		return nil, nil
	end
	local players = EventUtil.GetAlivePlayers()
	for i = #players, 2, -1 do
		local j = math.random(i)
		players[i], players[j] = players[j], players[i]
	end
	for _, player in players do
		local plate = EventUtil.GetPlateUnder(player, plates)
		if plate then
			return plate, player
		end
	end
	return plates[math.random(#plates)], nil
end

-- A random alive player's OWN plate (the one they were given this round), wherever they
-- are right now. Players whose plate is gone are skipped. Returns nil if nobody has one.
-- Pass PlateSpawner.GetPlate as getPlate.
function EventUtil.PickPlayersPlate(getPlate: (Player) -> BasePart?): (BasePart?, Player?)
	local players = EventUtil.GetAlivePlayers()
	for i = #players, 2, -1 do
		local j = math.random(i)
		players[i], players[j] = players[j], players[i]
	end
	for _, player in players do
		local plate = getPlate(player)
		if plate and plate.Parent then
			return plate, player
		end
	end
	return nil, nil
end

-- Shows a Toast message on one player's screen
function EventUtil.Notify(player: Player, title: string, text: string?, color: Color3?)
	if player.Parent == Players then
		EventUtil.GetRemote("ClientEffect"):FireClient(player, "Notify", { Title = title, Text = text or "", Color = color })
	end
end

-- How far a model's pivot sits above its lowest point, so it can be placed on a surface
function EventUtil.GetGroundOffset(model: Model): number
	local boxCFrame, boxSize = model:GetBoundingBox()
	return model:GetPivot().Position.Y - (boxCFrame.Position.Y - boxSize.Y / 2)
end

---------------------------------------------------------------------
---------------------------------------------------------------------
-- Everything below was Systems > EventKit2 (the helpers of the Oct 7 events). Same names, now on EventUtil.
-- The SERVER half of an event decides everything that matters (timing, hits, damage, plates). What players
-- SEE is drawn on each client by the event's module in ReplicatedStorage > EventClients, through the
-- visuals framework (context.Visuals): EventUtil.Show / Call / Signal / Hide.
---------------------------------------------------------------------
---------------------------------------------------------------------

local CollectionService = game:GetService("CollectionService")
local Debris = game:GetService("Debris")
local RunService = game:GetService("RunService")
local ServerStorage = game:GetService("ServerStorage")

local Systems = script.Parent :: Instance

export type Context = any

-- Another Systems module, or nil (with a warning) when it is missing / broken
function EventUtil.Sys(name: string): any
	local module = Systems:FindFirstChild(name)
	if not module or not module:IsA("ModuleScript") then
		return nil
	end
	local ok, result = pcall(require :: any, module)
	if ok then
		return result
	end
	warn("[EventUtil] could not require Systems/" .. name .. ": " .. tostring(result))
	return nil
end

-- Damage, Stats, PlateSpawner, DataManager and JournalRules are loaded the FIRST TIME a function needs them,
-- never at the top of this file: plenty of scripts require EventUtil, and if one of those systems does too,
-- requiring each other at the top would be a circular require (an error).
local systems: { [string]: any } = {}
local function system(name: string): any
	local found = systems[name]
	if found == nil then
		found = EventUtil.Sys(name) or false
		systems[name] = found
	end
	return found or nil
end

EventUtil.Colors = {
	Bone = Color3.fromRGB(236, 228, 206),
	Warn = Color3.fromRGB(255, 60, 60),
	Ghost = Color3.fromRGB(150, 205, 255),
	Gold = Color3.fromRGB(255, 200, 60),
	Purple = Color3.fromRGB(150, 80, 200),
	Green = Color3.fromRGB(100, 190, 90),
	Orange = Color3.fromRGB(255, 150, 40),
	Dark = Color3.fromRGB(30, 22, 28),
	White = Color3.fromRGB(245, 240, 240),
}

local warned: { [string]: boolean } = {}
local function warnOnce(key: string, message: any)
	if not warned[key] then
		warned[key] = true
		warn("[EventUtil] " .. tostring(message))
	end
end

---------------------------------------------------------------------
-- Time (the same clock on the server and on every client)
---------------------------------------------------------------------

function EventUtil.Now(): number
	return workspace:GetServerTimeNow()
end

local started: { [any]: number } = setmetatable({}, { __mode = "k" }) :: any

-- Call first in Run. Returns the moment the event started (server clock); visuals count from it.
function EventUtil.Start(context: Context): number
	local t0 = started[context]
	if not t0 then
		t0 = EventUtil.Now()
		started[context] = t0
	end
	return t0
end

-- seconds since EventUtil.Start
function EventUtil.Elapsed(context: Context): number
	return EventUtil.Now() - EventUtil.Start(context)
end

-- Waits until the server clock reaches `when`. false = the event ended first.
function EventUtil.WaitUntil(context: Context, when: number): boolean
	while context.IsRunning() do
		local left = when - EventUtil.Now()
		if left <= 0 then
			return true
		end
		task.wait(math.min(left, 0.25))
	end
	return false
end

-- Runs fn `seconds` before the event's Duration is over (visuals use it to bow out before they are removed)
function EventUtil.Outro(context: Context, seconds: number, fn: () -> ())
	local duration = tonumber(context.Event and context.Event.Duration) or 0
	task.delay(math.max(duration - seconds - EventUtil.Elapsed(context), 0), function()
		if context.IsRunning() then
			local ok, err = pcall(fn :: any)
			if not ok then
				warnOnce("outro" .. tostring(context.Event and context.Event.Name), tostring(context.Event and context.Event.Name) .. " outro: " .. tostring(err))
			end
		end
	end)
end

---------------------------------------------------------------------
-- Event Journal (Systems > JournalRules decides what a page needs; without it these do nothing)
---------------------------------------------------------------------

local function idOf(context: Context): string?
	local event = type(context) == "table" and context.Event
	if type(event) == "table" then
		return tostring(event.Id or event.Name)
	end
	return nil
end

-- "If this player is eliminated in the next few seconds, this event did it" (EventUtil.Hurt and EventUtil.Push call it for you)
function EventUtil.Blame(context: Context, player: Player, seconds: number?)
	local id = idOf(context)
	local rules = system("JournalRules")
	if id and rules and rules.Credit then
		pcall(rules.Credit, player, id, seconds)
	end
end

-- The player did what a friendly event is about (caught the fish, knocked on the door ...)
function EventUtil.Complete(context: Context, player: Player)
	local id = idOf(context)
	local rules = system("JournalRules")
	if id and rules and rules.Complete then
		pcall(rules.Complete, player, id)
	end
end

---------------------------------------------------------------------
-- Players
---------------------------------------------------------------------

EventUtil.Alive = EventUtil.GetAlivePlayers

-- root, humanoid. Unlike GetRoot this gives nil, nil when the character is dead (or the player is nil).
function EventUtil.Root(player: Player?): (BasePart?, Humanoid?)
	local character = player and player.Character
	local root = character and character:FindFirstChild("HumanoidRootPart")
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	if root and root:IsA("BasePart") and humanoid and humanoid.Health > 0 then
		return root, humanoid
	end
	return nil, nil
end

EventUtil.FeetY = EventUtil.GetFeetY

-- fn(player, root, humanoid, feetY) for everyone who is alive right now
function EventUtil.Each(fn: (player: Player, root: BasePart, humanoid: Humanoid, feetY: number) -> ())
	for _, player in EventUtil.Alive() do
		local root, humanoid = EventUtil.Root(player)
		if root and humanoid then
			fn(player, root, humanoid, EventUtil.FeetY(root, humanoid))
		end
	end
end

-- source = the event's context (so the Event Journal knows what did it), or just a name
-- kind = the damage type: "Fire", "Poison", "Bleed" or nil (Systems > Damage: Ghosts and Vampires take more or less)
function EventUtil.Hurt(player: Player, amount: number, source: any?, kind: string?)
	local name = "Event"
	if type(source) == "table" then
		name = tostring(source.Event and source.Event.Name or name)
		EventUtil.Blame(source, player)
	elseif type(source) == "string" then
		name = source
	end
	local Damage = system("Damage")
	if Damage and Damage.Deal then
		pcall(Damage.Deal, player, amount, { Source = name, Type = kind })
	else
		local _, humanoid = EventUtil.Root(player)
		if humanoid then
			humanoid:TakeDamage(amount)
		end
	end
end

function EventUtil.Heal(player: Player, amount: number)
	local Damage = system("Damage")
	if Damage and Damage.Heal then
		pcall(Damage.Heal, player, amount)
	end
end

-- (EventUtil.Push, further up, takes the optional duration and context)

-- Damage over time: `total` damage spread over `seconds` (one tick every half second), of damage type `kind`
-- ("Fire", "Poison", "Bleed" or nil). Giving the same player the same `key` again while it is still running
-- starts it over (it does not stack); different keys run side by side. It stops early if they leave the round.
-- A typed one shows on the character while it runs (drops of blood / green fumes / flames, for everybody to see).
-- e.g. EventUtil.Dot(player, 10, 4, context, "Bleed", "NailsBleed")
local dots: { [Player]: { [string]: number } } = setmetatable({}, { __mode = "k" }) :: any
function EventUtil.Dot(player: Player, total: number, seconds: number, source: any?, kind: string?, key: string?)
	if total <= 0 then
		return
	end
	local ticks = math.max(1, math.floor(seconds / 0.5 + 0.5))
	local each = total / ticks
	local id = key or tostring(kind or "Dot")
	local mine = dots[player] or {}
	dots[player] = mine
	local token = (mine[id] or 0) + 1
	mine[id] = token
	if kind then
		-- the status shows on the character for the whole of it (Systems > Damage > Mark), not only tick by tick
		local Damage = system("Damage")
		if Damage and Damage.Mark then
			Damage.Mark(player, kind, ticks * 0.5 + 0.4)
		end
	end
	task.spawn(function()
		for _ = 1, ticks do
			task.wait(0.5)
			if mine[id] ~= token or not EventUtil.IsAlive(player) then
				return
			end
			EventUtil.Hurt(player, each, source, kind)
		end
		if mine[id] == token then
			mine[id] = nil
		end
	end)
end

-- Knocks a player over: a little hop, a backflip, and they lie there for `seconds` (default 1.2) before they get
-- up again. (Made on the server, simulated by the player's own computer, like Push.) context is optional.
local toppled: { [Humanoid]: number } = setmetatable({}, { __mode = "k" }) :: any
function EventUtil.Topple(player: Player, seconds: number?, context: any?)
	local root, humanoid = EventUtil.Root(player)
	if not (root and humanoid) then
		return
	end
	if context then
		EventUtil.Blame(context, player)
	end
	local token = (toppled[humanoid] or 0) + 1
	toppled[humanoid] = token
	humanoid.PlatformStand = true
	local attachment = Instance.new("Attachment")
	attachment.Name = "ToppleAttachment"
	attachment.Parent = root
	local spin = Instance.new("AngularVelocity")
	spin.Attachment0 = attachment
	spin.MaxTorque = math.huge
	spin.RelativeTo = Enum.ActuatorRelativeTo.World
	spin.AngularVelocity = root.CFrame.RightVector * 13 -- (about the right-hand side: head goes back, feet go up)
	spin.Parent = root
	local hop = Instance.new("LinearVelocity")
	hop.Attachment0 = attachment
	hop.MaxForce = math.huge
	hop.VelocityConstraintMode = Enum.VelocityConstraintMode.Vector
	hop.RelativeTo = Enum.ActuatorRelativeTo.World
	hop.VectorVelocity = Vector3.new(0, 24, 0)
	hop.Parent = root
	game:GetService("Debris"):AddItem(hop, 0.18)
	game:GetService("Debris"):AddItem(spin, 0.45)
	game:GetService("Debris"):AddItem(attachment, 0.5)
	task.delay(seconds or 1.2, function()
		if toppled[humanoid] == token then
			toppled[humanoid] = nil
			if humanoid.Parent then
				humanoid.PlatformStand = false
			end
		end
	end)
end

-- A Stats modifier (e.g. EventUtil.Mod(player, "WalkSpeed", { Mult = 0.5 }, "MyId", 6)). seconds = nil keeps it
-- until EventUtil.Unmod (or until the character respawns, which clears every modifier).
function EventUtil.Mod(player: Player, stat: string, modifier: { [string]: number }, id: string, seconds: number?)
	local Stats = system("Stats")
	if not (Stats and Stats.AddModifier) then
		return
	end
	pcall(Stats.AddModifier, player, stat, modifier, id)
	if seconds then
		task.delay(seconds, function()
			EventUtil.Unmod(player, id)
		end)
	end
end

function EventUtil.Unmod(player: Player, id: string)
	local Stats = system("Stats")
	if Stats and Stats.RemoveModifier then
		pcall(Stats.RemoveModifier, player, id)
	end
end

EventUtil.Tell = EventUtil.Notify

-- A Toast for everyone who is alive in the round
function EventUtil.TellAll(title: string, text: string?, color: Color3?)
	for _, player in EventUtil.Alive() do
		EventUtil.Tell(player, title, text, color)
	end
end

-- A Toast on EVERYONE's screen (in the round or not)
function EventUtil.Announce(title: string, text: string?, color: Color3?)
	EventUtil.GetRemote("ClientEffect"):FireAllClients("Notify", { Title = title, Text = text or "", Color = color })
end

function EventUtil.Candles(player: Player, amount: number)
	local DataManager = system("DataManager")
	if DataManager and DataManager.AddCandles then
		pcall(DataManager.AddCandles, player, amount)
	end
end

-- Gives a random round item (a Tool from ServerStorage.Items). Returns its name, or nil.
function EventUtil.GiveItem(player: Player): string?
	local folder = ServerStorage:FindFirstChild("Items")
	local backpack = player:FindFirstChildOfClass("Backpack")
	if not (folder and backpack) then
		return nil
	end
	local tools: { Instance } = {}
	for _, item in folder:GetDescendants() do
		if item:IsA("Tool") then
			table.insert(tools, item)
		end
	end
	if #tools == 0 then
		return nil
	end
	local tool = tools[math.random(1, #tools)]:Clone()
	tool.Parent = backpack
	return tool.Name
end

---------------------------------------------------------------------
-- Plates (unrotated Parts)
---------------------------------------------------------------------

function EventUtil.Plates(): { BasePart }
	local list: { BasePart } = {}
	local PlateSpawner = system("PlateSpawner")
	if PlateSpawner and PlateSpawner.GetAllPlates then
		local ok, all = pcall(PlateSpawner.GetAllPlates)
		if ok and type(all) == "table" then
			for _, plate in all do
				if typeof(plate) == "Instance" and plate:IsA("BasePart") and plate.Parent then
					table.insert(list, plate)
				end
			end
		end
	end
	return list
end

function EventUtil.DestroyPlate(plate: BasePart)
	local PlateSpawner = system("PlateSpawner")
	if PlateSpawner and PlateSpawner.DestroyPlate then
		pcall(PlateSpawner.DestroyPlate, plate)
	end
end

EventUtil.Top = EventUtil.GetPlateTop

-- the middle of the plate's top surface
function EventUtil.TopCentre(plate: BasePart): Vector3
	return Vector3.new(plate.Position.X, EventUtil.Top(plate), plate.Position.Z)
end

-- Is this position above the plate (seen from the top)? margin widens (or, negative, shrinks) the plate.
function EventUtil.Inside(plate: BasePart, position: Vector3, margin: number?): boolean
	local extra = margin or 0
	return math.abs(position.X - plate.Position.X) <= plate.Size.X / 2 + extra
		and math.abs(position.Z - plate.Position.Z) <= plate.Size.Z / 2 + extra
end

function EventUtil.PlateAt(position: Vector3, plates: { BasePart }, margin: number?): BasePart?
	for _, plate in plates do
		if plate.Parent and EventUtil.Inside(plate, position, margin) then
			return plate
		end
	end
	return nil
end

-- Standing on it: over the plate and the feet at about its top
function EventUtil.StandingOn(plate: BasePart, root: BasePart, feetY: number, margin: number?): boolean
	local top = EventUtil.Top(plate)
	return EventUtil.Inside(plate, root.Position, margin or 0.5) and feetY >= top - 1.5 and feetY <= top + 7
end

-- the plate this player stands on (or is jumping above)
function EventUtil.PlateUnder(root: BasePart, feetY: number, plates: { BasePart }): BasePart?
	for _, plate in plates do
		if plate.Parent and EventUtil.StandingOn(plate, root, feetY) then
			return plate
		end
	end
	return nil
end

-- { [plate] = number of players on it } and the list of plates that have somebody
function EventUtil.Occupied(plates: { BasePart }): ({ [BasePart]: number }, { BasePart })
	local counts: { [BasePart]: number } = {}
	local list: { BasePart } = {}
	EventUtil.Each(function(_, root, _, feetY)
		local plate = EventUtil.PlateUnder(root, feetY, plates)
		if plate then
			if not counts[plate] then
				counts[plate] = 0
				table.insert(list, plate)
			end
			counts[plate] += 1
		end
	end)
	return counts, list
end

-- centre of the arena (Y = the top of the plates) and its radius (to the farthest plate corner)
function EventUtil.Arena(plates: { BasePart }): (Vector3, number)
	if #plates == 0 then
		return Vector3.new(0, 0, 0), 40
	end
	local minX, maxX, minZ, maxZ, top = math.huge, -math.huge, math.huge, -math.huge, -math.huge
	for _, plate in plates do
		local p, s = plate.Position, plate.Size
		minX = math.min(minX, p.X - s.X / 2)
		maxX = math.max(maxX, p.X + s.X / 2)
		minZ = math.min(minZ, p.Z - s.Z / 2)
		maxZ = math.max(maxZ, p.Z + s.Z / 2)
		top = math.max(top, EventUtil.Top(plate))
	end
	local centre = Vector3.new((minX + maxX) / 2, top, (minZ + maxZ) / 2)
	local radius = math.sqrt((maxX - minX) ^ 2 + (maxZ - minZ) ^ 2) / 2
	return centre, radius
end

-- Pairs of plates that sit next to each other in the grid (not diagonal): { { a, b }, ... }
function EventUtil.Neighbours(plates: { BasePart }): { { BasePart } }
	local nearest = math.huge
	for i = 1, #plates do
		for j = i + 1, #plates do
			nearest = math.min(nearest, (plates[i].Position - plates[j].Position).Magnitude)
		end
	end
	local pairsList: { { BasePart } } = {}
	for i = 1, #plates do
		for j = i + 1, #plates do
			local offset = plates[i].Position - plates[j].Position
			local straight = math.abs(offset.X) < 1 or math.abs(offset.Z) < 1
			if straight and offset.Magnitude <= nearest * 1.25 then
				table.insert(pairsList, { plates[i], plates[j] })
			end
		end
	end
	return pairsList
end

-- Hides a plate and lets everything fall through it. Returns a function that puts it back.
function EventUtil.OpenPlate(plate: BasePart): () -> ()
	local saved: { [BasePart]: { any } } = {}
	local parts: { BasePart } = { plate }
	for _, child in plate:GetDescendants() do
		if child:IsA("BasePart") then
			table.insert(parts, child)
		end
	end
	for _, part in parts do
		saved[part] = { part.Transparency, part.CanCollide }
		part.Transparency = 1
		part.CanCollide = false
	end
	local restored = false
	return function()
		if restored then
			return
		end
		restored = true
		for part, old in saved do
			if part.Parent then
				part.Transparency = old[1]
				part.CanCollide = old[2]
			end
		end
	end
end

---------------------------------------------------------------------
-- What players see: your visuals framework (context.Visuals), drawn by ReplicatedStorage > EventClients > <event Id>
-- Only send plain values: numbers, strings, true / false, Vector3, CFrame, Color3.
---------------------------------------------------------------------

-- context.Visuals functions are called with a dot. (If yours ever take `self`, this notices and adapts.)
local EXPECTED_ARGS = { Spawn = 3, Call = 2, Signal = 2, Destroy = 1 }
local callStyle: { [any]: boolean } = setmetatable({}, { __mode = "k" }) :: any
local function invoke(context: Context, name: string, ...: any): (boolean, any)
	local visuals = type(context) == "table" and context.Visuals
	local fn = type(visuals) == "table" and visuals[name]
	if type(fn) ~= "function" then
		warnOnce("novisuals", "this event got no context.Visuals." .. name .. " from EventSystem: it still works, but nothing is drawn")
		return false, nil
	end
	local withSelf = callStyle[fn]
	if withSelf == nil then
		local ok, arity = pcall(debug.info :: any, fn, "a")
		withSelf = ok and type(arity) == "number" and arity == EXPECTED_ARGS[name] + 1
		callStyle[fn] = withSelf
	end
	local ok, result
	if withSelf then
		ok, result = pcall(fn, visuals, ...)
	else
		ok, result = pcall(fn, ...)
	end
	if not ok then
		warnOnce("visuals" .. name, "context.Visuals." .. name .. " failed: " .. tostring(result))
	end
	return ok, result
end

-- Shows something on every client (and on anyone who joins while it is up). Returns its id.
-- asset = the name the event's client module knows; cframe = where; props = plain values for it.
function EventUtil.Show(context: Context, asset: string, cframe: CFrame, props: { [string]: any }?): number?
	-- (the event's name goes along, so the visual can answer: self:Send(...) there, context.ListenForHits here)
	local sent: { [string]: any } = props or {}
	if sent.EventName == nil and type(context) == "table" and type(context.Event) == "table" then
		sent.EventName = context.Event.Name
	end
	local ok, id = invoke(context, "Spawn", asset, cframe, sent)
	if ok and id ~= nil then
		return id
	end
	return nil
end

-- Tells that visual something that still matters for players who join later (they get it too, in order)
function EventUtil.Call(context: Context, id: number?, method: string, ...: any)
	if id ~= nil then
		invoke(context, "Call", id, method, ...)
	end
end

-- A one-off moment (a hit, a bang): players who join later do not need it
function EventUtil.Signal(context: Context, id: number?, method: string, ...: any)
	if id ~= nil then
		invoke(context, "Signal", id, method, ...)
	end
end

-- fn(player, ...) runs when a client's visual says something with self:Send(...) (a click on one of its buttons).
-- Only players alive in the round are heard. WHO it is comes from Roblox; everything after that is the client's
-- word: check it. One listener per event (the last one set). An error in fn is caught and shown once.
function EventUtil.Listen(context: Context, fn: (player: Player, ...any) -> ())
	local name = tostring(context.Event and context.Event.Name)
	context.ListenForHits(function(player: Player, ...: any)
		local ok, err = pcall(fn :: any, player, ...)
		if not ok then
			warnOnce("listen" .. name, name .. ": what a player sent could not be handled: " .. tostring(err))
		end
	end)
end

-- Removes that visual, now or `after` seconds from now. (Everything is removed anyway when the event ends.)
function EventUtil.Hide(context: Context, id: number?, after: number?)
	if id == nil then
		return
	end
	if after and after > 0 then
		task.delay(after, function()
			if context.IsRunning() then
				invoke(context, "Destroy", id)
			end
		end)
	else
		invoke(context, "Destroy", id)
	end
end

-- Hurts (and shoves) a player and lets that visual show the hit. push / pushTime / kind are optional.
-- kind = the damage type ("Fire", "Poison", "Bleed"), see EventUtil.Hurt.
function EventUtil.Strike(context: Context, id: number?, player: Player, damage: number, push: Vector3?, pushTime: number?, kind: string?)
	if damage > 0 then
		EventUtil.Hurt(player, damage, context, kind)
	end
	if push then
		EventUtil.Push(player, push, pushTime, context)
	end
	EventUtil.Signal(context, id, "Hit", player.UserId)
end

-- Marks an instance (a plate, a part of the event) so the client module can find the real thing.
-- Returns the tag (send it in props). The tag is taken off again when the event ends.
local tagCount = 0
function EventUtil.Tag(context: Context, instance: Instance): string
	tagCount += 1
	local tag = "DMPEvent" .. tostring(tagCount)
	CollectionService:AddTag(instance, tag)
	context.Trash.Add(function()
		if instance.Parent then
			CollectionService:RemoveTag(instance, tag)
		end
	end)
	return tag
end

---------------------------------------------------------------------
-- Building (server parts: only for things players must be able to STAND on, and for prompts)
---------------------------------------------------------------------

-- MakePart, but SmoothPlastic and without a shadow unless props say otherwise
function EventUtil.Part(props: { [string]: any }): Part
	local all: { [string]: any } = { CastShadow = false, Material = Enum.Material.SmoothPlastic }
	for key, value in props do
		all[key] = value
	end
	return EventUtil.MakePart(all)
end

function EventUtil.Solid(part: BasePart): BasePart
	part.CanCollide = true
	part.CanQuery = true
	return part
end

function EventUtil.Tween(instance: Instance, props: { [string]: any }, seconds: number, style: string?, direction: string?, repeats: number?, reverses: boolean?): Tween
	local easingStyle = (Enum.EasingStyle :: any)[style or "Quad"]
	local easingDirection = (Enum.EasingDirection :: any)[direction or "Out"]
	local tween = TweenService:Create(instance, TweenInfo.new(seconds, easingStyle, easingDirection, repeats or 0, reverses or false), props)
	tween:Play()
	return tween
end

-- Fades a part (or everything inside a model / folder) out, then destroys it
function EventUtil.Fade(instance: Instance, seconds: number?)
	local fadeTime = seconds or 0.5
	local parts = instance:GetDescendants()
	table.insert(parts, instance)
	for _, part in parts do
		if part:IsA("BasePart") then
			part.CanCollide = false
			EventUtil.Tween(part, { Transparency = 1 }, fadeTime)
		elseif part:IsA("BillboardGui") then
			part.Enabled = false
		end
	end
	Debris:AddItem(instance, fadeTime + 0.1)
end

-- Destroys something a little later (works even after the event has ended)
function EventUtil.Remove(instance: Instance, seconds: number?)
	Debris:AddItem(instance, seconds or 0)
end

-- MakePrompt with the object text, the hold time and the parent optional. Returns anchorPart, prompt.
function EventUtil.Prompt(position: Vector3, action: string, object: string?, hold: number?, parent: Instance?): (BasePart, ProximityPrompt)
	return EventUtil.MakePrompt(position, action, object or "", hold, parent :: Instance)
end

---------------------------------------------------------------------
-- Running
---------------------------------------------------------------------

-- fn(dt, secondsSinceStart) every frame until the event ends (stops itself if fn errors)
function EventUtil.Loop(context: Context, fn: (dt: number, t: number) -> ()): RBXScriptConnection
	local connection: RBXScriptConnection
	connection = RunService.Heartbeat:Connect(function(dt)
		local ok, err = pcall(fn :: any, dt, EventUtil.Elapsed(context))
		if not ok then
			warn("[EventUtil] " .. tostring(context.Event and context.Event.Name) .. " loop stopped: " .. tostring(err))
			connection:Disconnect()
		end
	end)
	context.Trash.Add(connection)
	return connection
end

-- fn(player, tool) every time somebody alive swings / clicks the Tool in their hand, until the event ends.
-- (Tool.Activated reaches the server too. Tools are picked up a few times a second, so one equipped a moment
-- ago counts from its first swing after that.) Your fn decides what the swing hits.
function EventUtil.Swings(context: Context, fn: (player: Player, tool: Tool) -> ())
	local hooked: { [Tool]: boolean } = setmetatable({}, { __mode = "k" }) :: any
	local function hook(player: Player, tool: Tool)
		if hooked[tool] then
			return
		end
		hooked[tool] = true
		context.Trash.Add(tool.Activated:Connect(function()
			if not context.IsRunning() or tool.Parent ~= player.Character or not EventUtil.IsAlive(player) then
				return
			end
			local ok, err = pcall(fn :: any, player, tool)
			if not ok then
				warnOnce("swing" .. tostring(context.Event and context.Event.Name), tostring(context.Event and context.Event.Name) .. " swing: " .. tostring(err))
			end
		end))
	end
	task.spawn(function()
		while context.IsRunning() do
			for _, player in EventUtil.Alive() do
				local character = player.Character
				local tool = character and character:FindFirstChildOfClass("Tool")
				if tool then
					hook(player, tool)
				end
			end
			task.wait(0.2)
		end
	end)
end

-- Waits until the event is over (its Duration ends it)
function EventUtil.Hold(context: Context)
	while context.IsRunning() do
		task.wait(0.25)
	end
end

-- local ready = EventUtil.Cooldown()  ->  ready(key, seconds) is true at most once per `seconds` for that key
function EventUtil.Cooldown(): (key: any, seconds: number) -> boolean
	local last: { [any]: number } = {}
	return function(key: any, seconds: number): boolean
		local now = os.clock()
		if last[key] and now - last[key] < seconds then
			return false
		end
		last[key] = now
		return true
	end
end

function EventUtil.Flat(vector: Vector3): Vector3
	return Vector3.new(vector.X, 0, vector.Z)
end

-- unit vector along the ground (fallback when the two points are on top of each other)
function EventUtil.Dir(vector: Vector3, fallback: Vector3?): Vector3
	local flat = Vector3.new(vector.X, 0, vector.Z)
	if flat.Magnitude < 0.05 then
		return fallback or Vector3.new(1, 0, 0)
	end
	return flat.Unit
end

-- Turns a ground direction toward another one, by at most maxTurn radians (creatures that chase)
function EventUtil.Steer(heading: Vector3, want: Vector3, maxTurn: number): Vector3
	local cross = heading.X * want.Z - heading.Z * want.X
	local turn = math.min(math.acos(math.clamp(heading:Dot(want), -1, 1)), maxTurn) * (if cross >= 0 then 1 else -1)
	local c, s = math.cos(turn), math.sin(turn)
	return EventUtil.Dir(Vector3.new(heading.X * c - heading.Z * s, 0, heading.X * s + heading.Z * c), heading)
end

function EventUtil.Shuffle<T>(list: { T }): { T }
	for i = #list, 2, -1 do
		local j = math.random(1, i)
		list[i], list[j] = list[j], list[i]
	end
	return list
end

function EventUtil.Pick<T>(list: { T }): T?
	if #list == 0 then
		return nil
	end
	return list[math.random(1, #list)]
end

-- a random point on a plate's top, `inset` studs in from the edges
function EventUtil.PointOn(plate: BasePart, inset: number?): Vector3
	local margin = inset or 2
	local hx = math.max(plate.Size.X / 2 - margin, 0)
	local hz = math.max(plate.Size.Z / 2 - margin, 0)
	return Vector3.new(plate.Position.X + (math.random() * 2 - 1) * hx, EventUtil.Top(plate), plate.Position.Z + (math.random() * 2 - 1) * hz)
end

---------------------------------------------------------------------
-- The Pocket Dimension and getting back
---------------------------------------------------------------------

export type PocketRoom = { Folder: Instance, Center: Vector3, Size: Vector3, FloorY: number, SpawnPoint: () -> Vector3, Inside: (position: Vector3) -> boolean }

-- workspace.Map.PocketDimension (built by hand), or nil if there isn't one / it is unusable.
-- Spawn points: parts named "PocketSpawn" or "Spawn" (or SpawnLocations) in it; else straight down from its middle.
-- (The Old Man has his own copy of this; it's the same rules.) nil also when the room sits BELOW the void line,
-- because RoundManager would knock out anybody sent there.
function EventUtil.PocketRoom(): PocketRoom?
	local map = workspace:FindFirstChild("Map")
	local pocket = map and map:FindFirstChild("PocketDimension")
	if not pocket then
		return nil
	end
	local low, high = Vector3.new(math.huge, math.huge, math.huge), Vector3.new(-math.huge, -math.huge, -math.huge)
	local spawns: { Vector3 } = {}
	local any = false
	for _, item in pocket:GetDescendants() do
		if item:IsA("BasePart") then
			any = true
			local half = item.Size / 2
			low = low:Min(item.Position - half)
			high = high:Max(item.Position + half)
			local lower = string.lower(item.Name)
			if lower == "pocketspawn" or lower == "spawn" or item:IsA("SpawnLocation") then
				table.insert(spawns, item.Position + Vector3.new(0, item.Size.Y / 2 + 3.5, 0))
			end
		end
	end
	if not any then
		return nil
	end
	local center, size = (low + high) / 2, high - low
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Include
	params.FilterDescendantsInstances = { pocket }
	local function spawnPoint(): Vector3
		if #spawns > 0 then
			return spawns[math.random(1, #spawns)]
		end
		local jitter = Vector3.new(math.random(-8, 8), 0, math.random(-8, 8))
		local hit = workspace:Raycast(center + jitter, Vector3.new(0, -size.Y, 0), params)
		if hit then
			return hit.Position + Vector3.new(0, 3.5, 0)
		end
		return Vector3.new(center.X, center.Y - size.Y / 2 + 5, center.Z)
	end
	local floorY = spawnPoint().Y - 3.5
	local plates = workspace:FindFirstChild("Map") and (workspace.Map :: any):FindFirstChild("Plates")
	local centrePart = plates and plates:FindFirstChild("Center")
	local ok, GameConfig = pcall(function()
		return require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("GameConfig")) :: any
	end)
	if centrePart and centrePart:IsA("BasePart") and ok and type(GameConfig) == "table" and type(GameConfig.VoidDepth) == "number" then
		if floorY < centrePart.Position.Y - GameConfig.VoidDepth then
			warnOnce("pocketvoid", "workspace.Map.PocketDimension is BELOW the void line, so nobody is sent there (move it up)")
			return nil
		end
	end
	return {
		Folder = pocket, Center = center, Size = size, FloorY = floorY, SpawnPoint = spawnPoint,
		Inside = function(position: Vector3): boolean
			local d = position - center
			return math.abs(d.X) <= size.X / 2 + 4 and math.abs(d.Z) <= size.Z / 2 + 4 and math.abs(d.Y) <= size.Y / 2 + 12
		end,
	}
end

-- Puts a player back on a plate: the one under `near` if it is still there, otherwise a random one.
-- Returns false if there is no plate (or no character).
function EventUtil.ReturnToPlates(player: Player, near: Vector3?): boolean
	local root = EventUtil.Root(player)
	local character = player.Character
	local plates = EventUtil.Plates()
	if not (root and character) or #plates == 0 then
		return false
	end
	local spot: Vector3
	local plate = if near then EventUtil.PlateAt(near, plates, 0) else nil
	if plate and near then
		spot = Vector3.new(near.X, EventUtil.Top(plate), near.Z)
	else
		spot = EventUtil.PointOn(plates[math.random(1, #plates)], 3)
	end
	root.AssemblyLinearVelocity = Vector3.zero
	character:PivotTo(CFrame.new(spot + Vector3.new(0, 3.5, 0)))
	return true
end

---------------------------------------------------------------------
-- Oct 8 2026 (update 3): an event's helpers and visuals OUTSIDE an event
---------------------------------------------------------------------

-- A stand-in for an event's context, for code that runs when that event is NOT running (an item's effect).
-- e.g. The Devil's Fiddle plays "Hellhound's Howl": Hellhound.Hunt(EventUtil.Detached("hellhound", "Hellhound's Howl", 11), ...)
-- eventId = whose client module draws it (ReplicatedStorage > EventClients > <eventId>); name = the source the
-- Event Journal and Damage see; seconds = how long it lives. After that IsRunning() is false, its Trash is
-- cleaned and everything it showed is removed. Uses Systems > EventVisuals directly, like ItemCrates does.
function EventUtil.Detached(eventId: string, name: string, seconds: number): Context
	local EventVisuals = system("EventVisuals")
	local running = true
	local trash: { any } = {}
	local shown: { any } = {}
	local function visuals(method: string, ...: any): any
		local fn = EventVisuals and EventVisuals[method]
		if type(fn) ~= "function" then
			warnOnce("detached" .. method, "Systems > EventVisuals has no " .. method .. ", so nothing is drawn for " .. name)
			return nil
		end
		local ok, result = pcall(fn, ...)
		if not ok then
			warnOnce("detached" .. method .. "error", "EventVisuals." .. method .. " failed for " .. name .. ": " .. tostring(result))
			return nil
		end
		return result
	end
	local context: { [string]: any } = {
		Event = { Id = eventId, Name = name, Duration = seconds },
		IsRunning = function(): boolean
			return running
		end,
		Trash = {
			Add = function(thing: any)
				table.insert(trash, thing)
			end,
		},
		Visuals = {
			Spawn = function(asset: string, cframe: CFrame, props: any): any
				local id = visuals("Spawn", eventId, asset, cframe, props)
				if id ~= nil then
					table.insert(shown, id)
				end
				return id
			end,
			Call = function(id: any, method: string, ...: any)
				visuals("Call", id, method, ...)
			end,
			Signal = function(id: any, method: string, ...: any)
				visuals("Signal", id, method, ...)
			end,
			Destroy = function(id: any)
				visuals("Destroy", id)
			end,
		},
	}
	task.delay(seconds, function()
		running = false
		for index = #trash, 1, -1 do
			local thing = trash[index]
			if typeof(thing) == "Instance" then
				thing:Destroy()
			elseif typeof(thing) == "RBXScriptConnection" then
				thing:Disconnect()
			elseif type(thing) == "function" then
				task.spawn(thing)
			end
		end
		table.clear(trash)
		for _, id in shown do
			visuals("Destroy", id)
		end
	end)
	return context
end

---------------------------------------------------------------------
-- Oct 10 2026 (update 8)
---------------------------------------------------------------------

local function gameConfig(): any
	local ok, config = pcall(function()
		return require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("GameConfig")) :: any
	end)
	return if ok and type(config) == "table" then config else nil
end

-- The Y of the top of a plate nobody has touched (Workspace.Map.Plates.Center + half a plate's thickness). It is the
-- same number all round long, whatever events have done to the plates since (raised, sunk, made thicker ...), so
-- anything that must always come in at the same height uses this instead of a plate's own top.
function EventUtil.BaseTop(): number
	local PlateSpawner = system("PlateSpawner")
	local ok, centre = pcall(function()
		return PlateSpawner.GetCenter()
	end)
	local y = if ok and typeof(centre) == "Instance" and centre:IsA("BasePart") then centre.Position.Y else 0
	local config = gameConfig()
	local thickness = if config and typeof(config.PlateSize) == "Vector3" then config.PlateSize.Y else 1
	return y + thickness / 2
end

-- The walls round the arena (Workspace.Map.border). Returns the middle of the arena (at BaseTop height) and how
-- far it is from there to the INSIDE of the walls along X and along Z. A map with no border: GameConfig.ArenaSize / 2.
function EventUtil.Border(): (Vector3, number, number)
	local top = EventUtil.BaseTop()
	local map = workspace:FindFirstChild("Map")
	local border = map and map:FindFirstChild("border")
	local minX, maxX, minZ, maxZ = math.huge, -math.huge, math.huge, -math.huge
	local thickness = 2
	for _, wall in if border then border:GetDescendants() else {} do
		if wall:IsA("BasePart") then
			minX, maxX = math.min(minX, wall.Position.X), math.max(maxX, wall.Position.X)
			minZ, maxZ = math.min(minZ, wall.Position.Z), math.max(maxZ, wall.Position.Z)
			thickness = math.min(wall.Size.X, wall.Size.Z)
		end
	end
	if maxX - minX > 20 and maxZ - minZ > 20 then
		return Vector3.new((minX + maxX) / 2, top, (minZ + maxZ) / 2), (maxX - minX) / 2 - thickness / 2, (maxZ - minZ) / 2 - thickness / 2
	end
	local config = gameConfig()
	local half = (if config and type(config.ArenaSize) == "number" then config.ArenaSize else 200) / 2
	local PlateSpawner = system("PlateSpawner")
	local ok, centre = pcall(function()
		return PlateSpawner.GetCenter().Position
	end)
	local middle: Vector3 = if ok and typeof(centre) == "Vector3" then centre else Vector3.new(0, top, 0)
	return Vector3.new(middle.X, top, middle.Z), half, half
end

-- A spot in the empty strip between the outermost plates and the border walls: off the plates, still in the arena.
-- depth: 0 = right at the edge of the plates, 1 = right at the wall (default 0.5). Returns the spot (BaseTop
-- height) and the direction from it toward the middle of the arena. side (optional) = 1..4 picks the wall.
function EventUtil.RingSpot(plates: { BasePart }, depth: number?, side: number?): (Vector3, Vector3)
	local middle, halfX, halfZ = EventUtil.Border()
	local minX, maxX, minZ, maxZ = middle.X, middle.X, middle.Z, middle.Z
	for _, plate in plates do
		local p, s = plate.Position, plate.Size
		minX, maxX = math.min(minX, p.X - s.X / 2), math.max(maxX, p.X + s.X / 2)
		minZ, maxZ = math.min(minZ, p.Z - s.Z / 2), math.max(maxZ, p.Z + s.Z / 2)
	end
	local d = math.clamp(depth or 0.5, 0, 1)
	local which = if side then (math.floor(side) - 1) % 4 + 1 else math.random(1, 4)
	local spot: Vector3
	if which == 1 then
		spot = Vector3.new(maxX + (middle.X + halfX - maxX) * d, middle.Y, minZ + math.random() * (maxZ - minZ))
	elseif which == 2 then
		spot = Vector3.new(minX - (minX - (middle.X - halfX)) * d, middle.Y, minZ + math.random() * (maxZ - minZ))
	elseif which == 3 then
		spot = Vector3.new(minX + math.random() * (maxX - minX), middle.Y, maxZ + (middle.Z + halfZ - maxZ) * d)
	else
		spot = Vector3.new(minX + math.random() * (maxX - minX), middle.Y, minZ - (minZ - (middle.Z - halfZ)) * d)
	end
	return spot, EventUtil.Dir(middle - spot, Vector3.new(0, 0, -1))
end

-- The box round every plate that is left: minX, maxX, minZ, maxZ (with no plates: the middle of the arena, four times)
function EventUtil.Box(plates: { BasePart }): (number, number, number, number)
	local minX, maxX, minZ, maxZ = math.huge, -math.huge, math.huge, -math.huge
	for _, plate in plates do
		local p, s = plate.Position, plate.Size
		minX, maxX = math.min(minX, p.X - s.X / 2), math.max(maxX, p.X + s.X / 2)
		minZ, maxZ = math.min(minZ, p.Z - s.Z / 2), math.max(maxZ, p.Z + s.Z / 2)
	end
	if minX > maxX then
		local middle = EventUtil.Border()
		return middle.X, middle.X, middle.Z, middle.Z
	end
	return minX, maxX, minZ, maxZ
end

-- A spot `gap` studs OUTSIDE the plates (straight out from the box round them), somewhere along one of its four
-- sides, never closer than `room` studs to the border wall: for something big that stands BESIDE the arena (the
-- kraken's head). Returns the spot (BaseTop height), the direction from it toward the middle of the plates, and the
-- side it is on (1 = +X, 2 = -X, 3 = +Z, 4 = -Z; 1 and 2 are opposite, so are 3 and 4).
-- side (optional) picks the side; along (optional, 0..1) = where along that side (default: anywhere).
function EventUtil.Beside(plates: { BasePart }, gap: number, room: number?, side: number?, along: number?): (Vector3, Vector3, number)
	local middle, halfX, halfZ = EventUtil.Border()
	local minX, maxX, minZ, maxZ = EventUtil.Box(plates)
	local which = if side then (math.floor(side) - 1) % 4 + 1 else math.random(1, 4)
	local keep = room or 0
	local f = if along then math.clamp(along, 0, 1) else math.random()
	local spot: Vector3
	if which == 1 then
		spot = Vector3.new(math.max(math.min(maxX + gap, middle.X + halfX - keep), maxX), middle.Y, minZ + f * (maxZ - minZ))
	elseif which == 2 then
		spot = Vector3.new(math.min(math.max(minX - gap, middle.X - halfX + keep), minX), middle.Y, minZ + f * (maxZ - minZ))
	elseif which == 3 then
		spot = Vector3.new(minX + f * (maxX - minX), middle.Y, math.max(math.min(maxZ + gap, middle.Z + halfZ - keep), maxZ))
	else
		spot = Vector3.new(minX + f * (maxX - minX), middle.Y, math.min(math.max(minZ - gap, middle.Z - halfZ + keep), minZ))
	end
	local centre = Vector3.new((minX + maxX) / 2, middle.Y, (minZ + maxZ) / 2)
	return spot, EventUtil.Dir(centre - spot, Vector3.new(0, 0, -1)), which
end

-- How far it is from `from`, going along `direction` (flat), to the EDGE OF THE PLATES (the box round every plate
-- that is left) and to the INSIDE OF THE BORDER WALL. Between those two distances is the empty strip: where something
-- big that must be "off the plates but inside the arena" belongs (the kraken, a pedestal). 0 for the first one when
-- `from` is already outside the plates.
function EventUtil.RingAlong(plates: { BasePart }, from: Vector3, direction: Vector3): (number, number)
	local dir = EventUtil.Dir(direction, Vector3.new(0, 0, -1))
	local function leaves(minX: number, maxX: number, minZ: number, maxZ: number): number
		local t = math.huge
		if dir.X > 1e-6 then
			t = math.min(t, (maxX - from.X) / dir.X)
		elseif dir.X < -1e-6 then
			t = math.min(t, (minX - from.X) / dir.X)
		end
		if dir.Z > 1e-6 then
			t = math.min(t, (maxZ - from.Z) / dir.Z)
		elseif dir.Z < -1e-6 then
			t = math.min(t, (minZ - from.Z) / dir.Z)
		end
		return if t == math.huge then 0 else math.max(t, 0)
	end
	local minX, maxX, minZ, maxZ = EventUtil.Box(plates)
	local toPlates = 0
	if from.X >= minX and from.X <= maxX and from.Z >= minZ and from.Z <= maxZ then
		toPlates = leaves(minX, maxX, minZ, maxZ)
	end
	local middle, halfX, halfZ = EventUtil.Border()
	local toWall = leaves(middle.X - halfX, middle.X + halfX, middle.Z - halfZ, middle.Z + halfZ)
	return toPlates, math.max(toWall, toPlates)
end

-- The Y of "the water" under the plates: the top of the part tagged "Void" (the one that takes players out of the
-- round). A map without one: 17 studs below the plate tops.
function EventUtil.WaterY(): number
	local best: number? = nil
	local ok = pcall(function()
		for _, part in game:GetService("CollectionService"):GetTagged("Void") do
			if part:IsA("BasePart") and part:IsDescendantOf(workspace) then
				local top = part.Position.Y + part.Size.Y / 2
				if top < EventUtil.BaseTop() - 2 and (best == nil or top > best) then
					best = top
				end
			end
		end
	end)
	if ok and best then
		return best
	end
	return EventUtil.BaseTop() - 17
end

-- A NORMAL item chest (the one that drops from the sky between events: same model, same "hold E", same items),
-- standing wherever you say. EVERY chest in the game is this one: events do not draw chests of their own.
-- position = the spot it stands on. options (all optional): see Systems > ItemCrates > Spawn (Plate, Lifetime,
-- Drop, Name, CanOpen, OnOpened, NoItem). With a context it is removed when the event ends. Returns the chest
-- (chest.Remove(), chest.IsOpen()) or nil when there is nothing to put in it.
function EventUtil.Chest(context: Context?, position: Vector3, options: { [string]: any }?): any
	local ItemCrates = system("ItemCrates")
	if not (ItemCrates and ItemCrates.Spawn) then
		warnOnce("chest", "Systems > ItemCrates has no Spawn (use the Oct 10 update 8 copy), so no chest was made")
		return nil
	end
	local ok, chest = pcall(ItemCrates.Spawn, position, options)
	if not ok then
		warnOnce("chesterror", "ItemCrates.Spawn failed: " .. tostring(chest))
		return nil
	end
	if chest and type(context) == "table" and context.Trash then
		context.Trash.Add(function()
			chest.Remove()
		end)
	end
	return chest
end

return EventUtil
