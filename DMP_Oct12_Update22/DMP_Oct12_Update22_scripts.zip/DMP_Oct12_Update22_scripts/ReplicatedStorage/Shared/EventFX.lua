-- ModuleScript: ReplicatedStorage > Shared > EventFX     (REPLACE)     CLIENT ONLY
-- Oct 8 2026 (update 3): FX.UseSounds (an event module's own sound slots) and FX.AddImp / FX.PoseImp (the imp of
-- Imp Swindle and Firecracker Imp).
-- Oct 10 2026 (update 8), all at the bottom of this file, nothing above it changed:
--   FX.RigFrom / FX.Clone   an event's look is a MODEL now (made once, kept under the event's server script, cloned
--                           at run time) instead of parts built one by one every time the event runs
--   FX.HeadWarning          THE warning over a player's head: your ReplicatedStorage > Assets > ExclamationWarning
-- Oct 10 2026 (update 9), also at the bottom: FX.Tube (a bendy tube out of a model's Seg / Joint parts: tentacles).
-- Oct 11 2026 (update 12): FX.Gui (an event's GUI is a ScreenGui kept under the event's server script and cloned
-- onto the screen, like its models) and self:Send(...) in a visual (tells the event's server script something).
-- What every event's client module (ReplicatedStorage > EventClients > <event id>) is built from:
--   * FX.Module(...)   plugs an event's visuals into your visuals framework (EventVisualsClient)
--   * camera / screen effects: all of them go through ReplicatedStorage > Utility (so they follow the
--     player's Settings: screen shake, flashing, tinting, FOV, particles)
--   * parts, particles, lights, beams, text, sounds, and ready-made bits (rings, booms, bones, skulls, ghosts...)
--   * FX.Actor(...)    a jointed rig (an R6 character, your Vampiette) that plays animations YOU uploaded
-- Nothing here decides gameplay: the server (ServerScriptService > Events) does. This only draws it.

local CollectionService = game:GetService("CollectionService")
local ContentProvider = game:GetService("ContentProvider")
local Debris = game:GetService("Debris")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")
local TweenService = game:GetService("TweenService")

local localPlayer = Players.LocalPlayer :: Player

local FX = {}

---------------------------------------------------------------------
-- Settings you may want to change
---------------------------------------------------------------------

FX.Settings = {
	Sounds = true,      -- false = the events make no sound at all
	Volume = 0.6,       -- 0 to 1, for every event sound
	Shake = 1,          -- camera shake strength for every event (0.5 = half, 0 = none)
	MaxChunks = 90,     -- the most flying bits (debris, confetti) on screen at once
}

-- Sounds. Id = "" turns one off. Put your own uploaded ids here ("rbxassetid://123..." or just the number).
-- The ones below ship with Roblox; each is tested once when the game starts and switches itself off if
-- it does not load, so a missing one can never spam Output.
FX.Sounds = {
	Thud = { Id = "rbxasset://sounds/action_jump_land.mp3", Speed = 0.7, Volume = 1 },    -- something heavy lands
	Slam = { Id = "rbxasset://sounds/action_jump_land.mp3", Speed = 0.45, Volume = 1.4 }, -- something HUGE lands
	Pop = { Id = "rbxasset://sounds/action_jump.mp3", Speed = 1.5, Volume = 0.9 },
	Boing = { Id = "rbxasset://sounds/action_jump.mp3", Speed = 0.8, Volume = 0.9 },
	Splash = { Id = "rbxasset://sounds/impact_water.mp3", Speed = 1, Volume = 0.9 },
	Shuffle = { Id = "rbxasset://sounds/action_get_up.mp3", Speed = 1, Volume = 0.7 },
	Whoosh = { Id = "rbxasset://sounds/swordslash.wav", Speed = 0.8, Volume = 0.8 },
	Lunge = { Id = "rbxasset://sounds/swordlunge.wav", Speed = 0.9, Volume = 0.8 },
	Shing = { Id = "rbxasset://sounds/unsheath.wav", Speed = 1, Volume = 0.7 },
	Ding = { Id = "rbxasset://sounds/electronicpingshort.wav", Speed = 1, Volume = 0.6 },
	Boom = { Id = "rbxasset://sounds/impact_explosion_03.mp3", Speed = 1, Volume = 1 },
	-- yours (empty = silent). Events ask for these by name:
	Whistle = { Id = "", Speed = 1, Volume = 1 },     -- Spirit Train
	Bell = { Id = "", Speed = 1, Volume = 1 },        -- Spirit Train crossing, Coin of Fate
	Laugh = { Id = "", Speed = 1, Volume = 1 },       -- Vampiette
	Crackle = { Id = "", Speed = 1, Volume = 1 },     -- Ghost Fire
	Croak = { Id = "", Speed = 1, Volume = 1 },       -- Plague of Frogs
	Groan = { Id = "", Speed = 1, Volume = 1 },       -- Zombie Shuffle
	Shutter = { Id = "", Speed = 1, Volume = 1 },     -- Vampiette's Group Photo
}

FX.Colors = {
	Bone = Color3.fromRGB(236, 228, 206),
	Warn = Color3.fromRGB(255, 60, 60),
	Ghost = Color3.fromRGB(150, 205, 255),
	Gold = Color3.fromRGB(255, 200, 60),
	Purple = Color3.fromRGB(150, 80, 200),
	Green = Color3.fromRGB(100, 190, 90),
	Orange = Color3.fromRGB(255, 150, 40),
	Dark = Color3.fromRGB(30, 22, 28),
	White = Color3.fromRGB(245, 240, 240),
	Blood = Color3.fromRGB(150, 24, 40),
	Void = Color3.fromRGB(58, 30, 84),
	Silver = Color3.fromRGB(200, 205, 215),
	Pink = Color3.fromRGB(255, 130, 170),
	Black = Color3.fromRGB(12, 10, 14),
}
local Colors = FX.Colors

local FONT = Enum.Font.FredokaOne
local TEX_SPARK = "rbxasset://textures/particles/sparkles_main.dds"
local TEX_SMOKE = "rbxasset://textures/particles/smoke_main.dds"
local TEX_FIRE = "rbxasset://textures/particles/fire_main.dds"

local warned: { [string]: boolean } = {}
local function warnOnce(key: string, message: string)
	if not warned[key] then
		warned[key] = true
		warn("[EventFX] " .. message)
	end
end
FX.WarnOnce = warnOnce

---------------------------------------------------------------------
-- ReplicatedStorage > Utility (camera shake, FOV, blur, flash, vignette, colour correction, particles)
---------------------------------------------------------------------

local Utility: any = nil
do
	local module = ReplicatedStorage:FindFirstChild("Utility") or ReplicatedStorage:WaitForChild("Utility", 3)
	if module and module:IsA("ModuleScript") then
		local ok, result = pcall(require :: any, module)
		if ok and type(result) == "table" then
			Utility = result
		else
			warnOnce("utility", "ReplicatedStorage.Utility could not be loaded, so events have no camera / screen effects: " .. tostring(result))
		end
	else
		warnOnce("utility", "ReplicatedStorage.Utility was not found, so events have no camera / screen effects")
	end
end
FX.Utility = Utility

-- calls Utility[name](...) and never throws
local function util(name: string, ...: any): any
	local fn = Utility and Utility[name]
	if type(fn) ~= "function" then
		return nil
	end
	local results = table.pack(pcall(fn, ...))
	if not results[1] then
		warnOnce("util" .. name, "Utility." .. name .. " failed: " .. tostring(results[2]))
		return nil
	end
	return results[2]
end

-- true when the player switched that effect OFF in Settings (e.g. "DisableParticles")
function FX.Off(key: string): boolean
	if Utility and type(Utility.GetSetting) == "function" then
		local ok, value = pcall(Utility.GetSetting, key)
		if ok then
			return value == true
		end
	end
	return localPlayer:GetAttribute("Setting_" .. key) == true
end

---------------------------------------------------------------------
-- Time and small maths
---------------------------------------------------------------------

-- the server's clock: the same number on every client, so everyone sees the same moment
function FX.Now(): number
	return workspace:GetServerTimeNow()
end

function FX.Clamp01(x: number): number
	return math.clamp(x, 0, 1)
end

-- 0..1: how far t is on its way from a to b
function FX.Span(t: number, a: number, b: number): number
	if b <= a then
		return if t >= b then 1 else 0
	end
	return math.clamp((t - a) / (b - a), 0, 1)
end

function FX.Lerp(a: number, b: number, t: number): number
	return a + (b - a) * t
end

FX.Ease = {}
function FX.Ease.Smooth(x: number): number
	x = math.clamp(x, 0, 1)
	return x * x * (3 - 2 * x)
end
function FX.Ease.In(x: number): number
	x = math.clamp(x, 0, 1)
	return x * x
end
function FX.Ease.Out(x: number): number
	x = math.clamp(x, 0, 1)
	return 1 - (1 - x) * (1 - x)
end
function FX.Ease.OutCubic(x: number): number
	x = math.clamp(x, 0, 1)
	return 1 - (1 - x) ^ 3
end
-- overshoots a little, then settles (things that pop up)
function FX.Ease.Back(x: number): number
	x = math.clamp(x, 0, 1)
	local c = 1.70158
	return 1 + (c + 1) * (x - 1) ^ 3 + c * (x - 1) ^ 2
end
-- drops and bounces (things that land)
function FX.Ease.Bounce(x: number): number
	x = math.clamp(x, 0, 1)
	local n, d = 7.5625, 2.75
	if x < 1 / d then
		return n * x * x
	elseif x < 2 / d then
		x -= 1.5 / d
		return n * x * x + 0.75
	elseif x < 2.5 / d then
		x -= 2.25 / d
		return n * x * x + 0.9375
	end
	x -= 2.625 / d
	return n * x * x + 0.984375
end
-- a wobble that dies away: 1 at x = 0, settles on 0 (springs, jelly)
function FX.Ease.Wobble(x: number, swings: number?, decay: number?): number
	return math.cos(x * (swings or 3) * math.pi * 2) * math.exp(-x * (decay or 4))
end

-- smooth random between -1 and 1 that changes with t (flicker, sway). seed = any number.
function FX.Noise(seed: number, t: number): number
	return math.clamp(math.noise(seed * 12.9898 + 0.5, t, seed * 4.123) * 2, -1, 1)
end

function FX.Flat(v: Vector3): Vector3
	return Vector3.new(v.X, 0, v.Z)
end

-- unit vector along the ground (fallback when it has no length)
function FX.Dir(v: Vector3, fallback: Vector3?): Vector3
	local flat = Vector3.new(v.X, 0, v.Z)
	if flat.Magnitude < 0.05 then
		return fallback or Vector3.new(0, 0, -1)
	end
	return flat.Unit
end

-- a CFrame standing at `position`, facing along `direction` on the ground (never NaN)
function FX.Facing(position: Vector3, direction: Vector3): CFrame
	local dir = FX.Dir(direction)
	return CFrame.lookAt(position, position + dir)
end

-- a random unit vector on the ground
function FX.RandomDir(): Vector3
	local angle = math.random() * math.pi * 2
	return Vector3.new(math.cos(angle), 0, math.sin(angle))
end

---------------------------------------------------------------------
-- Where things go
---------------------------------------------------------------------

local folder: Folder? = nil
-- short-lived effects (booms, rings, flying bits) live here and clean themselves up
function FX.Folder(): Folder
	local current = folder
	if current and current.Parent then
		return current
	end
	local made = Instance.new("Folder")
	made.Name = "EventFX"
	made.Parent = workspace
	folder = made
	return made
end

local holder: Part? = nil
-- one invisible part that loose attachments (particle bursts, lights, beam ends) hang on
local function getHolder(): Part
	local current = holder
	if current and current.Parent then
		return current
	end
	local part = Instance.new("Part")
	part.Name = "Holder"
	part.Anchored = true
	part.CanCollide = false
	part.CanQuery = false
	part.CanTouch = false
	part.Transparency = 1
	part.Size = Vector3.new(1, 1, 1)
	part.CFrame = CFrame.new(0, -500, 0)
	part.Parent = FX.Folder()
	holder = part
	return part
end

-- An attachment at a point in the world. life = seconds until it is removed (nil = you remove it).
function FX.Point(position: Vector3, life: number?): Attachment
	local attachment = Instance.new("Attachment")
	attachment.Name = "Point"
	attachment.Parent = getHolder()
	attachment.WorldPosition = position
	if life then
		Debris:AddItem(attachment, life)
	end
	return attachment
end

-- How close the camera is to something: 1 = right there (within `full` studs), 0 = `none` studs away or more.
-- No position = 1.
function FX.Near(position: Vector3?, full: number?, none: number?): number
	if not position then
		return 1
	end
	local camera = workspace.CurrentCamera
	if not camera then
		return 1
	end
	local a, b = full or 35, none or 150
	local distance = (camera.CFrame.Position - position).Magnitude
	if b <= a then
		return if distance <= a then 1 else 0
	end
	return math.clamp(1 - (distance - a) / (b - a), 0, 1)
end

---------------------------------------------------------------------
-- Camera and screen (ReplicatedStorage > Utility does the work and respects the player's Settings)
---------------------------------------------------------------------

-- Camera shake. position (optional) makes it weaker the farther the camera is from it.
-- Numbers are the same as Utility.Shake / CameraShaker:ShakeOnce (magnitude, roughness, fadeIn, fadeOut).
function FX.Shake(magnitude: number, roughness: number?, fadeIn: number?, fadeOut: number?, position: Vector3?, full: number?, none: number?)
	local strength = magnitude * FX.Near(position, full, none) * FX.Settings.Shake
	if strength < 0.05 then
		return
	end
	util("Shake", strength, roughness or 12, fadeIn or 0.05, fadeOut or 0.4)
end

-- A shake that GROWS from `from` to `to` over `duration` (Utility.ShakeRamp). Returns stop(fadeOut?).
function FX.Rumble(from: number, to: number, duration: number, roughness: number?, position: Vector3?): (fadeOut: number?) -> ()
	local scale = FX.Near(position) * FX.Settings.Shake
	local handle: any = nil
	if scale >= 0.05 then
		handle = util("ShakeRamp", from * scale, to * scale, duration, roughness or 12)
	end
	local stopped = false
	return function(fadeOut: number?)
		if stopped then
			return
		end
		stopped = true
		if type(handle) == "table" and type(handle.Stop) == "function" then
			local ok = pcall(handle.Stop, fadeOut or 0.3)
			if not ok then
				pcall(handle.Stop, handle, fadeOut or 0.3)
			end
		end
	end
end

function FX.Blur(size: number, duration: number, position: Vector3?)
	local strength = size * FX.Near(position)
	if strength >= 1 then
		util("Blur", strength, duration)
	end
end

function FX.Flash(strength: number?, position: Vector3?)
	local amount = (strength or 1) * FX.Near(position)
	if amount >= 0.1 then
		util("Flash", amount)
	end
end

-- delta = how much wider (+) or tighter (-) than the player's normal view
function FX.FOV(delta: number, seconds: number?)
	local base = (Utility and tonumber(Utility.BaseFOV)) or 70
	util("TweenFOV", base + delta, seconds or 0.2)
end

function FX.FOVReset(seconds: number?)
	util("ResetFOV", seconds or 0.5)
end

-- A quick view kick out and back (a big hit). strength = degrees.
function FX.Kick(strength: number, position: Vector3?)
	local amount = strength * FX.Near(position)
	if amount < 0.5 then
		return
	end
	FX.FOV(amount, 0.08)
	task.delay(0.1, function()
		FX.FOVReset(0.45)
	end)
end

-- transparency: 0 = black edges, 1 = nothing
function FX.Vignette(transparency: number, seconds: number?, color: Color3?)
	util("ShowVignette", transparency, seconds or 0.3, color or Colors.Black)
end

function FX.VignetteOff(seconds: number?)
	util("HideVignette", seconds or 0.4)
end

-- A short vignette pulse (you got hurt, you got chilled ...)
function FX.Pulse(color: Color3, transparency: number?, seconds: number?)
	FX.Vignette(transparency or 0.45, 0.1, color)
	task.delay(seconds or 0.35, function()
		FX.VignetteOff(0.5)
	end)
end

-- Colour correction that belongs to you: tint = FX.Tint(); tint.To({ Saturation = -0.5 }, 0.4); tint.Back(0.6); tint.Remove()
-- props are ColorCorrectionEffect properties (Brightness, Contrast, Saturation, TintColor).
function FX.Tint(): { To: (props: { [string]: any }, seconds: number?) -> (), Back: (seconds: number?) -> (), Remove: (delay: number?) -> () }
	local handle: any = util("ColorCorrection")
	local alive = type(handle) == "table"
	local function method(name: string, ...: any)
		if not alive then
			return
		end
		local fn = handle[name]
		if type(fn) == "function" then
			local ok, err = pcall(fn, handle, ...)
			if not ok then
				warnOnce("tint" .. name, "Utility.ColorCorrection():" .. name .. " failed: " .. tostring(err))
			end
		end
	end
	return {
		To = function(props: { [string]: any }, seconds: number?)
			method("Tween", props, seconds or 0.4)
		end,
		Back = function(seconds: number?)
			method("Reset", seconds or 0.5)
		end,
		Remove = function(delay: number?)
			method("Destroy", delay or 0)
			alive = false
		end,
	}
end

-- The standard "something big just landed here": shake + view kick + a touch of blur, all by distance.
-- power: 1 = a solid hit, 2 = huge.
function FX.Punch(position: Vector3?, power: number?)
	local p = power or 1
	FX.Shake(5 * p, 14, 0.04, 0.5 + 0.2 * p, position)
	FX.Kick(5 * p, position)
	if p >= 1.5 then
		FX.Blur(8 * p, 0.5, position)
	end
end

---------------------------------------------------------------------
-- Parts
---------------------------------------------------------------------

type Props = { [string]: any }

-- An anchored part nothing bumps into. props = any Part properties (Parent is applied last).
function FX.Part(props: Props): Part
	local part = Instance.new("Part")
	part.Anchored = true
	part.CanCollide = false
	part.CanQuery = false
	part.CanTouch = false
	part.CastShadow = false
	part.Material = Enum.Material.SmoothPlastic
	part.TopSurface = Enum.SurfaceType.Smooth
	part.BottomSurface = Enum.SurfaceType.Smooth
	local parent = nil
	for key, value in props do
		if key == "Parent" then
			parent = value
		else
			(part :: any)[key] = value
		end
	end
	part.Parent = parent
	return part
end

local function finish(part: BasePart, parent: Instance?, color: Color3, material: Enum.Material?, transparency: number?)
	part.Anchored = true
	part.CanCollide = false
	part.CanQuery = false
	part.CanTouch = false
	part.CastShadow = false
	part.Color = color
	part.Material = material or Enum.Material.SmoothPlastic
	part.Transparency = transparency or 0
	part.TopSurface = Enum.SurfaceType.Smooth
	part.BottomSurface = Enum.SurfaceType.Smooth
	part.Parent = parent
end

local MIN_SIZE = 0.05
local function safeSize(size: Vector3): Vector3
	return Vector3.new(math.max(size.X, MIN_SIZE), math.max(size.Y, MIN_SIZE), math.max(size.Z, MIN_SIZE))
end

function FX.Block(parent: Instance?, size: Vector3, cframe: CFrame, color: Color3, material: Enum.Material?, transparency: number?): Part
	local part = Instance.new("Part")
	part.Name = "Block"
	part.Size = safeSize(size)
	part.CFrame = cframe
	finish(part, parent, color, material, transparency)
	return part
end

function FX.Ball(parent: Instance?, diameter: number, position: Vector3, color: Color3, material: Enum.Material?, transparency: number?): Part
	local part = Instance.new("Part")
	part.Name = "Ball"
	part.Shape = Enum.PartType.Ball
	local d = math.max(diameter, MIN_SIZE)
	part.Size = Vector3.new(d, d, d)
	part.CFrame = CFrame.new(position)
	finish(part, parent, color, material, transparency)
	return part
end

-- Roblox cylinders lie along their X axis. CYL turns one so it stands along the Y axis of the CFrame you give.
local CYL = CFrame.Angles(0, 0, math.rad(90))
FX.CYL = CYL

-- A cylinder standing along the Y axis of `cframe` (length along Y).
function FX.Cyl(parent: Instance?, diameter: number, length: number, cframe: CFrame, color: Color3, material: Enum.Material?, transparency: number?): Part
	local part = Instance.new("Part")
	part.Name = "Cyl"
	part.Shape = Enum.PartType.Cylinder
	part.Size = Vector3.new(math.max(length, MIN_SIZE), math.max(diameter, MIN_SIZE), math.max(diameter, MIN_SIZE))
	part.CFrame = cframe * CYL
	finish(part, parent, color, material, transparency)
	return part
end

-- An egg / stretched ball that fills `size` (pointy things: spikes, flames, teeth, tentacle pieces)
function FX.Egg(parent: Instance?, size: Vector3, cframe: CFrame, color: Color3, material: Enum.Material?, transparency: number?): Part
	local part = Instance.new("Part")
	part.Name = "Egg"
	part.Size = safeSize(size)
	part.CFrame = cframe
	local mesh = Instance.new("SpecialMesh")
	mesh.MeshType = Enum.MeshType.Sphere
	mesh.Parent = part
	finish(part, parent, color, material, transparency)
	return part
end

function FX.Wedge(parent: Instance?, size: Vector3, cframe: CFrame, color: Color3, material: Enum.Material?, transparency: number?): WedgePart
	local part = Instance.new("WedgePart")
	part.Name = "Wedge"
	part.Size = safeSize(size)
	part.CFrame = cframe
	finish(part, parent, color, material, transparency)
	return part
end

-- A flat glowing disc lying on the ground at `position`
function FX.Disc(parent: Instance?, radius: number, position: Vector3, color: Color3, transparency: number?, thickness: number?): Part
	local part = FX.Cyl(parent, math.max(radius, 0.1) * 2, thickness or 0.2, CFrame.new(position + Vector3.new(0, 0.12, 0)), color, Enum.Material.Neon, transparency or 0.5)
	part.Name = "Disc"
	return part
end

-- resizes a disc made by FX.Disc
function FX.SetDisc(part: BasePart, radius: number, position: Vector3?)
	local d = math.max(radius, 0.05) * 2
	part.Size = Vector3.new(part.Size.X, d, d)
	if position then
		part.CFrame = CFrame.new(position + Vector3.new(0, 0.12, 0)) * CYL
	end
end

-- A flat glowing strip on the ground from a to b
function FX.Strip(parent: Instance?, a: Vector3, b: Vector3, width: number, color: Color3, transparency: number?): Part
	local length = math.max((b - a).Magnitude, 0.1)
	local lift = Vector3.new(0, 0.12, 0)
	local part = FX.Block(parent, Vector3.new(width, 0.2, length), FX.Facing((a + b) / 2 + lift, b - a), color, Enum.Material.Neon, transparency or 0.5)
	part.Name = "Strip"
	return part
end

-- A thin part from a to b (ropes, chains, legs, bolts). Its length runs along Z.
function FX.Line(parent: Instance?, a: Vector3, b: Vector3, thickness: number, color: Color3, material: Enum.Material?, transparency: number?): Part
	local part = FX.Block(parent, Vector3.new(thickness, thickness, 1), CFrame.new(), color, material, transparency)
	part.Name = "Line"
	FX.SetLine(part, a, b)
	return part
end

-- moves a part made by FX.Line
function FX.SetLine(part: BasePart, a: Vector3, b: Vector3)
	local offset = b - a
	local length = offset.Magnitude
	if length < 0.02 then
		part.Size = Vector3.new(part.Size.X, part.Size.Y, MIN_SIZE)
		part.CFrame = CFrame.new(a)
		return
	end
	part.Size = Vector3.new(part.Size.X, part.Size.Y, length)
	local up = if math.abs(offset.Unit.Y) > 0.98 then Vector3.new(1, 0, 0) else Vector3.new(0, 1, 0)
	part.CFrame = CFrame.lookAt((a + b) / 2, b, up)
end

-- Tweens anything. style / direction are names ("Quad", "Back", "Bounce", "Linear", "Sine" ... / "In", "Out", "InOut").
-- With no style it goes through Utility.Tween.
function FX.Tween(instance: Instance, props: Props, seconds: number, style: string?, direction: string?, repeats: number?, reverses: boolean?): Tween?
	if not style and not direction and not repeats and not reverses then
		local tween = util("Tween", instance, props, seconds)
		if typeof(tween) == "Instance" and tween:IsA("Tween") then
			tween:Play() -- (does nothing if Utility already started it)
			return tween
		end
	end
	local easingStyle = (Enum.EasingStyle :: any)[style or "Quad"]
	local easingDirection = (Enum.EasingDirection :: any)[direction or "Out"]
	local tween = TweenService:Create(instance, TweenInfo.new(seconds, easingStyle, easingDirection, repeats or 0, reverses or false), props)
	tween:Play()
	return tween
end

-- Fades a thing (parts, lights, beams, particles) out with Utility.FadeOut, then removes it.
function FX.FadeOut(root: Instance, seconds: number?)
	local fadeTime = seconds or 0.5
	if not root.Parent then
		return
	end
	if Utility and type(Utility.FadeOut) == "function" then
		util("FadeOut", root, fadeTime)
	else
		-- no Utility: do it here
		local list = root:GetDescendants()
		table.insert(list, root)
		for _, item in list do
			if item:IsA("BasePart") then
				FX.Tween(item, { Transparency = 1 }, fadeTime, "Quad")
			elseif item:IsA("ParticleEmitter") then
				item.Enabled = false
			elseif item:IsA("Trail") then
				item.Enabled = false
			elseif item:IsA("Beam") then
				item.Enabled = false
			elseif item:IsA("Light") then
				FX.Tween(item, { Brightness = 0 }, fadeTime, "Quad")
			elseif item:IsA("BillboardGui") then
				item.Enabled = false
			end
		end
	end
	for _, item in root:GetDescendants() do
		if item:IsA("BillboardGui") then
			item.Enabled = false
		end
	end
	Debris:AddItem(root, fadeTime + 0.15)
end

---------------------------------------------------------------------
-- Rigs: several parts that move as one. Build it once, then rig:Move(cframe) every frame.
-- Offsets are relative to the rig's own CFrame; -Z is the front (the way CFrame.lookAt faces).
---------------------------------------------------------------------

local Rig = {}
Rig.__index = Rig

export type Rig = typeof(setmetatable({} :: { Parent: Instance?, Items: { any }, ByName: { [string]: any }, Scale: number, Alpha: number, CFrame: CFrame }, Rig))

function FX.Rig(parent: Instance?): Rig
	return setmetatable({ Parent = parent, Items = {}, ByName = {}, Scale = 1, Alpha = 0, CFrame = CFrame.new() }, Rig)
end

-- adds a part you made yourself. twist = a fixed turn applied after the offset (FX.CYL for cylinders).
function Rig.Add(self: Rig, part: BasePart, offset: CFrame?, name: string?, twist: CFrame?): BasePart
	local item = { Part = part, Offset = offset or CFrame.new(), Twist = twist, Size = part.Size, Transparency = part.Transparency }
	table.insert(self.Items, item)
	if name then
		part.Name = name
		self.ByName[name] = item
	end
	return part
end

function Rig.Block(self: Rig, name: string, size: Vector3, offset: CFrame, color: Color3, material: Enum.Material?, transparency: number?): Part
	local part = FX.Block(self.Parent, size, offset, color, material, transparency)
	self:Add(part, offset, name)
	return part
end

function Rig.Ball(self: Rig, name: string, diameter: number, offset: Vector3, color: Color3, material: Enum.Material?, transparency: number?): Part
	local part = FX.Ball(self.Parent, diameter, offset, color, material, transparency)
	self:Add(part, CFrame.new(offset), name)
	return part
end

-- a cylinder standing along the Y axis of `offset`
function Rig.Cyl(self: Rig, name: string, diameter: number, length: number, offset: CFrame, color: Color3, material: Enum.Material?, transparency: number?): Part
	local part = FX.Cyl(self.Parent, diameter, length, offset, color, material, transparency)
	self:Add(part, offset, name, CYL)
	return part
end

function Rig.Egg(self: Rig, name: string, size: Vector3, offset: CFrame, color: Color3, material: Enum.Material?, transparency: number?): Part
	local part = FX.Egg(self.Parent, size, offset, color, material, transparency)
	self:Add(part, offset, name)
	return part
end

function Rig.Wedge(self: Rig, name: string, size: Vector3, offset: CFrame, color: Color3, material: Enum.Material?, transparency: number?): WedgePart
	local part = FX.Wedge(self.Parent, size, offset, color, material, transparency)
	self:Add(part, offset, name)
	return part
end

-- a thin part from a to b (both relative to the rig)
function Rig.Line(self: Rig, name: string, a: Vector3, b: Vector3, thickness: number, color: Color3, material: Enum.Material?, transparency: number?): Part
	local part = FX.Line(self.Parent, a, b, thickness, color, material, transparency)
	self:Add(part, part.CFrame, name)
	return part
end

function Rig.Get(self: Rig, name: string): BasePart?
	local item = self.ByName[name]
	return item and item.Part
end

-- changes where a named part sits in the rig (use it for moving jaws, arms, wings); shown at the next Move
function Rig.Pose(self: Rig, name: string, offset: CFrame)
	local item = self.ByName[name]
	if item then
		item.Offset = offset
	end
end

-- the offset a named part was given (so a pose can be "its normal place, turned a bit")
function Rig.Offset(self: Rig, name: string): CFrame
	local item = self.ByName[name]
	return if item then item.Offset else CFrame.new()
end

-- Places every part. scale (optional, 1 = as built) grows / shrinks the whole rig about its own middle.
function Rig.Move(self: Rig, cframe: CFrame, scale: number?)
	local s = math.max(scale or 1, 0.02)
	local resize = s ~= self.Scale
	self.Scale = s
	self.CFrame = cframe
	for _, item in self.Items do
		local offset: CFrame = item.Offset
		if s ~= 1 then
			offset = offset.Rotation + offset.Position * s
		end
		local part: BasePart = item.Part
		if resize then
			part.Size = safeSize(item.Size * s)
		end
		part.CFrame = if item.Twist then cframe * offset * item.Twist else cframe * offset
	end
end

-- 0 = as built, 1 = invisible
function Rig.Fade(self: Rig, alpha: number)
	local a = math.clamp(alpha, 0, 1)
	if a == self.Alpha then
		return
	end
	self.Alpha = a
	for _, item in self.Items do
		item.Part.Transparency = item.Transparency + (1 - item.Transparency) * a
	end
end

-- Hides every part whose name starts with `prefix` (hidden = false shows them again). They stay that way through Fade.
function Rig.Hide(self: Rig, prefix: string, hidden: boolean?)
	for _, item in self.Items do
		if string.sub(item.Part.Name, 1, #prefix) == prefix then
			if item.Shown == nil then
				item.Shown = item.Transparency
			end
			item.Transparency = if hidden == false then item.Shown else 1
			item.Part.Transparency = item.Transparency + (1 - item.Transparency) * self.Alpha
		end
	end
end

function Rig.Each(self: Rig, fn: (part: BasePart, name: string) -> ())
	for _, item in self.Items do
		fn(item.Part, item.Part.Name)
	end
end

function Rig.Destroy(self: Rig)
	for _, item in self.Items do
		item.Part:Destroy()
	end
	table.clear(self.Items)
	table.clear(self.ByName)
end

---------------------------------------------------------------------
-- Particles (built-in Roblox textures only, so there is nothing to upload)
---------------------------------------------------------------------

local function fade(from: number, to: number): NumberSequence
	return NumberSequence.new({ NumberSequenceKeypoint.new(0, from), NumberSequenceKeypoint.new(1, to) })
end
local function arc(a: number, b: number, c: number): NumberSequence
	return NumberSequence.new({ NumberSequenceKeypoint.new(0, a), NumberSequenceKeypoint.new(0.25, b), NumberSequenceKeypoint.new(1, c) })
end

local PRESETS: { [string]: (e: ParticleEmitter, color: Color3, s: number) -> () } = {
	-- quick bright sparks that fly out and fall
	Spark = function(e, color, s)
		e.Texture = TEX_SPARK
		e.Color = ColorSequence.new(color:Lerp(Color3.new(1, 1, 1), 0.5), color)
		e.Lifetime = NumberRange.new(0.3, 0.7)
		e.Speed = NumberRange.new(12 * s, 28 * s)
		e.Size = fade(0.55 * s, 0)
		e.Transparency = fade(0, 1)
		e.LightEmission = 1
		e.SpreadAngle = Vector2.new(180, 180)
		e.Acceleration = Vector3.new(0, -45, 0)
		e.Drag = 2
		e.Rotation = NumberRange.new(0, 360)
		e.Rate = 40
	end,
	-- twinkles that drift (magic, treasure, healing)
	Star = function(e, color, s)
		e.Texture = TEX_SPARK
		e.Color = ColorSequence.new(color:Lerp(Color3.new(1, 1, 1), 0.6), color)
		e.Lifetime = NumberRange.new(0.6, 1.3)
		e.Speed = NumberRange.new(2 * s, 7 * s)
		e.Size = arc(0, 0.8 * s, 0)
		e.Transparency = fade(0, 1)
		e.LightEmission = 1
		e.SpreadAngle = Vector2.new(180, 180)
		e.Acceleration = Vector3.new(0, 3, 0)
		e.Drag = 1
		e.Rotation = NumberRange.new(0, 360)
		e.RotSpeed = NumberRange.new(-120, 120)
		e.Rate = 14
	end,
	-- tiny glowing bits that float up (embers, spirit motes)
	Ember = function(e, color, s)
		e.Texture = TEX_SPARK
		e.Color = ColorSequence.new(color)
		e.Lifetime = NumberRange.new(1, 2.2)
		e.Speed = NumberRange.new(1.5 * s, 5 * s)
		e.Size = fade(0.35 * s, 0)
		e.Transparency = arc(1, 0, 1)
		e.LightEmission = 1
		e.SpreadAngle = Vector2.new(35, 35)
		e.Acceleration = Vector3.new(0, 4, 0)
		e.Rotation = NumberRange.new(0, 360)
		e.Rate = 12
	end,
	-- soft glowing puffs (ghost stuff, magic clouds)
	Glow = function(e, color, s)
		e.Texture = TEX_SMOKE
		e.Color = ColorSequence.new(color)
		e.Lifetime = NumberRange.new(0.8, 1.6)
		e.Speed = NumberRange.new(1 * s, 3 * s)
		e.Size = arc(0.6 * s, 1.8 * s, 2.6 * s)
		e.Transparency = arc(1, 0.55, 1)
		e.LightEmission = 0.9
		e.SpreadAngle = Vector2.new(180, 180)
		e.Rotation = NumberRange.new(0, 360)
		e.RotSpeed = NumberRange.new(-30, 30)
		e.Rate = 10
	end,
	-- dark smoke that rises
	Smoke = function(e, color, s)
		e.Texture = TEX_SMOKE
		e.Color = ColorSequence.new(color)
		e.Lifetime = NumberRange.new(0.9, 1.8)
		e.Speed = NumberRange.new(2 * s, 6 * s)
		e.Size = fade(1.6 * s, 4.5 * s)
		e.Transparency = arc(0.9, 0.45, 1)
		e.LightEmission = 0
		e.SpreadAngle = Vector2.new(50, 50)
		e.Acceleration = Vector3.new(0, 5, 0)
		e.Drag = 1.5
		e.Rotation = NumberRange.new(0, 360)
		e.RotSpeed = NumberRange.new(-40, 40)
		e.Rate = 12
	end,
	-- a low burst of dust along the ground
	Dust = function(e, color, s)
		e.Texture = TEX_SMOKE
		e.Color = ColorSequence.new(color)
		e.Lifetime = NumberRange.new(0.5, 1.1)
		e.Speed = NumberRange.new(7 * s, 15 * s)
		e.Size = fade(1.2 * s, 3.4 * s)
		e.Transparency = arc(0.8, 0.5, 1)
		e.LightEmission = 0
		e.SpreadAngle = Vector2.new(85, 85)
		e.Drag = 5
		e.Rotation = NumberRange.new(0, 360)
		e.Rate = 20
	end,
	-- flame tongues
	Fire = function(e, color, s)
		e.Texture = TEX_FIRE
		e.Color = ColorSequence.new(color:Lerp(Color3.new(1, 1, 1), 0.55), color)
		e.Lifetime = NumberRange.new(0.4, 0.9)
		e.Speed = NumberRange.new(3 * s, 7 * s)
		e.Size = arc(0.8 * s, 1.7 * s, 0.2 * s)
		e.Transparency = arc(0.6, 0.15, 1)
		e.LightEmission = 0.85
		e.SpreadAngle = Vector2.new(14, 14)
		e.Acceleration = Vector3.new(0, 7, 0)
		e.Rotation = NumberRange.new(-20, 20)
		e.Rate = 28
	end,
	-- huge slow see-through fog
	Mist = function(e, color, s)
		e.Texture = TEX_SMOKE
		e.Color = ColorSequence.new(color)
		e.Lifetime = NumberRange.new(2.5, 4.5)
		e.Speed = NumberRange.new(0.5, 1.6)
		e.Size = fade(5 * s, 9 * s)
		e.Transparency = arc(1, 0.86, 1)
		e.LightEmission = 0.2
		e.SpreadAngle = Vector2.new(180, 180)
		e.Rotation = NumberRange.new(0, 360)
		e.RotSpeed = NumberRange.new(-10, 10)
		e.Rate = 5
	end,
	-- drops that fly up and fall (splashes)
	Drop = function(e, color, s)
		e.Texture = TEX_SPARK
		e.Color = ColorSequence.new(color)
		e.Lifetime = NumberRange.new(0.5, 0.9)
		e.Speed = NumberRange.new(14 * s, 26 * s)
		e.Size = fade(0.45 * s, 0.2 * s)
		e.Transparency = fade(0.1, 1)
		e.LightEmission = 0.6
		e.SpreadAngle = Vector2.new(40, 40)
		e.Acceleration = Vector3.new(0, -70, 0)
		e.Rate = 30
	end,
}

-- A ParticleEmitter from a preset: "Spark", "Star", "Ember", "Glow", "Smoke", "Dust", "Fire", "Mist", "Drop".
-- props: Color (a Color3), Scale (a number) and any ParticleEmitter property to override. It starts switched OFF.
function FX.Emitter(parent: Instance, kind: string, props: Props?): ParticleEmitter
	local emitter = Instance.new("ParticleEmitter")
	emitter.Name = kind
	emitter.Enabled = false
	emitter.LightInfluence = 0
	local color: Color3 = Colors.White
	local scale = 1
	if props then
		if typeof(props.Color) == "Color3" then
			color = props.Color
		end
		if type(props.Scale) == "number" then
			scale = props.Scale
		end
	end
	local preset = PRESETS[kind] or PRESETS.Spark
	preset(emitter, color, scale)
	if props then
		for key, value in props do
			if key ~= "Scale" and not (key == "Color" and typeof(value) == "Color3") then
				(emitter :: any)[key] = value
			end
		end
	end
	emitter.Parent = parent
	return emitter
end

-- An emitter that keeps running (off when the player disabled particles). parent = a part or attachment.
function FX.Stream(parent: Instance, kind: string, props: Props?): ParticleEmitter
	local emitter = FX.Emitter(parent, kind, props)
	if not FX.Off("DisableParticles") then
		emitter.Enabled = true
	end
	return emitter
end

-- Switches every emitter under root on / off (Utility.SetEmitters); never on when particles are disabled.
function FX.SetEmitters(root: Instance, enabled: boolean)
	local on = enabled and not FX.Off("DisableParticles")
	if Utility and type(Utility.SetEmitters) == "function" then
		util("SetEmitters", root, on)
		return
	end
	for _, item in root:GetDescendants() do
		if item:IsA("ParticleEmitter") then
			item.Enabled = on
		end
	end
end

-- One puff of `count` particles at a spot in the world (through Utility.Emit).
function FX.Burst(at: Vector3, kind: string, count: number, props: Props?)
	if FX.Off("DisableParticles") or count <= 0 then
		return
	end
	local point = FX.Point(at)
	local emitter = FX.Emitter(point, kind, props)
	emitter:SetAttribute("EmitCount", math.floor(count))
	if Utility and type(Utility.Emit) == "function" then
		util("Emit", point)
	else
		emitter:Emit(math.floor(count))
	end
	Debris:AddItem(point, emitter.Lifetime.Max + 0.4)
end

---------------------------------------------------------------------
-- Lights, beams, trails
---------------------------------------------------------------------

function FX.Light(parent: Instance, color: Color3, range: number, brightness: number?, shadows: boolean?): PointLight
	local light = Instance.new("PointLight")
	light.Color = color
	light.Range = range
	light.Brightness = brightness or 2
	light.Shadows = shadows == true and not FX.Off("DisableShadows")
	light.Parent = parent
	return light
end

-- A flash of light in the world that fades away (skipped when the player turned flashing off)
function FX.Glint(position: Vector3, color: Color3, range: number, brightness: number?, seconds: number?)
	if FX.Off("DisableFlashing") then
		return
	end
	local life = seconds or 0.4
	local point = FX.Point(position, life + 0.2)
	local light = FX.Light(point, color, range, brightness or 4)
	FX.Tween(light, { Brightness = 0 }, life, "Quad", "Out")
end

-- an attachment on a part (offset in the part's own space)
function FX.Attach(part: BasePart, offset: Vector3?): Attachment
	local attachment = Instance.new("Attachment")
	attachment.Position = offset or Vector3.new(0, 0, 0)
	attachment.Parent = part
	return attachment
end

-- A glowing ribbon between two attachments
function FX.Beam(parent: Instance, a0: Attachment, a1: Attachment, color: Color3, width: number, props: Props?): Beam
	local beam = Instance.new("Beam")
	beam.Attachment0 = a0
	beam.Attachment1 = a1
	beam.Color = ColorSequence.new(color)
	beam.Width0 = width
	beam.Width1 = width
	beam.FaceCamera = true
	beam.LightEmission = 1
	beam.LightInfluence = 0
	beam.Segments = 12
	beam.Transparency = NumberSequence.new(0.25)
	if props then
		for key, value in props do
			(beam :: any)[key] = value
		end
	end
	beam.Parent = parent
	return beam
end

-- A glowing trail behind a moving part
function FX.Trail(part: BasePart, color: Color3, width: number, lifetime: number, props: Props?): Trail
	local trail = Instance.new("Trail")
	trail.Attachment0 = FX.Attach(part, Vector3.new(0, width / 2, 0))
	trail.Attachment1 = FX.Attach(part, Vector3.new(0, -width / 2, 0))
	trail.Color = ColorSequence.new(color)
	trail.Lifetime = lifetime
	trail.FaceCamera = true
	trail.LightEmission = 1
	trail.LightInfluence = 0
	trail.MinLength = 0.05
	trail.Transparency = fade(0.2, 1)
	trail.WidthScale = fade(1, 0)
	if props then
		for key, value in props do
			(trail :: any)[key] = value
		end
	end
	trail.Parent = part
	return trail
end

---------------------------------------------------------------------
-- Text
---------------------------------------------------------------------

-- Floating text above a part / attachment, sized in STUDS (it shrinks with distance). Returns the TextLabel
-- (change .Text any time) and its BillboardGui.
function FX.Label(adornee: Instance, text: string, color: Color3?, studsUp: number?, width: number?, height: number?): (TextLabel, BillboardGui)
	local gui = Instance.new("BillboardGui")
	gui.Name = "Label"
	gui.Size = UDim2.fromScale(width or 14, height or 3)
	gui.StudsOffsetWorldSpace = Vector3.new(0, studsUp or 4, 0)
	gui.AlwaysOnTop = true
	gui.MaxDistance = 320
	gui.LightInfluence = 0
	gui.ResetOnSpawn = false
	local label = Instance.new("TextLabel")
	label.BackgroundTransparency = 1
	label.Size = UDim2.fromScale(1, 1)
	label.Font = FONT
	label.TextScaled = true
	label.Text = text
	label.TextColor3 = color or Colors.White
	label.TextStrokeColor3 = Colors.Black
	label.TextStrokeTransparency = 0
	label.Parent = gui
	gui.Adornee = adornee
	gui.Parent = adornee
	return label, gui
end

-- Text that pops up at a spot, floats up and fades ("+3", "WHACK!")
function FX.Popup(position: Vector3, text: string, color: Color3?, size: number?)
	local point = FX.Point(position, 1.4)
	local label, gui = FX.Label(point, text, color, 0, (size or 2.4) * math.max(#text, 2) * 0.62, size or 2.4)
	FX.Tween(gui, { StudsOffsetWorldSpace = Vector3.new(0, 4.5, 0) }, 1.1, "Quad", "Out")
	task.delay(0.6, function()
		if label.Parent then
			FX.Tween(label, { TextTransparency = 1, TextStrokeTransparency = 1 }, 0.5, "Quad", "In")
		end
	end)
end

export type Banner = { Set: (title: string?, subtitle: string?) -> (), Bar: (fraction: number) -> (), Color: (color: Color3) -> (), Close: () -> () }

local bannerKill: (() -> ())? = nil
local bannerToken = 0

-- A banner at the top of the screen (dark red and black, chunky text). seconds = how long it stays
-- (nil = until you call .Close()). .Set(title, subtitle) changes the words, .Bar(0..1) shows a timer bar.
-- There is only ever one: a new banner replaces the one that is up. smallFirst = true puts the small line
-- above the big one ("Vampiette says..." over "JUMP!").
function FX.Banner(title: string, subtitle: string?, color: Color3?, seconds: number?, smallFirst: boolean?): Banner
	local accent = color or Colors.Gold
	local playerGui = localPlayer:FindFirstChildOfClass("PlayerGui")
	local dead: Banner = { Set = function() end, Bar = function() end, Color = function() end, Close = function() end }
	if not playerGui then
		return dead
	end
	local kill = bannerKill
	if kill then
		kill()
	end
	bannerToken += 1
	local token = bannerToken
	local closed = false
	local gui = Instance.new("ScreenGui")
	gui.Name = "EventFXGui"
	gui.ResetOnSpawn = false
	gui.DisplayOrder = 45
	gui.IgnoreGuiInset = true
	gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	bannerKill = function()
		closed = true
		gui:Destroy()
	end

	local panel = Instance.new("Frame")
	panel.Name = "Banner"
	panel.AnchorPoint = Vector2.new(0.5, 0)
	panel.Position = UDim2.new(0.5, 0, 0, 104)
	panel.Size = UDim2.fromOffset(460, 92)
	panel.BackgroundColor3 = Color3.new(1, 1, 1)
	panel.BorderSizePixel = 0
	panel.Parent = gui
	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(0, 16)
	corner.Parent = panel
	local gradient = Instance.new("UIGradient")
	gradient.Color = ColorSequence.new(Color3.fromRGB(64, 14, 22), Color3.fromRGB(14, 6, 9))
	gradient.Rotation = 90
	gradient.Parent = panel
	local edge = Instance.new("UIStroke")
	edge.Color = accent
	edge.Thickness = 3
	edge.Parent = panel
	local scale = Instance.new("UIScale")
	local camera = workspace.CurrentCamera
	local fit = if camera then math.clamp(camera.ViewportSize.X / 560, 0.55, 1) else 1
	scale.Scale = fit * 0.6
	scale.Parent = panel

	local function words(y: number, height: number, size: number, textColor: Color3): TextLabel
		local label = Instance.new("TextLabel")
		label.BackgroundTransparency = 1
		label.Position = UDim2.fromOffset(12, y)
		label.Size = UDim2.new(1, -24, 0, height)
		label.Font = FONT
		label.TextSize = size
		label.TextScaled = true
		label.TextColor3 = textColor
		label.TextStrokeColor3 = Colors.Black
		label.TextStrokeTransparency = 0.2
		label.Text = ""
		label.ZIndex = 2
		label.Parent = panel
		local limit = Instance.new("UITextSizeConstraint")
		limit.MaxTextSize = size
		limit.MinTextSize = 10
		limit.Parent = label
		return label
	end
	local titleLabel = words(if smallFirst then 32 else 8, 44, 38, Colors.White)
	local subLabel = words(if smallFirst then 8 else 52, 24, 20, accent)
	local track = Instance.new("Frame")
	track.Name = "Timer"
	track.AnchorPoint = Vector2.new(0.5, 1)
	track.Position = UDim2.new(0.5, 0, 1, -8)
	track.Size = UDim2.new(1, -40, 0, 6)
	track.BackgroundColor3 = Color3.fromRGB(40, 16, 20)
	track.BorderSizePixel = 0
	track.Visible = false
	track.ZIndex = 2
	track.Parent = panel
	local trackCorner = Instance.new("UICorner")
	trackCorner.CornerRadius = UDim.new(1, 0)
	trackCorner.Parent = track
	local fill = Instance.new("Frame")
	fill.Size = UDim2.fromScale(1, 1)
	fill.BackgroundColor3 = accent
	fill.BorderSizePixel = 0
	fill.ZIndex = 3
	fill.Parent = track
	local fillCorner = Instance.new("UICorner")
	fillCorner.CornerRadius = UDim.new(1, 0)
	fillCorner.Parent = fill

	titleLabel.Text = title
	subLabel.Text = subtitle or ""
	gui.Parent = playerGui
	FX.Tween(scale, { Scale = fit }, 0.3, "Back", "Out")

	local banner: Banner = {
		Set = function(newTitle: string?, newSubtitle: string?)
			if closed then
				return
			end
			if newTitle then
				titleLabel.Text = newTitle
			end
			if newSubtitle then
				subLabel.Text = newSubtitle
			end
		end,
		Bar = function(fraction: number)
			if closed then
				return
			end
			track.Visible = true
			fill.Size = UDim2.fromScale(math.clamp(fraction, 0, 1), 1)
		end,
		Color = function(newColor: Color3)
			if closed then
				return
			end
			edge.Color = newColor
			subLabel.TextColor3 = newColor
			fill.BackgroundColor3 = newColor
		end,
		Close = function()
			if closed then
				return
			end
			closed = true
			if gui.Parent then
				FX.Tween(scale, { Scale = fit * 0.5 }, 0.18, "Quad", "In")
				Debris:AddItem(gui, 0.2)
			end
			if bannerToken == token then
				bannerKill = nil
			end
		end,
	}
	if seconds then
		task.delay(seconds, banner.Close)
	end
	return banner
end

---------------------------------------------------------------------
-- Sounds
---------------------------------------------------------------------

local soundState: { [string]: string } = {} -- id -> "checking" / "ok" / "bad"

local function soundId(raw: any): string
	local id = tostring(raw or "")
	if id:match("^%d+$") then
		return "rbxassetid://" .. id
	end
	return id
end

local function checkSound(id: string)
	if soundState[id] then
		return
	end
	soundState[id] = "checking"
	task.spawn(function()
		local probe = Instance.new("Sound")
		probe.SoundId = id
		local good = true
		local ok = pcall(function()
			ContentProvider:PreloadAsync({ probe }, function(_, status)
				if status ~= Enum.AssetFetchStatus.Success then
					good = false
				end
			end)
		end)
		probe:Destroy()
		if ok and not good then
			soundState[id] = "bad"
			warnOnce("sound" .. id, "the sound " .. id .. " did not load, so it is switched off (put your own id in EventFX.Sounds)")
		else
			soundState[id] = "ok"
		end
	end)
end

-- Plays one of FX.Sounds by name. at = a spot in the world or a part (nil = heard everywhere the same).
-- volume / speed multiply that sound's own Volume / Speed. Returns the Sound (or nil when it is off).
function FX.Sound(name: string, at: (Vector3 | Instance)?, volume: number?, speed: number?): Sound?
	if not FX.Settings.Sounds then
		return nil
	end
	local entry = (FX.Sounds :: any)[name]
	if type(entry) ~= "table" then
		return nil
	end
	local id = soundId(entry.Id)
	if id == "" then
		return nil
	end
	local state = soundState[id]
	if state ~= "ok" then
		checkSound(id)
		return nil
	end
	local sound = Instance.new("Sound")
	sound.Name = name
	sound.SoundId = id
	sound.Volume = math.clamp((tonumber(entry.Volume) or 1) * (volume or 1) * FX.Settings.Volume, 0, 4)
	sound.PlaybackSpeed = math.clamp((tonumber(entry.Speed) or 1) * (speed or 1), 0.1, 4)
	sound.RollOffMinDistance = 14
	sound.RollOffMaxDistance = 220
	if typeof(at) == "Vector3" then
		sound.Parent = FX.Point(at, 8)
	elseif typeof(at) == "Instance" then
		sound.Parent = at
	else
		sound.Parent = SoundService
	end
	sound:Play()
	Debris:AddItem(sound, 8)
	return sound
end

-- test every sound once, in the background, so the first one an event needs is ready
task.spawn(function()
	for _, entry in FX.Sounds :: any do
		local id = soundId(entry.Id)
		if id ~= "" then
			checkSound(id)
		end
	end
end)

---------------------------------------------------------------------
-- Ready-made effects
---------------------------------------------------------------------

-- A warning circle on the ground that FILLS UP over `seconds` (when it is full, the thing happens). Removes itself.
function FX.WarnDisc(parent: Instance?, position: Vector3, radius: number, seconds: number, color: Color3?): Model
	local model = Instance.new("Model")
	model.Name = "Warning"
	local c = color or Colors.Warn
	local edge = FX.Disc(model, radius, position, c, 0.8)
	local fill = FX.Disc(model, 0.3, position + Vector3.new(0, 0.04, 0), c, 0.45)
	FX.Tween(edge, { Transparency = 0.55 }, 0.25, "Sine", "InOut", -1, true)
	FX.Tween(fill, { Size = Vector3.new(fill.Size.X, radius * 2, radius * 2) }, math.max(seconds, 0.05), "Linear")
	model.Parent = parent or FX.Folder()
	Debris:AddItem(model, seconds + 0.05)
	return model
end

-- A warning strip on the ground from a to b that fills up (gets wider) over `seconds`. Removes itself.
function FX.WarnStrip(parent: Instance?, a: Vector3, b: Vector3, width: number, seconds: number, color: Color3?): Model
	local model = Instance.new("Model")
	model.Name = "Warning"
	local c = color or Colors.Warn
	local edge = FX.Strip(model, a, b, width, c, 0.82)
	local lift = Vector3.new(0, 0.04, 0)
	local fill = FX.Strip(model, a + lift, b + lift, 0.3, c, 0.45)
	FX.Tween(edge, { Transparency = 0.6 }, 0.25, "Sine", "InOut", -1, true)
	FX.Tween(fill, { Size = Vector3.new(width, fill.Size.Y, fill.Size.Z) }, math.max(seconds, 0.05), "Linear")
	model.Parent = parent or FX.Folder()
	Debris:AddItem(model, seconds + 0.05)
	return model
end

-- A flat shockwave that spreads along the ground and fades
function FX.Ring(position: Vector3, fromRadius: number, toRadius: number, seconds: number, color: Color3?, parent: Instance?)
	local disc = FX.Disc(parent or FX.Folder(), fromRadius, position, color or Colors.White, 0.4, 0.25)
	disc.Name = "Ring"
	FX.Tween(disc, { Size = Vector3.new(disc.Size.X, toRadius * 2, toRadius * 2), Transparency = 1 }, seconds, "Quad", "Out")
	Debris:AddItem(disc, seconds + 0.1)
end

export type Hoop = { Set: (center: Vector3, radius: number, width: number?, height: number?) -> (), Look: (color: Color3, transparency: number?) -> (), Destroy: () -> () }

-- A real ring (a circle of segments) you can resize every frame: hoop.Set(center, radius, width, height)
function FX.Hoop(parent: Instance?, color: Color3, segments: number?, transparency: number?): Hoop
	local n = segments or 28
	local parts: { Part } = {}
	for i = 1, n do
		parts[i] = FX.Block(parent, Vector3.new(1, 1, 1), CFrame.new(0, -500, 0), color, Enum.Material.Neon, transparency or 0.15)
		parts[i].Name = "Hoop"
	end
	return {
		Set = function(center: Vector3, radius: number, width: number?, height: number?)
			local w, h = width or 1.2, height or 0.6
			local r = math.max(radius, 0.1)
			local length = math.max(2 * math.pi * r / n * 1.1, 0.05)
			local lift = Vector3.new(0, h / 2, 0)
			for i, part in parts do
				local angle = (i / n) * math.pi * 2
				local dir = Vector3.new(math.cos(angle), 0, math.sin(angle))
				part.Size = Vector3.new(length, h, w)
				part.CFrame = CFrame.lookAt(center + dir * r + lift, center + dir * (r + 1) + lift)
			end
		end,
		Look = function(newColor: Color3, newTransparency: number?)
			for _, part in parts do
				part.Color = newColor
				if newTransparency then
					part.Transparency = newTransparency
				end
			end
		end,
		Destroy = function()
			for _, part in parts do
				part:Destroy()
			end
			table.clear(parts)
		end,
	}
end

function FX.Sparks(position: Vector3, color: Color3?, count: number?, scale: number?)
	FX.Burst(position, "Spark", count or 16, { Color = color or Colors.Gold, Scale = scale or 1 })
end

-- a soft puff (something appears / vanishes)
function FX.Poof(position: Vector3, color: Color3?, size: number?)
	local s = size or 1
	FX.Burst(position, "Glow", 8, { Color = color or Colors.White, Scale = s })
	FX.Burst(position, "Star", 8, { Color = color or Colors.White, Scale = s })
end

function FX.Splash(position: Vector3, color: Color3?, size: number?)
	local s = size or 1
	FX.Burst(position, "Drop", 18, { Color = color or Colors.Ghost, Scale = s })
	FX.Ring(position, 0.5, 4 * s, 0.4, color or Colors.Ghost)
end

-- A bang: flash ball, sparks, smoke, a ring on the ground, light, sound and camera shake (by distance).
-- size = about how many studs wide. opts: Power (camera, default by size), Sound (a name in FX.Sounds, or false),
-- Smoke (false = none), Ring (false = none).
function FX.Boom(position: Vector3, size: number, color: Color3?, opts: Props?)
	local c = color or Colors.Orange
	local o: Props = opts or {}
	local parent = FX.Folder()
	local ball = FX.Ball(parent, size * 0.5, position, c:Lerp(Color3.new(1, 1, 1), 0.5), Enum.Material.Neon, if FX.Off("DisableFlashing") then 0.6 else 0.1)
	ball.Name = "Boom"
	FX.Tween(ball, { Size = Vector3.new(size * 1.7, size * 1.7, size * 1.7), Transparency = 1 }, 0.32, "Quad", "Out")
	Debris:AddItem(ball, 0.4)
	FX.Burst(position, "Spark", 14 + size * 2, { Color = c, Scale = math.clamp(size / 6, 0.6, 2.2) })
	if o.Smoke ~= false then
		FX.Burst(position, "Smoke", 6 + size * 0.5, { Color = Color3.fromRGB(60, 54, 60), Scale = math.clamp(size / 7, 0.6, 2.4) })
	end
	if o.Ring ~= false then
		FX.Ring(position, size * 0.2, size * 1.2, 0.45, c)
	end
	FX.Glint(position, c, size * 4, 5, 0.4)
	if o.Sound ~= false then
		FX.Sound(if type(o.Sound) == "string" then o.Sound else "Boom", position, math.clamp(size / 8, 0.5, 1.6))
	end
	FX.Punch(position, tonumber(o.Power) or math.clamp(size / 10, 0.4, 2))
end

-- A jagged bolt from a to b that fades
function FX.Lightning(a: Vector3, b: Vector3, color: Color3?, thickness: number?, seconds: number?, jag: number?)
	local c = color or Colors.White
	local life = seconds or 0.35
	local wobble = jag or 2.5
	local model = Instance.new("Model")
	model.Name = "Bolt"
	local points: { Vector3 } = { a }
	local n = math.clamp(math.floor((b - a).Magnitude / 6), 3, 14)
	for i = 1, n - 1 do
		local p = a:Lerp(b, i / n)
		table.insert(points, p + Vector3.new((math.random() - 0.5) * 2 * wobble, (math.random() - 0.5) * wobble, (math.random() - 0.5) * 2 * wobble))
	end
	table.insert(points, b)
	local soft = FX.Off("DisableFlashing")
	for i = 1, #points - 1 do
		local segment = FX.Line(model, points[i], points[i + 1], thickness or 0.6, c, Enum.Material.Neon, if soft then 0.6 else 0)
		FX.Tween(segment, { Transparency = 1 }, life, "Quad", "In")
	end
	model.Parent = FX.Folder()
	Debris:AddItem(model, life + 0.1)
	FX.Glint(b, c, 34, 5, 0.3)
end

---------------------------------------------------------------------
-- Flying bits (debris, confetti, coins): real little parts that fly, spin, fall and fade
---------------------------------------------------------------------

type Chunk = { Part: BasePart, Position: Vector3, Velocity: Vector3, Axis: Vector3, Spin: number, Angle: number, Age: number, Life: number, Gravity: number, Base: number, Drag: number }
local chunks: { Chunk } = {}
local needStepper: () -> ()

-- Throws `count` bits out from a spot. color = a Color3 or a list of them.
-- opts: Size 0.7, Speed 22 (sideways), Up 26, Life 1.4, Gravity 120, Spread 0.5 (how far apart they start),
--       Material, Shape ("Block" / "Ball"), Flat (true = thin squares, for confetti), Drag 0, Neon (true = glowing)
function FX.Chunks(position: Vector3, count: number, color: any, opts: Props?)
	local o: Props = opts or {}
	local amount = math.floor(if FX.Off("DisableParticles") then math.ceil(count / 3) else count)
	local parent = FX.Folder()
	local size: number = o.Size or 0.7
	local material: Enum.Material = o.Material or (if o.Neon then Enum.Material.Neon else Enum.Material.SmoothPlastic)
	for _ = 1, amount do
		if #chunks >= FX.Settings.MaxChunks then
			local oldest = table.remove(chunks, 1)
			if oldest then
				oldest.Part:Destroy()
			end
		end
		local c: Color3 = if typeof(color) == "Color3" then color else color[math.random(1, #color)]
		local s = size * (0.6 + math.random() * 0.8)
		local dims = if o.Flat then Vector3.new(s, s * 0.12, s) else Vector3.new(s, s, s)
		local spread: number = o.Spread or 0.5
		local start = position + Vector3.new((math.random() - 0.5) * 2 * spread, math.random() * spread, (math.random() - 0.5) * 2 * spread)
		local part: BasePart
		if o.Shape == "Ball" then
			part = FX.Ball(parent, s, start, c, material, 0)
		else
			part = FX.Block(parent, dims, CFrame.new(start), c, material, 0)
		end
		part.Name = "Chunk"
		local sideways = FX.RandomDir() * ((o.Speed or 22) * (0.35 + math.random() * 0.65))
		local axis = Vector3.new(math.random() - 0.5, math.random() - 0.5, math.random() - 0.5)
		table.insert(chunks, {
			Part = part, Position = start, Velocity = sideways + Vector3.new(0, (o.Up or 26) * (0.5 + math.random() * 0.5), 0),
			Axis = if axis.Magnitude > 0.01 then axis.Unit else Vector3.new(0, 1, 0), Spin = 4 + math.random() * 10, Angle = math.random() * 6,
			Age = 0, Life = (o.Life or 1.4) * (0.75 + math.random() * 0.5), Gravity = o.Gravity or 120, Base = 0, Drag = o.Drag or 0,
		})
	end
	if #chunks > 0 then
		needStepper()
	end
end

local CONFETTI = { Color3.fromRGB(255, 90, 110), Color3.fromRGB(255, 200, 60), Color3.fromRGB(120, 210, 120), Color3.fromRGB(110, 170, 255), Color3.fromRGB(200, 120, 255), Color3.fromRGB(245, 240, 240) }
function FX.Confetti(position: Vector3, count: number?)
	FX.Chunks(position, count or 24, CONFETTI, { Size = 0.6, Speed = 16, Up = 30, Life = 2.4, Gravity = 38, Flat = true, Drag = 1.2 })
end

local function stepChunks(dt: number)
	for index = #chunks, 1, -1 do
		local chunk = chunks[index]
		chunk.Age += dt
		if chunk.Age >= chunk.Life or not chunk.Part.Parent then
			chunk.Part:Destroy()
			table.remove(chunks, index)
		else
			local velocity = chunk.Velocity + Vector3.new(0, -chunk.Gravity * dt, 0)
			if chunk.Drag > 0 then
				velocity = velocity * math.max(1 - chunk.Drag * dt, 0)
			end
			chunk.Velocity = velocity
			chunk.Position += velocity * dt
			chunk.Angle += chunk.Spin * dt
			chunk.Part.CFrame = CFrame.new(chunk.Position) * CFrame.fromAxisAngle(chunk.Axis, chunk.Angle)
			local left = 1 - chunk.Age / chunk.Life
			if left < 0.3 then
				chunk.Part.Transparency = 1 - left / 0.3
			end
		end
	end
end

---------------------------------------------------------------------
-- Players
---------------------------------------------------------------------

function FX.Player(userId: number): Player?
	return Players:GetPlayerByUserId(userId)
end

-- that player's HumanoidRootPart (nil when they have no character right now)
function FX.Root(userId: number): BasePart?
	local player = Players:GetPlayerByUserId(userId)
	local character = player and player.Character
	local root = character and character:FindFirstChild("HumanoidRootPart")
	if root and root:IsA("BasePart") then
		return root
	end
	return nil
end

-- where that player's feet are
function FX.Feet(userId: number): Vector3?
	local root = FX.Root(userId)
	if not root then
		return nil
	end
	local humanoid = root.Parent and root.Parent:FindFirstChildOfClass("Humanoid")
	if humanoid and humanoid.RigType == Enum.HumanoidRigType.R15 then
		return root.Position - Vector3.new(0, root.Size.Y / 2 + humanoid.HipHeight, 0)
	end
	return root.Position - Vector3.new(0, 3, 0)
end

function FX.IsMe(userId: number): boolean
	return userId == localPlayer.UserId
end

function FX.MyRoot(): BasePart?
	return FX.Root(localPlayer.UserId)
end

-- everyone who is alive in the round right now: { { Player, root } }
function FX.AliveRoots(): { { Player: Player, Root: BasePart } }
	local list = {}
	for _, player in Players:GetPlayers() do
		if player:GetAttribute("Alive") == true then
			local root = FX.Root(player.UserId)
			if root then
				table.insert(list, { Player = player, Root = root })
			end
		end
	end
	return list
end

-- the first instance the server marked with K.Tag (nil until it has arrived on this client)
function FX.Tagged(tag: any): Instance?
	if type(tag) ~= "string" or tag == "" then
		return nil
	end
	return CollectionService:GetTagged(tag)[1]
end

---------------------------------------------------------------------
-- Followers: something the SERVER steers (a snake, a zombie). The server reports where it is a few times
-- a second; follower.Push(position, heading) takes a report and follower.Step(dt) gives a smooth position.
---------------------------------------------------------------------

export type Follower = { Push: (position: Vector3, heading: Vector3?) -> (), Step: (dt: number) -> (Vector3, Vector3), Snap: (position: Vector3, heading: Vector3?) -> () }

function FX.Follower(position: Vector3, heading: Vector3?, stiffness: number?): Follower
	local current, target = position, position
	local dir = FX.Dir(heading or Vector3.new(0, 0, -1))
	local targetDir = dir
	local velocity = Vector3.new(0, 0, 0)
	local lastPush = os.clock()
	local k = stiffness or 12
	local follower = {}
	function follower.Snap(p: Vector3, h: Vector3?)
		current, target, velocity = p, p, Vector3.new(0, 0, 0)
		if h then
			dir = FX.Dir(h, dir)
			targetDir = dir
		end
		lastPush = os.clock()
	end
	function follower.Push(p: Vector3, h: Vector3?)
		local now = os.clock()
		local gap = now - lastPush
		if (p - current).Magnitude > 45 then
			follower.Snap(p, h)
			return
		end
		velocity = if gap > 0.02 and gap < 1 then (p - target) / gap else Vector3.new(0, 0, 0)
		target = p
		lastPush = now
		if h then
			targetDir = FX.Dir(h, targetDir)
		end
	end
	function follower.Step(dt: number): (Vector3, Vector3)
		local ahead = math.min(os.clock() - lastPush, 0.25)
		local goal = target + velocity * ahead
		local a = 1 - math.exp(-k * dt)
		current = current:Lerp(goal, a)
		dir = FX.Dir(dir:Lerp(targetDir, a), targetDir)
		return current, dir
	end
	return follower
end

---------------------------------------------------------------------
-- Ready-made shapes (added to a rig; `at` is where it sits in the rig, -Z is its front)
---------------------------------------------------------------------

function Rig.Resize(self: Rig, name: string, size: Vector3)
	local item = self.ByName[name]
	if item then
		item.Size = size
		item.Part.Size = safeSize(size * self.Scale)
	end
end

-- a bone from a to b (a shaft with two knobs on each end)
function FX.AddBone(rig: Rig, name: string, a: Vector3, b: Vector3, thickness: number, color: Color3?)
	local c = color or Colors.Bone
	if (b - a).Magnitude < 0.1 then
		b = a + Vector3.new(0, 0.1, 0)
	end
	local offset = b - a
	local length = offset.Magnitude
	local up = if math.abs(offset.Unit.Y) > 0.98 then Vector3.new(1, 0, 0) else Vector3.new(0, 1, 0)
	local frame = CFrame.lookAt((a + b) / 2, b, up) * CFrame.Angles(-math.pi / 2, 0, 0) -- Y runs along the bone
	rig:Cyl(name, thickness, length, frame, c)
	for _, tip in { -1, 1 } do
		for _, side in { -1, 1 } do
			rig:Ball(name .. "Knob", thickness * 1.15, frame * Vector3.new(side * thickness * 0.42, tip * length / 2, 0), c)
		end
	end
end

-- a skull. Parts: <name>, <name>Jaw (pose it to chomp), <name>EyeL / EyeR. eyeColor = glowing eyes.
function FX.AddSkull(rig: Rig, name: string, at: CFrame, size: number, color: Color3?, eyeColor: Color3?)
	local c = color or Colors.Bone
	rig:Add(FX.Ball(rig.Parent, size, at.Position, c), at, name)
	rig:Block(name .. "Jaw", Vector3.new(size * 0.62, size * 0.3, size * 0.62), at * CFrame.new(0, -size * 0.46, -size * 0.1), c)
	for _, side in { -1, 1 } do
		local eye = rig:Add(FX.Ball(rig.Parent, size * 0.26, at.Position, eyeColor or Colors.Black, if eyeColor then Enum.Material.Neon else nil),
			at * CFrame.new(side * size * 0.2, size * 0.05, -size * 0.4), name .. (if side < 0 then "EyeL" else "EyeR"))
		eye.Name = name .. (if side < 0 then "EyeL" else "EyeR")
	end
	rig:Block(name .. "Nose", Vector3.new(size * 0.1, size * 0.14, size * 0.06), at * CFrame.new(0, -size * 0.12, -size * 0.48), Colors.Black)
	for i = -1, 1 do
		rig:Block(name .. "Tooth", Vector3.new(size * 0.14, size * 0.14, size * 0.06), at * CFrame.new(i * size * 0.17, -size * 0.3, -size * 0.42), Colors.White)
	end
end

-- a ghost. Parts: <name> (body), <name>Tail1..3, <name>ArmL / ArmR.
function FX.AddGhost(rig: Rig, name: string, at: CFrame, size: number, color: Color3?, transparency: number?)
	local c = color or Colors.White
	local tr = transparency or 0.25
	local neon = Enum.Material.Neon
	rig:Egg(name, Vector3.new(size, size * 1.15, size), at, c, neon, tr)
	rig:Egg(name .. "Tail1", Vector3.new(size * 0.8, size * 0.8, size * 0.8), at * CFrame.new(0, -size * 0.55, size * 0.12), c, neon, math.min(tr + 0.08, 0.95))
	rig:Egg(name .. "Tail2", Vector3.new(size * 0.55, size * 0.6, size * 0.55), at * CFrame.new(0, -size * 0.95, size * 0.3), c, neon, math.min(tr + 0.16, 0.95))
	rig:Egg(name .. "Tail3", Vector3.new(size * 0.3, size * 0.4, size * 0.3), at * CFrame.new(0, -size * 1.25, size * 0.5), c, neon, math.min(tr + 0.25, 0.95))
	for _, side in { -1, 1 } do
		rig:Egg(name .. "Eye", Vector3.new(size * 0.14, size * 0.22, size * 0.1), at * CFrame.new(side * size * 0.19, size * 0.12, -size * 0.45), Colors.Black)
		rig:Egg(name .. (if side < 0 then "ArmL" else "ArmR"), Vector3.new(size * 0.3, size * 0.22, size * 0.22), at * CFrame.new(side * size * 0.55, -size * 0.05, -size * 0.05), c, neon, tr)
	end
	rig:Egg(name .. "Mouth", Vector3.new(size * 0.16, size * 0.2, size * 0.1), at * CFrame.new(0, -size * 0.14, -size * 0.46), Colors.Black)
end

-- a bat. FX.FlapBat(rig, name, at, size, angle) moves its wings.
function FX.AddBat(rig: Rig, name: string, at: CFrame, size: number)
	local wing = Color3.fromRGB(44, 30, 52)
	rig:Egg(name, Vector3.new(size * 0.5, size * 0.6, size * 0.5), at, Colors.Black)
	for _, side in { -1, 1 } do
		rig:Block(name .. "Ear", Vector3.new(size * 0.12, size * 0.24, size * 0.08), at * CFrame.new(side * size * 0.14, size * 0.36, 0) * CFrame.Angles(0, 0, side * -0.3), Colors.Black)
		rig:Block(name .. (if side < 0 then "WingL" else "WingR"), Vector3.new(size * 0.9, size * 0.06, size * 0.5), at * CFrame.new(side * size * 0.65, size * 0.05, 0), wing)
		rig:Add(FX.Ball(rig.Parent, size * 0.1, at.Position, Colors.Warn, Enum.Material.Neon), at * CFrame.new(side * size * 0.1, size * 0.1, -size * 0.22), name .. "Eye")
	end
end

-- angle: 0 = wings flat, + = up
function FX.FlapBat(rig: Rig, name: string, at: CFrame, size: number, angle: number)
	for _, side in { -1, 1 } do
		rig:Pose(name .. (if side < 0 then "WingL" else "WingR"), at * CFrame.new(side * size * 0.2, size * 0.05, 0) * CFrame.Angles(0, 0, side * angle) * CFrame.new(side * size * 0.45, 0, 0))
	end
end

-- a jack-o'-lantern (front = -Z). lit = glowing face with a light inside.
function FX.AddPumpkin(rig: Rig, name: string, at: CFrame, size: number, lit: boolean?)
	local orange = Colors.Orange
	local rib = orange:Lerp(Colors.Black, 0.14)
	local body = rig:Egg(name, Vector3.new(size, size * 0.82, size), at, orange)
	rig:Egg(name .. "RibL", Vector3.new(size * 0.62, size * 0.86, size * 1.02), at * CFrame.new(-size * 0.24, 0, 0), rib)
	rig:Egg(name .. "RibR", Vector3.new(size * 0.62, size * 0.86, size * 1.02), at * CFrame.new(size * 0.24, 0, 0), rib)
	rig:Cyl(name .. "Stem", size * 0.16, size * 0.3, at * CFrame.new(0, size * 0.48, 0) * CFrame.Angles(0, 0, 0.25), Color3.fromRGB(70, 110, 50))
	local face = if lit then Color3.fromRGB(255, 214, 96) else Colors.Black
	local material = if lit then Enum.Material.Neon else Enum.Material.SmoothPlastic
	for _, side in { -1, 1 } do
		rig:Block(name .. "Eye", Vector3.new(size * 0.2, size * 0.2, size * 0.08), at * CFrame.new(side * size * 0.22, size * 0.1, -size * 0.47) * CFrame.Angles(0, 0, math.rad(45)), face, material)
	end
	for i = -1, 1 do
		rig:Block(name .. "Mouth", Vector3.new(size * 0.2, size * 0.12, size * 0.08), at * CFrame.new(i * size * 0.19, -size * 0.16 - (if i == 0 then size * 0.05 else 0), -size * 0.46), face, material)
	end
	if lit then
		FX.Light(body, orange, size * 6, 2)
	end
end

-- a flame (two glowing eggs standing on `at`). FX.Flicker(rig, name, size, t, seed) makes it dance.
function FX.AddFlame(rig: Rig, name: string, at: CFrame, size: number, color: Color3?)
	local c = color or Colors.Orange
	rig:Egg(name .. "Outer", Vector3.new(size, size * 2, size), at * CFrame.new(0, size, 0), c, Enum.Material.Neon, 0.35)
	rig:Egg(name .. "Inner", Vector3.new(size * 0.6, size * 1.3, size * 0.6), at * CFrame.new(0, size * 0.7, 0), c:Lerp(Color3.new(1, 1, 1), 0.6), Enum.Material.Neon, 0.15)
end

function FX.Flicker(rig: Rig, name: string, size: number, t: number, seed: number)
	local tall = 1 + FX.Noise(seed, t * 3.1) * 0.28
	local wide = 1 + FX.Noise(seed + 7, t * 4.3) * 0.18
	rig:Resize(name .. "Outer", Vector3.new(size * wide, size * 2 * tall, size * wide))
	rig:Resize(name .. "Inner", Vector3.new(size * 0.6 * wide, size * 1.3 * tall, size * 0.6 * wide))
end

---------------------------------------------------------------------
-- Animated rigs: a Model with Motor6D joints (an R6 character, your Vampiette) playing animations YOU uploaded.
--
-- ids = the list at the top of an event's client module, one line per animation:
--       local ANIMATIONS = { Walk = 1234567890, Lunge = 0 }
--   a number (or "rbxassetid://...") = the id Roblox gave you when you uploaded that animation. It has to be
--       uploaded by the OWNER of this game (you, or the group), or Roblox refuses to play it.
--   0 = not uploaded yet. In STUDIO the KeyframeSequence with that name in the module's own "Animations"
--       folder is then played directly, so you can watch an animation before you upload it.
--       In the real game an animation with no id does not play.
---------------------------------------------------------------------

export type Actor = {
	Model: Model,
	Root: BasePart,
	Animated: boolean,                                                                    -- at least one animation is there to play
	Place: (cframe: CFrame) -> (),                                                        -- where its ROOT part is
	Has: (name: string) -> boolean,
	Play: (name: string, fade: number?, speed: number?, at: number?) -> AnimationTrack?,  -- at = start (again) from that many seconds in
	Stop: (name: string?, fade: number?) -> (),                                           -- no name = every animation
	Seek: (name: string, at: number, fade: number?) -> (),                                -- hold it at that moment (call every frame to drive it by the clock)
	Playing: (name: string) -> boolean,
	Part: (name: string) -> BasePart?,
}

local registered: { [Instance]: string } = setmetatable({}, { __mode = "k" }) :: any
local previews: { [string]: boolean } = {}   -- ids that are Studio previews (not uploads)
local previewBroken = false                    -- this Studio would not play a KeyframeSequence directly: stop trying
local toldAbout: { [string]: boolean } = {}

-- Studio only: an id that plays a KeyframeSequence straight from the Explorer (nil when Studio will not give one)
local function previewId(sequence: Instance): string?
	local provider: any = game:GetService("KeyframeSequenceProvider")
	local plain: string? = nil
	for _, method in { "RegisterKeyframeSequence", "RegisterActiveKeyframeSequence" } do
		local ok, result = pcall(function(): any
			return provider[method](provider, sequence)
		end)
		if ok and type(result) == "string" and result ~= "" then
			if string.find(result, "://", 1, true) then
				return result
			end
			plain = plain or result -- (not a full address: kept only if nothing better comes)
		end
	end
	return plain
end

-- The "Animations" folders an event's module can keep its animations in: inside the module itself, or next to it
-- (ReplicatedStorage > EventClients > Animations). Sub-folders are fine.
local function animationFolders(source: Instance?): { Instance }
	local folders: { Instance } = {}
	if source then
		local inside = source:FindFirstChild("Animations")
		if inside then
			table.insert(folders, inside)
		end
		local parent = source.Parent
		local beside = parent and parent:FindFirstChild("Animations")
		if beside then
			table.insert(folders, beside)
		end
	end
	return folders
end

local function plainName(name: string): string
	return (string.lower(name):gsub("[%s_%-]", ""))
end

-- the Animation (uploaded, has an id) and / or KeyframeSequence called `name` in those folders (capitals and spaces do not matter)
local function findAnimation(folders: { Instance }, name: string): (Animation?, KeyframeSequence?)
	local want = plainName(name)
	local animation: Animation? = nil
	local sequence: KeyframeSequence? = nil
	for _, folder in folders do
		for _, item in folder:GetDescendants() do
			if plainName(item.Name) == want then
				if item:IsA("Animation") and not animation then
					animation = item
				elseif item:IsA("KeyframeSequence") and not sequence then
					sequence = item
				end
			end
		end
	end
	return animation, sequence
end

-- what to play for each animation name: { Walk = "rbxassetid://123", ... } (a name that cannot play is left out).
-- An animation is taken from, in this order: the id in `ids`; an Animation object with that name (and an
-- AnimationId) in an Animations folder; in Studio only, a KeyframeSequence with that name in an Animations folder.
function FX.Animations(ids: { [string]: any }?, source: Instance?): { [string]: string }
	local found: { [string]: string } = {}
	if type(ids) ~= "table" then
		return found
	end
	local uploaded: { string }, preview: { string }, missing: { string } = {}, {}, {}
	local folders = animationFolders(source)
	for name, value in ids do
		local id: string? = nil
		if type(value) == "number" and value > 0 then
			id = "rbxassetid://" .. string.format("%.0f", value)
		elseif type(value) == "string" and value ~= "" and value ~= "0" then
			id = if tonumber(value) then "rbxassetid://" .. value else value
		end
		local animation, sequence = findAnimation(folders, name)
		if not id and animation and animation.AnimationId ~= "" then
			id = animation.AnimationId -- (an Animation object you made from the upload)
		end
		if id then
			table.insert(uploaded, name)
		elseif RunService:IsStudio() and not previewBroken then
			if sequence then
				id = registered[sequence]
				if not id then
					id = previewId(sequence)
					if id then
						registered[sequence] = id
						previews[id] = true
					else
						warnOnce("register" .. name, "Studio would not preview the animation '" .. name .. "' (it will play once it is uploaded and its id is pasted in)")
					end
				end
			end
			table.insert(if id then preview else missing, name)
		else
			table.insert(missing, name)
		end
		if id then
			found[name] = id
		end
	end
	-- say once, in plain words, where each animation comes from
	local who = if source then source.Name else "?"
	if not toldAbout[who] then
		toldAbout[who] = true
		table.sort(uploaded)
		table.sort(preview)
		table.sort(missing)
		if #preview > 0 then
			print(("[EventFX] %s: playing %s straight from the KeyframeSequences in its Animations folder. That only works in STUDIO: upload them (right-click > Save to Roblox) and paste the ids at the top of the module for the real game."):format(who, table.concat(preview, ", ")))
		end
		if #missing > 0 then
			-- say what IS in the folders, so a wrong name or an empty AnimationId is easy to spot
			local seen: { string } = {}
			for _, folder in folders do
				for _, item in folder:GetDescendants() do
					if item:IsA("Animation") then
						table.insert(seen, item.Name .. (if item.AnimationId == "" then " (Animation with an EMPTY AnimationId)" else " (Animation)"))
					elseif item:IsA("KeyframeSequence") then
						table.insert(seen, item.Name .. " (KeyframeSequence)")
					end
				end
			end
			table.sort(seen)
			local why = "no id at the top of the module, and no Animation object with that name and an AnimationId in an Animations folder inside the module or next to it. "
				.. (if #folders == 0 then "No Animations folder was found" elseif #seen == 0 then "The Animations folder has no Animation in it" else "In the Animations folder: " .. table.concat(seen, ", "))
			if #uploaded + #preview == 0 then
				warn(("[EventFX] %s: none of its animations can play yet (%s: %s), so the built-in look is used."):format(who, table.concat(missing, ", "), why))
			else
				warn(("[EventFX] %s: no animation for %s (%s). Those moves are skipped."):format(who, table.concat(missing, ", "), why))
			end
		end
	end
	return found
end

-- Gets a rig ready to be animated and moved by its root: the root is anchored, everything joined to it follows,
-- nothing collides, and a Humanoid inside keeps quiet (no name, no health bar, no walking about).
-- Call it BEFORE the model goes into the workspace; the animations are loaded the first time one is played.
function FX.Actor(model: Model, ids: { [string]: any }?, source: Instance?): Actor
	local parts: { BasePart } = {}
	local links: { [BasePart]: { BasePart } } = {}
	local function link(a: BasePart?, b: BasePart?)
		if a and b then
			local la = links[a] or {}
			links[a] = la
			table.insert(la, b)
			local lb = links[b] or {}
			links[b] = lb
			table.insert(lb, a)
		end
	end
	local humanoid: Humanoid? = nil
	local controller: AnimationController? = nil
	for _, item in model:GetDescendants() do
		if item:IsA("BasePart") then
			table.insert(parts, item)
		elseif item:IsA("JointInstance") then
			link(item.Part0, item.Part1)
		elseif item:IsA("WeldConstraint") then
			link(item.Part0, item.Part1)
		elseif item:IsA("Humanoid") then
			humanoid = item
		elseif item:IsA("AnimationController") then
			controller = item
		elseif item:IsA("LuaSourceContainer") or item:IsA("ProximityPrompt") or item:IsA("ForceField") then
			item:Destroy()
		end
	end
	-- the root: the HumanoidRootPart when there is one (every other part of a character hangs from it)
	local root: BasePart? = nil
	local named = model:FindFirstChild("HumanoidRootPart", true)
	if named and named:IsA("BasePart") then
		root = named
	else
		root = model.PrimaryPart or parts[1]
	end
	if not root then
		-- (a model with no parts: nothing to move, nothing to animate)
		local empty = Instance.new("Part")
		empty.Name = "Root"
		empty.Anchored = true
		empty.Transparency = 1
		empty.CanCollide, empty.CanQuery, empty.CanTouch = false, false, false
		empty.Parent = model
		root = empty
		table.insert(parts, empty)
	end
	local rootPart: BasePart = root :: BasePart
	if humanoid then
		humanoid.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
		humanoid.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff
		humanoid.RequiresNeck = false
		humanoid.BreakJointsOnDeath = false
		-- (a Humanoid keeps making its torso and head solid again; with its own brain switched off it stops)
		pcall(function()
			(humanoid :: any).EvaluateStateMachine = false
		end)
	end
	-- which parts hang on the root through joints / welds (they follow it); the others are carried by hand
	local joined: { [BasePart]: boolean } = { [rootPart] = true }
	local queue: { BasePart } = { rootPart }
	while #queue > 0 do
		local part = table.remove(queue) :: BasePart
		local others: { BasePart } = links[part] or {}
		for _, other in others do
			if not joined[other] then
				joined[other] = true
				table.insert(queue, other)
			end
		end
	end
	local loose: { [BasePart]: CFrame } = {}
	for _, part in parts do
		part.CanCollide = false
		part.CanQuery = false
		part.CanTouch = false
		part.Massless = true
		if part == rootPart then
			part.Anchored = true
		elseif joined[part] then
			part.Anchored = false
		else
			part.Anchored = true
			loose[part] = rootPart.CFrame:ToObjectSpace(part.CFrame)
		end
	end

	local content = FX.Animations(ids, source)
	local tracks: { [string]: AnimationTrack } = {}
	local loaded = false
	local function load(): boolean
		if loaded then
			return true
		end
		if not model:IsDescendantOf(workspace) then
			return false -- (animations can only be loaded on a rig that is in the world)
		end
		loaded = true
		if next(content) == nil then
			return true
		end
		local host: Instance? = humanoid or controller
		if not host then
			local made = Instance.new("AnimationController")
			made.Parent = model
			host = made
		end
		local animator: Animator
		local existing = (host :: Instance):FindFirstChildOfClass("Animator")
		if existing then
			animator = existing
		else
			local made = Instance.new("Animator")
			made.Parent = host
			animator = made
		end
		for name, id in content do
			local animation = Instance.new("Animation")
			animation.Name = name
			animation.AnimationId = id
			local ok, track = pcall(function(): AnimationTrack
				return animator:LoadAnimation(animation)
			end)
			if ok and track then
				tracks[name] = track
			else
				warnOnce("load" .. id, "the animation '" .. name .. "' (" .. id .. ") could not be loaded: " .. tostring(track))
			end
		end
		-- an animation that is still empty after a while is not going to play
		task.delay(3, function()
			-- (a Studio preview is there at once, or never: if no track has any length AND no joint has been moved, it is not working)
			if previewBroken or not model.Parent then
				return
			end
			local empty: string? = nil
			for name, track in tracks do
				local id = content[name]
				if id and previews[id] then
					if track.Length > 0 then
						return
					end
					empty = empty or name
				end
			end
			if not empty then
				return
			end
			for _, item in model:GetDescendants() do
				if item:IsA("Motor6D") and item.Transform ~= CFrame.identity then
					return
				end
			end
			previewBroken = true
			warnOnce("preview", ("this Studio did not play the KeyframeSequence '%s' straight from the Animations folder (the id it gave was '%s'). The animations will show once they are uploaded and their ids are pasted in; until then the built-in look is used."):format(empty, tostring(content[empty])))
		end)
		task.delay(8, function()
			-- (an upload that Roblox refuses is nearly always one uploaded by somebody who does not own the game)
			for name, track in tracks do
				local id = content[name]
				if id and not previews[id] and track.Length <= 0 and model.Parent then
					warnOnce("empty" .. id, ("the animation '%s' (%s) did not load. Was it uploaded by the owner of this game (you or the group), and is the id right?"):format(name, id))
				end
			end
		end)
		return true
	end

	local found: { [string]: BasePart } = {}
	local actor: Actor
	actor = {
		Model = model,
		Root = rootPart,
		Animated = next(content) ~= nil,
		Place = function(cframe: CFrame)
			rootPart.CFrame = cframe
			for part, offset in loose do
				part.CFrame = cframe * offset
			end
		end,
		Has = function(name: string): boolean
			return content[name] ~= nil
		end,
		Play = function(name: string, fade: number?, speed: number?, at: number?): AnimationTrack?
			if not load() then
				return nil
			end
			local track = tracks[name]
			if not track then
				return nil
			end
			if not track.IsPlaying then
				track:Play(fade or 0.1, 1, speed or 1)
			elseif speed then
				track:AdjustSpeed(speed)
			end
			if at then
				track.TimePosition = at
			end
			return track
		end,
		Stop = function(name: string?, fade: number?)
			for trackName, track in tracks do
				if (name == nil or name == trackName) and track.IsPlaying then
					track:Stop(fade or 0.1)
				end
			end
		end,
		Seek = function(name: string, at: number, fade: number?)
			if not load() then
				return
			end
			local track = tracks[name]
			if not track then
				return
			end
			if not track.IsPlaying then
				track:Play(fade or 0.1, 1, 0)
			end
			track:AdjustSpeed(0)
			local length = track.Length
			track.TimePosition = if length > 0 then math.clamp(at, 0, length - 0.01) else math.max(at, 0)
		end,
		Playing = function(name: string): boolean
			local track: AnimationTrack? = tracks[name]
			return track ~= nil and track.IsPlaying
		end,
		Part = function(name: string): BasePart?
			local part = found[name]
			if part and part.Parent then
				return part
			end
			local item = model:FindFirstChild(name, true)
			if item and item:IsA("BasePart") then
				found[name] = item
				return item
			end
			return nil
		end,
	}
	return actor
end

-- Why a model can NOT play the R6 animations (nil = it can): it needs the six R6 body parts, each on a Motor6D.
local R6_PARTS = { "Torso", "Head", "Left Arm", "Right Arm", "Left Leg", "Right Leg" }
function FX.R6Problem(model: Instance): string?
	local onMotor: { [string]: boolean } = {}
	for _, item in model:GetDescendants() do
		if item:IsA("Motor6D") and item.Part0 and item.Part1 then
			onMotor[item.Part1.Name] = true
		end
	end
	local problem: string? = nil
	for _, name in R6_PARTS do
		local part = model:FindFirstChild(name, true)
		if not (part and part:IsA("BasePart")) then
			problem = "it has no part named '" .. name .. "' (the animations are made for R6 rigs)"
			break
		end
		if not onMotor[name] then
			problem = "its '" .. name .. "' does not hang on a Motor6D joint"
			break
		end
	end
	if problem and model:FindFirstChild("UpperTorso", true) then
		return "it is an R15 rig (it has an UpperTorso) and the animations are made for R6"
	end
	return problem
end

---------------------------------------------------------------------
-- Vampiette (Vampiette Says, Vampiette's Tantrum, Vampiette's Group Photo)
-- Uses YOUR model when it can find one: a Model named "Vampiette" or "Vampire" under the event's own script
-- (it is copied to ReplicatedStorage > EventAssets > <event id>), else the one from Vampiette's Shop
-- (EventAssets > vampmerchant > Vampire). No model = a stand-in built from parts.
-- An event that has uploaded animations for her (Vampiette's Tantrum) passes them in: they play when your
-- model is an R6 rig (Torso, Head, Left Arm, Right Arm, Left Leg, Right Leg, each on a Motor6D).
---------------------------------------------------------------------

FX.VampietteOptions = {
	Scale = 1.75,   -- how much bigger than the model she is shown (she has to be seen from across the arena)
	Yaw = 0,        -- degrees: turn her if she faces the wrong way (her front should be -Z)
	Raise = 0,      -- studs: lift her if her feet sink into the floor (or lower her with a negative number)
}

export type Vampiette = {
	Model: Instance,
	Custom: boolean,                                   -- true = your model, false = the stand-in
	Animated: boolean,                                 -- true = she is a jointed rig playing uploaded animations (see FX.Actor)
	Height: number,                                    -- feet to the top of her head
	Place: (cframe: CFrame) -> (),                     -- cframe = where her FEET are and which way she faces
	Arm: (side: string, pitch: number, roll: number?) -> (), -- "Left" / "Right"; pitch 0 = down, 1.57 = pointing forward, 3.14 = straight up (does nothing while Animated)
	Head: () -> Vector3,                               -- where her head is right now
	Feet: () -> CFrame,
	-- the animations (they do nothing, and Has says false, when she is not Animated):
	Has: (name: string) -> boolean,
	Play: (name: string, fade: number?, speed: number?, at: number?) -> AnimationTrack?,
	Stop: (name: string?, fade: number?) -> (),
	Seek: (name: string, at: number, fade: number?) -> (),
	Part: (name: string) -> BasePart?,                 -- one of her body parts ("Right Arm"), if her model has it
}

local function extentY(part: BasePart): number
	local cf, size = part.CFrame, part.Size
	return (math.abs(cf.RightVector.Y) * size.X + math.abs(cf.UpVector.Y) * size.Y + math.abs(cf.LookVector.Y) * size.Z) / 2
end

local function findVampietteModel(eventId: string?): Model?
	local assets = ReplicatedStorage:FindFirstChild("EventAssets")
	if not assets then
		return nil
	end
	local function named(container: Instance?): Model?
		if not container then
			return nil
		end
		for _, name in { "Vampiette", "Vampire" } do
			local found = container:FindFirstChild(name)
			if found and found:IsA("Model") then
				return found
			end
		end
		return nil
	end
	local model = named(eventId and assets:FindFirstChild(eventId)) or named(assets:FindFirstChild("vampmerchant"))
	if model then
		return model
	end
	for _, item in assets:GetDescendants() do
		if item:IsA("Model") and (item.Name == "Vampiette" or item.Name == "Vampire") then
			return item
		end
	end
	return nil
end

local function buildVampiette(parent: Instance): Rig
	local rig = FX.Rig(parent)
	local black, red, skin, white = Color3.fromRGB(24, 18, 26), Color3.fromRGB(170, 26, 48), Color3.fromRGB(242, 228, 228), Colors.White
	for _, side in { -1, 1 } do
		rig:Egg("Shoe", Vector3.new(0.7, 0.42, 1.05), CFrame.new(side * 0.45, 0.21, -0.1), red)
		rig:Cyl("Leg", 0.42, 1.3, CFrame.new(side * 0.45, 1, 0), black)
	end
	rig:Cyl("Frill", 3.15, 0.14, CFrame.new(0, 1.5, 0), white)
	rig:Cyl("Skirt1", 3, 0.5, CFrame.new(0, 1.78, 0), black)
	rig:Cyl("Skirt2", 2.5, 0.5, CFrame.new(0, 2.24, 0), red)
	rig:Cyl("Skirt3", 2, 0.5, CFrame.new(0, 2.7, 0), black)
	rig:Block("Torso", Vector3.new(1.5, 1.5, 0.9), CFrame.new(0, 3.55, 0), black)
	rig:Block("Bow", Vector3.new(0.5, 0.3, 0.12), CFrame.new(0, 3.95, -0.5), red)
	rig:Block("Collar", Vector3.new(1.1, 0.2, 0.96), CFrame.new(0, 4.3, 0), white)
	rig:Block("Cape", Vector3.new(2.3, 2.9, 0.15), CFrame.new(0, 3.2, 0.62), black)
	rig:Block("CapeInside", Vector3.new(2.1, 2.7, 0.06), CFrame.new(0, 3.2, 0.52), red)
	for _, side in { -1, 1 } do
		rig:Egg(if side < 0 then "Left Arm" else "Right Arm", Vector3.new(0.52, 1.7, 0.52), CFrame.new(side * 1.05, 3.5, 0), skin)
		rig:Wedge("CollarWing", Vector3.new(0.14, 0.8, 0.7), CFrame.new(side * 0.72, 4.65, 0.4) * CFrame.Angles(0, math.rad(180), 0), black)
		rig:Egg("Tail", Vector3.new(0.72, 1.9, 0.72), CFrame.new(side * 1.28, 4.65, 0.2) * CFrame.Angles(0, 0, side * math.rad(14)), black)
		rig:Ball("Ribbon", 0.46, Vector3.new(side * 1.05, 5.8, 0.1), red)
		rig:Add(FX.Ball(parent, 0.3, Vector3.new(), Color3.fromRGB(255, 70, 100), Enum.Material.Neon), CFrame.new(side * 0.38, 5.2, -0.8), "Eye")
		rig:Block("Fang", Vector3.new(0.1, 0.2, 0.08), CFrame.new(side * 0.15, 4.72, -0.84), white)
	end
	rig:Egg("Hair", Vector3.new(2.05, 1.95, 1.75), CFrame.new(0, 5.25, 0.25), black)
	rig:Ball("Head", 1.8, Vector3.new(0, 5.15, 0), skin)
	rig:Block("Fringe", Vector3.new(1.7, 0.45, 0.4), CFrame.new(0, 5.8, -0.72), black)
	rig:Block("Smile", Vector3.new(0.5, 0.08, 0.06), CFrame.new(0, 4.84, -0.86), red)
	return rig
end

local announcedVampiette = false
local announcedRig = false

-- Makes Vampiette inside `parent` (the visual's own instance, so she goes when it goes).
-- ids + source (optional) = the event's animation list and its module script (see FX.Actor): if YOUR model is an
-- R6 rig and at least one of the animations can play, she is animated by them (Animated = true) instead of
-- being moved as one frozen piece.
function FX.Vampiette(parent: Instance, eventId: string?, ids: { [string]: any }?, source: Instance?): Vampiette
	local options = FX.VampietteOptions
	local feet = CFrame.new()
	local arms: { [string]: { Pitch: number, Roll: number } } = { Left = { Pitch = 0, Roll = 0 }, Right = { Pitch = 0, Roll = 0 } }
	local original = findVampietteModel(eventId)
	local clone: Model? = nil
	if original then
		local ok, result = pcall(function()
			return original:Clone()
		end)
		if ok and result and result:IsA("Model") then
			clone = result
		end
	end

	if clone then
		local model: Model = clone
		-- can she play the animations? (only asked when the event has some)
		local problem: string? = nil
		local animate = false
		if ids ~= nil then
			problem = FX.R6Problem(model)
			if not problem then
				animate = next(FX.Animations(ids, source)) ~= nil
				if not animate then
					problem = "none of this event's animations can play yet (see the message about ids above)"
				end
			end
			if not announcedRig then
				announcedRig = true
				if animate then
					print("[EventFX] Vampiette: your model is an R6 rig, so she plays the uploaded animations")
				else
					warn("[EventFX] Vampiette: she is shown WITHOUT the uploaded animations (the built-in moves are used instead), because " .. tostring(problem))
				end
			end
		end
		for _, item in model:GetDescendants() do
			if item:IsA("BasePart") then
				item.Anchored = true
				item.CanCollide = false
				item.CanQuery = false
				item.CanTouch = false
			elseif item:IsA("LuaSourceContainer") or item:IsA("ProximityPrompt") then
				item:Destroy()
			elseif item:IsA("Humanoid") then
				item.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
				item.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff
			end
		end
		pcall(function()
			model:ScaleTo(model:GetScale() * options.Scale)
		end)
		-- stand her at the middle of the world, measure her, and remember where every part sits (so she can be
		-- put anywhere, any number of times, without the parts ever drifting apart)
		model:PivotTo(CFrame.new())
		local lowest, highest = math.huge, -math.huge
		local count = 0
		local sits: { [BasePart]: CFrame } = {}
		for _, item in model:GetDescendants() do
			if item:IsA("BasePart") then
				sits[item] = item.CFrame
				if item.Transparency < 0.99 then
					count += 1
					lowest = math.min(lowest, item.Position.Y - extentY(item))
					highest = math.max(highest, item.Position.Y + extentY(item))
				end
			end
		end
		if count == 0 then
			lowest, highest = -3, 3
		end
		local pivotAboveFeet = -lowest
		local height = highest - lowest
		local head = model:FindFirstChild("Head", true)
		local rest: { [string]: BasePart } = {}
		for _, side in { "Left", "Right" } do
			local arm = model:FindFirstChild(side .. " Arm", true)
			if arm and arm:IsA("BasePart") then
				rest[side] = arm
			end
		end
		if not announcedVampiette then
			announcedVampiette = true
			print(("[EventFX] Vampiette: using your model %s (%d parts, %.1f studs tall after scaling x%.2f, arms that can move: %s)"):format(
				original and original:GetFullName() or "?", count, height, options.Scale, if rest.Left and rest.Right then "yes" else "no (not R6 names)"))
		end
		local function headPosition(): Vector3
			if head and head:IsA("BasePart") then
				return head.Position
			end
			return (feet * CFrame.new(0, height * 0.88, 0)).Position
		end

		if animate then
			-- a jointed rig: only her root is placed, the joints (and the animations) do the rest
			local actor = FX.Actor(model, ids, source)
			local rootSit = sits[actor.Root] or CFrame.new()
			model.Parent = parent
			return {
				Model = model, Custom = true, Animated = true, Height = height,
				Place = function(cframe: CFrame)
					feet = cframe
					actor.Place(cframe * CFrame.Angles(0, math.rad(options.Yaw), 0) * CFrame.new(0, pivotAboveFeet + options.Raise, 0) * rootSit)
				end,
				Arm = function(_side: string, _pitch: number, _roll: number?) end,
				Head = headPosition,
				Feet = function(): CFrame
					return feet
				end,
				Has = actor.Has, Play = actor.Play, Stop = actor.Stop, Seek = actor.Seek, Part = actor.Part,
			}
		end

		model.Parent = parent
		return {
			Model = model, Custom = true, Animated = false, Height = height,
			Place = function(cframe: CFrame)
				feet = cframe
				local pivot = cframe * CFrame.Angles(0, math.rad(options.Yaw), 0) * CFrame.new(0, pivotAboveFeet + options.Raise, 0)
				for part, sit in sits do
					part.CFrame = pivot * sit
				end
				-- her arms turn about the shoulder (a quarter of the way down from the top of the arm)
				for side, arm in rest do
					local pose = arms[side]
					local shoulder = Vector3.new(0, arm.Size.Y * 0.25, 0)
					arm.CFrame = pivot * sits[arm] * CFrame.new(shoulder) * CFrame.Angles(pose.Pitch, 0, (if side == "Left" then -1 else 1) * pose.Roll) * CFrame.new(-shoulder)
				end
			end,
			Arm = function(side: string, pitch: number, roll: number?)
				local pose = arms[side]
				if pose then
					pose.Pitch, pose.Roll = pitch, roll or 0
				end
			end,
			Head = headPosition,
			Feet = function(): CFrame
				return feet
			end,
			Has = function(_name: string): boolean
				return false
			end,
			Play = function(_name: string, _fade: number?, _speed: number?, _at: number?): AnimationTrack?
				return nil
			end,
			Stop = function(_name: string?, _fade: number?) end,
			Seek = function(_name: string, _at: number, _fade: number?) end,
			Part = function(name: string): BasePart?
				local item = model:FindFirstChild(name, true)
				return if item and item:IsA("BasePart") then item else nil
			end,
		}
	end

	if not announcedVampiette then
		announcedVampiette = true
		print("[EventFX] Vampiette: no model named 'Vampiette' or 'Vampire' found in ReplicatedStorage > EventAssets, so a stand-in built from parts is shown")
	end
	if ids ~= nil and not announcedRig then
		announcedRig = true
		warn("[EventFX] Vampiette: the uploaded animations need YOUR Vampiette model (an R6 rig named 'Vampiette' or 'Vampire'). The stand-in uses its built-in moves.")
	end
	local holder = Instance.new("Model")
	holder.Name = "Vampiette"
	holder.Parent = parent
	local rig = buildVampiette(holder)
	local scale = options.Scale * 0.9
	local restArm: { [string]: CFrame } = { Left = rig:Offset("Left Arm"), Right = rig:Offset("Right Arm") }
	return {
		Model = holder, Custom = false, Animated = false, Height = 6.4 * scale,
		Place = function(cframe: CFrame)
			feet = cframe
			for side, base in restArm do
				local pose = arms[side]
				local shoulder = Vector3.new(0, 0.6, 0)
				rig:Pose(side .. " Arm", base * CFrame.new(shoulder) * CFrame.Angles(pose.Pitch, 0, (if side == "Left" then -1 else 1) * pose.Roll) * CFrame.new(-shoulder))
			end
			rig:Move(cframe * CFrame.new(0, options.Raise, 0), scale)
		end,
		Arm = function(side: string, pitch: number, roll: number?)
			local pose = arms[side]
			if pose then
				pose.Pitch, pose.Roll = pitch, roll or 0
			end
		end,
		Head = function(): Vector3
			return (feet * CFrame.new(0, 5.15 * scale, 0)).Position
		end,
		Feet = function(): CFrame
			return feet
		end,
		Has = function(_name: string): boolean
			return false
		end,
		Play = function(_name: string, _fade: number?, _speed: number?, _at: number?): AnimationTrack?
			return nil
		end,
		Stop = function(_name: string?, _fade: number?) end,
		Seek = function(_name: string, _at: number, _fade: number?) end,
		Part = function(_name: string): BasePart?
			return nil
		end,
	}
end

---------------------------------------------------------------------
-- FX.Module: how an event's client module plugs into your visuals framework (EventVisualsClient).
--
--   return FX.Module({
--       Rope = {                                   -- the asset name the server used in K.Show(context, "Rope", ...)
--           Init = function(self, props) ... end,  -- build it: put parts under self.Inst
--           Step = function(self, dt, t) ... end,  -- every frame (t = seconds since props.T0, same on every client)
--           Done = function(self) ... end,         -- it is going away (optional)
--           Hit = function(self, userId) ... end,  -- any other name: the server called K.Call / K.Signal(id, "Hit", ...)
--       },
--   })
--
-- self.Inst    the instance the framework made for this visual (everything under it goes when the visual goes)
-- self.Origin  the CFrame the server gave it          self.Props  the plain values the server sent
-- self:Time()  seconds since props.T0 (server clock)  self.Alive  false once it has been removed
-- self:After(seconds, fn) / self:At(serverTime, fn)   run fn later, only if the visual is still there
-- self:Keep(x)  something else to clean up with it (an Instance, a connection, or a function)
-- Screen effects that undo themselves if the visual is removed early:
-- self:Vignette / self:VignetteOff / self:FOV / self:FOVReset / self:Tint() / self:Rumble(...)
---------------------------------------------------------------------

local Visual = {}
Visual.__index = Visual

local stepping: { any } = {}
local stepConnection: RBXScriptConnection? = nil

local function trace(err: any): string
	return debug.traceback(tostring(err), 2)
end

local function run(self: any, what: string, fn: any, ...: any): boolean
	local ok, err = xpcall(fn, trace, ...)
	if not ok then
		warnOnce(tostring(self.Asset) .. what, "the '" .. tostring(self.Asset) .. "' visual failed in " .. what .. ": " .. tostring(err))
	end
	return ok
end

local function stopStepperIfIdle()
	local connection = stepConnection
	if connection and #stepping == 0 and #chunks == 0 then
		connection:Disconnect()
		stepConnection = nil
	end
end

needStepper = function()
	if stepConnection then
		return
	end
	stepConnection = RunService.RenderStepped:Connect(function(frame: number)
		local dt = math.min(frame, 0.1)
		for index = #stepping, 1, -1 do
			local self = stepping[index]
			if not self.Alive then
				table.remove(stepping, index)
			elseif not run(self, "Step", self.Def.Step, self, dt, FX.Now() - self.T0) then
				table.remove(stepping, index) -- (an error in Step: stop calling it, keep the rest alive)
			end
		end
		stepChunks(dt)
		stopStepperIfIdle()
	end)
end

function Visual.Time(self: any): number
	return FX.Now() - self.T0
end

function Visual.After(self: any, seconds: number, fn: () -> ())
	task.delay(math.max(seconds, 0), function()
		if self.Alive then
			run(self, "a delayed step", fn)
		end
	end)
end

function Visual.At(self: any, serverTime: number, fn: () -> ())
	self:After(serverTime - FX.Now(), fn)
end

function Visual.Keep(self: any, thing: any): any
	table.insert(self.Trash, thing)
	return thing
end

function Visual.Vignette(self: any, transparency: number, seconds: number?, color: Color3?)
	self.VignetteOn = true
	FX.Vignette(transparency, seconds, color)
end

function Visual.VignetteOff(self: any, seconds: number?)
	if self.VignetteOn then
		self.VignetteOn = false
		FX.VignetteOff(seconds)
	end
end

function Visual.FOV(self: any, delta: number, seconds: number?)
	self.FovOn = true
	FX.FOV(delta, seconds)
end

function Visual.FOVReset(self: any, seconds: number?)
	if self.FovOn then
		self.FovOn = false
		FX.FOVReset(seconds)
	end
end

function Visual.Tint(self: any): any
	local tint = FX.Tint()
	table.insert(self.Tints, tint)
	return tint
end

function Visual.Rumble(self: any, from: number, to: number, duration: number, roughness: number?, position: Vector3?): (fadeOut: number?) -> ()
	local stop = FX.Rumble(from, to, duration, roughness, position)
	table.insert(self.Rumbles, stop)
	return stop
end

-- the standard "this player got hit" effect (also what the server's K.Strike shows when a visual has no Hit of its own)
function Visual.Hurt(self: any, userId: number, color: Color3?)
	local root = FX.Root(userId)
	if not root then
		return
	end
	local c = color or Colors.Warn
	FX.Burst(root.Position, "Spark", 14, { Color = c })
	FX.Ring(root.Position - Vector3.new(0, 2.8, 0), 0.5, 4.5, 0.3, c)
	FX.Sound("Thud", root.Position, 0.7, 1.3)
	if FX.IsMe(userId) then
		FX.Shake(4, 14, 0.03, 0.35)
		FX.Pulse(Colors.Blood, 0.5, 0.25)
	end
end

local function finishVisual(self: any)
	if not self.Alive then
		return
	end
	self.Alive = false
	if self.Def.Done then
		run(self, "Done", self.Def.Done, self)
	end
	if self.VignetteOn then
		self.VignetteOn = false
		FX.VignetteOff(0.4)
	end
	if self.FovOn then
		self.FovOn = false
		FX.FOVReset(0.4)
	end
	for _, tint in self.Tints do
		tint.Back(0.3)
		tint.Remove(0.35)
	end
	for _, stop in self.Rumbles do
		stop(0.2)
	end
	for index = #self.Trash, 1, -1 do
		local thing = self.Trash[index]
		if typeof(thing) == "Instance" then
			thing:Destroy()
		elseif typeof(thing) == "RBXScriptConnection" then
			thing:Disconnect()
		elseif type(thing) == "function" then
			pcall(thing)
		elseif type(thing) == "table" and type(thing.Destroy) == "function" then
			pcall(thing.Destroy)
		end
	end
	table.clear(self.Trash)
end

-- Tells the event's SERVER script something (a click on one of this visual's buttons, an answer ...). Over there:
--     context.ListenForHits(function(player, ...) end)
-- WHO sent it comes from Roblox, never from the client; everything after that is the client's word, so the server
-- checks it. (The event's name travels in the props: EventUtil.Show puts it there.)
local hitRemote: RemoteEvent? = nil
function Visual.Send(self: any, ...: any)
	local name = self.Props and self.Props.EventName
	if type(name) ~= "string" then
		warnOnce("send" .. tostring(self.Asset), "ServerScriptService > Systems > EventUtil is an OLDER copy than the '" .. tostring(self.Asset) .. "' visual was made for (it sent no EventName), so its buttons do nothing. Install the WHOLE update (drag its .rbxmx in).")
		return
	end
	if not hitRemote then
		local remotes = ReplicatedStorage:FindFirstChild("Remotes")
		local found = remotes and remotes:FindFirstChild("EventHit")
		if found and found:IsA("RemoteEvent") then
			hitRemote = found
		end
	end
	if hitRemote then
		hitRemote:FireServer(name, ...)
	end
end

local RESERVED = { Init = true, Step = true, Done = true }
local DEFAULT_METHODS: { [string]: any } = {
	Hit = function(self: any, userId: number)
		self:Hurt(userId)
	end,
	Outro = function(self: any, seconds: number?)
		FX.FadeOut(self.Inst, seconds or 0.8)
	end,
}

function FX.Module(assets: { [string]: { [string]: any } }): { [string]: any }
	local module: { [string]: any } = {}
	local live: { [Instance]: any } = setmetatable({}, { __mode = "k" }) :: any

	-- The framework asks for a placeholder when there is no model named like the asset in EventAssets:
	-- an empty Model with one invisible root part. Init builds the real thing under it.
	function module.Build(asset: string, _props: any): Instance
		local model = Instance.new("Model")
		model.Name = asset
		local root = FX.Block(model, Vector3.new(1, 1, 1), CFrame.new(), Colors.White, nil, 1)
		root.Name = "Root"
		model.PrimaryPart = root
		return model
	end

	function module.Spawned(inst: Instance, state: any, props: any)
		local asset: string = (type(state) == "table" and type(state.Asset) == "string" and state.Asset) or inst.Name
		local def = assets[asset]
		if not def then
			warnOnce("asset" .. asset, "this event's client module has no visual named '" .. asset .. "'")
			return
		end
		local values: { [string]: any } = if type(props) == "table" then props else {}
		local self = setmetatable({
			Inst = inst, Def = def, Asset = asset, Props = values,
			Origin = if inst:IsA("PVInstance") then inst:GetPivot() else CFrame.new(),
			T0 = tonumber(values.T0) or FX.Now(),
			Alive = true, Trash = {}, Tints = {}, Rumbles = {}, VignetteOn = false, FovOn = false,
		}, Visual)
		live[inst] = self
		inst.Destroying:Once(function()
			finishVisual(self)
		end)
		if def.Init then
			run(self, "Init", def.Init, self, values)
		end
		if self.Alive and def.Step then
			table.insert(stepping, self)
			needStepper()
		end
	end

	function module.Destroyed(inst: Instance, _state: any)
		local self = live[inst]
		if self then
			finishVisual(self)
		end
	end

	local names: { [string]: boolean } = {}
	for name in DEFAULT_METHODS do
		names[name] = true
	end
	for _, def in assets do
		for name, value in def do
			if type(value) == "function" and not RESERVED[name] then
				names[name] = true
			end
		end
	end
	for name in names do
		module[name] = function(inst: Instance, _state: any, ...: any)
			local self = live[inst]
			if not self or not self.Alive then
				return
			end
			local fn = self.Def[name] or DEFAULT_METHODS[name]
			if fn then
				run(self, name, fn, self, ...)
			end
		end
	end
	return module
end

-- how many visuals / flying bits are being animated right now (for testing)
function FX.Busy(): (number, number, boolean)
	return #stepping, #chunks, stepConnection ~= nil
end

---------------------------------------------------------------------
-- Oct 8 2026 (update 3)
---------------------------------------------------------------------

-- An event module's own sound slots. Put your uploaded id in Id; while Id is "" the built-in Roblox sound in
-- Stand plays instead (Stand = "" means silence). The FIRST module that names a slot owns it, so a slot name
-- used by two modules (e.g. "ImpCackle") must get the same id in both.
--   FX.UseSounds({ PhoneRing = { Id = "", Stand = "rbxasset://sounds/electronicpingshort.wav", Speed = 1, Volume = 1 } })
function FX.UseSounds(slots: { [string]: { [string]: any } })
	for name, entry in slots do
		if (FX.Sounds :: any)[name] == nil then
			local id = tostring(entry.Id or "")
			if id == "" then
				id = tostring(entry.Stand or "")
			end
			(FX.Sounds :: any)[name] = { Id = id, Speed = tonumber(entry.Speed) or 1, Volume = tonumber(entry.Volume) or 1 }
			local full = soundId(id)
			if full ~= "" then
				checkSound(full)
			end
		end
	end
end

-- The imp (front = -Z, `at` = between its feet). Parts: <name> (belly), <name>Head, <name>Eye, <name>Horn,
-- <name>ArmL / ArmR, <name>WingL / WingR, <name>Tail, <name>Grin. Pose it with FX.PoseImp.
local IMP_SKIN = Color3.fromRGB(78, 42, 40)
local IMP_DARK = Color3.fromRGB(36, 24, 26)
local IMP_HORN = Color3.fromRGB(176, 164, 136)
local IMP_EYE = Color3.fromRGB(255, 132, 40)
FX.ImpColors = { Skin = IMP_SKIN, Dark = IMP_DARK, Horn = IMP_HORN, Eye = IMP_EYE }

local function impArm(at: CFrame, s: number, side: number, raise: number): CFrame
	return at * CFrame.new(side * s * 0.42, s * 0.92, -s * 0.1) * CFrame.Angles(-raise * 2.7, 0, side * 0.3) * CFrame.new(0, -s * 0.27, 0)
end

local function impWing(at: CFrame, s: number, side: number, flap: number): CFrame
	return at * CFrame.new(side * s * 0.3, s * 1.0, s * 0.3) * CFrame.Angles(0, side * (0.45 + flap * 0.7), 0) * CFrame.new(side * s * 0.28, 0, s * 0.18)
end

function FX.AddImp(rig: Rig, name: string, at: CFrame, size: number)
	local s = size
	rig:Egg(name, Vector3.new(s * 0.86, s * 0.92, s * 0.8), at * CFrame.new(0, s * 0.62, 0.02 * s) * CFrame.Angles(-0.22, 0, 0), IMP_SKIN)
	rig:Egg(name .. "Head", Vector3.new(s * 0.74, s * 0.64, s * 0.68), at * CFrame.new(0, s * 1.28, -s * 0.2), IMP_SKIN)
	rig:Block(name .. "Grin", Vector3.new(s * 0.38, s * 0.05, s * 0.05), at * CFrame.new(0, s * 1.13, -s * 0.52), IMP_EYE, Enum.Material.Neon)
	rig:Line(name .. "Tail", at * Vector3.new(0, s * 0.42, s * 0.36), at * Vector3.new(s * 0.1, s * 0.18, s * 1.0), s * 0.08, IMP_DARK)
	rig:Egg(name .. "TailTip", Vector3.new(s * 0.08, s * 0.24, s * 0.22), at * CFrame.new(s * 0.11, s * 0.18, s * 1.06), IMP_DARK)
	for _, side in { -1, 1 } do
		rig:Add(FX.Ball(rig.Parent, s * 0.15, at.Position, IMP_EYE, Enum.Material.Neon), at * CFrame.new(side * s * 0.16, s * 1.33, -s * 0.5), name .. "Eye")
		rig:Egg(name .. "Horn", Vector3.new(s * 0.14, s * 0.42, s * 0.14), at * CFrame.new(side * s * 0.21, s * 1.64, -s * 0.14) * CFrame.Angles(0.25, 0, side * -0.45), IMP_HORN)
		rig:Egg(name .. "Horn", Vector3.new(s * 0.09, s * 0.28, s * 0.09), at * CFrame.new(side * s * 0.33, s * 1.86, -s * 0.06) * CFrame.Angles(-0.35, 0, side * -1.05), IMP_HORN)
		rig:Egg(name .. "Ear", Vector3.new(s * 0.08, s * 0.16, s * 0.34), at * CFrame.new(side * s * 0.4, s * 1.33, -s * 0.12) * CFrame.Angles(0, side * 0.9, side * 0.3), IMP_SKIN)
		rig:Egg(name .. "Leg", Vector3.new(s * 0.26, s * 0.5, s * 0.28), at * CFrame.new(side * s * 0.24, s * 0.22, 0), IMP_DARK)
		rig:Egg(name .. "Foot", Vector3.new(s * 0.22, s * 0.12, s * 0.36), at * CFrame.new(side * s * 0.26, s * 0.04, -s * 0.08), IMP_DARK)
		rig:Wedge(name .. (if side < 0 then "WingL" else "WingR"), Vector3.new(s * 0.05, s * 0.6, s * 0.62), impWing(at, s, side, 0), IMP_DARK)
		rig:Egg(name .. (if side < 0 then "ArmL" else "ArmR"), Vector3.new(s * 0.17, s * 0.58, s * 0.17), impArm(at, s, side, 0), IMP_SKIN)
	end
end

-- raiseL / raiseR: 0 = arm hanging, 1 = straight up over the head. flap: 0 = wings folded, 1 = spread.
function FX.PoseImp(rig: Rig, name: string, at: CFrame, size: number, raiseL: number, raiseR: number, flap: number?)
	rig:Pose(name .. "ArmL", impArm(at, size, -1, raiseL))
	rig:Pose(name .. "ArmR", impArm(at, size, 1, raiseR))
	local f = flap or 0
	rig:Pose(name .. "WingL", impWing(at, size, -1, f))
	rig:Pose(name .. "WingR", impWing(at, size, 1, f))
end

---------------------------------------------------------------------
-- Oct 10 2026 (update 8): pre-built models and the head warning
---------------------------------------------------------------------

-- A Rig out of a model that already exists. An event's look is made ONCE (a Model under the event's server script
-- in ServerScriptService > Events, which EventSystem copies to ReplicatedStorage > EventAssets > <event id>) and
-- CLONED when the event runs, instead of being built part by part every time (a clone is far cheaper than 50
-- Instance.new calls). Restyle those models in Studio as you like: keep the part NAMES, they are what the code moves.
--   container = the Model / Folder whose parts become the rig's parts, in order, under their own names
--   origin    = what the rig's offsets are measured from (the model's Root part, on the ground, front = -Z)
-- A part with the attribute Twist = true is a cylinder made to stand along Y (FX.CYL), so rig:Pose keeps working.
function FX.RigFrom(container: Instance?, origin: CFrame?): Rig
	local rig = FX.Rig(container)
	if not container then
		return rig
	end
	local base = origin or (if container:IsA("PVInstance") then container:GetPivot() else CFrame.new())
	local inverse = base:Inverse()
	for _, part in container:GetChildren() do
		if part:IsA("BasePart") and part.Name ~= "Root" then
			local offset = inverse * part.CFrame
			local twist: CFrame? = nil
			if part:GetAttribute("Twist") == true then
				twist = CYL
				offset = offset * CYL:Inverse()
			end
			rig:Add(part, offset, part.Name, twist)
		end
	end
	return rig
end

-- A copy of one of an event's models (ReplicatedStorage > EventAssets > <eventId> > <name>), for a visual that needs
-- MORE of something than the one model the framework gave it (every segment of a snake, every spider of a swarm).
-- Its parts are anchored and nothing bumps into them. nil (and one warning) when the model is not there.
function FX.Clone(eventId: string, name: string, parent: Instance?): Model?
	local assets = ReplicatedStorage:FindFirstChild("EventAssets")
	local folder = assets and assets:FindFirstChild(eventId)
	local source = folder and folder:FindFirstChild(name)
	if not (source and source:IsA("Model")) then
		warnOnce("clone" .. eventId .. name, "the model '" .. name .. "' is missing under ServerScriptService > Events > (the " .. eventId .. " event): install the update again")
		return nil
	end
	local copy = source:Clone()
	for _, item in copy:GetDescendants() do
		if item:IsA("BasePart") then
			item.Anchored = true
			item.CanCollide = false
			item.CanQuery = false
			item.CanTouch = false
		end
	end
	copy.Parent = parent
	return copy
end

-- A bendy tube (a tentacle, a tail, a vine) out of a model that already has the pieces: cylinders named Seg1, Seg2 ...
-- and balls named Joint1, Joint2 ... (the knuckle at the far end of each Seg). The model owns the looks; code only
-- says where the tube runs, every frame:
--   local tube = FX.Tube(model)                      -- tube.Count = how many pieces it found
--   tube:Place(i, from, to, thick [, hidden])        -- piece i runs from `from` to `to`, `thick` studs thick
-- hidden = true takes that piece out of sight (under water, not grown yet) until it is placed again.
local Tube = {}
Tube.__index = Tube
export type Tube = typeof(setmetatable({} :: { Segs: { BasePart }, Joints: { BasePart }, Shown: { number }, Hidden: { boolean }, Count: number }, Tube))
local QUARTER = CFrame.Angles(0, math.rad(90), 0) -- (a cylinder lies along its X axis: this turns X onto the way a CFrame looks)

function FX.Tube(model: Instance?): Tube
	local self = setmetatable({ Segs = {}, Joints = {}, Shown = {}, Hidden = {}, Count = 0 }, Tube)
	local index = 1
	while model do
		local seg, joint = model:FindFirstChild("Seg" .. index), model:FindFirstChild("Joint" .. index)
		if not (seg and joint and seg:IsA("BasePart") and joint:IsA("BasePart")) then
			break
		end
		self.Segs[index], self.Joints[index] = seg, joint
		self.Shown[index] = seg.Transparency
		self.Hidden[index] = false
		self.Count = index
		index += 1
	end
	return self
end

function Tube.Place(self: Tube, index: number, from: Vector3, to: Vector3, thick: number, hidden: boolean?)
	local seg, joint = self.Segs[index], self.Joints[index]
	if not seg then
		return
	end
	if hidden then
		if not self.Hidden[index] then
			self.Hidden[index] = true
			seg.Transparency, joint.Transparency = 1, 1
		end
		return
	end
	if self.Hidden[index] then
		self.Hidden[index] = false
		seg.Transparency, joint.Transparency = self.Shown[index], self.Shown[index]
	end
	local t = math.max(thick, MIN_SIZE)
	local length = (to - from).Magnitude
	if length > 0.05 then
		local size = Vector3.new(length + t * 0.2, t, t)
		if (seg.Size - size).Magnitude > 0.02 then
			seg.Size = size
		end
		seg.CFrame = CFrame.lookAt((from + to) / 2, to) * QUARTER
	end
	if math.abs(joint.Size.X - t) > 0.02 then
		joint.Size = Vector3.new(t, t, t)
	end
	joint.CFrame = CFrame.new(to)
end

-- hides (true) or shows (false) the whole tube
function Tube.Hide(self: Tube, hidden: boolean)
	for index = 1, self.Count do
		if self.Hidden[index] ~= hidden then
			self.Hidden[index] = hidden
			local alpha = if hidden then 1 else self.Shown[index]
			self.Segs[index].Transparency, self.Joints[index].Transparency = alpha, alpha
		end
	end
end

-- THE warning over a player's head, for every event that warns one player: your own effect, ReplicatedStorage >
-- Assets > ExclamationWarning (an Attachment full of emitters). It is copied onto their Head, 3 studs up, and
-- emitted once with Utility.Emit (so it follows the "particles off" setting). who = a userId, a Player or a character.
function FX.HeadWarning(who: any, life: number?): Attachment?
	local character: Instance? = nil
	if type(who) == "number" then
		local player = Players:GetPlayerByUserId(who)
		character = player and player.Character
	elseif typeof(who) == "Instance" then
		character = if who:IsA("Player") then who.Character else who
	end
	local head = character and character:FindFirstChild("Head")
	if not (head and head:IsA("BasePart")) then
		return nil
	end
	local assets = ReplicatedStorage:FindFirstChild("Assets")
	local template = assets and assets:FindFirstChild("ExclamationWarning")
	if not (template and template:IsA("Attachment")) then
		warnOnce("headwarning", "ReplicatedStorage > Assets > ExclamationWarning (an Attachment) was not found, so there is no warning over anybody's head")
		return nil
	end
	local mark = template:Clone()
	mark.Name = "HeadWarning"
	mark.Position = Vector3.new(0, 3, 0)
	mark.Parent = head
	util("Emit", mark)
	Debris:AddItem(mark, life or 2)
	return mark
end

---------------------------------------------------------------------
-- Oct 11 2026 (update 12): pre-built GUIs
---------------------------------------------------------------------

-- A copy of one of an event's GUIs on THIS player's screen. Like an event's models, the GUI is made once: a ScreenGui
-- kept under the event's server script (ServerScriptService > Events > <event>), which EventSystem copies to
-- ReplicatedStorage > EventAssets > <eventId>; here it is cloned into the PlayerGui instead of being built instance
-- by instance. Restyle those ScreenGuis in Studio as you like: keep the NAMES of the things in them.
-- There is never more than one copy of the same GUI on the screen. nil (and one warning) when it is not there.
-- Destroy it when you are done: self:Keep(gui) does that when the visual goes.
function FX.Gui(eventId: string, name: string): ScreenGui?
	local assets = ReplicatedStorage:FindFirstChild("EventAssets")
	local folder = assets and assets:FindFirstChild(eventId)
	local source = folder and folder:FindFirstChild(name)
	if not (source and source:IsA("ScreenGui")) then
		warnOnce("gui" .. eventId .. name, "the ScreenGui '" .. name .. "' is missing under ServerScriptService > Events > (the " .. eventId .. " event): install the update again")
		return nil
	end
	local playerGui = localPlayer and localPlayer:FindFirstChildOfClass("PlayerGui")
	if not playerGui then
		return nil
	end
	local old = playerGui:FindFirstChild(name)
	if old then
		old:Destroy()
	end
	local copy = source:Clone()
	copy.Enabled = true
	copy.Parent = playerGui
	return copy
end

return FX
