These are the scripts of Update 22 as plain files, for reading.
TO INSTALL THE UPDATE, DRAG DMP_Oct12_Update22.rbxmx INTO STUDIO. Do not paste these in one by one: the new event
Lantern Procession needs its model Bearer (under its script in the .rbxmx) and its animation BearerWalk (under its
client module), and the events need the shared scripts and the models, and those are only in the .rbxmx. (Updates are
cumulative: Updates 8 to 21 are in it too, Gentle Rain included, except StarterPlayerScripts > TarotClient, which you
edited yourself: your copy is left as it is.)
New in Update 22: ServerScriptService/Events/LanternProcession.lua and ReplicatedStorage/EventClients/procession.lua.
